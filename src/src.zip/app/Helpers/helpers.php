<?php

use App\Models\Content;
use App\Models\MenuMain;
use App\Models\PageSection;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Request;
use App\Models\SettingImage;
use App\Models\Setting;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Storage;

if (!function_exists('is_current_route')) {
    function is_current_route(string $routeName, array $params = []): bool
    {
        return request()->routeIs($routeName)
            && empty(array_diff_assoc($params, request()->route()->parameters()));
    }
}

if (!function_exists('setting')) {
    function setting(string $key, ?string $locale = null)
    {
        $locale ??= app()->getLocale();

        $settings = Cache::remember('setting_global', now()->addMinute(5),function () {
            return Setting::first();
        });
        $property = $settings?->toArray();
        return isset($property['title'][$locale]) ? $property['title'][$locale] : '';
    }
}
if (!function_exists('settingImageMain')) {
    function settingImageMain()
    {

        $settings = Cache::remember('setting_global_image', now()->addMinute(5),function () {
            return SettingImage::where('main',true)->first();
        });
        return $settings ? url(Storage::url($settings->image)) : null;
    }
}

if (!function_exists('sectionValue')) {
    function sectionValue($item, string $key, $default = null)
    {

        return data_get($item, "content.$key", $default);
    }
}

if (!function_exists('sectionValue_at')) {
    function sectionValue_at(Collection $items, int $index, string $key, $default = null)
    {
        if (!$items->has($index)) {
            return $default;
        }

        return data_get($items->get($index), "content.$key", $default);
    }
}
if (!function_exists('sectionImages')) {

    function sectionImages($item, ?bool $main = null)
    {
        if (!isset($item->images)) {
            return $main === true ? null : [];
        }

        $query = $item->images();

        if ($main === true) {
            $image = $query->where('main', true)->first();
            return $image ? Storage::url($image->image) : null;
        }

        $images = $main === false
            ? $query->where('main', false)->get()
            : $query->get();

        return $images->map(fn($img) => Storage::url($img->image))->toArray();
    }
}

if (!function_exists('menuSections')) {

        function menuSections($menu, $limit = null, $order = true, $onlyparents = false)
        {
            if (is_bool($limit)) {
                $order = $limit;
                $limit = null;
            }

            if (is_numeric($menu)) {
                $menu = MenuMain::with('children')->find(id: $menu);
                if (!$menu) {
                    return collect();
                }
            }

            $sections = collect();
            $orderDirection = $order ? 'desc' : 'asc';
            if ($onlyparents) {
                $query = PageSection::with(['children', 'translations', 'images'])
                    ->where('menu_main_id', $menu->id)->whereNull('parent_id')
                    ->orderBy('sort_order', $orderDirection);
                      if (is_numeric($limit)) {
                        $query->limit($limit);
                    }
                    $sections = $query->get();
            } else {
                if ($menu->children->isNotEmpty()) {
                    $query = PageSection::with(['children', 'translations', 'images'])
                        ->whereIn('menu_main_id', $menu->children->pluck('id'))
                        ->orderBy('sort_order', $orderDirection);

                    if (is_numeric($limit)) {
                        $query->limit($limit);
                    }

                    $sections = $query->get();
                }

                if ($sections->isEmpty()) {
                    $query = PageSection::with(['children', 'translations', 'images'])
                        ->where('menu_main_id', $menu->id)
                        ->orderBy('sort_order', $orderDirection);

                    if (is_numeric($limit)) {
                        $query->limit($limit);
                    }

                    $sections = $query->get();
                }
            }


            return $sections;
        }

}
if (!function_exists('menuSection')) {

    function menuSection($menu)
    {
        if (is_numeric($menu)) {
            $menu = MenuMain::find($menu);
        }

        return $menu ?? null;
    }
}


if (!function_exists('contentSection')) {

    function contentSection($category)
    {
        $content = Content::where('category',$category)->get();
        return $content ?? null;
    }
}
use Illuminate\Support\Facades\DB;


if (!function_exists('staticValue')) {
    function staticValue(
        string $staticKey,
        string $field = 'title',
        $default = null,
        ?string $locale = null
    ) {
        $locale = $locale ?? app()->getLocale();

        $value = DB::table('content_translations as g')
            ->leftJoin('content_translations as l', function ($join) use ($locale) {
                $join->on('l.content_id', '=', 'g.content_id')
                    ->where('l.locale', '=', $locale);
            })
            ->whereNull('g.locale')
            ->where('g.data->key', $staticKey)
            ->selectRaw("
                COALESCE(
                    l.data->>'$field',
                    g.data->>'$field'
                ) as value
            ")
            ->value('value');

        return $value ?? $default;
    }
}
if (!function_exists('countries')) {
    /**
     * Get all countries optionally localized.
     *
     * @param bool $localized Return localized names if true
     * @return \Illuminate\Support\Collection
     */
    function countries($localized = true)
    {
        $locale = app()->getLocale();

        $all = \App\Models\Country::all();
        if($locale=='uz' || $locale==null ){
            $locale = 'oz';
        }

        if ($localized) {
            return $all->map(function ($country) use ($locale) {
                return [
                    'id' => $country->id,
                    'iso' => $country->iso,
                    'iso3' => $country->iso3,
                    'nicename' => $country->nicename,
                    'phonecode' => $country->phonecode,
                    'name' => $country->name[$locale] ?? $country->name['en'] ?? $country->nicename,
                ];
            });
        }

        return $all;
    }
}
