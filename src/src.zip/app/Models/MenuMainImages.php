<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MenuMainImages extends Model
{
    protected $fillable =[
        'menu_main_id',
        'main'
    ];
}
