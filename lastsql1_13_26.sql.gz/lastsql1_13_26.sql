-- Adminer 5.4.1 PostgreSQL 16.11 dump

DROP DATABASE IF EXISTS "userdb";
CREATE DATABASE "userdb";
\connect "userdb";

DROP TABLE IF EXISTS "cache";
CREATE TABLE "public"."cache" (
    "key" character varying(255) NOT NULL,
    "value" text NOT NULL,
    "expiration" integer NOT NULL,
    CONSTRAINT "cache_pkey" PRIMARY KEY ("key")
)
WITH (oids = false);


DROP TABLE IF EXISTS "cache_locks";
CREATE TABLE "public"."cache_locks" (
    "key" character varying(255) NOT NULL,
    "owner" character varying(255) NOT NULL,
    "expiration" integer NOT NULL,
    CONSTRAINT "cache_locks_pkey" PRIMARY KEY ("key")
)
WITH (oids = false);


DROP TABLE IF EXISTS "content_images";
DROP SEQUENCE IF EXISTS content_images_id_seq;
CREATE SEQUENCE content_images_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "public"."content_images" (
    "id" bigint DEFAULT nextval('content_images_id_seq') NOT NULL,
    "content_id" bigint NOT NULL,
    "image" text,
    "compressed" text,
    "type" character varying(255),
    "size" bigint,
    "main" boolean DEFAULT false NOT NULL,
    "status" boolean DEFAULT true NOT NULL,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    "category" text,
    CONSTRAINT "content_images_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE INDEX content_images_main_index ON public.content_images USING btree (main);


DROP TABLE IF EXISTS "content_settings";
DROP SEQUENCE IF EXISTS content_settings_id_seq;
CREATE SEQUENCE content_settings_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "public"."content_settings" (
    "id" bigint DEFAULT nextval('content_settings_id_seq') NOT NULL,
    "key" character varying(255) NOT NULL,
    "label" character varying(255) NOT NULL,
    "type" character varying(255) NOT NULL,
    "required" boolean DEFAULT true NOT NULL,
    "is_translatable" boolean DEFAULT true NOT NULL,
    "options" json,
    "sort_order" integer DEFAULT '0' NOT NULL,
    "relation" text,
    "status" boolean DEFAULT true NOT NULL,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    "category" text,
    CONSTRAINT "content_settings_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE INDEX content_settings_key_is_translatable_status_sort_order_index ON public.content_settings USING btree (key, is_translatable, status, sort_order);


DROP TABLE IF EXISTS "content_translations";
DROP SEQUENCE IF EXISTS content_translations_id_seq;
CREATE SEQUENCE content_translations_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "public"."content_translations" (
    "id" bigint DEFAULT nextval('content_translations_id_seq') NOT NULL,
    "content_id" bigint NOT NULL,
    "locale" character varying(3),
    "data" jsonb,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    "category" text,
    CONSTRAINT "content_translations_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE INDEX content_translations_locale_index ON public.content_translations USING btree (locale);


DROP TABLE IF EXISTS "contents";
DROP SEQUENCE IF EXISTS contents_id_seq;
CREATE SEQUENCE contents_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "public"."contents" (
    "id" bigint DEFAULT nextval('contents_id_seq') NOT NULL,
    "type" character varying(255) DEFAULT 'category' NOT NULL,
    "slug" text,
    "url" text,
    "test" boolean DEFAULT false NOT NULL,
    "show_admin" boolean DEFAULT true NOT NULL,
    "sort_order" integer DEFAULT '1' NOT NULL,
    "icon" character varying(255),
    "status" boolean DEFAULT true NOT NULL,
    "parent_id" bigint,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    "category" text,
    CONSTRAINT "contents_pkey" PRIMARY KEY ("id"),
    CONSTRAINT "contents_type_check" CHECK (((type)::text = ANY (ARRAY[('category'::character varying)::text, ('page'::character varying)::text, ('url'::character varying)::text, ('section'::character varying)::text])))
)
WITH (oids = false);

CREATE INDEX contents_type_slug_status_sort_order_index ON public.contents USING btree (type, slug, status, sort_order);

TRUNCATE "contents";
INSERT INTO "contents" ("id", "type", "slug", "url", "test", "show_admin", "sort_order", "icon", "status", "parent_id", "created_at", "updated_at", "category") VALUES
(1,	'category',	NULL,	NULL,	'0',	'1',	1,	NULL,	'1',	NULL,	'2025-12-29 11:28:37',	'2026-01-08 12:16:36',	'list'),
(2,	'category',	NULL,	NULL,	'0',	'1',	1,	NULL,	'1',	NULL,	'2025-12-29 11:34:12',	'2026-01-08 12:16:36',	'list'),
(3,	'category',	NULL,	NULL,	'0',	'1',	1,	NULL,	'1',	NULL,	'2025-12-29 11:34:55',	'2026-01-08 12:16:36',	'list'),
(4,	'category',	NULL,	NULL,	'0',	'1',	1,	NULL,	'1',	NULL,	'2025-12-29 11:36:08',	'2026-01-08 12:16:36',	'list'),
(5,	'category',	NULL,	NULL,	'0',	'1',	1,	NULL,	'1',	NULL,	'2025-12-29 11:37:26',	'2026-01-08 12:16:36',	'list'),
(6,	'category',	NULL,	NULL,	'0',	'1',	1,	NULL,	'1',	NULL,	'2025-12-29 13:28:11',	'2026-01-08 12:16:36',	'list'),
(7,	'category',	NULL,	NULL,	'0',	'1',	1,	NULL,	'1',	NULL,	'2026-01-05 06:08:08',	'2026-01-08 12:16:36',	'list'),
(8,	'category',	NULL,	NULL,	'0',	'1',	1,	NULL,	'1',	NULL,	'2026-01-05 06:08:54',	'2026-01-08 12:16:36',	'list'),
(9,	'category',	NULL,	NULL,	'0',	'1',	1,	NULL,	'1',	NULL,	'2026-01-05 06:09:45',	'2026-01-08 12:16:36',	'list'),
(10,	'category',	NULL,	NULL,	'0',	'1',	1,	NULL,	'1',	NULL,	'2026-01-05 06:10:28',	'2026-01-08 12:16:36',	'list'),
(11,	'category',	NULL,	NULL,	'0',	'1',	1,	NULL,	'1',	NULL,	'2026-01-05 06:11:20',	'2026-01-08 12:16:36',	'list'),
(12,	'category',	NULL,	NULL,	'0',	'1',	1,	NULL,	'1',	NULL,	'2026-01-05 06:12:41',	'2026-01-08 12:16:36',	'list'),
(13,	'category',	NULL,	NULL,	'0',	'1',	1,	NULL,	'1',	NULL,	'2026-01-05 06:13:52',	'2026-01-08 12:16:36',	'list'),
(14,	'category',	NULL,	NULL,	'0',	'1',	1,	NULL,	'1',	NULL,	'2026-01-05 06:15:07',	'2026-01-08 12:16:36',	'list'),
(15,	'category',	NULL,	NULL,	'0',	'1',	1,	NULL,	'1',	NULL,	'2026-01-05 06:16:32',	'2026-01-08 12:16:36',	'list'),
(16,	'category',	NULL,	NULL,	'0',	'1',	1,	NULL,	'1',	NULL,	'2026-01-05 06:17:30',	'2026-01-08 12:16:36',	'list'),
(17,	'category',	NULL,	NULL,	'0',	'1',	1,	NULL,	'1',	NULL,	'2026-01-05 06:18:28',	'2026-01-08 12:16:36',	'list'),
(18,	'category',	NULL,	NULL,	'0',	'1',	1,	NULL,	'1',	NULL,	'2026-01-05 06:19:15',	'2026-01-08 12:16:36',	'list'),
(19,	'category',	NULL,	NULL,	'0',	'1',	1,	NULL,	'1',	NULL,	'2026-01-05 06:20:38',	'2026-01-08 12:16:36',	'list'),
(20,	'category',	NULL,	NULL,	'0',	'1',	1,	NULL,	'1',	NULL,	'2026-01-05 06:21:27',	'2026-01-08 12:16:36',	'list'),
(21,	'category',	NULL,	NULL,	'0',	'1',	1,	NULL,	'1',	NULL,	'2026-01-05 06:43:23',	'2026-01-08 12:16:36',	'list'),
(22,	'category',	NULL,	NULL,	'0',	'1',	1,	NULL,	'1',	NULL,	'2026-01-05 06:54:59',	'2026-01-08 12:16:36',	'list'),
(23,	'category',	NULL,	NULL,	'0',	'1',	1,	NULL,	'1',	NULL,	'2026-01-05 06:57:49',	'2026-01-08 12:16:36',	'list'),
(24,	'category',	NULL,	NULL,	'0',	'1',	1,	NULL,	'1',	NULL,	'2026-01-05 06:58:49',	'2026-01-08 12:16:36',	'list'),
(33,	'category',	NULL,	NULL,	'0',	'1',	1,	NULL,	'1',	NULL,	'2026-01-09 03:53:25',	'2026-01-09 03:53:25',	'job'),
(27,	'category',	NULL,	NULL,	'0',	'1',	1,	NULL,	'1',	NULL,	'2026-01-08 14:16:27',	'2026-01-08 14:16:27',	'job'),
(28,	'category',	NULL,	NULL,	'0',	'1',	1,	NULL,	'1',	NULL,	'2026-01-08 14:33:53',	'2026-01-08 14:33:53',	'job'),
(29,	'category',	NULL,	NULL,	'0',	'1',	1,	NULL,	'1',	NULL,	'2026-01-09 01:55:40',	'2026-01-09 01:55:40',	'job'),
(34,	'category',	NULL,	NULL,	'0',	'1',	1,	NULL,	'1',	NULL,	'2026-01-12 12:51:22',	'2026-01-12 12:51:22',	'job'),
(35,	'category',	NULL,	NULL,	'0',	'1',	1,	NULL,	'1',	NULL,	'2026-01-13 06:58:18',	'2026-01-13 06:58:18',	'list');

DROP TABLE IF EXISTS "failed_jobs";
DROP SEQUENCE IF EXISTS failed_jobs_id_seq;
CREATE SEQUENCE failed_jobs_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "public"."failed_jobs" (
    "id" bigint DEFAULT nextval('failed_jobs_id_seq') NOT NULL,
    "uuid" character varying(255) NOT NULL,
    "connection" text NOT NULL,
    "queue" text NOT NULL,
    "payload" text NOT NULL,
    "exception" text NOT NULL,
    "failed_at" timestamp(0) DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT "failed_jobs_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE UNIQUE INDEX failed_jobs_uuid_unique ON public.failed_jobs USING btree (uuid);


DROP TABLE IF EXISTS "form_images";
DROP SEQUENCE IF EXISTS form_images_id_seq;
CREATE SEQUENCE form_images_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "public"."form_images" (
    "id" bigint DEFAULT nextval('form_images_id_seq') NOT NULL,
    "support_id" bigint,
    "type" character varying(255),
    "size" bigint,
    "image" text,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "form_images_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);


DROP TABLE IF EXISTS "job_batches";
CREATE TABLE "public"."job_batches" (
    "id" character varying(255) NOT NULL,
    "name" character varying(255) NOT NULL,
    "total_jobs" integer NOT NULL,
    "pending_jobs" integer NOT NULL,
    "failed_jobs" integer NOT NULL,
    "failed_job_ids" text NOT NULL,
    "options" text,
    "cancelled_at" integer,
    "created_at" integer NOT NULL,
    "finished_at" integer,
    CONSTRAINT "job_batches_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);


DROP TABLE IF EXISTS "jobs";
DROP SEQUENCE IF EXISTS jobs_id_seq;
CREATE SEQUENCE jobs_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "public"."jobs" (
    "id" bigint DEFAULT nextval('jobs_id_seq') NOT NULL,
    "queue" character varying(255) NOT NULL,
    "payload" text NOT NULL,
    "attempts" smallint NOT NULL,
    "reserved_at" integer,
    "available_at" integer NOT NULL,
    "created_at" integer NOT NULL,
    CONSTRAINT "jobs_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE INDEX jobs_queue_index ON public.jobs USING btree (queue);


DROP TABLE IF EXISTS "langs";
DROP SEQUENCE IF EXISTS langs_id_seq;
CREATE SEQUENCE langs_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "public"."langs" (
    "id" bigint DEFAULT nextval('langs_id_seq') NOT NULL,
    "code" character varying(10) NOT NULL,
    "name" character varying(50) NOT NULL,
    "is_default" boolean DEFAULT false NOT NULL,
    "status" boolean DEFAULT true NOT NULL,
    "locale" character varying(10),
    "flag_icon" character varying(255),
    "sort_order" bigint DEFAULT '0' NOT NULL,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    "short_name" text,
    CONSTRAINT "langs_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE UNIQUE INDEX langs_code_unique ON public.langs USING btree (code);


DROP TABLE IF EXISTS "menu_main_images";
DROP SEQUENCE IF EXISTS menu_main_images_id_seq;
CREATE SEQUENCE menu_main_images_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "public"."menu_main_images" (
    "id" bigint DEFAULT nextval('menu_main_images_id_seq') NOT NULL,
    "menu_main_id" bigint NOT NULL,
    "image" text,
    "compressed" text,
    "type" character varying(255),
    "size" bigint,
    "main" boolean DEFAULT false NOT NULL,
    "status" boolean DEFAULT true NOT NULL,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "menu_main_images_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE INDEX menu_main_images_main_index ON public.menu_main_images USING btree (main);


DROP TABLE IF EXISTS "menu_main_settings";
DROP SEQUENCE IF EXISTS menu_main_settings_id_seq;
CREATE SEQUENCE menu_main_settings_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "public"."menu_main_settings" (
    "id" bigint DEFAULT nextval('menu_main_settings_id_seq') NOT NULL,
    "key" character varying(255) NOT NULL,
    "label" character varying(255) NOT NULL,
    "type" character varying(255) NOT NULL,
    "required" boolean DEFAULT true NOT NULL,
    "is_translatable" boolean DEFAULT true NOT NULL,
    "options" json,
    "sort_order" integer DEFAULT '0' NOT NULL,
    "relation" text,
    "status" boolean DEFAULT true NOT NULL,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "menu_main_settings_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE INDEX menu_main_settings_key_is_translatable_status_sort_order_index ON public.menu_main_settings USING btree (key, is_translatable, status, sort_order);


DROP TABLE IF EXISTS "menu_main_translations";
DROP SEQUENCE IF EXISTS menu_main_translations_id_seq;
CREATE SEQUENCE menu_main_translations_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "public"."menu_main_translations" (
    "id" bigint DEFAULT nextval('menu_main_translations_id_seq') NOT NULL,
    "menu_main_id" bigint NOT NULL,
    "locale" character varying(3),
    "data" jsonb,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "menu_main_translations_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE INDEX menu_main_translations_locale_index ON public.menu_main_translations USING btree (locale);


DROP TABLE IF EXISTS "menu_mains";
DROP SEQUENCE IF EXISTS menu_mains_id_seq;
CREATE SEQUENCE menu_mains_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "public"."menu_mains" (
    "id" bigint DEFAULT nextval('menu_mains_id_seq') NOT NULL,
    "type" character varying(255) DEFAULT 'category' NOT NULL,
    "slug" text,
    "url" text,
    "test" boolean DEFAULT false NOT NULL,
    "show_admin" boolean DEFAULT true NOT NULL,
    "sort_order" integer DEFAULT '1' NOT NULL,
    "icon" character varying(255),
    "status" boolean DEFAULT true NOT NULL,
    "parent_id" bigint,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "menu_mains_pkey" PRIMARY KEY ("id"),
    CONSTRAINT "menu_mains_type_check" CHECK (((type)::text = ANY (ARRAY[('category'::character varying)::text, ('page'::character varying)::text, ('url'::character varying)::text, ('section'::character varying)::text])))
)
WITH (oids = false);

CREATE INDEX menu_mains_type_slug_status_sort_order_index ON public.menu_mains USING btree (type, slug, status, sort_order);


DROP TABLE IF EXISTS "menus";
DROP SEQUENCE IF EXISTS menus_id_seq;
CREATE SEQUENCE menus_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "public"."menus" (
    "id" bigint DEFAULT nextval('menus_id_seq') NOT NULL,
    "title" character varying(255) NOT NULL,
    "status" boolean DEFAULT true NOT NULL,
    "sort_order" bigint DEFAULT '0' NOT NULL,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "menus_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);


DROP TABLE IF EXISTS "migrations";
DROP SEQUENCE IF EXISTS migrations_id_seq;
CREATE SEQUENCE migrations_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1;

CREATE TABLE "public"."migrations" (
    "id" integer DEFAULT nextval('migrations_id_seq') NOT NULL,
    "migration" character varying(255) NOT NULL,
    "batch" integer NOT NULL,
    CONSTRAINT "migrations_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);


DROP TABLE IF EXISTS "order_settings";
DROP SEQUENCE IF EXISTS order_settings_id_seq;
CREATE SEQUENCE order_settings_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "public"."order_settings" (
    "id" bigint DEFAULT nextval('order_settings_id_seq') NOT NULL,
    "menu_main_id" bigint NOT NULL,
    "order" text NOT NULL,
    "status" boolean DEFAULT true NOT NULL,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "order_settings_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);


DROP TABLE IF EXISTS "page_section_images";
DROP SEQUENCE IF EXISTS page_section_images_id_seq;
CREATE SEQUENCE page_section_images_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "public"."page_section_images" (
    "id" bigint DEFAULT nextval('page_section_images_id_seq') NOT NULL,
    "page_section_id" bigint NOT NULL,
    "page_section_parent_id" bigint,
    "category" text,
    "category_slug" text,
    "image" text,
    "compressed" text,
    "type" character varying(255),
    "size" bigint,
    "main" boolean DEFAULT false NOT NULL,
    "status" boolean DEFAULT true NOT NULL,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "page_section_images_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE INDEX page_section_images_main_status_category_category_slug_page_sec ON public.page_section_images USING btree (main, status, category, category_slug, page_section_parent_id, page_section_id);


DROP TABLE IF EXISTS "page_section_settings";
DROP SEQUENCE IF EXISTS page_section_settings_id_seq;
CREATE SEQUENCE page_section_settings_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "public"."page_section_settings" (
    "id" bigint DEFAULT nextval('page_section_settings_id_seq') NOT NULL,
    "menu_main_id" bigint NOT NULL,
    "page_section_parent_id" bigint,
    "category" text,
    "category_slug" text,
    "key" character varying(255) NOT NULL,
    "label" character varying(255) NOT NULL,
    "type" character varying(255) NOT NULL,
    "required" boolean DEFAULT true NOT NULL,
    "is_translatable" boolean DEFAULT true NOT NULL,
    "options" json,
    "sort_order" integer DEFAULT '0' NOT NULL,
    "relation" text,
    "status" boolean DEFAULT true NOT NULL,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "page_section_settings_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE INDEX page_section_settings_key_is_translatable_status_sort_order_cat ON public.page_section_settings USING btree (key, is_translatable, status, sort_order, category, category_slug);


DROP TABLE IF EXISTS "page_section_translations";
DROP SEQUENCE IF EXISTS page_section_translations_id_seq;
CREATE SEQUENCE page_section_translations_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "public"."page_section_translations" (
    "id" bigint DEFAULT nextval('page_section_translations_id_seq') NOT NULL,
    "page_section_id" bigint NOT NULL,
    "page_section_parent_id" bigint,
    "category" text,
    "category_slug" text,
    "locale" character varying(3),
    "data" jsonb,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "page_section_translations_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE INDEX page_section_translations_locale_category_page_section_id_page_ ON public.page_section_translations USING btree (locale, category, page_section_id, page_section_parent_id, category_slug);


DROP TABLE IF EXISTS "page_sections";
DROP SEQUENCE IF EXISTS page_sections_id_seq;
CREATE SEQUENCE page_sections_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "public"."page_sections" (
    "id" bigint DEFAULT nextval('page_sections_id_seq') NOT NULL,
    "menu_main_id" bigint NOT NULL,
    "sort_order" integer DEFAULT '1' NOT NULL,
    "status" boolean DEFAULT true NOT NULL,
    "slug" character varying(255),
    "category" text,
    "category_slug" text,
    "parent_id" bigint,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    "publish_at" timestamp,
    CONSTRAINT "page_sections_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE INDEX page_sections_status_sort_order_menu_main_id_category_category_ ON public.page_sections USING btree (status, sort_order, menu_main_id, category, category_slug, parent_id);


DROP TABLE IF EXISTS "password_reset_tokens";
CREATE TABLE "public"."password_reset_tokens" (
    "email" character varying(255) NOT NULL,
    "token" character varying(255) NOT NULL,
    "created_at" timestamp(0),
    CONSTRAINT "password_reset_tokens_pkey" PRIMARY KEY ("email")
)
WITH (oids = false);


DROP TABLE IF EXISTS "permissions";
DROP SEQUENCE IF EXISTS permissions_id_seq;
CREATE SEQUENCE permissions_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "public"."permissions" (
    "id" bigint DEFAULT nextval('permissions_id_seq') NOT NULL,
    "name" character varying(255) NOT NULL,
    "sort_order" bigint DEFAULT '0' NOT NULL,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "permissions_pkey" PRIMARY KEY ("id"),
    CONSTRAINT "permissions_name_check" CHECK (((name)::text = ANY (ARRAY[('given'::character varying)::text, ('not_given'::character varying)::text])))
)
WITH (oids = false);


DROP TABLE IF EXISTS "role_menu_permissions";
DROP SEQUENCE IF EXISTS role_menu_permissions_id_seq;
CREATE SEQUENCE role_menu_permissions_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "public"."role_menu_permissions" (
    "id" bigint DEFAULT nextval('role_menu_permissions_id_seq') NOT NULL,
    "role_id" bigint NOT NULL,
    "menu_main_id" bigint NOT NULL,
    "permission_id" bigint NOT NULL,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "role_menu_permissions_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE INDEX role_menu_permissions_role_id_menu_main_id_permission_id_index ON public.role_menu_permissions USING btree (role_id, menu_main_id, permission_id);


DROP TABLE IF EXISTS "roles";
DROP SEQUENCE IF EXISTS roles_id_seq;
CREATE SEQUENCE roles_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "public"."roles" (
    "id" bigint DEFAULT nextval('roles_id_seq') NOT NULL,
    "name" character varying(255) NOT NULL,
    "sort_order" bigint DEFAULT '0' NOT NULL,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "roles_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);


DROP TABLE IF EXISTS "sessions";
CREATE TABLE "public"."sessions" (
    "id" character varying(255) NOT NULL,
    "user_id" bigint,
    "ip_address" character varying(45),
    "user_agent" text,
    "payload" text NOT NULL,
    "last_activity" integer NOT NULL,
    CONSTRAINT "sessions_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE INDEX sessions_user_id_index ON public.sessions USING btree (user_id);

CREATE INDEX sessions_last_activity_index ON public.sessions USING btree (last_activity);


DROP TABLE IF EXISTS "settings";
DROP SEQUENCE IF EXISTS settings_id_seq;
CREATE SEQUENCE settings_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "public"."settings" (
    "id" bigint DEFAULT nextval('settings_id_seq') NOT NULL,
    "title" jsonb NOT NULL,
    "meta_description" jsonb,
    "meta_keywords" jsonb,
    "email" character varying(255),
    "status" boolean DEFAULT false NOT NULL,
    "main_page_id" bigint,
    "admin_ips" character varying(255),
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    "search_ids" json,
    "sorting_ids" json,
    "bot_token" text,
    "chat_id" text,
    CONSTRAINT "settings_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);


DROP TABLE IF EXISTS "socials";
DROP SEQUENCE IF EXISTS socials_id_seq;
CREATE SEQUENCE socials_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "public"."socials" (
    "id" bigint DEFAULT nextval('socials_id_seq') NOT NULL,
    "name" character varying(255) NOT NULL,
    "icon" character varying(255),
    "url" character varying(255) NOT NULL,
    "key" character varying(255),
    "status" boolean DEFAULT true NOT NULL,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "socials_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);


DROP TABLE IF EXISTS "supports";
DROP SEQUENCE IF EXISTS supports_id_seq;
CREATE SEQUENCE supports_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "public"."supports" (
    "id" bigint DEFAULT nextval('supports_id_seq') NOT NULL,
    "data" jsonb NOT NULL,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    "type" text,
    CONSTRAINT "supports_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);


DROP TABLE IF EXISTS "users";
DROP SEQUENCE IF EXISTS users_id_seq;
CREATE SEQUENCE users_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "public"."users" (
    "id" bigint DEFAULT nextval('users_id_seq') NOT NULL,
    "name" character varying(255) NOT NULL,
    "username" character varying(255) NOT NULL,
    "status" boolean DEFAULT true NOT NULL,
    "password" character varying(255) NOT NULL,
    "role_id" bigint,
    "email" character varying(255),
    "email_verified_at" timestamp(0),
    "remember_token" character varying(100),
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "users_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE UNIQUE INDEX users_username_unique ON public.users USING btree (username);


DROP TABLE IF EXISTS "view_counts";
DROP SEQUENCE IF EXISTS view_counts_id_seq;
CREATE SEQUENCE view_counts_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "public"."view_counts" (
    "id" bigint DEFAULT nextval('view_counts_id_seq') NOT NULL,
    "viewable_type" character varying(255) NOT NULL,
    "viewable_id" bigint NOT NULL,
    "ip_address" character varying(45) NOT NULL,
    "user_agent" text NOT NULL,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "view_counts_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

CREATE INDEX view_counts_viewable_type_viewable_id_index ON public.view_counts USING btree (viewable_type, viewable_id);


ALTER TABLE ONLY "public"."content_images" ADD CONSTRAINT "content_images_content_id_foreign" FOREIGN KEY (content_id) REFERENCES contents(id) NOT DEFERRABLE;

ALTER TABLE ONLY "public"."content_translations" ADD CONSTRAINT "content_translations_content_id_foreign" FOREIGN KEY (content_id) REFERENCES contents(id) ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."contents" ADD CONSTRAINT "contents_parent_id_foreign" FOREIGN KEY (parent_id) REFERENCES contents(id) NOT DEFERRABLE;

ALTER TABLE ONLY "public"."menu_main_images" ADD CONSTRAINT "menu_main_images_menu_main_id_foreign" FOREIGN KEY (menu_main_id) REFERENCES menu_mains(id) NOT DEFERRABLE;

ALTER TABLE ONLY "public"."menu_main_translations" ADD CONSTRAINT "menu_main_translations_menu_main_id_foreign" FOREIGN KEY (menu_main_id) REFERENCES menu_mains(id) ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."menu_mains" ADD CONSTRAINT "menu_mains_parent_id_foreign" FOREIGN KEY (parent_id) REFERENCES menu_mains(id) NOT DEFERRABLE;

ALTER TABLE ONLY "public"."role_menu_permissions" ADD CONSTRAINT "role_menu_permissions_menu_main_id_foreign" FOREIGN KEY (menu_main_id) REFERENCES menu_mains(id) ON DELETE CASCADE NOT DEFERRABLE;
ALTER TABLE ONLY "public"."role_menu_permissions" ADD CONSTRAINT "role_menu_permissions_permission_id_foreign" FOREIGN KEY (permission_id) REFERENCES permissions(id) ON DELETE CASCADE NOT DEFERRABLE;
ALTER TABLE ONLY "public"."role_menu_permissions" ADD CONSTRAINT "role_menu_permissions_role_id_foreign" FOREIGN KEY (role_id) REFERENCES roles(id) ON DELETE CASCADE NOT DEFERRABLE;

-- 2026-01-13 07:10:01 UTC
