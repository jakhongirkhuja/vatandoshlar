--
-- PostgreSQL database dump
--

-- Dumped from database version 16.9 (Ubuntu 16.9-1.pgdg22.04+1)
-- Dumped by pg_dump version 16.9 (Ubuntu 16.9-1.pgdg22.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: cache; Type: TABLE; Schema: public; Owner: vatandoshlar_usr
--

CREATE TABLE public.cache (
    key character varying(255) NOT NULL,
    value text NOT NULL,
    expiration integer NOT NULL
);


ALTER TABLE public.cache OWNER TO vatandoshlar_usr;

--
-- Name: cache_locks; Type: TABLE; Schema: public; Owner: vatandoshlar_usr
--

CREATE TABLE public.cache_locks (
    key character varying(255) NOT NULL,
    owner character varying(255) NOT NULL,
    expiration integer NOT NULL
);


ALTER TABLE public.cache_locks OWNER TO vatandoshlar_usr;

--
-- Name: content_images_id_seq; Type: SEQUENCE; Schema: public; Owner: vatandoshlar_usr
--

CREATE SEQUENCE public.content_images_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.content_images_id_seq OWNER TO vatandoshlar_usr;

--
-- Name: content_images; Type: TABLE; Schema: public; Owner: vatandoshlar_usr
--

CREATE TABLE public.content_images (
    id bigint DEFAULT nextval('public.content_images_id_seq'::regclass) NOT NULL,
    content_id bigint NOT NULL,
    image text,
    compressed text,
    type character varying(255),
    size bigint,
    main boolean DEFAULT false NOT NULL,
    status boolean DEFAULT true NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    category text,
    sort_order bigint
);


ALTER TABLE public.content_images OWNER TO vatandoshlar_usr;

--
-- Name: content_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: vatandoshlar_usr
--

CREATE SEQUENCE public.content_settings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.content_settings_id_seq OWNER TO vatandoshlar_usr;

--
-- Name: content_settings; Type: TABLE; Schema: public; Owner: vatandoshlar_usr
--

CREATE TABLE public.content_settings (
    id bigint DEFAULT nextval('public.content_settings_id_seq'::regclass) NOT NULL,
    key character varying(255) NOT NULL,
    label character varying(255) NOT NULL,
    type character varying(255) NOT NULL,
    required boolean DEFAULT true NOT NULL,
    is_translatable boolean DEFAULT true NOT NULL,
    options json,
    sort_order integer DEFAULT 0 NOT NULL,
    relation text,
    status boolean DEFAULT true NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    category text
);


ALTER TABLE public.content_settings OWNER TO vatandoshlar_usr;

--
-- Name: content_translations_id_seq; Type: SEQUENCE; Schema: public; Owner: vatandoshlar_usr
--

CREATE SEQUENCE public.content_translations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.content_translations_id_seq OWNER TO vatandoshlar_usr;

--
-- Name: content_translations; Type: TABLE; Schema: public; Owner: vatandoshlar_usr
--

CREATE TABLE public.content_translations (
    id bigint DEFAULT nextval('public.content_translations_id_seq'::regclass) NOT NULL,
    content_id bigint NOT NULL,
    locale character varying(3),
    data jsonb,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    category text
);


ALTER TABLE public.content_translations OWNER TO vatandoshlar_usr;

--
-- Name: contents_id_seq; Type: SEQUENCE; Schema: public; Owner: vatandoshlar_usr
--

CREATE SEQUENCE public.contents_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.contents_id_seq OWNER TO vatandoshlar_usr;

--
-- Name: contents; Type: TABLE; Schema: public; Owner: vatandoshlar_usr
--

CREATE TABLE public.contents (
    id bigint DEFAULT nextval('public.contents_id_seq'::regclass) NOT NULL,
    type character varying(255) DEFAULT 'category'::character varying NOT NULL,
    slug text,
    url text,
    test boolean DEFAULT false NOT NULL,
    show_admin boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 1 NOT NULL,
    icon character varying(255),
    status boolean DEFAULT true NOT NULL,
    parent_id bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    category text,
    CONSTRAINT contents_type_check CHECK (((type)::text = ANY (ARRAY[('category'::character varying)::text, ('page'::character varying)::text, ('url'::character varying)::text, ('section'::character varying)::text])))
);


ALTER TABLE public.contents OWNER TO vatandoshlar_usr;

--
-- Name: countries_id_seq; Type: SEQUENCE; Schema: public; Owner: vatandoshlar_usr
--

CREATE SEQUENCE public.countries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.countries_id_seq OWNER TO vatandoshlar_usr;

--
-- Name: countries; Type: TABLE; Schema: public; Owner: vatandoshlar_usr
--

CREATE TABLE public.countries (
    id bigint DEFAULT nextval('public.countries_id_seq'::regclass) NOT NULL,
    name text NOT NULL,
    nicename character varying(255),
    iso character varying(100),
    iso3 character varying(100),
    numcode character varying(100),
    phonecode character varying(100),
    phonemask character varying(255),
    status character varying(255) DEFAULT 'active'::character varying NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT countries_status_check CHECK (((status)::text = ANY (ARRAY[('active'::character varying)::text, ('inactive'::character varying)::text])))
);


ALTER TABLE public.countries OWNER TO vatandoshlar_usr;

--
-- Name: failed_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: vatandoshlar_usr
--

CREATE SEQUENCE public.failed_jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.failed_jobs_id_seq OWNER TO vatandoshlar_usr;

--
-- Name: failed_jobs; Type: TABLE; Schema: public; Owner: vatandoshlar_usr
--

CREATE TABLE public.failed_jobs (
    id bigint DEFAULT nextval('public.failed_jobs_id_seq'::regclass) NOT NULL,
    uuid character varying(255) NOT NULL,
    connection text NOT NULL,
    queue text NOT NULL,
    payload text NOT NULL,
    exception text NOT NULL,
    failed_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.failed_jobs OWNER TO vatandoshlar_usr;

--
-- Name: form_images_id_seq; Type: SEQUENCE; Schema: public; Owner: vatandoshlar_usr
--

CREATE SEQUENCE public.form_images_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.form_images_id_seq OWNER TO vatandoshlar_usr;

--
-- Name: form_images; Type: TABLE; Schema: public; Owner: vatandoshlar_usr
--

CREATE TABLE public.form_images (
    id bigint DEFAULT nextval('public.form_images_id_seq'::regclass) NOT NULL,
    support_id bigint,
    type character varying(255),
    size bigint,
    image text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.form_images OWNER TO vatandoshlar_usr;

--
-- Name: job_batches; Type: TABLE; Schema: public; Owner: vatandoshlar_usr
--

CREATE TABLE public.job_batches (
    id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    total_jobs integer NOT NULL,
    pending_jobs integer NOT NULL,
    failed_jobs integer NOT NULL,
    failed_job_ids text NOT NULL,
    options text,
    cancelled_at integer,
    created_at integer NOT NULL,
    finished_at integer
);


ALTER TABLE public.job_batches OWNER TO vatandoshlar_usr;

--
-- Name: jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: vatandoshlar_usr
--

CREATE SEQUENCE public.jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.jobs_id_seq OWNER TO vatandoshlar_usr;

--
-- Name: jobs; Type: TABLE; Schema: public; Owner: vatandoshlar_usr
--

CREATE TABLE public.jobs (
    id bigint DEFAULT nextval('public.jobs_id_seq'::regclass) NOT NULL,
    queue character varying(255) NOT NULL,
    payload text NOT NULL,
    attempts smallint NOT NULL,
    reserved_at integer,
    available_at integer NOT NULL,
    created_at integer NOT NULL
);


ALTER TABLE public.jobs OWNER TO vatandoshlar_usr;

--
-- Name: lang_images_id_seq; Type: SEQUENCE; Schema: public; Owner: vatandoshlar_usr
--

CREATE SEQUENCE public.lang_images_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.lang_images_id_seq OWNER TO vatandoshlar_usr;

--
-- Name: lang_images; Type: TABLE; Schema: public; Owner: vatandoshlar_usr
--

CREATE TABLE public.lang_images (
    id bigint DEFAULT nextval('public.lang_images_id_seq'::regclass) NOT NULL,
    image text,
    compressed text,
    type character varying(255),
    size bigint,
    main boolean DEFAULT false NOT NULL,
    status boolean DEFAULT true NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    lang_id bigint NOT NULL,
    sort_order bigint
);


ALTER TABLE public.lang_images OWNER TO vatandoshlar_usr;

--
-- Name: langs_id_seq; Type: SEQUENCE; Schema: public; Owner: vatandoshlar_usr
--

CREATE SEQUENCE public.langs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.langs_id_seq OWNER TO vatandoshlar_usr;

--
-- Name: langs; Type: TABLE; Schema: public; Owner: vatandoshlar_usr
--

CREATE TABLE public.langs (
    id bigint DEFAULT nextval('public.langs_id_seq'::regclass) NOT NULL,
    code character varying(10) NOT NULL,
    name character varying(50) NOT NULL,
    is_default boolean DEFAULT false NOT NULL,
    status boolean DEFAULT true NOT NULL,
    locale character varying(10),
    flag_icon character varying(255),
    sort_order bigint DEFAULT '0'::bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    short_name text
);


ALTER TABLE public.langs OWNER TO vatandoshlar_usr;

--
-- Name: menu_main_images_id_seq; Type: SEQUENCE; Schema: public; Owner: vatandoshlar_usr
--

CREATE SEQUENCE public.menu_main_images_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.menu_main_images_id_seq OWNER TO vatandoshlar_usr;

--
-- Name: menu_main_images; Type: TABLE; Schema: public; Owner: vatandoshlar_usr
--

CREATE TABLE public.menu_main_images (
    id bigint DEFAULT nextval('public.menu_main_images_id_seq'::regclass) NOT NULL,
    menu_main_id bigint NOT NULL,
    image text,
    compressed text,
    type character varying(255),
    size bigint,
    main boolean DEFAULT false NOT NULL,
    status boolean DEFAULT true NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    sort_order bigint
);


ALTER TABLE public.menu_main_images OWNER TO vatandoshlar_usr;

--
-- Name: menu_main_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: vatandoshlar_usr
--

CREATE SEQUENCE public.menu_main_settings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.menu_main_settings_id_seq OWNER TO vatandoshlar_usr;

--
-- Name: menu_main_settings; Type: TABLE; Schema: public; Owner: vatandoshlar_usr
--

CREATE TABLE public.menu_main_settings (
    id bigint DEFAULT nextval('public.menu_main_settings_id_seq'::regclass) NOT NULL,
    key character varying(255) NOT NULL,
    label character varying(255) NOT NULL,
    type character varying(255) NOT NULL,
    required boolean DEFAULT true NOT NULL,
    is_translatable boolean DEFAULT true NOT NULL,
    options json,
    sort_order integer DEFAULT 0 NOT NULL,
    relation text,
    status boolean DEFAULT true NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.menu_main_settings OWNER TO vatandoshlar_usr;

--
-- Name: menu_main_translations_id_seq; Type: SEQUENCE; Schema: public; Owner: vatandoshlar_usr
--

CREATE SEQUENCE public.menu_main_translations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.menu_main_translations_id_seq OWNER TO vatandoshlar_usr;

--
-- Name: menu_main_translations; Type: TABLE; Schema: public; Owner: vatandoshlar_usr
--

CREATE TABLE public.menu_main_translations (
    id bigint DEFAULT nextval('public.menu_main_translations_id_seq'::regclass) NOT NULL,
    menu_main_id bigint NOT NULL,
    locale character varying(3),
    data jsonb,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.menu_main_translations OWNER TO vatandoshlar_usr;

--
-- Name: menu_mains_id_seq; Type: SEQUENCE; Schema: public; Owner: vatandoshlar_usr
--

CREATE SEQUENCE public.menu_mains_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.menu_mains_id_seq OWNER TO vatandoshlar_usr;

--
-- Name: menu_mains; Type: TABLE; Schema: public; Owner: vatandoshlar_usr
--

CREATE TABLE public.menu_mains (
    id bigint DEFAULT nextval('public.menu_mains_id_seq'::regclass) NOT NULL,
    type character varying(255) DEFAULT 'category'::character varying NOT NULL,
    slug text,
    url text,
    test boolean DEFAULT false NOT NULL,
    show_admin boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 1 NOT NULL,
    icon character varying(255),
    status boolean DEFAULT true NOT NULL,
    parent_id bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT menu_mains_type_check CHECK (((type)::text = ANY (ARRAY[('category'::character varying)::text, ('page'::character varying)::text, ('url'::character varying)::text, ('section'::character varying)::text])))
);


ALTER TABLE public.menu_mains OWNER TO vatandoshlar_usr;

--
-- Name: menus_id_seq; Type: SEQUENCE; Schema: public; Owner: vatandoshlar_usr
--

CREATE SEQUENCE public.menus_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.menus_id_seq OWNER TO vatandoshlar_usr;

--
-- Name: menus; Type: TABLE; Schema: public; Owner: vatandoshlar_usr
--

CREATE TABLE public.menus (
    id bigint DEFAULT nextval('public.menus_id_seq'::regclass) NOT NULL,
    title character varying(255) NOT NULL,
    status boolean DEFAULT true NOT NULL,
    sort_order bigint DEFAULT '0'::bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.menus OWNER TO vatandoshlar_usr;

--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: vatandoshlar_usr
--

CREATE SEQUENCE public.migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


ALTER SEQUENCE public.migrations_id_seq OWNER TO vatandoshlar_usr;

--
-- Name: migrations; Type: TABLE; Schema: public; Owner: vatandoshlar_usr
--

CREATE TABLE public.migrations (
    id integer DEFAULT nextval('public.migrations_id_seq'::regclass) NOT NULL,
    migration character varying(255) NOT NULL,
    batch integer NOT NULL
);


ALTER TABLE public.migrations OWNER TO vatandoshlar_usr;

--
-- Name: order_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: vatandoshlar_usr
--

CREATE SEQUENCE public.order_settings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.order_settings_id_seq OWNER TO vatandoshlar_usr;

--
-- Name: order_settings; Type: TABLE; Schema: public; Owner: vatandoshlar_usr
--

CREATE TABLE public.order_settings (
    id bigint DEFAULT nextval('public.order_settings_id_seq'::regclass) NOT NULL,
    menu_main_id bigint NOT NULL,
    "order" text NOT NULL,
    status boolean DEFAULT true NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.order_settings OWNER TO vatandoshlar_usr;

--
-- Name: page_section_images_id_seq; Type: SEQUENCE; Schema: public; Owner: vatandoshlar_usr
--

CREATE SEQUENCE public.page_section_images_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.page_section_images_id_seq OWNER TO vatandoshlar_usr;

--
-- Name: page_section_images; Type: TABLE; Schema: public; Owner: vatandoshlar_usr
--

CREATE TABLE public.page_section_images (
    id bigint DEFAULT nextval('public.page_section_images_id_seq'::regclass) NOT NULL,
    page_section_id bigint NOT NULL,
    page_section_parent_id bigint,
    category text,
    category_slug text,
    image text,
    compressed text,
    type character varying(255),
    size bigint,
    main boolean DEFAULT false NOT NULL,
    status boolean DEFAULT true NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    sort_order bigint
);


ALTER TABLE public.page_section_images OWNER TO vatandoshlar_usr;

--
-- Name: page_section_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: vatandoshlar_usr
--

CREATE SEQUENCE public.page_section_settings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.page_section_settings_id_seq OWNER TO vatandoshlar_usr;

--
-- Name: page_section_settings; Type: TABLE; Schema: public; Owner: vatandoshlar_usr
--

CREATE TABLE public.page_section_settings (
    id bigint DEFAULT nextval('public.page_section_settings_id_seq'::regclass) NOT NULL,
    menu_main_id bigint NOT NULL,
    page_section_parent_id bigint,
    category text,
    category_slug text,
    key character varying(255) NOT NULL,
    label character varying(255) NOT NULL,
    type character varying(255) NOT NULL,
    required boolean DEFAULT true NOT NULL,
    is_translatable boolean DEFAULT true NOT NULL,
    options json,
    sort_order integer DEFAULT 0 NOT NULL,
    relation text,
    status boolean DEFAULT true NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.page_section_settings OWNER TO vatandoshlar_usr;

--
-- Name: page_section_translations_id_seq; Type: SEQUENCE; Schema: public; Owner: vatandoshlar_usr
--

CREATE SEQUENCE public.page_section_translations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.page_section_translations_id_seq OWNER TO vatandoshlar_usr;

--
-- Name: page_section_translations; Type: TABLE; Schema: public; Owner: vatandoshlar_usr
--

CREATE TABLE public.page_section_translations (
    id bigint DEFAULT nextval('public.page_section_translations_id_seq'::regclass) NOT NULL,
    page_section_id bigint NOT NULL,
    page_section_parent_id bigint,
    category text,
    category_slug text,
    locale character varying(3),
    data jsonb,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.page_section_translations OWNER TO vatandoshlar_usr;

--
-- Name: page_sections_id_seq; Type: SEQUENCE; Schema: public; Owner: vatandoshlar_usr
--

CREATE SEQUENCE public.page_sections_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.page_sections_id_seq OWNER TO vatandoshlar_usr;

--
-- Name: page_sections; Type: TABLE; Schema: public; Owner: vatandoshlar_usr
--

CREATE TABLE public.page_sections (
    id bigint DEFAULT nextval('public.page_sections_id_seq'::regclass) NOT NULL,
    menu_main_id bigint NOT NULL,
    sort_order integer DEFAULT 1 NOT NULL,
    status boolean DEFAULT true NOT NULL,
    slug character varying(255),
    category text,
    category_slug text,
    parent_id bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    publish_at timestamp without time zone
);


ALTER TABLE public.page_sections OWNER TO vatandoshlar_usr;

--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: vatandoshlar_usr
--

CREATE TABLE public.password_reset_tokens (
    email character varying(255) NOT NULL,
    token character varying(255) NOT NULL,
    created_at timestamp(0) without time zone
);


ALTER TABLE public.password_reset_tokens OWNER TO vatandoshlar_usr;

--
-- Name: permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: vatandoshlar_usr
--

CREATE SEQUENCE public.permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.permissions_id_seq OWNER TO vatandoshlar_usr;

--
-- Name: permissions; Type: TABLE; Schema: public; Owner: vatandoshlar_usr
--

CREATE TABLE public.permissions (
    id bigint DEFAULT nextval('public.permissions_id_seq'::regclass) NOT NULL,
    name character varying(255) NOT NULL,
    sort_order bigint DEFAULT '0'::bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT permissions_name_check CHECK (((name)::text = ANY (ARRAY[('given'::character varying)::text, ('not_given'::character varying)::text])))
);


ALTER TABLE public.permissions OWNER TO vatandoshlar_usr;

--
-- Name: role_menu_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: vatandoshlar_usr
--

CREATE SEQUENCE public.role_menu_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.role_menu_permissions_id_seq OWNER TO vatandoshlar_usr;

--
-- Name: role_menu_permissions; Type: TABLE; Schema: public; Owner: vatandoshlar_usr
--

CREATE TABLE public.role_menu_permissions (
    id bigint DEFAULT nextval('public.role_menu_permissions_id_seq'::regclass) NOT NULL,
    role_id bigint NOT NULL,
    menu_main_id bigint NOT NULL,
    permission_id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.role_menu_permissions OWNER TO vatandoshlar_usr;

--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: vatandoshlar_usr
--

CREATE SEQUENCE public.roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.roles_id_seq OWNER TO vatandoshlar_usr;

--
-- Name: roles; Type: TABLE; Schema: public; Owner: vatandoshlar_usr
--

CREATE TABLE public.roles (
    id bigint DEFAULT nextval('public.roles_id_seq'::regclass) NOT NULL,
    name character varying(255) NOT NULL,
    sort_order bigint DEFAULT '0'::bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    status boolean DEFAULT true NOT NULL
);


ALTER TABLE public.roles OWNER TO vatandoshlar_usr;

--
-- Name: sessions; Type: TABLE; Schema: public; Owner: vatandoshlar_usr
--

CREATE TABLE public.sessions (
    id character varying(255) NOT NULL,
    user_id bigint,
    ip_address character varying(45),
    user_agent text,
    payload text NOT NULL,
    last_activity integer NOT NULL
);


ALTER TABLE public.sessions OWNER TO vatandoshlar_usr;

--
-- Name: setting_images_id_seq; Type: SEQUENCE; Schema: public; Owner: vatandoshlar_usr
--

CREATE SEQUENCE public.setting_images_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.setting_images_id_seq OWNER TO vatandoshlar_usr;

--
-- Name: setting_images; Type: TABLE; Schema: public; Owner: vatandoshlar_usr
--

CREATE TABLE public.setting_images (
    id bigint DEFAULT nextval('public.setting_images_id_seq'::regclass) NOT NULL,
    setting_id bigint NOT NULL,
    image text,
    compressed text,
    type character varying(255),
    size bigint,
    main boolean DEFAULT false NOT NULL,
    status boolean DEFAULT true NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    sort_order bigint
);


ALTER TABLE public.setting_images OWNER TO vatandoshlar_usr;

--
-- Name: settings_id_seq; Type: SEQUENCE; Schema: public; Owner: vatandoshlar_usr
--

CREATE SEQUENCE public.settings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.settings_id_seq OWNER TO vatandoshlar_usr;

--
-- Name: settings; Type: TABLE; Schema: public; Owner: vatandoshlar_usr
--

CREATE TABLE public.settings (
    id bigint DEFAULT nextval('public.settings_id_seq'::regclass) NOT NULL,
    title jsonb NOT NULL,
    meta_description jsonb,
    meta_keywords jsonb,
    email character varying(255),
    status boolean DEFAULT false NOT NULL,
    main_page_id bigint,
    admin_ips character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    search_ids json,
    sorting_ids json,
    bot_token text,
    chat_id text,
    week_short jsonb,
    week_long jsonb,
    month_long jsonb,
    month_short jsonb,
    default_lang text
);


ALTER TABLE public.settings OWNER TO vatandoshlar_usr;

--
-- Name: socials_id_seq; Type: SEQUENCE; Schema: public; Owner: vatandoshlar_usr
--

CREATE SEQUENCE public.socials_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.socials_id_seq OWNER TO vatandoshlar_usr;

--
-- Name: socials; Type: TABLE; Schema: public; Owner: vatandoshlar_usr
--

CREATE TABLE public.socials (
    id bigint DEFAULT nextval('public.socials_id_seq'::regclass) NOT NULL,
    name character varying(255) NOT NULL,
    icon character varying(255),
    url character varying(255) NOT NULL,
    key character varying(255),
    status boolean DEFAULT true NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.socials OWNER TO vatandoshlar_usr;

--
-- Name: supports_id_seq; Type: SEQUENCE; Schema: public; Owner: vatandoshlar_usr
--

CREATE SEQUENCE public.supports_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.supports_id_seq OWNER TO vatandoshlar_usr;

--
-- Name: supports; Type: TABLE; Schema: public; Owner: vatandoshlar_usr
--

CREATE TABLE public.supports (
    id bigint DEFAULT nextval('public.supports_id_seq'::regclass) NOT NULL,
    data jsonb NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    type text,
    user_id bigint,
    chat_id text
);


ALTER TABLE public.supports OWNER TO vatandoshlar_usr;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: vatandoshlar_usr
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO vatandoshlar_usr;

--
-- Name: users; Type: TABLE; Schema: public; Owner: vatandoshlar_usr
--

CREATE TABLE public.users (
    id bigint DEFAULT nextval('public.users_id_seq'::regclass) NOT NULL,
    name character varying(255) NOT NULL,
    username character varying(255) NOT NULL,
    status boolean DEFAULT true NOT NULL,
    password character varying(255) NOT NULL,
    role_id bigint,
    email character varying(255),
    email_verified_at timestamp(0) without time zone,
    remember_token character varying(100),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.users OWNER TO vatandoshlar_usr;

--
-- Name: view_counts_id_seq; Type: SEQUENCE; Schema: public; Owner: vatandoshlar_usr
--

CREATE SEQUENCE public.view_counts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.view_counts_id_seq OWNER TO vatandoshlar_usr;

--
-- Name: view_counts; Type: TABLE; Schema: public; Owner: vatandoshlar_usr
--

CREATE TABLE public.view_counts (
    id bigint DEFAULT nextval('public.view_counts_id_seq'::regclass) NOT NULL,
    viewable_type character varying(255) NOT NULL,
    viewable_id bigint NOT NULL,
    ip_address character varying(45) NOT NULL,
    user_agent text NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    page_section_created_at timestamp without time zone
);


ALTER TABLE public.view_counts OWNER TO vatandoshlar_usr;

--
-- Data for Name: cache; Type: TABLE DATA; Schema: public; Owner: vatandoshlar_usr
--

COPY public.cache (key, value, expiration) FROM stdin;
laravel-cache-setting_global	TzoxODoiQXBwXE1vZGVsc1xTZXR0aW5nIjozMzp7czoxMzoiACoAY29ubmVjdGlvbiI7czo1OiJwZ3NxbCI7czo4OiIAKgB0YWJsZSI7czo4OiJzZXR0aW5ncyI7czoxMzoiACoAcHJpbWFyeUtleSI7czoyOiJpZCI7czoxMDoiACoAa2V5VHlwZSI7czozOiJpbnQiO3M6MTI6ImluY3JlbWVudGluZyI7YjoxO3M6NzoiACoAd2l0aCI7YTowOnt9czoxMjoiACoAd2l0aENvdW50IjthOjA6e31zOjE5OiJwcmV2ZW50c0xhenlMb2FkaW5nIjtiOjA7czoxMDoiACoAcGVyUGFnZSI7aToxNTtzOjY6ImV4aXN0cyI7YjoxO3M6MTg6Indhc1JlY2VudGx5Q3JlYXRlZCI7YjowO3M6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDtzOjEzOiIAKgBhdHRyaWJ1dGVzIjthOjE4OntzOjI6ImlkIjtpOjE7czo1OiJ0aXRsZSI7czoxMDU6InsiZW4iOiAiVmF0YW5kb3NobGFyIGphbW9hdCBmb25kaSIsICJydSI6ICJWYXRhbmRvc2hsYXIgamFtb2F0IGZvbmRpIiwgInV6IjogIlZhdGFuZG9zaGxhciBqYW1vYXQgZm9uZGkifSI7czoxNjoibWV0YV9kZXNjcmlwdGlvbiI7czo2NDoieyJlbiI6IG51bGwsICJydSI6ICJQcm9FbmQiLCAidXoiOiAiVmF0YW5kb3NobGFyIGphbW9hdCBmb25kaTIifSI7czoxMzoibWV0YV9rZXl3b3JkcyI7czo2MDoieyJlbiI6IG51bGwsICJydSI6ICJQcm9FbmQsIFByb0VuZCIsICJ1eiI6ICJQcm9FbmQsIFByb0VuZCJ9IjtzOjU6ImVtYWlsIjtOO3M6Njoic3RhdHVzIjtiOjA7czoxMjoibWFpbl9wYWdlX2lkIjtpOjM4O3M6OToiYWRtaW5faXBzIjtOO3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjUtMTItMjAgMTU6MjI6NTIiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDEtMjIgMTU6NDA6MDgiO3M6MTA6InNlYXJjaF9pZHMiO3M6MjA6IlsiNiIsIjE0IiwiMjYiLCIzOCJdIjtzOjExOiJzb3J0aW5nX2lkcyI7czo2OiJbIjI2Il0iO3M6OToiYm90X3Rva2VuIjtOO3M6NzoiY2hhdF9pZCI7TjtzOjEwOiJ3ZWVrX3Nob3J0IjtzOjEzMToieyJlbiI6ICJTdW4sIE1vbiwgVHVlLCBXZWQsIFRodSwgRnJpLCBTYXQiLCAicnUiOiAi0JLRgSwg0J/QvSwg0JLRgiwg0KHRgCwg0KfRgiwg0J/Rgiwg0KHQsSIsICJ1eiI6ICJZYWssIER1LCBTZSwgQ2gsIFBhLCBKdSwgU2hhIn0iO3M6OToid2Vla19sb25nIjtzOjI4MDoieyJlbiI6ICJTdW5kYXksIE1vbmRheSwgVHVlc2RheSwgV2VkbmVzZGF5LCBUaHVyc2RheSwgRnJpZGF5LCBTYXR1cmRheSIsICJydSI6ICLQktC+0YHQutGA0LXRgdC10L3RjNC1LCDQn9C+0L3QtdC00LXQu9GM0L3QuNC6LCDQktGC0L7RgNC90LjQuiwg0KHRgNC10LTQsCwg0KfQtdGC0LLQtdGA0LMsINCf0Y/RgtC90LjRhtCwLCDQodGD0LHQsdC+0YLQsCIsICJ1eiI6ICJZYWtzaGFuYmEsIER1c2hhbmJhLCBTZXNoYW5iYSwgQ2hvcnNoYW5iYSwgUGF5c2hhbmJhLCBKdW1hLCBTaGFuYmEifSI7czoxMDoibW9udGhfbG9uZyI7czozNzE6InsiZW4iOiAiSmFudWFyeSwgRmVicnVhcnksIE1hcmNoLCBBcHJpbCwgTWF5LCBKdW5lLCBKdWx5LCBBdWd1c3QsIFNlcHRlbWJlciwgT2N0b2JlciwgTm92ZW1iZXIsIERlY2VtYmVyIiwgInJ1IjogItCv0L3QstCw0YDRjCwg0KTQtdCy0YDQsNC70YwsINCc0LDRgNGCLCDQkNC/0YDQtdC70YwsINCc0LDQuSwg0JjRjtC90YwsINCY0Y7Qu9GMLCDQkNCy0LPRg9GB0YIsINCh0LXQvdGC0Y/QsdGA0YwsINCe0LrRgtGP0LHRgNGMLCDQndC+0Y/QsdGA0YwsINCU0LXQutCw0LHRgNGMIiwgInV6IjogIllhbnZhciwgRmV2cmFsLCBNYXJ0LCBBcHJlbCwgTWF5LCBJeXVuLCBJeXVsLCBBdmd1c3QsIFNlbnR5YWJyLCBPa3R5YWJyLCBOb3lhYnIsIERla2FiciJ9IjtzOjExOiJtb250aF9zaG9ydCI7czoyNDA6InsiZW4iOiAiSmFuLCBGZWIsIE1hciwgQXByLCBNYXksIEp1biwgSnVsLCBBdWcsIFNlcCwgT2N0LCBOb3YsIERlYyIsICJydSI6ICLQr9C90LIsINCk0LXQsiwg0JzQsNGALCDQkNC/0YAsINCc0LDQuSwg0JjRjtC9LCDQmNGO0LssINCQ0LLQsywg0KHQtdC9LCDQntC60YIsINCd0L7Rjywg0JTQtdC6IiwgInV6IjogIllhbiwgRmV2LCBNYXIsIEFwciwgTWF5LCBJeW4sIEl5bCwgQXZnLCBTZW4sIE9rdCwgTm95LCBEZWsifSI7fXM6MTE6IgAqAG9yaWdpbmFsIjthOjE4OntzOjI6ImlkIjtpOjE7czo1OiJ0aXRsZSI7czoxMDU6InsiZW4iOiAiVmF0YW5kb3NobGFyIGphbW9hdCBmb25kaSIsICJydSI6ICJWYXRhbmRvc2hsYXIgamFtb2F0IGZvbmRpIiwgInV6IjogIlZhdGFuZG9zaGxhciBqYW1vYXQgZm9uZGkifSI7czoxNjoibWV0YV9kZXNjcmlwdGlvbiI7czo2NDoieyJlbiI6IG51bGwsICJydSI6ICJQcm9FbmQiLCAidXoiOiAiVmF0YW5kb3NobGFyIGphbW9hdCBmb25kaTIifSI7czoxMzoibWV0YV9rZXl3b3JkcyI7czo2MDoieyJlbiI6IG51bGwsICJydSI6ICJQcm9FbmQsIFByb0VuZCIsICJ1eiI6ICJQcm9FbmQsIFByb0VuZCJ9IjtzOjU6ImVtYWlsIjtOO3M6Njoic3RhdHVzIjtiOjA7czoxMjoibWFpbl9wYWdlX2lkIjtpOjM4O3M6OToiYWRtaW5faXBzIjtOO3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjUtMTItMjAgMTU6MjI6NTIiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDEtMjIgMTU6NDA6MDgiO3M6MTA6InNlYXJjaF9pZHMiO3M6MjA6IlsiNiIsIjE0IiwiMjYiLCIzOCJdIjtzOjExOiJzb3J0aW5nX2lkcyI7czo2OiJbIjI2Il0iO3M6OToiYm90X3Rva2VuIjtOO3M6NzoiY2hhdF9pZCI7TjtzOjEwOiJ3ZWVrX3Nob3J0IjtzOjEzMToieyJlbiI6ICJTdW4sIE1vbiwgVHVlLCBXZWQsIFRodSwgRnJpLCBTYXQiLCAicnUiOiAi0JLRgSwg0J/QvSwg0JLRgiwg0KHRgCwg0KfRgiwg0J/Rgiwg0KHQsSIsICJ1eiI6ICJZYWssIER1LCBTZSwgQ2gsIFBhLCBKdSwgU2hhIn0iO3M6OToid2Vla19sb25nIjtzOjI4MDoieyJlbiI6ICJTdW5kYXksIE1vbmRheSwgVHVlc2RheSwgV2VkbmVzZGF5LCBUaHVyc2RheSwgRnJpZGF5LCBTYXR1cmRheSIsICJydSI6ICLQktC+0YHQutGA0LXRgdC10L3RjNC1LCDQn9C+0L3QtdC00LXQu9GM0L3QuNC6LCDQktGC0L7RgNC90LjQuiwg0KHRgNC10LTQsCwg0KfQtdGC0LLQtdGA0LMsINCf0Y/RgtC90LjRhtCwLCDQodGD0LHQsdC+0YLQsCIsICJ1eiI6ICJZYWtzaGFuYmEsIER1c2hhbmJhLCBTZXNoYW5iYSwgQ2hvcnNoYW5iYSwgUGF5c2hhbmJhLCBKdW1hLCBTaGFuYmEifSI7czoxMDoibW9udGhfbG9uZyI7czozNzE6InsiZW4iOiAiSmFudWFyeSwgRmVicnVhcnksIE1hcmNoLCBBcHJpbCwgTWF5LCBKdW5lLCBKdWx5LCBBdWd1c3QsIFNlcHRlbWJlciwgT2N0b2JlciwgTm92ZW1iZXIsIERlY2VtYmVyIiwgInJ1IjogItCv0L3QstCw0YDRjCwg0KTQtdCy0YDQsNC70YwsINCc0LDRgNGCLCDQkNC/0YDQtdC70YwsINCc0LDQuSwg0JjRjtC90YwsINCY0Y7Qu9GMLCDQkNCy0LPRg9GB0YIsINCh0LXQvdGC0Y/QsdGA0YwsINCe0LrRgtGP0LHRgNGMLCDQndC+0Y/QsdGA0YwsINCU0LXQutCw0LHRgNGMIiwgInV6IjogIllhbnZhciwgRmV2cmFsLCBNYXJ0LCBBcHJlbCwgTWF5LCBJeXVuLCBJeXVsLCBBdmd1c3QsIFNlbnR5YWJyLCBPa3R5YWJyLCBOb3lhYnIsIERla2FiciJ9IjtzOjExOiJtb250aF9zaG9ydCI7czoyNDA6InsiZW4iOiAiSmFuLCBGZWIsIE1hciwgQXByLCBNYXksIEp1biwgSnVsLCBBdWcsIFNlcCwgT2N0LCBOb3YsIERlYyIsICJydSI6ICLQr9C90LIsINCk0LXQsiwg0JzQsNGALCDQkNC/0YAsINCc0LDQuSwg0JjRjtC9LCDQmNGO0LssINCQ0LLQsywg0KHQtdC9LCDQntC60YIsINCd0L7Rjywg0JTQtdC6IiwgInV6IjogIllhbiwgRmV2LCBNYXIsIEFwciwgTWF5LCBJeW4sIEl5bCwgQXZnLCBTZW4sIE9rdCwgTm95LCBEZWsifSI7fXM6MTA6IgAqAGNoYW5nZXMiO2E6MDp7fXM6MTE6IgAqAHByZXZpb3VzIjthOjA6e31zOjg6IgAqAGNhc3RzIjthOjEwOntzOjU6InRpdGxlIjtzOjU6ImFycmF5IjtzOjEwOiJzZWFyY2hfaWRzIjtzOjU6ImFycmF5IjtzOjExOiJzb3J0aW5nX2lkcyI7czo1OiJhcnJheSI7czoxNjoibWV0YV9kZXNjcmlwdGlvbiI7czo1OiJhcnJheSI7czoxMzoibWV0YV9rZXl3b3JkcyI7czo1OiJhcnJheSI7czo2OiJzdGF0dXMiO3M6NzoiYm9vbGVhbiI7czoxMDoid2Vla19zaG9ydCI7czo1OiJhcnJheSI7czo5OiJ3ZWVrX2xvbmciO3M6NToiYXJyYXkiO3M6MTA6Im1vbnRoX2xvbmciO3M6NToiYXJyYXkiO3M6MTE6Im1vbnRoX3Nob3J0IjtzOjU6ImFycmF5Ijt9czoxNzoiACoAY2xhc3NDYXN0Q2FjaGUiO2E6MDp7fXM6MjE6IgAqAGF0dHJpYnV0ZUNhc3RDYWNoZSI7YTowOnt9czoxMzoiACoAZGF0ZUZvcm1hdCI7TjtzOjEwOiIAKgBhcHBlbmRzIjthOjA6e31zOjE5OiIAKgBkaXNwYXRjaGVzRXZlbnRzIjthOjA6e31zOjE0OiIAKgBvYnNlcnZhYmxlcyI7YTowOnt9czoxMjoiACoAcmVsYXRpb25zIjthOjA6e31zOjEwOiIAKgB0b3VjaGVzIjthOjA6e31zOjI3OiIAKgByZWxhdGlvbkF1dG9sb2FkQ2FsbGJhY2siO047czoyNjoiACoAcmVsYXRpb25BdXRvbG9hZENvbnRleHQiO047czoxMDoidGltZXN0YW1wcyI7YjoxO3M6MTM6InVzZXNVbmlxdWVJZHMiO2I6MDtzOjk6IgAqAGhpZGRlbiI7YTowOnt9czoxMDoiACoAdmlzaWJsZSI7YTowOnt9czoxMToiACoAZmlsbGFibGUiO2E6MTU6e2k6MDtzOjU6InRpdGxlIjtpOjE7czoxNjoibWV0YV9kZXNjcmlwdGlvbiI7aToyO3M6MTM6Im1ldGFfa2V5d29yZHMiO2k6MztzOjU6ImVtYWlsIjtpOjQ7czo2OiJzdGF0dXMiO2k6NTtzOjEyOiJtYWluX3BhZ2VfaWQiO2k6NjtzOjk6ImFkbWluX2lwcyI7aTo3O3M6MTA6InNlYXJjaF9pZHMiO2k6ODtzOjExOiJzb3J0aW5nX2lkcyI7aTo5O3M6OToiYm90X3Rva2VuIjtpOjEwO3M6NzoiY2hhdF9pZCI7aToxMTtzOjEwOiJ3ZWVrX3Nob3J0IjtpOjEyO3M6OToid2Vla19sb25nIjtpOjEzO3M6MTA6Im1vbnRoX2xvbmciO2k6MTQ7czoxMToibW9udGhfc2hvcnQiO31zOjEwOiIAKgBndWFyZGVkIjthOjE6e2k6MDtzOjE6IioiO319	1769097664
laravel-cache-lang	TzozOToiSWxsdW1pbmF0ZVxEYXRhYmFzZVxFbG9xdWVudFxDb2xsZWN0aW9uIjoyOntzOjg6IgAqAGl0ZW1zIjthOjM6e2k6MDtPOjE1OiJBcHBcTW9kZWxzXExhbmciOjMzOntzOjEzOiIAKgBjb25uZWN0aW9uIjtzOjU6InBnc3FsIjtzOjg6IgAqAHRhYmxlIjtzOjU6ImxhbmdzIjtzOjEzOiIAKgBwcmltYXJ5S2V5IjtzOjI6ImlkIjtzOjEwOiIAKgBrZXlUeXBlIjtzOjM6ImludCI7czoxMjoiaW5jcmVtZW50aW5nIjtiOjE7czo3OiIAKgB3aXRoIjthOjA6e31zOjEyOiIAKgB3aXRoQ291bnQiO2E6MDp7fXM6MTk6InByZXZlbnRzTGF6eUxvYWRpbmciO2I6MDtzOjEwOiIAKgBwZXJQYWdlIjtpOjE1O3M6NjoiZXhpc3RzIjtiOjE7czoxODoid2FzUmVjZW50bHlDcmVhdGVkIjtiOjA7czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO3M6MTM6IgAqAGF0dHJpYnV0ZXMiO2E6Mzp7czoyOiJpZCI7aToyO3M6NDoiY29kZSI7czoyOiJ1eiI7czoxMDoic2hvcnRfbmFtZSI7czo0OiJPJ3piIjt9czoxMToiACoAb3JpZ2luYWwiO2E6Mzp7czoyOiJpZCI7aToyO3M6NDoiY29kZSI7czoyOiJ1eiI7czoxMDoic2hvcnRfbmFtZSI7czo0OiJPJ3piIjt9czoxMDoiACoAY2hhbmdlcyI7YTowOnt9czoxMToiACoAcHJldmlvdXMiO2E6MDp7fXM6ODoiACoAY2FzdHMiO2E6MDp7fXM6MTc6IgAqAGNsYXNzQ2FzdENhY2hlIjthOjA6e31zOjIxOiIAKgBhdHRyaWJ1dGVDYXN0Q2FjaGUiO2E6MDp7fXM6MTM6IgAqAGRhdGVGb3JtYXQiO047czoxMDoiACoAYXBwZW5kcyI7YTowOnt9czoxOToiACoAZGlzcGF0Y2hlc0V2ZW50cyI7YTowOnt9czoxNDoiACoAb2JzZXJ2YWJsZXMiO2E6MDp7fXM6MTI6IgAqAHJlbGF0aW9ucyI7YToxOntzOjY6ImltYWdlcyI7TzozOToiSWxsdW1pbmF0ZVxEYXRhYmFzZVxFbG9xdWVudFxDb2xsZWN0aW9uIjoyOntzOjg6IgAqAGl0ZW1zIjthOjE6e2k6MDtPOjIwOiJBcHBcTW9kZWxzXExhbmdJbWFnZSI6MzM6e3M6MTM6IgAqAGNvbm5lY3Rpb24iO3M6NToicGdzcWwiO3M6ODoiACoAdGFibGUiO3M6MTE6ImxhbmdfaW1hZ2VzIjtzOjEzOiIAKgBwcmltYXJ5S2V5IjtzOjI6ImlkIjtzOjEwOiIAKgBrZXlUeXBlIjtzOjM6ImludCI7czoxMjoiaW5jcmVtZW50aW5nIjtiOjE7czo3OiIAKgB3aXRoIjthOjA6e31zOjEyOiIAKgB3aXRoQ291bnQiO2E6MDp7fXM6MTk6InByZXZlbnRzTGF6eUxvYWRpbmciO2I6MDtzOjEwOiIAKgBwZXJQYWdlIjtpOjE1O3M6NjoiZXhpc3RzIjtiOjE7czoxODoid2FzUmVjZW50bHlDcmVhdGVkIjtiOjA7czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO3M6MTM6IgAqAGF0dHJpYnV0ZXMiO2E6MTE6e3M6MjoiaWQiO2k6ODtzOjU6ImltYWdlIjtzOjQ5OiJsYW5ncy9hMGRiODQ5YS0xOWE0LTRjYTctOWUwNy1mMmY1ZWMxMDg1ZDQ0ODcucG5nIjtzOjEwOiJjb21wcmVzc2VkIjtOO3M6NDoidHlwZSI7czo5OiJpbWFnZS9wbmciO3M6NDoic2l6ZSI7aTo5OTc2O3M6NDoibWFpbiI7YjoxO3M6Njoic3RhdHVzIjtiOjE7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNi0wMS0xNyAxMDo0NzowOSI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0xNyAxMDo0NzoyMiI7czo3OiJsYW5nX2lkIjtpOjI7czoxMDoic29ydF9vcmRlciI7Tjt9czoxMToiACoAb3JpZ2luYWwiO2E6MTE6e3M6MjoiaWQiO2k6ODtzOjU6ImltYWdlIjtzOjQ5OiJsYW5ncy9hMGRiODQ5YS0xOWE0LTRjYTctOWUwNy1mMmY1ZWMxMDg1ZDQ0ODcucG5nIjtzOjEwOiJjb21wcmVzc2VkIjtOO3M6NDoidHlwZSI7czo5OiJpbWFnZS9wbmciO3M6NDoic2l6ZSI7aTo5OTc2O3M6NDoibWFpbiI7YjoxO3M6Njoic3RhdHVzIjtiOjE7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNi0wMS0xNyAxMDo0NzowOSI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0xNyAxMDo0NzoyMiI7czo3OiJsYW5nX2lkIjtpOjI7czoxMDoic29ydF9vcmRlciI7Tjt9czoxMDoiACoAY2hhbmdlcyI7YTowOnt9czoxMToiACoAcHJldmlvdXMiO2E6MDp7fXM6ODoiACoAY2FzdHMiO2E6MDp7fXM6MTc6IgAqAGNsYXNzQ2FzdENhY2hlIjthOjA6e31zOjIxOiIAKgBhdHRyaWJ1dGVDYXN0Q2FjaGUiO2E6MDp7fXM6MTM6IgAqAGRhdGVGb3JtYXQiO047czoxMDoiACoAYXBwZW5kcyI7YTowOnt9czoxOToiACoAZGlzcGF0Y2hlc0V2ZW50cyI7YTowOnt9czoxNDoiACoAb2JzZXJ2YWJsZXMiO2E6MDp7fXM6MTI6IgAqAHJlbGF0aW9ucyI7YTowOnt9czoxMDoiACoAdG91Y2hlcyI7YTowOnt9czoyNzoiACoAcmVsYXRpb25BdXRvbG9hZENhbGxiYWNrIjtOO3M6MjY6IgAqAHJlbGF0aW9uQXV0b2xvYWRDb250ZXh0IjtOO3M6MTA6InRpbWVzdGFtcHMiO2I6MTtzOjEzOiJ1c2VzVW5pcXVlSWRzIjtiOjA7czo5OiIAKgBoaWRkZW4iO2E6MDp7fXM6MTA6IgAqAHZpc2libGUiO2E6MDp7fXM6MTE6IgAqAGZpbGxhYmxlIjthOjE6e2k6MDtzOjQ6Im1haW4iO31zOjEwOiIAKgBndWFyZGVkIjthOjE6e2k6MDtzOjE6IioiO319fXM6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDt9fXM6MTA6IgAqAHRvdWNoZXMiO2E6MDp7fXM6Mjc6IgAqAHJlbGF0aW9uQXV0b2xvYWRDYWxsYmFjayI7TjtzOjI2OiIAKgByZWxhdGlvbkF1dG9sb2FkQ29udGV4dCI7TjtzOjEwOiJ0aW1lc3RhbXBzIjtiOjE7czoxMzoidXNlc1VuaXF1ZUlkcyI7YjowO3M6OToiACoAaGlkZGVuIjthOjA6e31zOjEwOiIAKgB2aXNpYmxlIjthOjA6e31zOjExOiIAKgBmaWxsYWJsZSI7YTo4OntpOjA7czo0OiJjb2RlIjtpOjE7czo0OiJuYW1lIjtpOjI7czoxMDoiaXNfZGVmYXVsdCI7aTozO3M6Njoic3RhdHVzIjtpOjQ7czo2OiJsb2NhbGUiO2k6NTtzOjk6ImZsYWdfaWNvbiI7aTo2O3M6MTA6InNob3J0X25hbWUiO2k6NztzOjEwOiJzb3J0X29yZGVyIjt9czoxMDoiACoAZ3VhcmRlZCI7YToxOntpOjA7czoxOiIqIjt9fWk6MTtPOjE1OiJBcHBcTW9kZWxzXExhbmciOjMzOntzOjEzOiIAKgBjb25uZWN0aW9uIjtzOjU6InBnc3FsIjtzOjg6IgAqAHRhYmxlIjtzOjU6ImxhbmdzIjtzOjEzOiIAKgBwcmltYXJ5S2V5IjtzOjI6ImlkIjtzOjEwOiIAKgBrZXlUeXBlIjtzOjM6ImludCI7czoxMjoiaW5jcmVtZW50aW5nIjtiOjE7czo3OiIAKgB3aXRoIjthOjA6e31zOjEyOiIAKgB3aXRoQ291bnQiO2E6MDp7fXM6MTk6InByZXZlbnRzTGF6eUxvYWRpbmciO2I6MDtzOjEwOiIAKgBwZXJQYWdlIjtpOjE1O3M6NjoiZXhpc3RzIjtiOjE7czoxODoid2FzUmVjZW50bHlDcmVhdGVkIjtiOjA7czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO3M6MTM6IgAqAGF0dHJpYnV0ZXMiO2E6Mzp7czoyOiJpZCI7aTozO3M6NDoiY29kZSI7czoyOiJydSI7czoxMDoic2hvcnRfbmFtZSI7czo2OiLQoNGD0YEiO31zOjExOiIAKgBvcmlnaW5hbCI7YTozOntzOjI6ImlkIjtpOjM7czo0OiJjb2RlIjtzOjI6InJ1IjtzOjEwOiJzaG9ydF9uYW1lIjtzOjY6ItCg0YPRgSI7fXM6MTA6IgAqAGNoYW5nZXMiO2E6MDp7fXM6MTE6IgAqAHByZXZpb3VzIjthOjA6e31zOjg6IgAqAGNhc3RzIjthOjA6e31zOjE3OiIAKgBjbGFzc0Nhc3RDYWNoZSI7YTowOnt9czoyMToiACoAYXR0cmlidXRlQ2FzdENhY2hlIjthOjA6e31zOjEzOiIAKgBkYXRlRm9ybWF0IjtOO3M6MTA6IgAqAGFwcGVuZHMiO2E6MDp7fXM6MTk6IgAqAGRpc3BhdGNoZXNFdmVudHMiO2E6MDp7fXM6MTQ6IgAqAG9ic2VydmFibGVzIjthOjA6e31zOjEyOiIAKgByZWxhdGlvbnMiO2E6MTp7czo2OiJpbWFnZXMiO086Mzk6IklsbHVtaW5hdGVcRGF0YWJhc2VcRWxvcXVlbnRcQ29sbGVjdGlvbiI6Mjp7czo4OiIAKgBpdGVtcyI7YToxOntpOjA7TzoyMDoiQXBwXE1vZGVsc1xMYW5nSW1hZ2UiOjMzOntzOjEzOiIAKgBjb25uZWN0aW9uIjtzOjU6InBnc3FsIjtzOjg6IgAqAHRhYmxlIjtzOjExOiJsYW5nX2ltYWdlcyI7czoxMzoiACoAcHJpbWFyeUtleSI7czoyOiJpZCI7czoxMDoiACoAa2V5VHlwZSI7czozOiJpbnQiO3M6MTI6ImluY3JlbWVudGluZyI7YjoxO3M6NzoiACoAd2l0aCI7YTowOnt9czoxMjoiACoAd2l0aENvdW50IjthOjA6e31zOjE5OiJwcmV2ZW50c0xhenlMb2FkaW5nIjtiOjA7czoxMDoiACoAcGVyUGFnZSI7aToxNTtzOjY6ImV4aXN0cyI7YjoxO3M6MTg6Indhc1JlY2VudGx5Q3JlYXRlZCI7YjowO3M6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDtzOjEzOiIAKgBhdHRyaWJ1dGVzIjthOjExOntzOjI6ImlkIjtpOjk7czo1OiJpbWFnZSI7czo0OToibGFuZ3MvYTBkYjg0YjUtYTI1My00NDFlLWE3ZWMtMmUwZjIzODU0N2YxMzc1LnBuZyI7czoxMDoiY29tcHJlc3NlZCI7TjtzOjQ6InR5cGUiO3M6OToiaW1hZ2UvcG5nIjtzOjQ6InNpemUiO2k6MTc0MztzOjQ6Im1haW4iO2I6MTtzOjY6InN0YXR1cyI7YjoxO3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjYtMDEtMTcgMTA6NDc6MjciO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDEtMTcgMTA6NDc6MzIiO3M6NzoibGFuZ19pZCI7aTozO3M6MTA6InNvcnRfb3JkZXIiO047fXM6MTE6IgAqAG9yaWdpbmFsIjthOjExOntzOjI6ImlkIjtpOjk7czo1OiJpbWFnZSI7czo0OToibGFuZ3MvYTBkYjg0YjUtYTI1My00NDFlLWE3ZWMtMmUwZjIzODU0N2YxMzc1LnBuZyI7czoxMDoiY29tcHJlc3NlZCI7TjtzOjQ6InR5cGUiO3M6OToiaW1hZ2UvcG5nIjtzOjQ6InNpemUiO2k6MTc0MztzOjQ6Im1haW4iO2I6MTtzOjY6InN0YXR1cyI7YjoxO3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjYtMDEtMTcgMTA6NDc6MjciO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDEtMTcgMTA6NDc6MzIiO3M6NzoibGFuZ19pZCI7aTozO3M6MTA6InNvcnRfb3JkZXIiO047fXM6MTA6IgAqAGNoYW5nZXMiO2E6MDp7fXM6MTE6IgAqAHByZXZpb3VzIjthOjA6e31zOjg6IgAqAGNhc3RzIjthOjA6e31zOjE3OiIAKgBjbGFzc0Nhc3RDYWNoZSI7YTowOnt9czoyMToiACoAYXR0cmlidXRlQ2FzdENhY2hlIjthOjA6e31zOjEzOiIAKgBkYXRlRm9ybWF0IjtOO3M6MTA6IgAqAGFwcGVuZHMiO2E6MDp7fXM6MTk6IgAqAGRpc3BhdGNoZXNFdmVudHMiO2E6MDp7fXM6MTQ6IgAqAG9ic2VydmFibGVzIjthOjA6e31zOjEyOiIAKgByZWxhdGlvbnMiO2E6MDp7fXM6MTA6IgAqAHRvdWNoZXMiO2E6MDp7fXM6Mjc6IgAqAHJlbGF0aW9uQXV0b2xvYWRDYWxsYmFjayI7TjtzOjI2OiIAKgByZWxhdGlvbkF1dG9sb2FkQ29udGV4dCI7TjtzOjEwOiJ0aW1lc3RhbXBzIjtiOjE7czoxMzoidXNlc1VuaXF1ZUlkcyI7YjowO3M6OToiACoAaGlkZGVuIjthOjA6e31zOjEwOiIAKgB2aXNpYmxlIjthOjA6e31zOjExOiIAKgBmaWxsYWJsZSI7YToxOntpOjA7czo0OiJtYWluIjt9czoxMDoiACoAZ3VhcmRlZCI7YToxOntpOjA7czoxOiIqIjt9fX1zOjI4OiIAKgBlc2NhcGVXaGVuQ2FzdGluZ1RvU3RyaW5nIjtiOjA7fX1zOjEwOiIAKgB0b3VjaGVzIjthOjA6e31zOjI3OiIAKgByZWxhdGlvbkF1dG9sb2FkQ2FsbGJhY2siO047czoyNjoiACoAcmVsYXRpb25BdXRvbG9hZENvbnRleHQiO047czoxMDoidGltZXN0YW1wcyI7YjoxO3M6MTM6InVzZXNVbmlxdWVJZHMiO2I6MDtzOjk6IgAqAGhpZGRlbiI7YTowOnt9czoxMDoiACoAdmlzaWJsZSI7YTowOnt9czoxMToiACoAZmlsbGFibGUiO2E6ODp7aTowO3M6NDoiY29kZSI7aToxO3M6NDoibmFtZSI7aToyO3M6MTA6ImlzX2RlZmF1bHQiO2k6MztzOjY6InN0YXR1cyI7aTo0O3M6NjoibG9jYWxlIjtpOjU7czo5OiJmbGFnX2ljb24iO2k6NjtzOjEwOiJzaG9ydF9uYW1lIjtpOjc7czoxMDoic29ydF9vcmRlciI7fXM6MTA6IgAqAGd1YXJkZWQiO2E6MTp7aTowO3M6MToiKiI7fX1pOjI7TzoxNToiQXBwXE1vZGVsc1xMYW5nIjozMzp7czoxMzoiACoAY29ubmVjdGlvbiI7czo1OiJwZ3NxbCI7czo4OiIAKgB0YWJsZSI7czo1OiJsYW5ncyI7czoxMzoiACoAcHJpbWFyeUtleSI7czoyOiJpZCI7czoxMDoiACoAa2V5VHlwZSI7czozOiJpbnQiO3M6MTI6ImluY3JlbWVudGluZyI7YjoxO3M6NzoiACoAd2l0aCI7YTowOnt9czoxMjoiACoAd2l0aENvdW50IjthOjA6e31zOjE5OiJwcmV2ZW50c0xhenlMb2FkaW5nIjtiOjA7czoxMDoiACoAcGVyUGFnZSI7aToxNTtzOjY6ImV4aXN0cyI7YjoxO3M6MTg6Indhc1JlY2VudGx5Q3JlYXRlZCI7YjowO3M6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDtzOjEzOiIAKgBhdHRyaWJ1dGVzIjthOjM6e3M6MjoiaWQiO2k6MTtzOjQ6ImNvZGUiO3M6MjoiZW4iO3M6MTA6InNob3J0X25hbWUiO3M6MzoiRW5nIjt9czoxMToiACoAb3JpZ2luYWwiO2E6Mzp7czoyOiJpZCI7aToxO3M6NDoiY29kZSI7czoyOiJlbiI7czoxMDoic2hvcnRfbmFtZSI7czozOiJFbmciO31zOjEwOiIAKgBjaGFuZ2VzIjthOjA6e31zOjExOiIAKgBwcmV2aW91cyI7YTowOnt9czo4OiIAKgBjYXN0cyI7YTowOnt9czoxNzoiACoAY2xhc3NDYXN0Q2FjaGUiO2E6MDp7fXM6MjE6IgAqAGF0dHJpYnV0ZUNhc3RDYWNoZSI7YTowOnt9czoxMzoiACoAZGF0ZUZvcm1hdCI7TjtzOjEwOiIAKgBhcHBlbmRzIjthOjA6e31zOjE5OiIAKgBkaXNwYXRjaGVzRXZlbnRzIjthOjA6e31zOjE0OiIAKgBvYnNlcnZhYmxlcyI7YTowOnt9czoxMjoiACoAcmVsYXRpb25zIjthOjE6e3M6NjoiaW1hZ2VzIjtPOjM5OiJJbGx1bWluYXRlXERhdGFiYXNlXEVsb3F1ZW50XENvbGxlY3Rpb24iOjI6e3M6ODoiACoAaXRlbXMiO2E6MTp7aTowO086MjA6IkFwcFxNb2RlbHNcTGFuZ0ltYWdlIjozMzp7czoxMzoiACoAY29ubmVjdGlvbiI7czo1OiJwZ3NxbCI7czo4OiIAKgB0YWJsZSI7czoxMToibGFuZ19pbWFnZXMiO3M6MTM6IgAqAHByaW1hcnlLZXkiO3M6MjoiaWQiO3M6MTA6IgAqAGtleVR5cGUiO3M6MzoiaW50IjtzOjEyOiJpbmNyZW1lbnRpbmciO2I6MTtzOjc6IgAqAHdpdGgiO2E6MDp7fXM6MTI6IgAqAHdpdGhDb3VudCI7YTowOnt9czoxOToicHJldmVudHNMYXp5TG9hZGluZyI7YjowO3M6MTA6IgAqAHBlclBhZ2UiO2k6MTU7czo2OiJleGlzdHMiO2I6MTtzOjE4OiJ3YXNSZWNlbnRseUNyZWF0ZWQiO2I6MDtzOjI4OiIAKgBlc2NhcGVXaGVuQ2FzdGluZ1RvU3RyaW5nIjtiOjA7czoxMzoiACoAYXR0cmlidXRlcyI7YToxMTp7czoyOiJpZCI7aToxMDtzOjU6ImltYWdlIjtzOjQ5OiJsYW5ncy9hMGRiODRjNS01MDliLTQxY2YtYmU1ZS1mOWM4YThlMjIxZjIxMzgucG5nIjtzOjEwOiJjb21wcmVzc2VkIjtOO3M6NDoidHlwZSI7czo5OiJpbWFnZS9wbmciO3M6NDoic2l6ZSI7aToxODE0MjtzOjQ6Im1haW4iO2I6MTtzOjY6InN0YXR1cyI7YjoxO3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjYtMDEtMTcgMTA6NDc6MzgiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDEtMTcgMTA6NDc6NDIiO3M6NzoibGFuZ19pZCI7aToxO3M6MTA6InNvcnRfb3JkZXIiO047fXM6MTE6IgAqAG9yaWdpbmFsIjthOjExOntzOjI6ImlkIjtpOjEwO3M6NToiaW1hZ2UiO3M6NDk6ImxhbmdzL2EwZGI4NGM1LTUwOWItNDFjZi1iZTVlLWY5YzhhOGUyMjFmMjEzOC5wbmciO3M6MTA6ImNvbXByZXNzZWQiO047czo0OiJ0eXBlIjtzOjk6ImltYWdlL3BuZyI7czo0OiJzaXplIjtpOjE4MTQyO3M6NDoibWFpbiI7YjoxO3M6Njoic3RhdHVzIjtiOjE7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNi0wMS0xNyAxMDo0NzozOCI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0xNyAxMDo0Nzo0MiI7czo3OiJsYW5nX2lkIjtpOjE7czoxMDoic29ydF9vcmRlciI7Tjt9czoxMDoiACoAY2hhbmdlcyI7YTowOnt9czoxMToiACoAcHJldmlvdXMiO2E6MDp7fXM6ODoiACoAY2FzdHMiO2E6MDp7fXM6MTc6IgAqAGNsYXNzQ2FzdENhY2hlIjthOjA6e31zOjIxOiIAKgBhdHRyaWJ1dGVDYXN0Q2FjaGUiO2E6MDp7fXM6MTM6IgAqAGRhdGVGb3JtYXQiO047czoxMDoiACoAYXBwZW5kcyI7YTowOnt9czoxOToiACoAZGlzcGF0Y2hlc0V2ZW50cyI7YTowOnt9czoxNDoiACoAb2JzZXJ2YWJsZXMiO2E6MDp7fXM6MTI6IgAqAHJlbGF0aW9ucyI7YTowOnt9czoxMDoiACoAdG91Y2hlcyI7YTowOnt9czoyNzoiACoAcmVsYXRpb25BdXRvbG9hZENhbGxiYWNrIjtOO3M6MjY6IgAqAHJlbGF0aW9uQXV0b2xvYWRDb250ZXh0IjtOO3M6MTA6InRpbWVzdGFtcHMiO2I6MTtzOjEzOiJ1c2VzVW5pcXVlSWRzIjtiOjA7czo5OiIAKgBoaWRkZW4iO2E6MDp7fXM6MTA6IgAqAHZpc2libGUiO2E6MDp7fXM6MTE6IgAqAGZpbGxhYmxlIjthOjE6e2k6MDtzOjQ6Im1haW4iO31zOjEwOiIAKgBndWFyZGVkIjthOjE6e2k6MDtzOjE6IioiO319fXM6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDt9fXM6MTA6IgAqAHRvdWNoZXMiO2E6MDp7fXM6Mjc6IgAqAHJlbGF0aW9uQXV0b2xvYWRDYWxsYmFjayI7TjtzOjI2OiIAKgByZWxhdGlvbkF1dG9sb2FkQ29udGV4dCI7TjtzOjEwOiJ0aW1lc3RhbXBzIjtiOjE7czoxMzoidXNlc1VuaXF1ZUlkcyI7YjowO3M6OToiACoAaGlkZGVuIjthOjA6e31zOjEwOiIAKgB2aXNpYmxlIjthOjA6e31zOjExOiIAKgBmaWxsYWJsZSI7YTo4OntpOjA7czo0OiJjb2RlIjtpOjE7czo0OiJuYW1lIjtpOjI7czoxMDoiaXNfZGVmYXVsdCI7aTozO3M6Njoic3RhdHVzIjtpOjQ7czo2OiJsb2NhbGUiO2k6NTtzOjk6ImZsYWdfaWNvbiI7aTo2O3M6MTA6InNob3J0X25hbWUiO2k6NztzOjEwOiJzb3J0X29yZGVyIjt9czoxMDoiACoAZ3VhcmRlZCI7YToxOntpOjA7czoxOiIqIjt9fX1zOjI4OiIAKgBlc2NhcGVXaGVuQ2FzdGluZ1RvU3RyaW5nIjtiOjA7fQ==	1769097664
laravel-cache-menu	TzozOToiSWxsdW1pbmF0ZVxEYXRhYmFzZVxFbG9xdWVudFxDb2xsZWN0aW9uIjoyOntzOjg6IgAqAGl0ZW1zIjthOjY6e2k6MDtPOjE5OiJBcHBcTW9kZWxzXE1lbnVNYWluIjozNDp7czoxMzoiACoAY29ubmVjdGlvbiI7czo1OiJwZ3NxbCI7czo4OiIAKgB0YWJsZSI7czoxMDoibWVudV9tYWlucyI7czoxMzoiACoAcHJpbWFyeUtleSI7czoyOiJpZCI7czoxMDoiACoAa2V5VHlwZSI7czozOiJpbnQiO3M6MTI6ImluY3JlbWVudGluZyI7YjoxO3M6NzoiACoAd2l0aCI7YTowOnt9czoxMjoiACoAd2l0aENvdW50IjthOjA6e31zOjE5OiJwcmV2ZW50c0xhenlMb2FkaW5nIjtiOjA7czoxMDoiACoAcGVyUGFnZSI7aToxNTtzOjY6ImV4aXN0cyI7YjoxO3M6MTg6Indhc1JlY2VudGx5Q3JlYXRlZCI7YjowO3M6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDtzOjEzOiIAKgBhdHRyaWJ1dGVzIjthOjEyOntzOjI6ImlkIjtpOjU7czo0OiJ0eXBlIjtzOjg6ImNhdGVnb3J5IjtzOjQ6InNsdWciO3M6MTA6Im96YmVraXN0b24iO3M6MzoidXJsIjtOO3M6NDoidGVzdCI7YjowO3M6MTA6InNob3dfYWRtaW4iO2I6MTtzOjEwOiJzb3J0X29yZGVyIjtpOjI7czo0OiJpY29uIjtOO3M6Njoic3RhdHVzIjtiOjE7czo5OiJwYXJlbnRfaWQiO047czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNS0xMi0yMyAwNDo1MTozNSI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMiAxNToxMDozNSI7fXM6MTE6IgAqAG9yaWdpbmFsIjthOjEyOntzOjI6ImlkIjtpOjU7czo0OiJ0eXBlIjtzOjg6ImNhdGVnb3J5IjtzOjQ6InNsdWciO3M6MTA6Im96YmVraXN0b24iO3M6MzoidXJsIjtOO3M6NDoidGVzdCI7YjowO3M6MTA6InNob3dfYWRtaW4iO2I6MTtzOjEwOiJzb3J0X29yZGVyIjtpOjI7czo0OiJpY29uIjtOO3M6Njoic3RhdHVzIjtiOjE7czo5OiJwYXJlbnRfaWQiO047czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNS0xMi0yMyAwNDo1MTozNSI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMiAxNToxMDozNSI7fXM6MTA6IgAqAGNoYW5nZXMiO2E6MDp7fXM6MTE6IgAqAHByZXZpb3VzIjthOjA6e31zOjg6IgAqAGNhc3RzIjthOjA6e31zOjE3OiIAKgBjbGFzc0Nhc3RDYWNoZSI7YTowOnt9czoyMToiACoAYXR0cmlidXRlQ2FzdENhY2hlIjthOjA6e31zOjEzOiIAKgBkYXRlRm9ybWF0IjtOO3M6MTA6IgAqAGFwcGVuZHMiO2E6MDp7fXM6MTk6IgAqAGRpc3BhdGNoZXNFdmVudHMiO2E6MDp7fXM6MTQ6IgAqAG9ic2VydmFibGVzIjthOjA6e31zOjEyOiIAKgByZWxhdGlvbnMiO2E6Mjp7czo5OiJjaGlsZHJlbnMiO086Mzk6IklsbHVtaW5hdGVcRGF0YWJhc2VcRWxvcXVlbnRcQ29sbGVjdGlvbiI6Mjp7czo4OiIAKgBpdGVtcyI7YTo1OntpOjA7TzoxOToiQXBwXE1vZGVsc1xNZW51TWFpbiI6MzQ6e3M6MTM6IgAqAGNvbm5lY3Rpb24iO3M6NToicGdzcWwiO3M6ODoiACoAdGFibGUiO3M6MTA6Im1lbnVfbWFpbnMiO3M6MTM6IgAqAHByaW1hcnlLZXkiO3M6MjoiaWQiO3M6MTA6IgAqAGtleVR5cGUiO3M6MzoiaW50IjtzOjEyOiJpbmNyZW1lbnRpbmciO2I6MTtzOjc6IgAqAHdpdGgiO2E6MDp7fXM6MTI6IgAqAHdpdGhDb3VudCI7YTowOnt9czoxOToicHJldmVudHNMYXp5TG9hZGluZyI7YjowO3M6MTA6IgAqAHBlclBhZ2UiO2k6MTU7czo2OiJleGlzdHMiO2I6MTtzOjE4OiJ3YXNSZWNlbnRseUNyZWF0ZWQiO2I6MDtzOjI4OiIAKgBlc2NhcGVXaGVuQ2FzdGluZ1RvU3RyaW5nIjtiOjA7czoxMzoiACoAYXR0cmlidXRlcyI7YToxMjp7czoyOiJpZCI7aTo2O3M6NDoidHlwZSI7czo0OiJwYWdlIjtzOjQ6InNsdWciO3M6MTA6InV6YmVraXN0YW4iO3M6MzoidXJsIjtOO3M6NDoidGVzdCI7YjowO3M6MTA6InNob3dfYWRtaW4iO2I6MTtzOjEwOiJzb3J0X29yZGVyIjtpOjE7czo0OiJpY29uIjtOO3M6Njoic3RhdHVzIjtiOjE7czo5OiJwYXJlbnRfaWQiO2k6NTtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI1LTEyLTIzIDA0OjUyOjAyIjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIyIDA2OjIzOjUzIjt9czoxMToiACoAb3JpZ2luYWwiO2E6MTI6e3M6MjoiaWQiO2k6NjtzOjQ6InR5cGUiO3M6NDoicGFnZSI7czo0OiJzbHVnIjtzOjEwOiJ1emJla2lzdGFuIjtzOjM6InVybCI7TjtzOjQ6InRlc3QiO2I6MDtzOjEwOiJzaG93X2FkbWluIjtiOjE7czoxMDoic29ydF9vcmRlciI7aToxO3M6NDoiaWNvbiI7TjtzOjY6InN0YXR1cyI7YjoxO3M6OToicGFyZW50X2lkIjtpOjU7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNS0xMi0yMyAwNDo1MjowMiI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMiAwNjoyMzo1MyI7fXM6MTA6IgAqAGNoYW5nZXMiO2E6MDp7fXM6MTE6IgAqAHByZXZpb3VzIjthOjA6e31zOjg6IgAqAGNhc3RzIjthOjA6e31zOjE3OiIAKgBjbGFzc0Nhc3RDYWNoZSI7YTowOnt9czoyMToiACoAYXR0cmlidXRlQ2FzdENhY2hlIjthOjA6e31zOjEzOiIAKgBkYXRlRm9ybWF0IjtOO3M6MTA6IgAqAGFwcGVuZHMiO2E6MDp7fXM6MTk6IgAqAGRpc3BhdGNoZXNFdmVudHMiO2E6MDp7fXM6MTQ6IgAqAG9ic2VydmFibGVzIjthOjA6e31zOjEyOiIAKgByZWxhdGlvbnMiO2E6Mjp7czoxMjoidHJhbnNsYXRpb25zIjtPOjM5OiJJbGx1bWluYXRlXERhdGFiYXNlXEVsb3F1ZW50XENvbGxlY3Rpb24iOjI6e3M6ODoiACoAaXRlbXMiO2E6Mzp7aTowO086MzA6IkFwcFxNb2RlbHNcTWVudU1haW5UcmFuc2xhdGlvbiI6MzM6e3M6MTM6IgAqAGNvbm5lY3Rpb24iO3M6NToicGdzcWwiO3M6ODoiACoAdGFibGUiO3M6MjI6Im1lbnVfbWFpbl90cmFuc2xhdGlvbnMiO3M6MTM6IgAqAHByaW1hcnlLZXkiO3M6MjoiaWQiO3M6MTA6IgAqAGtleVR5cGUiO3M6MzoiaW50IjtzOjEyOiJpbmNyZW1lbnRpbmciO2I6MTtzOjc6IgAqAHdpdGgiO2E6MDp7fXM6MTI6IgAqAHdpdGhDb3VudCI7YTowOnt9czoxOToicHJldmVudHNMYXp5TG9hZGluZyI7YjowO3M6MTA6IgAqAHBlclBhZ2UiO2k6MTU7czo2OiJleGlzdHMiO2I6MTtzOjE4OiJ3YXNSZWNlbnRseUNyZWF0ZWQiO2I6MDtzOjI4OiIAKgBlc2NhcGVXaGVuQ2FzdGluZ1RvU3RyaW5nIjtiOjA7czoxMzoiACoAYXR0cmlidXRlcyI7YTo2OntzOjI6ImlkIjtpOjEyO3M6MTI6Im1lbnVfbWFpbl9pZCI7aTo2O3M6NjoibG9jYWxlIjtzOjI6InJ1IjtzOjQ6ImRhdGEiO3M6Nzk6InsiaW5mbyI6IG51bGwsICJ0aXRsZSI6ICLQk9C70LDQstC90LDRjyDRgdGC0YDQsNC90LjRhtCwIiwgImRlc2NyaXB0aW9uIjogbnVsbH0iO3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjUtMTItMjMgMDQ6NTI6MDMiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDEtMjIgMDY6MjM6NTMiO31zOjExOiIAKgBvcmlnaW5hbCI7YTo2OntzOjI6ImlkIjtpOjEyO3M6MTI6Im1lbnVfbWFpbl9pZCI7aTo2O3M6NjoibG9jYWxlIjtzOjI6InJ1IjtzOjQ6ImRhdGEiO3M6Nzk6InsiaW5mbyI6IG51bGwsICJ0aXRsZSI6ICLQk9C70LDQstC90LDRjyDRgdGC0YDQsNC90LjRhtCwIiwgImRlc2NyaXB0aW9uIjogbnVsbH0iO3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjUtMTItMjMgMDQ6NTI6MDMiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDEtMjIgMDY6MjM6NTMiO31zOjEwOiIAKgBjaGFuZ2VzIjthOjA6e31zOjExOiIAKgBwcmV2aW91cyI7YTowOnt9czo4OiIAKgBjYXN0cyI7YTowOnt9czoxNzoiACoAY2xhc3NDYXN0Q2FjaGUiO2E6MDp7fXM6MjE6IgAqAGF0dHJpYnV0ZUNhc3RDYWNoZSI7YTowOnt9czoxMzoiACoAZGF0ZUZvcm1hdCI7TjtzOjEwOiIAKgBhcHBlbmRzIjthOjA6e31zOjE5OiIAKgBkaXNwYXRjaGVzRXZlbnRzIjthOjA6e31zOjE0OiIAKgBvYnNlcnZhYmxlcyI7YTowOnt9czoxMjoiACoAcmVsYXRpb25zIjthOjA6e31zOjEwOiIAKgB0b3VjaGVzIjthOjA6e31zOjI3OiIAKgByZWxhdGlvbkF1dG9sb2FkQ2FsbGJhY2siO047czoyNjoiACoAcmVsYXRpb25BdXRvbG9hZENvbnRleHQiO047czoxMDoidGltZXN0YW1wcyI7YjoxO3M6MTM6InVzZXNVbmlxdWVJZHMiO2I6MDtzOjk6IgAqAGhpZGRlbiI7YTowOnt9czoxMDoiACoAdmlzaWJsZSI7YTowOnt9czoxMToiACoAZmlsbGFibGUiO2E6Mzp7aTowO3M6MTI6Im1lbnVfbWFpbl9pZCI7aToxO3M6NjoibG9jYWxlIjtpOjI7czo0OiJkYXRhIjt9czoxMDoiACoAZ3VhcmRlZCI7YToxOntpOjA7czoxOiIqIjt9fWk6MTtPOjMwOiJBcHBcTW9kZWxzXE1lbnVNYWluVHJhbnNsYXRpb24iOjMzOntzOjEzOiIAKgBjb25uZWN0aW9uIjtzOjU6InBnc3FsIjtzOjg6IgAqAHRhYmxlIjtzOjIyOiJtZW51X21haW5fdHJhbnNsYXRpb25zIjtzOjEzOiIAKgBwcmltYXJ5S2V5IjtzOjI6ImlkIjtzOjEwOiIAKgBrZXlUeXBlIjtzOjM6ImludCI7czoxMjoiaW5jcmVtZW50aW5nIjtiOjE7czo3OiIAKgB3aXRoIjthOjA6e31zOjEyOiIAKgB3aXRoQ291bnQiO2E6MDp7fXM6MTk6InByZXZlbnRzTGF6eUxvYWRpbmciO2I6MDtzOjEwOiIAKgBwZXJQYWdlIjtpOjE1O3M6NjoiZXhpc3RzIjtiOjE7czoxODoid2FzUmVjZW50bHlDcmVhdGVkIjtiOjA7czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO3M6MTM6IgAqAGF0dHJpYnV0ZXMiO2E6Njp7czoyOiJpZCI7aToxMTtzOjEyOiJtZW51X21haW5faWQiO2k6NjtzOjY6ImxvY2FsZSI7czoyOiJ1eiI7czo0OiJkYXRhIjtzOjU5OiJ7ImluZm8iOiBudWxsLCAidGl0bGUiOiAiQm9zaCBzYWhpZmEiLCAiZGVzY3JpcHRpb24iOiBudWxsfSI7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNS0xMi0yMyAwNDo1MjowMyI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMiAwNjoyMzo1MyI7fXM6MTE6IgAqAG9yaWdpbmFsIjthOjY6e3M6MjoiaWQiO2k6MTE7czoxMjoibWVudV9tYWluX2lkIjtpOjY7czo2OiJsb2NhbGUiO3M6MjoidXoiO3M6NDoiZGF0YSI7czo1OToieyJpbmZvIjogbnVsbCwgInRpdGxlIjogIkJvc2ggc2FoaWZhIiwgImRlc2NyaXB0aW9uIjogbnVsbH0iO3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjUtMTItMjMgMDQ6NTI6MDMiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDEtMjIgMDY6MjM6NTMiO31zOjEwOiIAKgBjaGFuZ2VzIjthOjA6e31zOjExOiIAKgBwcmV2aW91cyI7YTowOnt9czo4OiIAKgBjYXN0cyI7YTowOnt9czoxNzoiACoAY2xhc3NDYXN0Q2FjaGUiO2E6MDp7fXM6MjE6IgAqAGF0dHJpYnV0ZUNhc3RDYWNoZSI7YTowOnt9czoxMzoiACoAZGF0ZUZvcm1hdCI7TjtzOjEwOiIAKgBhcHBlbmRzIjthOjA6e31zOjE5OiIAKgBkaXNwYXRjaGVzRXZlbnRzIjthOjA6e31zOjE0OiIAKgBvYnNlcnZhYmxlcyI7YTowOnt9czoxMjoiACoAcmVsYXRpb25zIjthOjA6e31zOjEwOiIAKgB0b3VjaGVzIjthOjA6e31zOjI3OiIAKgByZWxhdGlvbkF1dG9sb2FkQ2FsbGJhY2siO047czoyNjoiACoAcmVsYXRpb25BdXRvbG9hZENvbnRleHQiO047czoxMDoidGltZXN0YW1wcyI7YjoxO3M6MTM6InVzZXNVbmlxdWVJZHMiO2I6MDtzOjk6IgAqAGhpZGRlbiI7YTowOnt9czoxMDoiACoAdmlzaWJsZSI7YTowOnt9czoxMToiACoAZmlsbGFibGUiO2E6Mzp7aTowO3M6MTI6Im1lbnVfbWFpbl9pZCI7aToxO3M6NjoibG9jYWxlIjtpOjI7czo0OiJkYXRhIjt9czoxMDoiACoAZ3VhcmRlZCI7YToxOntpOjA7czoxOiIqIjt9fWk6MjtPOjMwOiJBcHBcTW9kZWxzXE1lbnVNYWluVHJhbnNsYXRpb24iOjMzOntzOjEzOiIAKgBjb25uZWN0aW9uIjtzOjU6InBnc3FsIjtzOjg6IgAqAHRhYmxlIjtzOjIyOiJtZW51X21haW5fdHJhbnNsYXRpb25zIjtzOjEzOiIAKgBwcmltYXJ5S2V5IjtzOjI6ImlkIjtzOjEwOiIAKgBrZXlUeXBlIjtzOjM6ImludCI7czoxMjoiaW5jcmVtZW50aW5nIjtiOjE7czo3OiIAKgB3aXRoIjthOjA6e31zOjEyOiIAKgB3aXRoQ291bnQiO2E6MDp7fXM6MTk6InByZXZlbnRzTGF6eUxvYWRpbmciO2I6MDtzOjEwOiIAKgBwZXJQYWdlIjtpOjE1O3M6NjoiZXhpc3RzIjtiOjE7czoxODoid2FzUmVjZW50bHlDcmVhdGVkIjtiOjA7czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO3M6MTM6IgAqAGF0dHJpYnV0ZXMiO2E6Njp7czoyOiJpZCI7aToxMjg7czoxMjoibWVudV9tYWluX2lkIjtpOjY7czo2OiJsb2NhbGUiO3M6MjoiZW4iO3M6NDoiZGF0YSI7czo1NzoieyJpbmZvIjogbnVsbCwgInRpdGxlIjogIk1haW4gUGFnZSIsICJkZXNjcmlwdGlvbiI6IG51bGx9IjtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTE0IDEwOjMzOjE2IjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIyIDA2OjIzOjUzIjt9czoxMToiACoAb3JpZ2luYWwiO2E6Njp7czoyOiJpZCI7aToxMjg7czoxMjoibWVudV9tYWluX2lkIjtpOjY7czo2OiJsb2NhbGUiO3M6MjoiZW4iO3M6NDoiZGF0YSI7czo1NzoieyJpbmZvIjogbnVsbCwgInRpdGxlIjogIk1haW4gUGFnZSIsICJkZXNjcmlwdGlvbiI6IG51bGx9IjtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTE0IDEwOjMzOjE2IjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIyIDA2OjIzOjUzIjt9czoxMDoiACoAY2hhbmdlcyI7YTowOnt9czoxMToiACoAcHJldmlvdXMiO2E6MDp7fXM6ODoiACoAY2FzdHMiO2E6MDp7fXM6MTc6IgAqAGNsYXNzQ2FzdENhY2hlIjthOjA6e31zOjIxOiIAKgBhdHRyaWJ1dGVDYXN0Q2FjaGUiO2E6MDp7fXM6MTM6IgAqAGRhdGVGb3JtYXQiO047czoxMDoiACoAYXBwZW5kcyI7YTowOnt9czoxOToiACoAZGlzcGF0Y2hlc0V2ZW50cyI7YTowOnt9czoxNDoiACoAb2JzZXJ2YWJsZXMiO2E6MDp7fXM6MTI6IgAqAHJlbGF0aW9ucyI7YTowOnt9czoxMDoiACoAdG91Y2hlcyI7YTowOnt9czoyNzoiACoAcmVsYXRpb25BdXRvbG9hZENhbGxiYWNrIjtOO3M6MjY6IgAqAHJlbGF0aW9uQXV0b2xvYWRDb250ZXh0IjtOO3M6MTA6InRpbWVzdGFtcHMiO2I6MTtzOjEzOiJ1c2VzVW5pcXVlSWRzIjtiOjA7czo5OiIAKgBoaWRkZW4iO2E6MDp7fXM6MTA6IgAqAHZpc2libGUiO2E6MDp7fXM6MTE6IgAqAGZpbGxhYmxlIjthOjM6e2k6MDtzOjEyOiJtZW51X21haW5faWQiO2k6MTtzOjY6ImxvY2FsZSI7aToyO3M6NDoiZGF0YSI7fXM6MTA6IgAqAGd1YXJkZWQiO2E6MTp7aTowO3M6MToiKiI7fX19czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO31zOjk6ImNoaWxkcmVucyI7TzozOToiSWxsdW1pbmF0ZVxEYXRhYmFzZVxFbG9xdWVudFxDb2xsZWN0aW9uIjoyOntzOjg6IgAqAGl0ZW1zIjthOjA6e31zOjI4OiIAKgBlc2NhcGVXaGVuQ2FzdGluZ1RvU3RyaW5nIjtiOjA7fX1zOjEwOiIAKgB0b3VjaGVzIjthOjA6e31zOjI3OiIAKgByZWxhdGlvbkF1dG9sb2FkQ2FsbGJhY2siO047czoyNjoiACoAcmVsYXRpb25BdXRvbG9hZENvbnRleHQiO047czoxMDoidGltZXN0YW1wcyI7YjoxO3M6MTM6InVzZXNVbmlxdWVJZHMiO2I6MDtzOjk6IgAqAGhpZGRlbiI7YTowOnt9czoxMDoiACoAdmlzaWJsZSI7YTowOnt9czoxMToiACoAZmlsbGFibGUiO2E6OTp7aTowO3M6NDoidHlwZSI7aToxO3M6NDoic2x1ZyI7aToyO3M6MzoidXJsIjtpOjM7czo0OiJ0ZXN0IjtpOjQ7czoxMDoic2hvd19hZG1pbiI7aTo1O3M6MTA6InNvcnRfb3JkZXIiO2k6NjtzOjQ6Imljb24iO2k6NztzOjY6InN0YXR1cyI7aTo4O3M6OToicGFyZW50X2lkIjt9czoxMDoiACoAZ3VhcmRlZCI7YToxOntpOjA7czoxOiIqIjt9czoxOToiACoAdHJhbnNsYXRpb25DYWNoZSI7Tjt9aToxO086MTk6IkFwcFxNb2RlbHNcTWVudU1haW4iOjM0OntzOjEzOiIAKgBjb25uZWN0aW9uIjtzOjU6InBnc3FsIjtzOjg6IgAqAHRhYmxlIjtzOjEwOiJtZW51X21haW5zIjtzOjEzOiIAKgBwcmltYXJ5S2V5IjtzOjI6ImlkIjtzOjEwOiIAKgBrZXlUeXBlIjtzOjM6ImludCI7czoxMjoiaW5jcmVtZW50aW5nIjtiOjE7czo3OiIAKgB3aXRoIjthOjA6e31zOjEyOiIAKgB3aXRoQ291bnQiO2E6MDp7fXM6MTk6InByZXZlbnRzTGF6eUxvYWRpbmciO2I6MDtzOjEwOiIAKgBwZXJQYWdlIjtpOjE1O3M6NjoiZXhpc3RzIjtiOjE7czoxODoid2FzUmVjZW50bHlDcmVhdGVkIjtiOjA7czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO3M6MTM6IgAqAGF0dHJpYnV0ZXMiO2E6MTI6e3M6MjoiaWQiO2k6NztzOjQ6InR5cGUiO3M6NDoicGFnZSI7czo0OiJzbHVnIjtzOjEwOiJ0cmFkaXRpb25zIjtzOjM6InVybCI7TjtzOjQ6InRlc3QiO2I6MDtzOjEwOiJzaG93X2FkbWluIjtiOjE7czoxMDoic29ydF9vcmRlciI7aToyO3M6NDoiaWNvbiI7TjtzOjY6InN0YXR1cyI7YjoxO3M6OToicGFyZW50X2lkIjtpOjU7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNS0xMi0yMyAwNDo1MjozNiI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMSAxOTo0NjoyNSI7fXM6MTE6IgAqAG9yaWdpbmFsIjthOjEyOntzOjI6ImlkIjtpOjc7czo0OiJ0eXBlIjtzOjQ6InBhZ2UiO3M6NDoic2x1ZyI7czoxMDoidHJhZGl0aW9ucyI7czozOiJ1cmwiO047czo0OiJ0ZXN0IjtiOjA7czoxMDoic2hvd19hZG1pbiI7YjoxO3M6MTA6InNvcnRfb3JkZXIiO2k6MjtzOjQ6Imljb24iO047czo2OiJzdGF0dXMiO2I6MTtzOjk6InBhcmVudF9pZCI7aTo1O3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjUtMTItMjMgMDQ6NTI6MzYiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDEtMjEgMTk6NDY6MjUiO31zOjEwOiIAKgBjaGFuZ2VzIjthOjA6e31zOjExOiIAKgBwcmV2aW91cyI7YTowOnt9czo4OiIAKgBjYXN0cyI7YTowOnt9czoxNzoiACoAY2xhc3NDYXN0Q2FjaGUiO2E6MDp7fXM6MjE6IgAqAGF0dHJpYnV0ZUNhc3RDYWNoZSI7YTowOnt9czoxMzoiACoAZGF0ZUZvcm1hdCI7TjtzOjEwOiIAKgBhcHBlbmRzIjthOjA6e31zOjE5OiIAKgBkaXNwYXRjaGVzRXZlbnRzIjthOjA6e31zOjE0OiIAKgBvYnNlcnZhYmxlcyI7YTowOnt9czoxMjoiACoAcmVsYXRpb25zIjthOjI6e3M6MTI6InRyYW5zbGF0aW9ucyI7TzozOToiSWxsdW1pbmF0ZVxEYXRhYmFzZVxFbG9xdWVudFxDb2xsZWN0aW9uIjoyOntzOjg6IgAqAGl0ZW1zIjthOjM6e2k6MDtPOjMwOiJBcHBcTW9kZWxzXE1lbnVNYWluVHJhbnNsYXRpb24iOjMzOntzOjEzOiIAKgBjb25uZWN0aW9uIjtzOjU6InBnc3FsIjtzOjg6IgAqAHRhYmxlIjtzOjIyOiJtZW51X21haW5fdHJhbnNsYXRpb25zIjtzOjEzOiIAKgBwcmltYXJ5S2V5IjtzOjI6ImlkIjtzOjEwOiIAKgBrZXlUeXBlIjtzOjM6ImludCI7czoxMjoiaW5jcmVtZW50aW5nIjtiOjE7czo3OiIAKgB3aXRoIjthOjA6e31zOjEyOiIAKgB3aXRoQ291bnQiO2E6MDp7fXM6MTk6InByZXZlbnRzTGF6eUxvYWRpbmciO2I6MDtzOjEwOiIAKgBwZXJQYWdlIjtpOjE1O3M6NjoiZXhpc3RzIjtiOjE7czoxODoid2FzUmVjZW50bHlDcmVhdGVkIjtiOjA7czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO3M6MTM6IgAqAGF0dHJpYnV0ZXMiO2E6Njp7czoyOiJpZCI7aToxMztzOjEyOiJtZW51X21haW5faWQiO2k6NztzOjY6ImxvY2FsZSI7czoyOiJ1eiI7czo0OiJkYXRhIjtzOjU5OiJ7ImluZm8iOiBudWxsLCAidGl0bGUiOiAiUWFkcml5YXRsYXIiLCAiZGVzY3JpcHRpb24iOiBudWxsfSI7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNS0xMi0yMyAwNDo1MjozNiI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMSAxOTo0NzowOSI7fXM6MTE6IgAqAG9yaWdpbmFsIjthOjY6e3M6MjoiaWQiO2k6MTM7czoxMjoibWVudV9tYWluX2lkIjtpOjc7czo2OiJsb2NhbGUiO3M6MjoidXoiO3M6NDoiZGF0YSI7czo1OToieyJpbmZvIjogbnVsbCwgInRpdGxlIjogIlFhZHJpeWF0bGFyIiwgImRlc2NyaXB0aW9uIjogbnVsbH0iO3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjUtMTItMjMgMDQ6NTI6MzYiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDEtMjEgMTk6NDc6MDkiO31zOjEwOiIAKgBjaGFuZ2VzIjthOjA6e31zOjExOiIAKgBwcmV2aW91cyI7YTowOnt9czo4OiIAKgBjYXN0cyI7YTowOnt9czoxNzoiACoAY2xhc3NDYXN0Q2FjaGUiO2E6MDp7fXM6MjE6IgAqAGF0dHJpYnV0ZUNhc3RDYWNoZSI7YTowOnt9czoxMzoiACoAZGF0ZUZvcm1hdCI7TjtzOjEwOiIAKgBhcHBlbmRzIjthOjA6e31zOjE5OiIAKgBkaXNwYXRjaGVzRXZlbnRzIjthOjA6e31zOjE0OiIAKgBvYnNlcnZhYmxlcyI7YTowOnt9czoxMjoiACoAcmVsYXRpb25zIjthOjA6e31zOjEwOiIAKgB0b3VjaGVzIjthOjA6e31zOjI3OiIAKgByZWxhdGlvbkF1dG9sb2FkQ2FsbGJhY2siO047czoyNjoiACoAcmVsYXRpb25BdXRvbG9hZENvbnRleHQiO047czoxMDoidGltZXN0YW1wcyI7YjoxO3M6MTM6InVzZXNVbmlxdWVJZHMiO2I6MDtzOjk6IgAqAGhpZGRlbiI7YTowOnt9czoxMDoiACoAdmlzaWJsZSI7YTowOnt9czoxMToiACoAZmlsbGFibGUiO2E6Mzp7aTowO3M6MTI6Im1lbnVfbWFpbl9pZCI7aToxO3M6NjoibG9jYWxlIjtpOjI7czo0OiJkYXRhIjt9czoxMDoiACoAZ3VhcmRlZCI7YToxOntpOjA7czoxOiIqIjt9fWk6MTtPOjMwOiJBcHBcTW9kZWxzXE1lbnVNYWluVHJhbnNsYXRpb24iOjMzOntzOjEzOiIAKgBjb25uZWN0aW9uIjtzOjU6InBnc3FsIjtzOjg6IgAqAHRhYmxlIjtzOjIyOiJtZW51X21haW5fdHJhbnNsYXRpb25zIjtzOjEzOiIAKgBwcmltYXJ5S2V5IjtzOjI6ImlkIjtzOjEwOiIAKgBrZXlUeXBlIjtzOjM6ImludCI7czoxMjoiaW5jcmVtZW50aW5nIjtiOjE7czo3OiIAKgB3aXRoIjthOjA6e31zOjEyOiIAKgB3aXRoQ291bnQiO2E6MDp7fXM6MTk6InByZXZlbnRzTGF6eUxvYWRpbmciO2I6MDtzOjEwOiIAKgBwZXJQYWdlIjtpOjE1O3M6NjoiZXhpc3RzIjtiOjE7czoxODoid2FzUmVjZW50bHlDcmVhdGVkIjtiOjA7czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO3M6MTM6IgAqAGF0dHJpYnV0ZXMiO2E6Njp7czoyOiJpZCI7aToxNDtzOjEyOiJtZW51X21haW5faWQiO2k6NztzOjY6ImxvY2FsZSI7czoyOiJydSI7czo0OiJkYXRhIjtzOjY0OiJ7ImluZm8iOiBudWxsLCAidGl0bGUiOiAi0KbQtdC90L3QvtGB0YLQuCIsICJkZXNjcmlwdGlvbiI6IG51bGx9IjtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI1LTEyLTIzIDA0OjUyOjM2IjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIxIDE5OjQ3OjA5Ijt9czoxMToiACoAb3JpZ2luYWwiO2E6Njp7czoyOiJpZCI7aToxNDtzOjEyOiJtZW51X21haW5faWQiO2k6NztzOjY6ImxvY2FsZSI7czoyOiJydSI7czo0OiJkYXRhIjtzOjY0OiJ7ImluZm8iOiBudWxsLCAidGl0bGUiOiAi0KbQtdC90L3QvtGB0YLQuCIsICJkZXNjcmlwdGlvbiI6IG51bGx9IjtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI1LTEyLTIzIDA0OjUyOjM2IjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIxIDE5OjQ3OjA5Ijt9czoxMDoiACoAY2hhbmdlcyI7YTowOnt9czoxMToiACoAcHJldmlvdXMiO2E6MDp7fXM6ODoiACoAY2FzdHMiO2E6MDp7fXM6MTc6IgAqAGNsYXNzQ2FzdENhY2hlIjthOjA6e31zOjIxOiIAKgBhdHRyaWJ1dGVDYXN0Q2FjaGUiO2E6MDp7fXM6MTM6IgAqAGRhdGVGb3JtYXQiO047czoxMDoiACoAYXBwZW5kcyI7YTowOnt9czoxOToiACoAZGlzcGF0Y2hlc0V2ZW50cyI7YTowOnt9czoxNDoiACoAb2JzZXJ2YWJsZXMiO2E6MDp7fXM6MTI6IgAqAHJlbGF0aW9ucyI7YTowOnt9czoxMDoiACoAdG91Y2hlcyI7YTowOnt9czoyNzoiACoAcmVsYXRpb25BdXRvbG9hZENhbGxiYWNrIjtOO3M6MjY6IgAqAHJlbGF0aW9uQXV0b2xvYWRDb250ZXh0IjtOO3M6MTA6InRpbWVzdGFtcHMiO2I6MTtzOjEzOiJ1c2VzVW5pcXVlSWRzIjtiOjA7czo5OiIAKgBoaWRkZW4iO2E6MDp7fXM6MTA6IgAqAHZpc2libGUiO2E6MDp7fXM6MTE6IgAqAGZpbGxhYmxlIjthOjM6e2k6MDtzOjEyOiJtZW51X21haW5faWQiO2k6MTtzOjY6ImxvY2FsZSI7aToyO3M6NDoiZGF0YSI7fXM6MTA6IgAqAGd1YXJkZWQiO2E6MTp7aTowO3M6MToiKiI7fX1pOjI7TzozMDoiQXBwXE1vZGVsc1xNZW51TWFpblRyYW5zbGF0aW9uIjozMzp7czoxMzoiACoAY29ubmVjdGlvbiI7czo1OiJwZ3NxbCI7czo4OiIAKgB0YWJsZSI7czoyMjoibWVudV9tYWluX3RyYW5zbGF0aW9ucyI7czoxMzoiACoAcHJpbWFyeUtleSI7czoyOiJpZCI7czoxMDoiACoAa2V5VHlwZSI7czozOiJpbnQiO3M6MTI6ImluY3JlbWVudGluZyI7YjoxO3M6NzoiACoAd2l0aCI7YTowOnt9czoxMjoiACoAd2l0aENvdW50IjthOjA6e31zOjE5OiJwcmV2ZW50c0xhenlMb2FkaW5nIjtiOjA7czoxMDoiACoAcGVyUGFnZSI7aToxNTtzOjY6ImV4aXN0cyI7YjoxO3M6MTg6Indhc1JlY2VudGx5Q3JlYXRlZCI7YjowO3M6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDtzOjEzOiIAKgBhdHRyaWJ1dGVzIjthOjY6e3M6MjoiaWQiO2k6MTI5O3M6MTI6Im1lbnVfbWFpbl9pZCI7aTo3O3M6NjoibG9jYWxlIjtzOjI6ImVuIjtzOjQ6ImRhdGEiO3M6NTQ6InsiaW5mbyI6IG51bGwsICJ0aXRsZSI6ICJWYWx1ZXMiLCAiZGVzY3JpcHRpb24iOiBudWxsfSI7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNi0wMS0xNCAxMDozMzo1MyI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMSAxOTo0NzowOSI7fXM6MTE6IgAqAG9yaWdpbmFsIjthOjY6e3M6MjoiaWQiO2k6MTI5O3M6MTI6Im1lbnVfbWFpbl9pZCI7aTo3O3M6NjoibG9jYWxlIjtzOjI6ImVuIjtzOjQ6ImRhdGEiO3M6NTQ6InsiaW5mbyI6IG51bGwsICJ0aXRsZSI6ICJWYWx1ZXMiLCAiZGVzY3JpcHRpb24iOiBudWxsfSI7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNi0wMS0xNCAxMDozMzo1MyI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMSAxOTo0NzowOSI7fXM6MTA6IgAqAGNoYW5nZXMiO2E6MDp7fXM6MTE6IgAqAHByZXZpb3VzIjthOjA6e31zOjg6IgAqAGNhc3RzIjthOjA6e31zOjE3OiIAKgBjbGFzc0Nhc3RDYWNoZSI7YTowOnt9czoyMToiACoAYXR0cmlidXRlQ2FzdENhY2hlIjthOjA6e31zOjEzOiIAKgBkYXRlRm9ybWF0IjtOO3M6MTA6IgAqAGFwcGVuZHMiO2E6MDp7fXM6MTk6IgAqAGRpc3BhdGNoZXNFdmVudHMiO2E6MDp7fXM6MTQ6IgAqAG9ic2VydmFibGVzIjthOjA6e31zOjEyOiIAKgByZWxhdGlvbnMiO2E6MDp7fXM6MTA6IgAqAHRvdWNoZXMiO2E6MDp7fXM6Mjc6IgAqAHJlbGF0aW9uQXV0b2xvYWRDYWxsYmFjayI7TjtzOjI2OiIAKgByZWxhdGlvbkF1dG9sb2FkQ29udGV4dCI7TjtzOjEwOiJ0aW1lc3RhbXBzIjtiOjE7czoxMzoidXNlc1VuaXF1ZUlkcyI7YjowO3M6OToiACoAaGlkZGVuIjthOjA6e31zOjEwOiIAKgB2aXNpYmxlIjthOjA6e31zOjExOiIAKgBmaWxsYWJsZSI7YTozOntpOjA7czoxMjoibWVudV9tYWluX2lkIjtpOjE7czo2OiJsb2NhbGUiO2k6MjtzOjQ6ImRhdGEiO31zOjEwOiIAKgBndWFyZGVkIjthOjE6e2k6MDtzOjE6IioiO319fXM6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDt9czo5OiJjaGlsZHJlbnMiO086Mzk6IklsbHVtaW5hdGVcRGF0YWJhc2VcRWxvcXVlbnRcQ29sbGVjdGlvbiI6Mjp7czo4OiIAKgBpdGVtcyI7YTowOnt9czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO319czoxMDoiACoAdG91Y2hlcyI7YTowOnt9czoyNzoiACoAcmVsYXRpb25BdXRvbG9hZENhbGxiYWNrIjtOO3M6MjY6IgAqAHJlbGF0aW9uQXV0b2xvYWRDb250ZXh0IjtOO3M6MTA6InRpbWVzdGFtcHMiO2I6MTtzOjEzOiJ1c2VzVW5pcXVlSWRzIjtiOjA7czo5OiIAKgBoaWRkZW4iO2E6MDp7fXM6MTA6IgAqAHZpc2libGUiO2E6MDp7fXM6MTE6IgAqAGZpbGxhYmxlIjthOjk6e2k6MDtzOjQ6InR5cGUiO2k6MTtzOjQ6InNsdWciO2k6MjtzOjM6InVybCI7aTozO3M6NDoidGVzdCI7aTo0O3M6MTA6InNob3dfYWRtaW4iO2k6NTtzOjEwOiJzb3J0X29yZGVyIjtpOjY7czo0OiJpY29uIjtpOjc7czo2OiJzdGF0dXMiO2k6ODtzOjk6InBhcmVudF9pZCI7fXM6MTA6IgAqAGd1YXJkZWQiO2E6MTp7aTowO3M6MToiKiI7fXM6MTk6IgAqAHRyYW5zbGF0aW9uQ2FjaGUiO047fWk6MjtPOjE5OiJBcHBcTW9kZWxzXE1lbnVNYWluIjozNDp7czoxMzoiACoAY29ubmVjdGlvbiI7czo1OiJwZ3NxbCI7czo4OiIAKgB0YWJsZSI7czoxMDoibWVudV9tYWlucyI7czoxMzoiACoAcHJpbWFyeUtleSI7czoyOiJpZCI7czoxMDoiACoAa2V5VHlwZSI7czozOiJpbnQiO3M6MTI6ImluY3JlbWVudGluZyI7YjoxO3M6NzoiACoAd2l0aCI7YTowOnt9czoxMjoiACoAd2l0aENvdW50IjthOjA6e31zOjE5OiJwcmV2ZW50c0xhenlMb2FkaW5nIjtiOjA7czoxMDoiACoAcGVyUGFnZSI7aToxNTtzOjY6ImV4aXN0cyI7YjoxO3M6MTg6Indhc1JlY2VudGx5Q3JlYXRlZCI7YjowO3M6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDtzOjEzOiIAKgBhdHRyaWJ1dGVzIjthOjEyOntzOjI6ImlkIjtpOjg7czo0OiJ0eXBlIjtzOjM6InVybCI7czo0OiJzbHVnIjtzOjEwOiIzZC1zYXlvaGF0IjtzOjM6InVybCI7czoyNzoiaHR0cHM6Ly91emJla2lzdGFuMzYwLnV6L3J1IjtzOjQ6InRlc3QiO2I6MDtzOjEwOiJzaG93X2FkbWluIjtiOjA7czoxMDoic29ydF9vcmRlciI7aTozO3M6NDoiaWNvbiI7TjtzOjY6InN0YXR1cyI7YjoxO3M6OToicGFyZW50X2lkIjtpOjU7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNS0xMi0yMyAwNDo1MzoxMiI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMSAxOTo0NjoyNSI7fXM6MTE6IgAqAG9yaWdpbmFsIjthOjEyOntzOjI6ImlkIjtpOjg7czo0OiJ0eXBlIjtzOjM6InVybCI7czo0OiJzbHVnIjtzOjEwOiIzZC1zYXlvaGF0IjtzOjM6InVybCI7czoyNzoiaHR0cHM6Ly91emJla2lzdGFuMzYwLnV6L3J1IjtzOjQ6InRlc3QiO2I6MDtzOjEwOiJzaG93X2FkbWluIjtiOjA7czoxMDoic29ydF9vcmRlciI7aTozO3M6NDoiaWNvbiI7TjtzOjY6InN0YXR1cyI7YjoxO3M6OToicGFyZW50X2lkIjtpOjU7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNS0xMi0yMyAwNDo1MzoxMiI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMSAxOTo0NjoyNSI7fXM6MTA6IgAqAGNoYW5nZXMiO2E6MDp7fXM6MTE6IgAqAHByZXZpb3VzIjthOjA6e31zOjg6IgAqAGNhc3RzIjthOjA6e31zOjE3OiIAKgBjbGFzc0Nhc3RDYWNoZSI7YTowOnt9czoyMToiACoAYXR0cmlidXRlQ2FzdENhY2hlIjthOjA6e31zOjEzOiIAKgBkYXRlRm9ybWF0IjtOO3M6MTA6IgAqAGFwcGVuZHMiO2E6MDp7fXM6MTk6IgAqAGRpc3BhdGNoZXNFdmVudHMiO2E6MDp7fXM6MTQ6IgAqAG9ic2VydmFibGVzIjthOjA6e31zOjEyOiIAKgByZWxhdGlvbnMiO2E6Mjp7czoxMjoidHJhbnNsYXRpb25zIjtPOjM5OiJJbGx1bWluYXRlXERhdGFiYXNlXEVsb3F1ZW50XENvbGxlY3Rpb24iOjI6e3M6ODoiACoAaXRlbXMiO2E6Mzp7aTowO086MzA6IkFwcFxNb2RlbHNcTWVudU1haW5UcmFuc2xhdGlvbiI6MzM6e3M6MTM6IgAqAGNvbm5lY3Rpb24iO3M6NToicGdzcWwiO3M6ODoiACoAdGFibGUiO3M6MjI6Im1lbnVfbWFpbl90cmFuc2xhdGlvbnMiO3M6MTM6IgAqAHByaW1hcnlLZXkiO3M6MjoiaWQiO3M6MTA6IgAqAGtleVR5cGUiO3M6MzoiaW50IjtzOjEyOiJpbmNyZW1lbnRpbmciO2I6MTtzOjc6IgAqAHdpdGgiO2E6MDp7fXM6MTI6IgAqAHdpdGhDb3VudCI7YTowOnt9czoxOToicHJldmVudHNMYXp5TG9hZGluZyI7YjowO3M6MTA6IgAqAHBlclBhZ2UiO2k6MTU7czo2OiJleGlzdHMiO2I6MTtzOjE4OiJ3YXNSZWNlbnRseUNyZWF0ZWQiO2I6MDtzOjI4OiIAKgBlc2NhcGVXaGVuQ2FzdGluZ1RvU3RyaW5nIjtiOjA7czoxMzoiACoAYXR0cmlidXRlcyI7YTo2OntzOjI6ImlkIjtpOjY4O3M6MTI6Im1lbnVfbWFpbl9pZCI7aTo4O3M6NjoibG9jYWxlIjtzOjI6ImVuIjtzOjQ6ImRhdGEiO3M6NTc6InsiaW5mbyI6IG51bGwsICJ0aXRsZSI6ICIzRCBUcmF2ZWwiLCAiZGVzY3JpcHRpb24iOiBudWxsfSI7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNS0xMi0yNiAwNTozMjowOSI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMSAxOTo0ODozNSI7fXM6MTE6IgAqAG9yaWdpbmFsIjthOjY6e3M6MjoiaWQiO2k6Njg7czoxMjoibWVudV9tYWluX2lkIjtpOjg7czo2OiJsb2NhbGUiO3M6MjoiZW4iO3M6NDoiZGF0YSI7czo1NzoieyJpbmZvIjogbnVsbCwgInRpdGxlIjogIjNEIFRyYXZlbCIsICJkZXNjcmlwdGlvbiI6IG51bGx9IjtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI1LTEyLTI2IDA1OjMyOjA5IjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIxIDE5OjQ4OjM1Ijt9czoxMDoiACoAY2hhbmdlcyI7YTowOnt9czoxMToiACoAcHJldmlvdXMiO2E6MDp7fXM6ODoiACoAY2FzdHMiO2E6MDp7fXM6MTc6IgAqAGNsYXNzQ2FzdENhY2hlIjthOjA6e31zOjIxOiIAKgBhdHRyaWJ1dGVDYXN0Q2FjaGUiO2E6MDp7fXM6MTM6IgAqAGRhdGVGb3JtYXQiO047czoxMDoiACoAYXBwZW5kcyI7YTowOnt9czoxOToiACoAZGlzcGF0Y2hlc0V2ZW50cyI7YTowOnt9czoxNDoiACoAb2JzZXJ2YWJsZXMiO2E6MDp7fXM6MTI6IgAqAHJlbGF0aW9ucyI7YTowOnt9czoxMDoiACoAdG91Y2hlcyI7YTowOnt9czoyNzoiACoAcmVsYXRpb25BdXRvbG9hZENhbGxiYWNrIjtOO3M6MjY6IgAqAHJlbGF0aW9uQXV0b2xvYWRDb250ZXh0IjtOO3M6MTA6InRpbWVzdGFtcHMiO2I6MTtzOjEzOiJ1c2VzVW5pcXVlSWRzIjtiOjA7czo5OiIAKgBoaWRkZW4iO2E6MDp7fXM6MTA6IgAqAHZpc2libGUiO2E6MDp7fXM6MTE6IgAqAGZpbGxhYmxlIjthOjM6e2k6MDtzOjEyOiJtZW51X21haW5faWQiO2k6MTtzOjY6ImxvY2FsZSI7aToyO3M6NDoiZGF0YSI7fXM6MTA6IgAqAGd1YXJkZWQiO2E6MTp7aTowO3M6MToiKiI7fX1pOjE7TzozMDoiQXBwXE1vZGVsc1xNZW51TWFpblRyYW5zbGF0aW9uIjozMzp7czoxMzoiACoAY29ubmVjdGlvbiI7czo1OiJwZ3NxbCI7czo4OiIAKgB0YWJsZSI7czoyMjoibWVudV9tYWluX3RyYW5zbGF0aW9ucyI7czoxMzoiACoAcHJpbWFyeUtleSI7czoyOiJpZCI7czoxMDoiACoAa2V5VHlwZSI7czozOiJpbnQiO3M6MTI6ImluY3JlbWVudGluZyI7YjoxO3M6NzoiACoAd2l0aCI7YTowOnt9czoxMjoiACoAd2l0aENvdW50IjthOjA6e31zOjE5OiJwcmV2ZW50c0xhenlMb2FkaW5nIjtiOjA7czoxMDoiACoAcGVyUGFnZSI7aToxNTtzOjY6ImV4aXN0cyI7YjoxO3M6MTg6Indhc1JlY2VudGx5Q3JlYXRlZCI7YjowO3M6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDtzOjEzOiIAKgBhdHRyaWJ1dGVzIjthOjY6e3M6MjoiaWQiO2k6MTU7czoxMjoibWVudV9tYWluX2lkIjtpOjg7czo2OiJsb2NhbGUiO3M6MjoidXoiO3M6NDoiZGF0YSI7czo1OToieyJpbmZvIjogbnVsbCwgInRpdGxlIjogIjNEICBTYXlvaGF0IiwgImRlc2NyaXB0aW9uIjogbnVsbH0iO3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjUtMTItMjMgMDQ6NTM6MTIiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDEtMjEgMTk6NDg6MzUiO31zOjExOiIAKgBvcmlnaW5hbCI7YTo2OntzOjI6ImlkIjtpOjE1O3M6MTI6Im1lbnVfbWFpbl9pZCI7aTo4O3M6NjoibG9jYWxlIjtzOjI6InV6IjtzOjQ6ImRhdGEiO3M6NTk6InsiaW5mbyI6IG51bGwsICJ0aXRsZSI6ICIzRCAgU2F5b2hhdCIsICJkZXNjcmlwdGlvbiI6IG51bGx9IjtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI1LTEyLTIzIDA0OjUzOjEyIjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIxIDE5OjQ4OjM1Ijt9czoxMDoiACoAY2hhbmdlcyI7YTowOnt9czoxMToiACoAcHJldmlvdXMiO2E6MDp7fXM6ODoiACoAY2FzdHMiO2E6MDp7fXM6MTc6IgAqAGNsYXNzQ2FzdENhY2hlIjthOjA6e31zOjIxOiIAKgBhdHRyaWJ1dGVDYXN0Q2FjaGUiO2E6MDp7fXM6MTM6IgAqAGRhdGVGb3JtYXQiO047czoxMDoiACoAYXBwZW5kcyI7YTowOnt9czoxOToiACoAZGlzcGF0Y2hlc0V2ZW50cyI7YTowOnt9czoxNDoiACoAb2JzZXJ2YWJsZXMiO2E6MDp7fXM6MTI6IgAqAHJlbGF0aW9ucyI7YTowOnt9czoxMDoiACoAdG91Y2hlcyI7YTowOnt9czoyNzoiACoAcmVsYXRpb25BdXRvbG9hZENhbGxiYWNrIjtOO3M6MjY6IgAqAHJlbGF0aW9uQXV0b2xvYWRDb250ZXh0IjtOO3M6MTA6InRpbWVzdGFtcHMiO2I6MTtzOjEzOiJ1c2VzVW5pcXVlSWRzIjtiOjA7czo5OiIAKgBoaWRkZW4iO2E6MDp7fXM6MTA6IgAqAHZpc2libGUiO2E6MDp7fXM6MTE6IgAqAGZpbGxhYmxlIjthOjM6e2k6MDtzOjEyOiJtZW51X21haW5faWQiO2k6MTtzOjY6ImxvY2FsZSI7aToyO3M6NDoiZGF0YSI7fXM6MTA6IgAqAGd1YXJkZWQiO2E6MTp7aTowO3M6MToiKiI7fX1pOjI7TzozMDoiQXBwXE1vZGVsc1xNZW51TWFpblRyYW5zbGF0aW9uIjozMzp7czoxMzoiACoAY29ubmVjdGlvbiI7czo1OiJwZ3NxbCI7czo4OiIAKgB0YWJsZSI7czoyMjoibWVudV9tYWluX3RyYW5zbGF0aW9ucyI7czoxMzoiACoAcHJpbWFyeUtleSI7czoyOiJpZCI7czoxMDoiACoAa2V5VHlwZSI7czozOiJpbnQiO3M6MTI6ImluY3JlbWVudGluZyI7YjoxO3M6NzoiACoAd2l0aCI7YTowOnt9czoxMjoiACoAd2l0aENvdW50IjthOjA6e31zOjE5OiJwcmV2ZW50c0xhenlMb2FkaW5nIjtiOjA7czoxMDoiACoAcGVyUGFnZSI7aToxNTtzOjY6ImV4aXN0cyI7YjoxO3M6MTg6Indhc1JlY2VudGx5Q3JlYXRlZCI7YjowO3M6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDtzOjEzOiIAKgBhdHRyaWJ1dGVzIjthOjY6e3M6MjoiaWQiO2k6MTY7czoxMjoibWVudV9tYWluX2lkIjtpOjg7czo2OiJsb2NhbGUiO3M6MjoicnUiO3M6NDoiZGF0YSI7czo3MzoieyJpbmZvIjogbnVsbCwgInRpdGxlIjogIjNEINCf0YPRgtC10YjQtdGB0YLQstC40Y8iLCAiZGVzY3JpcHRpb24iOiBudWxsfSI7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNS0xMi0yMyAwNDo1MzoxMiI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMSAxOTo0ODozNSI7fXM6MTE6IgAqAG9yaWdpbmFsIjthOjY6e3M6MjoiaWQiO2k6MTY7czoxMjoibWVudV9tYWluX2lkIjtpOjg7czo2OiJsb2NhbGUiO3M6MjoicnUiO3M6NDoiZGF0YSI7czo3MzoieyJpbmZvIjogbnVsbCwgInRpdGxlIjogIjNEINCf0YPRgtC10YjQtdGB0YLQstC40Y8iLCAiZGVzY3JpcHRpb24iOiBudWxsfSI7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNS0xMi0yMyAwNDo1MzoxMiI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMSAxOTo0ODozNSI7fXM6MTA6IgAqAGNoYW5nZXMiO2E6MDp7fXM6MTE6IgAqAHByZXZpb3VzIjthOjA6e31zOjg6IgAqAGNhc3RzIjthOjA6e31zOjE3OiIAKgBjbGFzc0Nhc3RDYWNoZSI7YTowOnt9czoyMToiACoAYXR0cmlidXRlQ2FzdENhY2hlIjthOjA6e31zOjEzOiIAKgBkYXRlRm9ybWF0IjtOO3M6MTA6IgAqAGFwcGVuZHMiO2E6MDp7fXM6MTk6IgAqAGRpc3BhdGNoZXNFdmVudHMiO2E6MDp7fXM6MTQ6IgAqAG9ic2VydmFibGVzIjthOjA6e31zOjEyOiIAKgByZWxhdGlvbnMiO2E6MDp7fXM6MTA6IgAqAHRvdWNoZXMiO2E6MDp7fXM6Mjc6IgAqAHJlbGF0aW9uQXV0b2xvYWRDYWxsYmFjayI7TjtzOjI2OiIAKgByZWxhdGlvbkF1dG9sb2FkQ29udGV4dCI7TjtzOjEwOiJ0aW1lc3RhbXBzIjtiOjE7czoxMzoidXNlc1VuaXF1ZUlkcyI7YjowO3M6OToiACoAaGlkZGVuIjthOjA6e31zOjEwOiIAKgB2aXNpYmxlIjthOjA6e31zOjExOiIAKgBmaWxsYWJsZSI7YTozOntpOjA7czoxMjoibWVudV9tYWluX2lkIjtpOjE7czo2OiJsb2NhbGUiO2k6MjtzOjQ6ImRhdGEiO31zOjEwOiIAKgBndWFyZGVkIjthOjE6e2k6MDtzOjE6IioiO319fXM6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDt9czo5OiJjaGlsZHJlbnMiO086Mzk6IklsbHVtaW5hdGVcRGF0YWJhc2VcRWxvcXVlbnRcQ29sbGVjdGlvbiI6Mjp7czo4OiIAKgBpdGVtcyI7YTowOnt9czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO319czoxMDoiACoAdG91Y2hlcyI7YTowOnt9czoyNzoiACoAcmVsYXRpb25BdXRvbG9hZENhbGxiYWNrIjtOO3M6MjY6IgAqAHJlbGF0aW9uQXV0b2xvYWRDb250ZXh0IjtOO3M6MTA6InRpbWVzdGFtcHMiO2I6MTtzOjEzOiJ1c2VzVW5pcXVlSWRzIjtiOjA7czo5OiIAKgBoaWRkZW4iO2E6MDp7fXM6MTA6IgAqAHZpc2libGUiO2E6MDp7fXM6MTE6IgAqAGZpbGxhYmxlIjthOjk6e2k6MDtzOjQ6InR5cGUiO2k6MTtzOjQ6InNsdWciO2k6MjtzOjM6InVybCI7aTozO3M6NDoidGVzdCI7aTo0O3M6MTA6InNob3dfYWRtaW4iO2k6NTtzOjEwOiJzb3J0X29yZGVyIjtpOjY7czo0OiJpY29uIjtpOjc7czo2OiJzdGF0dXMiO2k6ODtzOjk6InBhcmVudF9pZCI7fXM6MTA6IgAqAGd1YXJkZWQiO2E6MTp7aTowO3M6MToiKiI7fXM6MTk6IgAqAHRyYW5zbGF0aW9uQ2FjaGUiO047fWk6MztPOjE5OiJBcHBcTW9kZWxzXE1lbnVNYWluIjozNDp7czoxMzoiACoAY29ubmVjdGlvbiI7czo1OiJwZ3NxbCI7czo4OiIAKgB0YWJsZSI7czoxMDoibWVudV9tYWlucyI7czoxMzoiACoAcHJpbWFyeUtleSI7czoyOiJpZCI7czoxMDoiACoAa2V5VHlwZSI7czozOiJpbnQiO3M6MTI6ImluY3JlbWVudGluZyI7YjoxO3M6NzoiACoAd2l0aCI7YTowOnt9czoxMjoiACoAd2l0aENvdW50IjthOjA6e31zOjE5OiJwcmV2ZW50c0xhenlMb2FkaW5nIjtiOjA7czoxMDoiACoAcGVyUGFnZSI7aToxNTtzOjY6ImV4aXN0cyI7YjoxO3M6MTg6Indhc1JlY2VudGx5Q3JlYXRlZCI7YjowO3M6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDtzOjEzOiIAKgBhdHRyaWJ1dGVzIjthOjEyOntzOjI6ImlkIjtpOjk7czo0OiJ0eXBlIjtzOjQ6InBhZ2UiO3M6NDoic2x1ZyI7czoxNDoicGFzdGFuZHByZXNlbnQiO3M6MzoidXJsIjtOO3M6NDoidGVzdCI7YjowO3M6MTA6InNob3dfYWRtaW4iO2I6MTtzOjEwOiJzb3J0X29yZGVyIjtpOjQ7czo0OiJpY29uIjtOO3M6Njoic3RhdHVzIjtiOjE7czo5OiJwYXJlbnRfaWQiO2k6NTtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI1LTEyLTIzIDA0OjU1OjUxIjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIyIDA2OjI1OjQwIjt9czoxMToiACoAb3JpZ2luYWwiO2E6MTI6e3M6MjoiaWQiO2k6OTtzOjQ6InR5cGUiO3M6NDoicGFnZSI7czo0OiJzbHVnIjtzOjE0OiJwYXN0YW5kcHJlc2VudCI7czozOiJ1cmwiO047czo0OiJ0ZXN0IjtiOjA7czoxMDoic2hvd19hZG1pbiI7YjoxO3M6MTA6InNvcnRfb3JkZXIiO2k6NDtzOjQ6Imljb24iO047czo2OiJzdGF0dXMiO2I6MTtzOjk6InBhcmVudF9pZCI7aTo1O3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjUtMTItMjMgMDQ6NTU6NTEiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDEtMjIgMDY6MjU6NDAiO31zOjEwOiIAKgBjaGFuZ2VzIjthOjA6e31zOjExOiIAKgBwcmV2aW91cyI7YTowOnt9czo4OiIAKgBjYXN0cyI7YTowOnt9czoxNzoiACoAY2xhc3NDYXN0Q2FjaGUiO2E6MDp7fXM6MjE6IgAqAGF0dHJpYnV0ZUNhc3RDYWNoZSI7YTowOnt9czoxMzoiACoAZGF0ZUZvcm1hdCI7TjtzOjEwOiIAKgBhcHBlbmRzIjthOjA6e31zOjE5OiIAKgBkaXNwYXRjaGVzRXZlbnRzIjthOjA6e31zOjE0OiIAKgBvYnNlcnZhYmxlcyI7YTowOnt9czoxMjoiACoAcmVsYXRpb25zIjthOjI6e3M6MTI6InRyYW5zbGF0aW9ucyI7TzozOToiSWxsdW1pbmF0ZVxEYXRhYmFzZVxFbG9xdWVudFxDb2xsZWN0aW9uIjoyOntzOjg6IgAqAGl0ZW1zIjthOjM6e2k6MDtPOjMwOiJBcHBcTW9kZWxzXE1lbnVNYWluVHJhbnNsYXRpb24iOjMzOntzOjEzOiIAKgBjb25uZWN0aW9uIjtzOjU6InBnc3FsIjtzOjg6IgAqAHRhYmxlIjtzOjIyOiJtZW51X21haW5fdHJhbnNsYXRpb25zIjtzOjEzOiIAKgBwcmltYXJ5S2V5IjtzOjI6ImlkIjtzOjEwOiIAKgBrZXlUeXBlIjtzOjM6ImludCI7czoxMjoiaW5jcmVtZW50aW5nIjtiOjE7czo3OiIAKgB3aXRoIjthOjA6e31zOjEyOiIAKgB3aXRoQ291bnQiO2E6MDp7fXM6MTk6InByZXZlbnRzTGF6eUxvYWRpbmciO2I6MDtzOjEwOiIAKgBwZXJQYWdlIjtpOjE1O3M6NjoiZXhpc3RzIjtiOjE7czoxODoid2FzUmVjZW50bHlDcmVhdGVkIjtiOjA7czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO3M6MTM6IgAqAGF0dHJpYnV0ZXMiO2E6Njp7czoyOiJpZCI7aToxODtzOjEyOiJtZW51X21haW5faWQiO2k6OTtzOjY6ImxvY2FsZSI7czoyOiJydSI7czo0OiJkYXRhIjtzOjg0OiJ7ImluZm8iOiBudWxsLCAidGl0bGUiOiAi0J/RgNC+0YjQu9C+0LUg0Lgg0L3QsNGB0YLQvtGP0YnQtdC1IiwgImRlc2NyaXB0aW9uIjogbnVsbH0iO3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjUtMTItMjMgMDQ6NTU6NTEiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDEtMjIgMDY6MjU6NDAiO31zOjExOiIAKgBvcmlnaW5hbCI7YTo2OntzOjI6ImlkIjtpOjE4O3M6MTI6Im1lbnVfbWFpbl9pZCI7aTo5O3M6NjoibG9jYWxlIjtzOjI6InJ1IjtzOjQ6ImRhdGEiO3M6ODQ6InsiaW5mbyI6IG51bGwsICJ0aXRsZSI6ICLQn9GA0L7RiNC70L7QtSDQuCDQvdCw0YHRgtC+0Y/RidC10LUiLCAiZGVzY3JpcHRpb24iOiBudWxsfSI7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNS0xMi0yMyAwNDo1NTo1MSI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMiAwNjoyNTo0MCI7fXM6MTA6IgAqAGNoYW5nZXMiO2E6MDp7fXM6MTE6IgAqAHByZXZpb3VzIjthOjA6e31zOjg6IgAqAGNhc3RzIjthOjA6e31zOjE3OiIAKgBjbGFzc0Nhc3RDYWNoZSI7YTowOnt9czoyMToiACoAYXR0cmlidXRlQ2FzdENhY2hlIjthOjA6e31zOjEzOiIAKgBkYXRlRm9ybWF0IjtOO3M6MTA6IgAqAGFwcGVuZHMiO2E6MDp7fXM6MTk6IgAqAGRpc3BhdGNoZXNFdmVudHMiO2E6MDp7fXM6MTQ6IgAqAG9ic2VydmFibGVzIjthOjA6e31zOjEyOiIAKgByZWxhdGlvbnMiO2E6MDp7fXM6MTA6IgAqAHRvdWNoZXMiO2E6MDp7fXM6Mjc6IgAqAHJlbGF0aW9uQXV0b2xvYWRDYWxsYmFjayI7TjtzOjI2OiIAKgByZWxhdGlvbkF1dG9sb2FkQ29udGV4dCI7TjtzOjEwOiJ0aW1lc3RhbXBzIjtiOjE7czoxMzoidXNlc1VuaXF1ZUlkcyI7YjowO3M6OToiACoAaGlkZGVuIjthOjA6e31zOjEwOiIAKgB2aXNpYmxlIjthOjA6e31zOjExOiIAKgBmaWxsYWJsZSI7YTozOntpOjA7czoxMjoibWVudV9tYWluX2lkIjtpOjE7czo2OiJsb2NhbGUiO2k6MjtzOjQ6ImRhdGEiO31zOjEwOiIAKgBndWFyZGVkIjthOjE6e2k6MDtzOjE6IioiO319aToxO086MzA6IkFwcFxNb2RlbHNcTWVudU1haW5UcmFuc2xhdGlvbiI6MzM6e3M6MTM6IgAqAGNvbm5lY3Rpb24iO3M6NToicGdzcWwiO3M6ODoiACoAdGFibGUiO3M6MjI6Im1lbnVfbWFpbl90cmFuc2xhdGlvbnMiO3M6MTM6IgAqAHByaW1hcnlLZXkiO3M6MjoiaWQiO3M6MTA6IgAqAGtleVR5cGUiO3M6MzoiaW50IjtzOjEyOiJpbmNyZW1lbnRpbmciO2I6MTtzOjc6IgAqAHdpdGgiO2E6MDp7fXM6MTI6IgAqAHdpdGhDb3VudCI7YTowOnt9czoxOToicHJldmVudHNMYXp5TG9hZGluZyI7YjowO3M6MTA6IgAqAHBlclBhZ2UiO2k6MTU7czo2OiJleGlzdHMiO2I6MTtzOjE4OiJ3YXNSZWNlbnRseUNyZWF0ZWQiO2I6MDtzOjI4OiIAKgBlc2NhcGVXaGVuQ2FzdGluZ1RvU3RyaW5nIjtiOjA7czoxMzoiACoAYXR0cmlidXRlcyI7YTo2OntzOjI6ImlkIjtpOjE3O3M6MTI6Im1lbnVfbWFpbl9pZCI7aTo5O3M6NjoibG9jYWxlIjtzOjI6InV6IjtzOjQ6ImRhdGEiO3M6NjI6InsiaW5mbyI6IG51bGwsICJ0aXRsZSI6ICJNb3ppeSB2YSBidWd1biIsICJkZXNjcmlwdGlvbiI6IG51bGx9IjtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI1LTEyLTIzIDA0OjU1OjUxIjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIyIDA2OjI1OjQwIjt9czoxMToiACoAb3JpZ2luYWwiO2E6Njp7czoyOiJpZCI7aToxNztzOjEyOiJtZW51X21haW5faWQiO2k6OTtzOjY6ImxvY2FsZSI7czoyOiJ1eiI7czo0OiJkYXRhIjtzOjYyOiJ7ImluZm8iOiBudWxsLCAidGl0bGUiOiAiTW96aXkgdmEgYnVndW4iLCAiZGVzY3JpcHRpb24iOiBudWxsfSI7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNS0xMi0yMyAwNDo1NTo1MSI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMiAwNjoyNTo0MCI7fXM6MTA6IgAqAGNoYW5nZXMiO2E6MDp7fXM6MTE6IgAqAHByZXZpb3VzIjthOjA6e31zOjg6IgAqAGNhc3RzIjthOjA6e31zOjE3OiIAKgBjbGFzc0Nhc3RDYWNoZSI7YTowOnt9czoyMToiACoAYXR0cmlidXRlQ2FzdENhY2hlIjthOjA6e31zOjEzOiIAKgBkYXRlRm9ybWF0IjtOO3M6MTA6IgAqAGFwcGVuZHMiO2E6MDp7fXM6MTk6IgAqAGRpc3BhdGNoZXNFdmVudHMiO2E6MDp7fXM6MTQ6IgAqAG9ic2VydmFibGVzIjthOjA6e31zOjEyOiIAKgByZWxhdGlvbnMiO2E6MDp7fXM6MTA6IgAqAHRvdWNoZXMiO2E6MDp7fXM6Mjc6IgAqAHJlbGF0aW9uQXV0b2xvYWRDYWxsYmFjayI7TjtzOjI2OiIAKgByZWxhdGlvbkF1dG9sb2FkQ29udGV4dCI7TjtzOjEwOiJ0aW1lc3RhbXBzIjtiOjE7czoxMzoidXNlc1VuaXF1ZUlkcyI7YjowO3M6OToiACoAaGlkZGVuIjthOjA6e31zOjEwOiIAKgB2aXNpYmxlIjthOjA6e31zOjExOiIAKgBmaWxsYWJsZSI7YTozOntpOjA7czoxMjoibWVudV9tYWluX2lkIjtpOjE7czo2OiJsb2NhbGUiO2k6MjtzOjQ6ImRhdGEiO31zOjEwOiIAKgBndWFyZGVkIjthOjE6e2k6MDtzOjE6IioiO319aToyO086MzA6IkFwcFxNb2RlbHNcTWVudU1haW5UcmFuc2xhdGlvbiI6MzM6e3M6MTM6IgAqAGNvbm5lY3Rpb24iO3M6NToicGdzcWwiO3M6ODoiACoAdGFibGUiO3M6MjI6Im1lbnVfbWFpbl90cmFuc2xhdGlvbnMiO3M6MTM6IgAqAHByaW1hcnlLZXkiO3M6MjoiaWQiO3M6MTA6IgAqAGtleVR5cGUiO3M6MzoiaW50IjtzOjEyOiJpbmNyZW1lbnRpbmciO2I6MTtzOjc6IgAqAHdpdGgiO2E6MDp7fXM6MTI6IgAqAHdpdGhDb3VudCI7YTowOnt9czoxOToicHJldmVudHNMYXp5TG9hZGluZyI7YjowO3M6MTA6IgAqAHBlclBhZ2UiO2k6MTU7czo2OiJleGlzdHMiO2I6MTtzOjE4OiJ3YXNSZWNlbnRseUNyZWF0ZWQiO2I6MDtzOjI4OiIAKgBlc2NhcGVXaGVuQ2FzdGluZ1RvU3RyaW5nIjtiOjA7czoxMzoiACoAYXR0cmlidXRlcyI7YTo2OntzOjI6ImlkIjtpOjEzMDtzOjEyOiJtZW51X21haW5faWQiO2k6OTtzOjY6ImxvY2FsZSI7czoyOiJlbiI7czo0OiJkYXRhIjtzOjY0OiJ7ImluZm8iOiBudWxsLCAidGl0bGUiOiAiUGFzdCBhbmQgcHJlc2VudCIsICJkZXNjcmlwdGlvbiI6IG51bGx9IjtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTE0IDEwOjM1OjM3IjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIyIDA2OjI1OjQwIjt9czoxMToiACoAb3JpZ2luYWwiO2E6Njp7czoyOiJpZCI7aToxMzA7czoxMjoibWVudV9tYWluX2lkIjtpOjk7czo2OiJsb2NhbGUiO3M6MjoiZW4iO3M6NDoiZGF0YSI7czo2NDoieyJpbmZvIjogbnVsbCwgInRpdGxlIjogIlBhc3QgYW5kIHByZXNlbnQiLCAiZGVzY3JpcHRpb24iOiBudWxsfSI7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNi0wMS0xNCAxMDozNTozNyI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMiAwNjoyNTo0MCI7fXM6MTA6IgAqAGNoYW5nZXMiO2E6MDp7fXM6MTE6IgAqAHByZXZpb3VzIjthOjA6e31zOjg6IgAqAGNhc3RzIjthOjA6e31zOjE3OiIAKgBjbGFzc0Nhc3RDYWNoZSI7YTowOnt9czoyMToiACoAYXR0cmlidXRlQ2FzdENhY2hlIjthOjA6e31zOjEzOiIAKgBkYXRlRm9ybWF0IjtOO3M6MTA6IgAqAGFwcGVuZHMiO2E6MDp7fXM6MTk6IgAqAGRpc3BhdGNoZXNFdmVudHMiO2E6MDp7fXM6MTQ6IgAqAG9ic2VydmFibGVzIjthOjA6e31zOjEyOiIAKgByZWxhdGlvbnMiO2E6MDp7fXM6MTA6IgAqAHRvdWNoZXMiO2E6MDp7fXM6Mjc6IgAqAHJlbGF0aW9uQXV0b2xvYWRDYWxsYmFjayI7TjtzOjI2OiIAKgByZWxhdGlvbkF1dG9sb2FkQ29udGV4dCI7TjtzOjEwOiJ0aW1lc3RhbXBzIjtiOjE7czoxMzoidXNlc1VuaXF1ZUlkcyI7YjowO3M6OToiACoAaGlkZGVuIjthOjA6e31zOjEwOiIAKgB2aXNpYmxlIjthOjA6e31zOjExOiIAKgBmaWxsYWJsZSI7YTozOntpOjA7czoxMjoibWVudV9tYWluX2lkIjtpOjE7czo2OiJsb2NhbGUiO2k6MjtzOjQ6ImRhdGEiO31zOjEwOiIAKgBndWFyZGVkIjthOjE6e2k6MDtzOjE6IioiO319fXM6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDt9czo5OiJjaGlsZHJlbnMiO086Mzk6IklsbHVtaW5hdGVcRGF0YWJhc2VcRWxvcXVlbnRcQ29sbGVjdGlvbiI6Mjp7czo4OiIAKgBpdGVtcyI7YTowOnt9czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO319czoxMDoiACoAdG91Y2hlcyI7YTowOnt9czoyNzoiACoAcmVsYXRpb25BdXRvbG9hZENhbGxiYWNrIjtOO3M6MjY6IgAqAHJlbGF0aW9uQXV0b2xvYWRDb250ZXh0IjtOO3M6MTA6InRpbWVzdGFtcHMiO2I6MTtzOjEzOiJ1c2VzVW5pcXVlSWRzIjtiOjA7czo5OiIAKgBoaWRkZW4iO2E6MDp7fXM6MTA6IgAqAHZpc2libGUiO2E6MDp7fXM6MTE6IgAqAGZpbGxhYmxlIjthOjk6e2k6MDtzOjQ6InR5cGUiO2k6MTtzOjQ6InNsdWciO2k6MjtzOjM6InVybCI7aTozO3M6NDoidGVzdCI7aTo0O3M6MTA6InNob3dfYWRtaW4iO2k6NTtzOjEwOiJzb3J0X29yZGVyIjtpOjY7czo0OiJpY29uIjtpOjc7czo2OiJzdGF0dXMiO2k6ODtzOjk6InBhcmVudF9pZCI7fXM6MTA6IgAqAGd1YXJkZWQiO2E6MTp7aTowO3M6MToiKiI7fXM6MTk6IgAqAHRyYW5zbGF0aW9uQ2FjaGUiO047fWk6NDtPOjE5OiJBcHBcTW9kZWxzXE1lbnVNYWluIjozNDp7czoxMzoiACoAY29ubmVjdGlvbiI7czo1OiJwZ3NxbCI7czo4OiIAKgB0YWJsZSI7czoxMDoibWVudV9tYWlucyI7czoxMzoiACoAcHJpbWFyeUtleSI7czoyOiJpZCI7czoxMDoiACoAa2V5VHlwZSI7czozOiJpbnQiO3M6MTI6ImluY3JlbWVudGluZyI7YjoxO3M6NzoiACoAd2l0aCI7YTowOnt9czoxMjoiACoAd2l0aENvdW50IjthOjA6e31zOjE5OiJwcmV2ZW50c0xhenlMb2FkaW5nIjtiOjA7czoxMDoiACoAcGVyUGFnZSI7aToxNTtzOjY6ImV4aXN0cyI7YjoxO3M6MTg6Indhc1JlY2VudGx5Q3JlYXRlZCI7YjowO3M6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDtzOjEzOiIAKgBhdHRyaWJ1dGVzIjthOjEyOntzOjI6ImlkIjtpOjEwO3M6NDoidHlwZSI7czo0OiJwYWdlIjtzOjQ6InNsdWciO3M6OToibG9jYXRpb25zIjtzOjM6InVybCI7TjtzOjQ6InRlc3QiO2I6MDtzOjEwOiJzaG93X2FkbWluIjtiOjE7czoxMDoic29ydF9vcmRlciI7aTo1O3M6NDoiaWNvbiI7TjtzOjY6InN0YXR1cyI7YjoxO3M6OToicGFyZW50X2lkIjtpOjU7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNS0xMi0yMyAwNDo1Njo1NSI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMiAwNjoyNzo0NSI7fXM6MTE6IgAqAG9yaWdpbmFsIjthOjEyOntzOjI6ImlkIjtpOjEwO3M6NDoidHlwZSI7czo0OiJwYWdlIjtzOjQ6InNsdWciO3M6OToibG9jYXRpb25zIjtzOjM6InVybCI7TjtzOjQ6InRlc3QiO2I6MDtzOjEwOiJzaG93X2FkbWluIjtiOjE7czoxMDoic29ydF9vcmRlciI7aTo1O3M6NDoiaWNvbiI7TjtzOjY6InN0YXR1cyI7YjoxO3M6OToicGFyZW50X2lkIjtpOjU7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNS0xMi0yMyAwNDo1Njo1NSI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMiAwNjoyNzo0NSI7fXM6MTA6IgAqAGNoYW5nZXMiO2E6MDp7fXM6MTE6IgAqAHByZXZpb3VzIjthOjA6e31zOjg6IgAqAGNhc3RzIjthOjA6e31zOjE3OiIAKgBjbGFzc0Nhc3RDYWNoZSI7YTowOnt9czoyMToiACoAYXR0cmlidXRlQ2FzdENhY2hlIjthOjA6e31zOjEzOiIAKgBkYXRlRm9ybWF0IjtOO3M6MTA6IgAqAGFwcGVuZHMiO2E6MDp7fXM6MTk6IgAqAGRpc3BhdGNoZXNFdmVudHMiO2E6MDp7fXM6MTQ6IgAqAG9ic2VydmFibGVzIjthOjA6e31zOjEyOiIAKgByZWxhdGlvbnMiO2E6Mjp7czoxMjoidHJhbnNsYXRpb25zIjtPOjM5OiJJbGx1bWluYXRlXERhdGFiYXNlXEVsb3F1ZW50XENvbGxlY3Rpb24iOjI6e3M6ODoiACoAaXRlbXMiO2E6Mzp7aTowO086MzA6IkFwcFxNb2RlbHNcTWVudU1haW5UcmFuc2xhdGlvbiI6MzM6e3M6MTM6IgAqAGNvbm5lY3Rpb24iO3M6NToicGdzcWwiO3M6ODoiACoAdGFibGUiO3M6MjI6Im1lbnVfbWFpbl90cmFuc2xhdGlvbnMiO3M6MTM6IgAqAHByaW1hcnlLZXkiO3M6MjoiaWQiO3M6MTA6IgAqAGtleVR5cGUiO3M6MzoiaW50IjtzOjEyOiJpbmNyZW1lbnRpbmciO2I6MTtzOjc6IgAqAHdpdGgiO2E6MDp7fXM6MTI6IgAqAHdpdGhDb3VudCI7YTowOnt9czoxOToicHJldmVudHNMYXp5TG9hZGluZyI7YjowO3M6MTA6IgAqAHBlclBhZ2UiO2k6MTU7czo2OiJleGlzdHMiO2I6MTtzOjE4OiJ3YXNSZWNlbnRseUNyZWF0ZWQiO2I6MDtzOjI4OiIAKgBlc2NhcGVXaGVuQ2FzdGluZ1RvU3RyaW5nIjtiOjA7czoxMzoiACoAYXR0cmlidXRlcyI7YTo2OntzOjI6ImlkIjtpOjIwO3M6MTI6Im1lbnVfbWFpbl9pZCI7aToxMDtzOjY6ImxvY2FsZSI7czoyOiJydSI7czo0OiJkYXRhIjtzOjgzOiJ7ImluZm8iOiBudWxsLCAidGl0bGUiOiAi0JzQtdGB0YLQsCDRgNCw0YHQv9C+0LvQvtC20LXQvdC40Y8iLCAiZGVzY3JpcHRpb24iOiBudWxsfSI7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNS0xMi0yMyAwNDo1Njo1NSI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMiAwNjoyNzo0NSI7fXM6MTE6IgAqAG9yaWdpbmFsIjthOjY6e3M6MjoiaWQiO2k6MjA7czoxMjoibWVudV9tYWluX2lkIjtpOjEwO3M6NjoibG9jYWxlIjtzOjI6InJ1IjtzOjQ6ImRhdGEiO3M6ODM6InsiaW5mbyI6IG51bGwsICJ0aXRsZSI6ICLQnNC10YHRgtCwINGA0LDRgdC/0L7Qu9C+0LbQtdC90LjRjyIsICJkZXNjcmlwdGlvbiI6IG51bGx9IjtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI1LTEyLTIzIDA0OjU2OjU1IjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIyIDA2OjI3OjQ1Ijt9czoxMDoiACoAY2hhbmdlcyI7YTowOnt9czoxMToiACoAcHJldmlvdXMiO2E6MDp7fXM6ODoiACoAY2FzdHMiO2E6MDp7fXM6MTc6IgAqAGNsYXNzQ2FzdENhY2hlIjthOjA6e31zOjIxOiIAKgBhdHRyaWJ1dGVDYXN0Q2FjaGUiO2E6MDp7fXM6MTM6IgAqAGRhdGVGb3JtYXQiO047czoxMDoiACoAYXBwZW5kcyI7YTowOnt9czoxOToiACoAZGlzcGF0Y2hlc0V2ZW50cyI7YTowOnt9czoxNDoiACoAb2JzZXJ2YWJsZXMiO2E6MDp7fXM6MTI6IgAqAHJlbGF0aW9ucyI7YTowOnt9czoxMDoiACoAdG91Y2hlcyI7YTowOnt9czoyNzoiACoAcmVsYXRpb25BdXRvbG9hZENhbGxiYWNrIjtOO3M6MjY6IgAqAHJlbGF0aW9uQXV0b2xvYWRDb250ZXh0IjtOO3M6MTA6InRpbWVzdGFtcHMiO2I6MTtzOjEzOiJ1c2VzVW5pcXVlSWRzIjtiOjA7czo5OiIAKgBoaWRkZW4iO2E6MDp7fXM6MTA6IgAqAHZpc2libGUiO2E6MDp7fXM6MTE6IgAqAGZpbGxhYmxlIjthOjM6e2k6MDtzOjEyOiJtZW51X21haW5faWQiO2k6MTtzOjY6ImxvY2FsZSI7aToyO3M6NDoiZGF0YSI7fXM6MTA6IgAqAGd1YXJkZWQiO2E6MTp7aTowO3M6MToiKiI7fX1pOjE7TzozMDoiQXBwXE1vZGVsc1xNZW51TWFpblRyYW5zbGF0aW9uIjozMzp7czoxMzoiACoAY29ubmVjdGlvbiI7czo1OiJwZ3NxbCI7czo4OiIAKgB0YWJsZSI7czoyMjoibWVudV9tYWluX3RyYW5zbGF0aW9ucyI7czoxMzoiACoAcHJpbWFyeUtleSI7czoyOiJpZCI7czoxMDoiACoAa2V5VHlwZSI7czozOiJpbnQiO3M6MTI6ImluY3JlbWVudGluZyI7YjoxO3M6NzoiACoAd2l0aCI7YTowOnt9czoxMjoiACoAd2l0aENvdW50IjthOjA6e31zOjE5OiJwcmV2ZW50c0xhenlMb2FkaW5nIjtiOjA7czoxMDoiACoAcGVyUGFnZSI7aToxNTtzOjY6ImV4aXN0cyI7YjoxO3M6MTg6Indhc1JlY2VudGx5Q3JlYXRlZCI7YjowO3M6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDtzOjEzOiIAKgBhdHRyaWJ1dGVzIjthOjY6e3M6MjoiaWQiO2k6MTk7czoxMjoibWVudV9tYWluX2lkIjtpOjEwO3M6NjoibG9jYWxlIjtzOjI6InV6IjtzOjQ6ImRhdGEiO3M6NjA6InsiaW5mbyI6IG51bGwsICJ0aXRsZSI6ICJNYW56aWxnb2hsYXIiLCAiZGVzY3JpcHRpb24iOiBudWxsfSI7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNS0xMi0yMyAwNDo1Njo1NSI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMiAwNjoyNzo0NSI7fXM6MTE6IgAqAG9yaWdpbmFsIjthOjY6e3M6MjoiaWQiO2k6MTk7czoxMjoibWVudV9tYWluX2lkIjtpOjEwO3M6NjoibG9jYWxlIjtzOjI6InV6IjtzOjQ6ImRhdGEiO3M6NjA6InsiaW5mbyI6IG51bGwsICJ0aXRsZSI6ICJNYW56aWxnb2hsYXIiLCAiZGVzY3JpcHRpb24iOiBudWxsfSI7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNS0xMi0yMyAwNDo1Njo1NSI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMiAwNjoyNzo0NSI7fXM6MTA6IgAqAGNoYW5nZXMiO2E6MDp7fXM6MTE6IgAqAHByZXZpb3VzIjthOjA6e31zOjg6IgAqAGNhc3RzIjthOjA6e31zOjE3OiIAKgBjbGFzc0Nhc3RDYWNoZSI7YTowOnt9czoyMToiACoAYXR0cmlidXRlQ2FzdENhY2hlIjthOjA6e31zOjEzOiIAKgBkYXRlRm9ybWF0IjtOO3M6MTA6IgAqAGFwcGVuZHMiO2E6MDp7fXM6MTk6IgAqAGRpc3BhdGNoZXNFdmVudHMiO2E6MDp7fXM6MTQ6IgAqAG9ic2VydmFibGVzIjthOjA6e31zOjEyOiIAKgByZWxhdGlvbnMiO2E6MDp7fXM6MTA6IgAqAHRvdWNoZXMiO2E6MDp7fXM6Mjc6IgAqAHJlbGF0aW9uQXV0b2xvYWRDYWxsYmFjayI7TjtzOjI2OiIAKgByZWxhdGlvbkF1dG9sb2FkQ29udGV4dCI7TjtzOjEwOiJ0aW1lc3RhbXBzIjtiOjE7czoxMzoidXNlc1VuaXF1ZUlkcyI7YjowO3M6OToiACoAaGlkZGVuIjthOjA6e31zOjEwOiIAKgB2aXNpYmxlIjthOjA6e31zOjExOiIAKgBmaWxsYWJsZSI7YTozOntpOjA7czoxMjoibWVudV9tYWluX2lkIjtpOjE7czo2OiJsb2NhbGUiO2k6MjtzOjQ6ImRhdGEiO31zOjEwOiIAKgBndWFyZGVkIjthOjE6e2k6MDtzOjE6IioiO319aToyO086MzA6IkFwcFxNb2RlbHNcTWVudU1haW5UcmFuc2xhdGlvbiI6MzM6e3M6MTM6IgAqAGNvbm5lY3Rpb24iO3M6NToicGdzcWwiO3M6ODoiACoAdGFibGUiO3M6MjI6Im1lbnVfbWFpbl90cmFuc2xhdGlvbnMiO3M6MTM6IgAqAHByaW1hcnlLZXkiO3M6MjoiaWQiO3M6MTA6IgAqAGtleVR5cGUiO3M6MzoiaW50IjtzOjEyOiJpbmNyZW1lbnRpbmciO2I6MTtzOjc6IgAqAHdpdGgiO2E6MDp7fXM6MTI6IgAqAHdpdGhDb3VudCI7YTowOnt9czoxOToicHJldmVudHNMYXp5TG9hZGluZyI7YjowO3M6MTA6IgAqAHBlclBhZ2UiO2k6MTU7czo2OiJleGlzdHMiO2I6MTtzOjE4OiJ3YXNSZWNlbnRseUNyZWF0ZWQiO2I6MDtzOjI4OiIAKgBlc2NhcGVXaGVuQ2FzdGluZ1RvU3RyaW5nIjtiOjA7czoxMzoiACoAYXR0cmlidXRlcyI7YTo2OntzOjI6ImlkIjtpOjEzMTtzOjEyOiJtZW51X21haW5faWQiO2k6MTA7czo2OiJsb2NhbGUiO3M6MjoiZW4iO3M6NDoiZGF0YSI7czo1NzoieyJpbmZvIjogbnVsbCwgInRpdGxlIjogIkxvY2F0aW9ucyIsICJkZXNjcmlwdGlvbiI6IG51bGx9IjtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTE0IDEwOjM2OjA5IjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIyIDA2OjI3OjQ1Ijt9czoxMToiACoAb3JpZ2luYWwiO2E6Njp7czoyOiJpZCI7aToxMzE7czoxMjoibWVudV9tYWluX2lkIjtpOjEwO3M6NjoibG9jYWxlIjtzOjI6ImVuIjtzOjQ6ImRhdGEiO3M6NTc6InsiaW5mbyI6IG51bGwsICJ0aXRsZSI6ICJMb2NhdGlvbnMiLCAiZGVzY3JpcHRpb24iOiBudWxsfSI7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNi0wMS0xNCAxMDozNjowOSI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMiAwNjoyNzo0NSI7fXM6MTA6IgAqAGNoYW5nZXMiO2E6MDp7fXM6MTE6IgAqAHByZXZpb3VzIjthOjA6e31zOjg6IgAqAGNhc3RzIjthOjA6e31zOjE3OiIAKgBjbGFzc0Nhc3RDYWNoZSI7YTowOnt9czoyMToiACoAYXR0cmlidXRlQ2FzdENhY2hlIjthOjA6e31zOjEzOiIAKgBkYXRlRm9ybWF0IjtOO3M6MTA6IgAqAGFwcGVuZHMiO2E6MDp7fXM6MTk6IgAqAGRpc3BhdGNoZXNFdmVudHMiO2E6MDp7fXM6MTQ6IgAqAG9ic2VydmFibGVzIjthOjA6e31zOjEyOiIAKgByZWxhdGlvbnMiO2E6MDp7fXM6MTA6IgAqAHRvdWNoZXMiO2E6MDp7fXM6Mjc6IgAqAHJlbGF0aW9uQXV0b2xvYWRDYWxsYmFjayI7TjtzOjI2OiIAKgByZWxhdGlvbkF1dG9sb2FkQ29udGV4dCI7TjtzOjEwOiJ0aW1lc3RhbXBzIjtiOjE7czoxMzoidXNlc1VuaXF1ZUlkcyI7YjowO3M6OToiACoAaGlkZGVuIjthOjA6e31zOjEwOiIAKgB2aXNpYmxlIjthOjA6e31zOjExOiIAKgBmaWxsYWJsZSI7YTozOntpOjA7czoxMjoibWVudV9tYWluX2lkIjtpOjE7czo2OiJsb2NhbGUiO2k6MjtzOjQ6ImRhdGEiO31zOjEwOiIAKgBndWFyZGVkIjthOjE6e2k6MDtzOjE6IioiO319fXM6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDt9czo5OiJjaGlsZHJlbnMiO086Mzk6IklsbHVtaW5hdGVcRGF0YWJhc2VcRWxvcXVlbnRcQ29sbGVjdGlvbiI6Mjp7czo4OiIAKgBpdGVtcyI7YTowOnt9czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO319czoxMDoiACoAdG91Y2hlcyI7YTowOnt9czoyNzoiACoAcmVsYXRpb25BdXRvbG9hZENhbGxiYWNrIjtOO3M6MjY6IgAqAHJlbGF0aW9uQXV0b2xvYWRDb250ZXh0IjtOO3M6MTA6InRpbWVzdGFtcHMiO2I6MTtzOjEzOiJ1c2VzVW5pcXVlSWRzIjtiOjA7czo5OiIAKgBoaWRkZW4iO2E6MDp7fXM6MTA6IgAqAHZpc2libGUiO2E6MDp7fXM6MTE6IgAqAGZpbGxhYmxlIjthOjk6e2k6MDtzOjQ6InR5cGUiO2k6MTtzOjQ6InNsdWciO2k6MjtzOjM6InVybCI7aTozO3M6NDoidGVzdCI7aTo0O3M6MTA6InNob3dfYWRtaW4iO2k6NTtzOjEwOiJzb3J0X29yZGVyIjtpOjY7czo0OiJpY29uIjtpOjc7czo2OiJzdGF0dXMiO2k6ODtzOjk6InBhcmVudF9pZCI7fXM6MTA6IgAqAGd1YXJkZWQiO2E6MTp7aTowO3M6MToiKiI7fXM6MTk6IgAqAHRyYW5zbGF0aW9uQ2FjaGUiO047fX1zOjI4OiIAKgBlc2NhcGVXaGVuQ2FzdGluZ1RvU3RyaW5nIjtiOjA7fXM6MTI6InRyYW5zbGF0aW9ucyI7TzozOToiSWxsdW1pbmF0ZVxEYXRhYmFzZVxFbG9xdWVudFxDb2xsZWN0aW9uIjoyOntzOjg6IgAqAGl0ZW1zIjthOjM6e2k6MDtPOjMwOiJBcHBcTW9kZWxzXE1lbnVNYWluVHJhbnNsYXRpb24iOjMzOntzOjEzOiIAKgBjb25uZWN0aW9uIjtzOjU6InBnc3FsIjtzOjg6IgAqAHRhYmxlIjtzOjIyOiJtZW51X21haW5fdHJhbnNsYXRpb25zIjtzOjEzOiIAKgBwcmltYXJ5S2V5IjtzOjI6ImlkIjtzOjEwOiIAKgBrZXlUeXBlIjtzOjM6ImludCI7czoxMjoiaW5jcmVtZW50aW5nIjtiOjE7czo3OiIAKgB3aXRoIjthOjA6e31zOjEyOiIAKgB3aXRoQ291bnQiO2E6MDp7fXM6MTk6InByZXZlbnRzTGF6eUxvYWRpbmciO2I6MDtzOjEwOiIAKgBwZXJQYWdlIjtpOjE1O3M6NjoiZXhpc3RzIjtiOjE7czoxODoid2FzUmVjZW50bHlDcmVhdGVkIjtiOjA7czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO3M6MTM6IgAqAGF0dHJpYnV0ZXMiO2E6Njp7czoyOiJpZCI7aTo1NTtzOjEyOiJtZW51X21haW5faWQiO2k6NTtzOjY6ImxvY2FsZSI7czoyOiJlbiI7czo0OiJkYXRhIjtzOjU4OiJ7ImluZm8iOiBudWxsLCAidGl0bGUiOiAiVXpiZWtpc3RhbiIsICJkZXNjcmlwdGlvbiI6IG51bGx9IjtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI1LTEyLTI1IDEyOjEzOjUyIjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIxIDE5OjQ1OjUyIjt9czoxMToiACoAb3JpZ2luYWwiO2E6Njp7czoyOiJpZCI7aTo1NTtzOjEyOiJtZW51X21haW5faWQiO2k6NTtzOjY6ImxvY2FsZSI7czoyOiJlbiI7czo0OiJkYXRhIjtzOjU4OiJ7ImluZm8iOiBudWxsLCAidGl0bGUiOiAiVXpiZWtpc3RhbiIsICJkZXNjcmlwdGlvbiI6IG51bGx9IjtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI1LTEyLTI1IDEyOjEzOjUyIjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIxIDE5OjQ1OjUyIjt9czoxMDoiACoAY2hhbmdlcyI7YTowOnt9czoxMToiACoAcHJldmlvdXMiO2E6MDp7fXM6ODoiACoAY2FzdHMiO2E6MDp7fXM6MTc6IgAqAGNsYXNzQ2FzdENhY2hlIjthOjA6e31zOjIxOiIAKgBhdHRyaWJ1dGVDYXN0Q2FjaGUiO2E6MDp7fXM6MTM6IgAqAGRhdGVGb3JtYXQiO047czoxMDoiACoAYXBwZW5kcyI7YTowOnt9czoxOToiACoAZGlzcGF0Y2hlc0V2ZW50cyI7YTowOnt9czoxNDoiACoAb2JzZXJ2YWJsZXMiO2E6MDp7fXM6MTI6IgAqAHJlbGF0aW9ucyI7YTowOnt9czoxMDoiACoAdG91Y2hlcyI7YTowOnt9czoyNzoiACoAcmVsYXRpb25BdXRvbG9hZENhbGxiYWNrIjtOO3M6MjY6IgAqAHJlbGF0aW9uQXV0b2xvYWRDb250ZXh0IjtOO3M6MTA6InRpbWVzdGFtcHMiO2I6MTtzOjEzOiJ1c2VzVW5pcXVlSWRzIjtiOjA7czo5OiIAKgBoaWRkZW4iO2E6MDp7fXM6MTA6IgAqAHZpc2libGUiO2E6MDp7fXM6MTE6IgAqAGZpbGxhYmxlIjthOjM6e2k6MDtzOjEyOiJtZW51X21haW5faWQiO2k6MTtzOjY6ImxvY2FsZSI7aToyO3M6NDoiZGF0YSI7fXM6MTA6IgAqAGd1YXJkZWQiO2E6MTp7aTowO3M6MToiKiI7fX1pOjE7TzozMDoiQXBwXE1vZGVsc1xNZW51TWFpblRyYW5zbGF0aW9uIjozMzp7czoxMzoiACoAY29ubmVjdGlvbiI7czo1OiJwZ3NxbCI7czo4OiIAKgB0YWJsZSI7czoyMjoibWVudV9tYWluX3RyYW5zbGF0aW9ucyI7czoxMzoiACoAcHJpbWFyeUtleSI7czoyOiJpZCI7czoxMDoiACoAa2V5VHlwZSI7czozOiJpbnQiO3M6MTI6ImluY3JlbWVudGluZyI7YjoxO3M6NzoiACoAd2l0aCI7YTowOnt9czoxMjoiACoAd2l0aENvdW50IjthOjA6e31zOjE5OiJwcmV2ZW50c0xhenlMb2FkaW5nIjtiOjA7czoxMDoiACoAcGVyUGFnZSI7aToxNTtzOjY6ImV4aXN0cyI7YjoxO3M6MTg6Indhc1JlY2VudGx5Q3JlYXRlZCI7YjowO3M6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDtzOjEzOiIAKgBhdHRyaWJ1dGVzIjthOjY6e3M6MjoiaWQiO2k6MTA7czoxMjoibWVudV9tYWluX2lkIjtpOjU7czo2OiJsb2NhbGUiO3M6MjoicnUiO3M6NDoiZGF0YSI7czo2ODoieyJpbmZvIjogbnVsbCwgInRpdGxlIjogItCj0LfQsdC10LrQuNGB0YLQsNC9IiwgImRlc2NyaXB0aW9uIjogbnVsbH0iO3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjUtMTItMjMgMDQ6NTE6MzUiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDEtMjEgMTk6NDU6NTIiO31zOjExOiIAKgBvcmlnaW5hbCI7YTo2OntzOjI6ImlkIjtpOjEwO3M6MTI6Im1lbnVfbWFpbl9pZCI7aTo1O3M6NjoibG9jYWxlIjtzOjI6InJ1IjtzOjQ6ImRhdGEiO3M6Njg6InsiaW5mbyI6IG51bGwsICJ0aXRsZSI6ICLQo9C30LHQtdC60LjRgdGC0LDQvSIsICJkZXNjcmlwdGlvbiI6IG51bGx9IjtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI1LTEyLTIzIDA0OjUxOjM1IjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIxIDE5OjQ1OjUyIjt9czoxMDoiACoAY2hhbmdlcyI7YTowOnt9czoxMToiACoAcHJldmlvdXMiO2E6MDp7fXM6ODoiACoAY2FzdHMiO2E6MDp7fXM6MTc6IgAqAGNsYXNzQ2FzdENhY2hlIjthOjA6e31zOjIxOiIAKgBhdHRyaWJ1dGVDYXN0Q2FjaGUiO2E6MDp7fXM6MTM6IgAqAGRhdGVGb3JtYXQiO047czoxMDoiACoAYXBwZW5kcyI7YTowOnt9czoxOToiACoAZGlzcGF0Y2hlc0V2ZW50cyI7YTowOnt9czoxNDoiACoAb2JzZXJ2YWJsZXMiO2E6MDp7fXM6MTI6IgAqAHJlbGF0aW9ucyI7YTowOnt9czoxMDoiACoAdG91Y2hlcyI7YTowOnt9czoyNzoiACoAcmVsYXRpb25BdXRvbG9hZENhbGxiYWNrIjtOO3M6MjY6IgAqAHJlbGF0aW9uQXV0b2xvYWRDb250ZXh0IjtOO3M6MTA6InRpbWVzdGFtcHMiO2I6MTtzOjEzOiJ1c2VzVW5pcXVlSWRzIjtiOjA7czo5OiIAKgBoaWRkZW4iO2E6MDp7fXM6MTA6IgAqAHZpc2libGUiO2E6MDp7fXM6MTE6IgAqAGZpbGxhYmxlIjthOjM6e2k6MDtzOjEyOiJtZW51X21haW5faWQiO2k6MTtzOjY6ImxvY2FsZSI7aToyO3M6NDoiZGF0YSI7fXM6MTA6IgAqAGd1YXJkZWQiO2E6MTp7aTowO3M6MToiKiI7fX1pOjI7TzozMDoiQXBwXE1vZGVsc1xNZW51TWFpblRyYW5zbGF0aW9uIjozMzp7czoxMzoiACoAY29ubmVjdGlvbiI7czo1OiJwZ3NxbCI7czo4OiIAKgB0YWJsZSI7czoyMjoibWVudV9tYWluX3RyYW5zbGF0aW9ucyI7czoxMzoiACoAcHJpbWFyeUtleSI7czoyOiJpZCI7czoxMDoiACoAa2V5VHlwZSI7czozOiJpbnQiO3M6MTI6ImluY3JlbWVudGluZyI7YjoxO3M6NzoiACoAd2l0aCI7YTowOnt9czoxMjoiACoAd2l0aENvdW50IjthOjA6e31zOjE5OiJwcmV2ZW50c0xhenlMb2FkaW5nIjtiOjA7czoxMDoiACoAcGVyUGFnZSI7aToxNTtzOjY6ImV4aXN0cyI7YjoxO3M6MTg6Indhc1JlY2VudGx5Q3JlYXRlZCI7YjowO3M6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDtzOjEzOiIAKgBhdHRyaWJ1dGVzIjthOjY6e3M6MjoiaWQiO2k6OTtzOjEyOiJtZW51X21haW5faWQiO2k6NTtzOjY6ImxvY2FsZSI7czoyOiJ1eiI7czo0OiJkYXRhIjtzOjU4OiJ7ImluZm8iOiBudWxsLCAidGl0bGUiOiAiT3piZWtpc3RvbiIsICJkZXNjcmlwdGlvbiI6IG51bGx9IjtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI1LTEyLTIzIDA0OjUxOjM1IjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIxIDE5OjQ1OjUyIjt9czoxMToiACoAb3JpZ2luYWwiO2E6Njp7czoyOiJpZCI7aTo5O3M6MTI6Im1lbnVfbWFpbl9pZCI7aTo1O3M6NjoibG9jYWxlIjtzOjI6InV6IjtzOjQ6ImRhdGEiO3M6NTg6InsiaW5mbyI6IG51bGwsICJ0aXRsZSI6ICJPemJla2lzdG9uIiwgImRlc2NyaXB0aW9uIjogbnVsbH0iO3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjUtMTItMjMgMDQ6NTE6MzUiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDEtMjEgMTk6NDU6NTIiO31zOjEwOiIAKgBjaGFuZ2VzIjthOjA6e31zOjExOiIAKgBwcmV2aW91cyI7YTowOnt9czo4OiIAKgBjYXN0cyI7YTowOnt9czoxNzoiACoAY2xhc3NDYXN0Q2FjaGUiO2E6MDp7fXM6MjE6IgAqAGF0dHJpYnV0ZUNhc3RDYWNoZSI7YTowOnt9czoxMzoiACoAZGF0ZUZvcm1hdCI7TjtzOjEwOiIAKgBhcHBlbmRzIjthOjA6e31zOjE5OiIAKgBkaXNwYXRjaGVzRXZlbnRzIjthOjA6e31zOjE0OiIAKgBvYnNlcnZhYmxlcyI7YTowOnt9czoxMjoiACoAcmVsYXRpb25zIjthOjA6e31zOjEwOiIAKgB0b3VjaGVzIjthOjA6e31zOjI3OiIAKgByZWxhdGlvbkF1dG9sb2FkQ2FsbGJhY2siO047czoyNjoiACoAcmVsYXRpb25BdXRvbG9hZENvbnRleHQiO047czoxMDoidGltZXN0YW1wcyI7YjoxO3M6MTM6InVzZXNVbmlxdWVJZHMiO2I6MDtzOjk6IgAqAGhpZGRlbiI7YTowOnt9czoxMDoiACoAdmlzaWJsZSI7YTowOnt9czoxMToiACoAZmlsbGFibGUiO2E6Mzp7aTowO3M6MTI6Im1lbnVfbWFpbl9pZCI7aToxO3M6NjoibG9jYWxlIjtpOjI7czo0OiJkYXRhIjt9czoxMDoiACoAZ3VhcmRlZCI7YToxOntpOjA7czoxOiIqIjt9fX1zOjI4OiIAKgBlc2NhcGVXaGVuQ2FzdGluZ1RvU3RyaW5nIjtiOjA7fX1zOjEwOiIAKgB0b3VjaGVzIjthOjA6e31zOjI3OiIAKgByZWxhdGlvbkF1dG9sb2FkQ2FsbGJhY2siO047czoyNjoiACoAcmVsYXRpb25BdXRvbG9hZENvbnRleHQiO047czoxMDoidGltZXN0YW1wcyI7YjoxO3M6MTM6InVzZXNVbmlxdWVJZHMiO2I6MDtzOjk6IgAqAGhpZGRlbiI7YTowOnt9czoxMDoiACoAdmlzaWJsZSI7YTowOnt9czoxMToiACoAZmlsbGFibGUiO2E6OTp7aTowO3M6NDoidHlwZSI7aToxO3M6NDoic2x1ZyI7aToyO3M6MzoidXJsIjtpOjM7czo0OiJ0ZXN0IjtpOjQ7czoxMDoic2hvd19hZG1pbiI7aTo1O3M6MTA6InNvcnRfb3JkZXIiO2k6NjtzOjQ6Imljb24iO2k6NztzOjY6InN0YXR1cyI7aTo4O3M6OToicGFyZW50X2lkIjt9czoxMDoiACoAZ3VhcmRlZCI7YToxOntpOjA7czoxOiIqIjt9czoxOToiACoAdHJhbnNsYXRpb25DYWNoZSI7Tjt9aToxO086MTk6IkFwcFxNb2RlbHNcTWVudU1haW4iOjM0OntzOjEzOiIAKgBjb25uZWN0aW9uIjtzOjU6InBnc3FsIjtzOjg6IgAqAHRhYmxlIjtzOjEwOiJtZW51X21haW5zIjtzOjEzOiIAKgBwcmltYXJ5S2V5IjtzOjI6ImlkIjtzOjEwOiIAKgBrZXlUeXBlIjtzOjM6ImludCI7czoxMjoiaW5jcmVtZW50aW5nIjtiOjE7czo3OiIAKgB3aXRoIjthOjA6e31zOjEyOiIAKgB3aXRoQ291bnQiO2E6MDp7fXM6MTk6InByZXZlbnRzTGF6eUxvYWRpbmciO2I6MDtzOjEwOiIAKgBwZXJQYWdlIjtpOjE1O3M6NjoiZXhpc3RzIjtiOjE7czoxODoid2FzUmVjZW50bHlDcmVhdGVkIjtiOjA7czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO3M6MTM6IgAqAGF0dHJpYnV0ZXMiO2E6MTI6e3M6MjoiaWQiO2k6MTM7czo0OiJ0eXBlIjtzOjg6ImNhdGVnb3J5IjtzOjQ6InNsdWciO3M6MTM6ImJpei1oYXFpbWl6ZGEiO3M6MzoidXJsIjtOO3M6NDoidGVzdCI7YjowO3M6MTA6InNob3dfYWRtaW4iO2I6MTtzOjEwOiJzb3J0X29yZGVyIjtpOjM7czo0OiJpY29uIjtOO3M6Njoic3RhdHVzIjtiOjE7czo5OiJwYXJlbnRfaWQiO047czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNS0xMi0yMyAwNToxMzoyNCI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMiAxNToxMDozNSI7fXM6MTE6IgAqAG9yaWdpbmFsIjthOjEyOntzOjI6ImlkIjtpOjEzO3M6NDoidHlwZSI7czo4OiJjYXRlZ29yeSI7czo0OiJzbHVnIjtzOjEzOiJiaXotaGFxaW1pemRhIjtzOjM6InVybCI7TjtzOjQ6InRlc3QiO2I6MDtzOjEwOiJzaG93X2FkbWluIjtiOjE7czoxMDoic29ydF9vcmRlciI7aTozO3M6NDoiaWNvbiI7TjtzOjY6InN0YXR1cyI7YjoxO3M6OToicGFyZW50X2lkIjtOO3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjUtMTItMjMgMDU6MTM6MjQiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDEtMjIgMTU6MTA6MzUiO31zOjEwOiIAKgBjaGFuZ2VzIjthOjA6e31zOjExOiIAKgBwcmV2aW91cyI7YTowOnt9czo4OiIAKgBjYXN0cyI7YTowOnt9czoxNzoiACoAY2xhc3NDYXN0Q2FjaGUiO2E6MDp7fXM6MjE6IgAqAGF0dHJpYnV0ZUNhc3RDYWNoZSI7YTowOnt9czoxMzoiACoAZGF0ZUZvcm1hdCI7TjtzOjEwOiIAKgBhcHBlbmRzIjthOjA6e31zOjE5OiIAKgBkaXNwYXRjaGVzRXZlbnRzIjthOjA6e31zOjE0OiIAKgBvYnNlcnZhYmxlcyI7YTowOnt9czoxMjoiACoAcmVsYXRpb25zIjthOjI6e3M6OToiY2hpbGRyZW5zIjtPOjM5OiJJbGx1bWluYXRlXERhdGFiYXNlXEVsb3F1ZW50XENvbGxlY3Rpb24iOjI6e3M6ODoiACoAaXRlbXMiO2E6NDp7aTowO086MTk6IkFwcFxNb2RlbHNcTWVudU1haW4iOjM0OntzOjEzOiIAKgBjb25uZWN0aW9uIjtzOjU6InBnc3FsIjtzOjg6IgAqAHRhYmxlIjtzOjEwOiJtZW51X21haW5zIjtzOjEzOiIAKgBwcmltYXJ5S2V5IjtzOjI6ImlkIjtzOjEwOiIAKgBrZXlUeXBlIjtzOjM6ImludCI7czoxMjoiaW5jcmVtZW50aW5nIjtiOjE7czo3OiIAKgB3aXRoIjthOjA6e31zOjEyOiIAKgB3aXRoQ291bnQiO2E6MDp7fXM6MTk6InByZXZlbnRzTGF6eUxvYWRpbmciO2I6MDtzOjEwOiIAKgBwZXJQYWdlIjtpOjE1O3M6NjoiZXhpc3RzIjtiOjE7czoxODoid2FzUmVjZW50bHlDcmVhdGVkIjtiOjA7czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO3M6MTM6IgAqAGF0dHJpYnV0ZXMiO2E6MTI6e3M6MjoiaWQiO2k6MjQ7czo0OiJ0eXBlIjtzOjQ6InBhZ2UiO3M6NDoic2x1ZyI7czo1OiJhYm91dCI7czozOiJ1cmwiO047czo0OiJ0ZXN0IjtiOjA7czoxMDoic2hvd19hZG1pbiI7YjoxO3M6MTA6InNvcnRfb3JkZXIiO2k6MTQ7czo0OiJpY29uIjtOO3M6Njoic3RhdHVzIjtiOjE7czo5OiJwYXJlbnRfaWQiO2k6MTM7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNS0xMi0yMyAwNTo0MjozNCI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMiAwNjoyNDo0NiI7fXM6MTE6IgAqAG9yaWdpbmFsIjthOjEyOntzOjI6ImlkIjtpOjI0O3M6NDoidHlwZSI7czo0OiJwYWdlIjtzOjQ6InNsdWciO3M6NToiYWJvdXQiO3M6MzoidXJsIjtOO3M6NDoidGVzdCI7YjowO3M6MTA6InNob3dfYWRtaW4iO2I6MTtzOjEwOiJzb3J0X29yZGVyIjtpOjE0O3M6NDoiaWNvbiI7TjtzOjY6InN0YXR1cyI7YjoxO3M6OToicGFyZW50X2lkIjtpOjEzO3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjUtMTItMjMgMDU6NDI6MzQiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDEtMjIgMDY6MjQ6NDYiO31zOjEwOiIAKgBjaGFuZ2VzIjthOjA6e31zOjExOiIAKgBwcmV2aW91cyI7YTowOnt9czo4OiIAKgBjYXN0cyI7YTowOnt9czoxNzoiACoAY2xhc3NDYXN0Q2FjaGUiO2E6MDp7fXM6MjE6IgAqAGF0dHJpYnV0ZUNhc3RDYWNoZSI7YTowOnt9czoxMzoiACoAZGF0ZUZvcm1hdCI7TjtzOjEwOiIAKgBhcHBlbmRzIjthOjA6e31zOjE5OiIAKgBkaXNwYXRjaGVzRXZlbnRzIjthOjA6e31zOjE0OiIAKgBvYnNlcnZhYmxlcyI7YTowOnt9czoxMjoiACoAcmVsYXRpb25zIjthOjI6e3M6MTI6InRyYW5zbGF0aW9ucyI7TzozOToiSWxsdW1pbmF0ZVxEYXRhYmFzZVxFbG9xdWVudFxDb2xsZWN0aW9uIjoyOntzOjg6IgAqAGl0ZW1zIjthOjM6e2k6MDtPOjMwOiJBcHBcTW9kZWxzXE1lbnVNYWluVHJhbnNsYXRpb24iOjMzOntzOjEzOiIAKgBjb25uZWN0aW9uIjtzOjU6InBnc3FsIjtzOjg6IgAqAHRhYmxlIjtzOjIyOiJtZW51X21haW5fdHJhbnNsYXRpb25zIjtzOjEzOiIAKgBwcmltYXJ5S2V5IjtzOjI6ImlkIjtzOjEwOiIAKgBrZXlUeXBlIjtzOjM6ImludCI7czoxMjoiaW5jcmVtZW50aW5nIjtiOjE7czo3OiIAKgB3aXRoIjthOjA6e31zOjEyOiIAKgB3aXRoQ291bnQiO2E6MDp7fXM6MTk6InByZXZlbnRzTGF6eUxvYWRpbmciO2I6MDtzOjEwOiIAKgBwZXJQYWdlIjtpOjE1O3M6NjoiZXhpc3RzIjtiOjE7czoxODoid2FzUmVjZW50bHlDcmVhdGVkIjtiOjA7czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO3M6MTM6IgAqAGF0dHJpYnV0ZXMiO2E6Njp7czoyOiJpZCI7aTo0NztzOjEyOiJtZW51X21haW5faWQiO2k6MjQ7czo2OiJsb2NhbGUiO3M6MjoidXoiO3M6NDoiZGF0YSI7czo2MToieyJpbmZvIjogbnVsbCwgInRpdGxlIjogIkJpeiBoYXFpbWl6ZGEiLCAiZGVzY3JpcHRpb24iOiBudWxsfSI7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNS0xMi0yMyAwNTo0MjozNCI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMiAwNjoyNDo0NiI7fXM6MTE6IgAqAG9yaWdpbmFsIjthOjY6e3M6MjoiaWQiO2k6NDc7czoxMjoibWVudV9tYWluX2lkIjtpOjI0O3M6NjoibG9jYWxlIjtzOjI6InV6IjtzOjQ6ImRhdGEiO3M6NjE6InsiaW5mbyI6IG51bGwsICJ0aXRsZSI6ICJCaXogaGFxaW1pemRhIiwgImRlc2NyaXB0aW9uIjogbnVsbH0iO3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjUtMTItMjMgMDU6NDI6MzQiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDEtMjIgMDY6MjQ6NDYiO31zOjEwOiIAKgBjaGFuZ2VzIjthOjA6e31zOjExOiIAKgBwcmV2aW91cyI7YTowOnt9czo4OiIAKgBjYXN0cyI7YTowOnt9czoxNzoiACoAY2xhc3NDYXN0Q2FjaGUiO2E6MDp7fXM6MjE6IgAqAGF0dHJpYnV0ZUNhc3RDYWNoZSI7YTowOnt9czoxMzoiACoAZGF0ZUZvcm1hdCI7TjtzOjEwOiIAKgBhcHBlbmRzIjthOjA6e31zOjE5OiIAKgBkaXNwYXRjaGVzRXZlbnRzIjthOjA6e31zOjE0OiIAKgBvYnNlcnZhYmxlcyI7YTowOnt9czoxMjoiACoAcmVsYXRpb25zIjthOjA6e31zOjEwOiIAKgB0b3VjaGVzIjthOjA6e31zOjI3OiIAKgByZWxhdGlvbkF1dG9sb2FkQ2FsbGJhY2siO047czoyNjoiACoAcmVsYXRpb25BdXRvbG9hZENvbnRleHQiO047czoxMDoidGltZXN0YW1wcyI7YjoxO3M6MTM6InVzZXNVbmlxdWVJZHMiO2I6MDtzOjk6IgAqAGhpZGRlbiI7YTowOnt9czoxMDoiACoAdmlzaWJsZSI7YTowOnt9czoxMToiACoAZmlsbGFibGUiO2E6Mzp7aTowO3M6MTI6Im1lbnVfbWFpbl9pZCI7aToxO3M6NjoibG9jYWxlIjtpOjI7czo0OiJkYXRhIjt9czoxMDoiACoAZ3VhcmRlZCI7YToxOntpOjA7czoxOiIqIjt9fWk6MTtPOjMwOiJBcHBcTW9kZWxzXE1lbnVNYWluVHJhbnNsYXRpb24iOjMzOntzOjEzOiIAKgBjb25uZWN0aW9uIjtzOjU6InBnc3FsIjtzOjg6IgAqAHRhYmxlIjtzOjIyOiJtZW51X21haW5fdHJhbnNsYXRpb25zIjtzOjEzOiIAKgBwcmltYXJ5S2V5IjtzOjI6ImlkIjtzOjEwOiIAKgBrZXlUeXBlIjtzOjM6ImludCI7czoxMjoiaW5jcmVtZW50aW5nIjtiOjE7czo3OiIAKgB3aXRoIjthOjA6e31zOjEyOiIAKgB3aXRoQ291bnQiO2E6MDp7fXM6MTk6InByZXZlbnRzTGF6eUxvYWRpbmciO2I6MDtzOjEwOiIAKgBwZXJQYWdlIjtpOjE1O3M6NjoiZXhpc3RzIjtiOjE7czoxODoid2FzUmVjZW50bHlDcmVhdGVkIjtiOjA7czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO3M6MTM6IgAqAGF0dHJpYnV0ZXMiO2E6Njp7czoyOiJpZCI7aTo0ODtzOjEyOiJtZW51X21haW5faWQiO2k6MjQ7czo2OiJsb2NhbGUiO3M6MjoicnUiO3M6NDoiZGF0YSI7czo1ODoieyJpbmZvIjogbnVsbCwgInRpdGxlIjogItCeICDQvdCw0YEiLCAiZGVzY3JpcHRpb24iOiBudWxsfSI7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNS0xMi0yMyAwNTo0MjozNCI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMiAwNjoyNDo0NiI7fXM6MTE6IgAqAG9yaWdpbmFsIjthOjY6e3M6MjoiaWQiO2k6NDg7czoxMjoibWVudV9tYWluX2lkIjtpOjI0O3M6NjoibG9jYWxlIjtzOjI6InJ1IjtzOjQ6ImRhdGEiO3M6NTg6InsiaW5mbyI6IG51bGwsICJ0aXRsZSI6ICLQniAg0L3QsNGBIiwgImRlc2NyaXB0aW9uIjogbnVsbH0iO3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjUtMTItMjMgMDU6NDI6MzQiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDEtMjIgMDY6MjQ6NDYiO31zOjEwOiIAKgBjaGFuZ2VzIjthOjA6e31zOjExOiIAKgBwcmV2aW91cyI7YTowOnt9czo4OiIAKgBjYXN0cyI7YTowOnt9czoxNzoiACoAY2xhc3NDYXN0Q2FjaGUiO2E6MDp7fXM6MjE6IgAqAGF0dHJpYnV0ZUNhc3RDYWNoZSI7YTowOnt9czoxMzoiACoAZGF0ZUZvcm1hdCI7TjtzOjEwOiIAKgBhcHBlbmRzIjthOjA6e31zOjE5OiIAKgBkaXNwYXRjaGVzRXZlbnRzIjthOjA6e31zOjE0OiIAKgBvYnNlcnZhYmxlcyI7YTowOnt9czoxMjoiACoAcmVsYXRpb25zIjthOjA6e31zOjEwOiIAKgB0b3VjaGVzIjthOjA6e31zOjI3OiIAKgByZWxhdGlvbkF1dG9sb2FkQ2FsbGJhY2siO047czoyNjoiACoAcmVsYXRpb25BdXRvbG9hZENvbnRleHQiO047czoxMDoidGltZXN0YW1wcyI7YjoxO3M6MTM6InVzZXNVbmlxdWVJZHMiO2I6MDtzOjk6IgAqAGhpZGRlbiI7YTowOnt9czoxMDoiACoAdmlzaWJsZSI7YTowOnt9czoxMToiACoAZmlsbGFibGUiO2E6Mzp7aTowO3M6MTI6Im1lbnVfbWFpbl9pZCI7aToxO3M6NjoibG9jYWxlIjtpOjI7czo0OiJkYXRhIjt9czoxMDoiACoAZ3VhcmRlZCI7YToxOntpOjA7czoxOiIqIjt9fWk6MjtPOjMwOiJBcHBcTW9kZWxzXE1lbnVNYWluVHJhbnNsYXRpb24iOjMzOntzOjEzOiIAKgBjb25uZWN0aW9uIjtzOjU6InBnc3FsIjtzOjg6IgAqAHRhYmxlIjtzOjIyOiJtZW51X21haW5fdHJhbnNsYXRpb25zIjtzOjEzOiIAKgBwcmltYXJ5S2V5IjtzOjI6ImlkIjtzOjEwOiIAKgBrZXlUeXBlIjtzOjM6ImludCI7czoxMjoiaW5jcmVtZW50aW5nIjtiOjE7czo3OiIAKgB3aXRoIjthOjA6e31zOjEyOiIAKgB3aXRoQ291bnQiO2E6MDp7fXM6MTk6InByZXZlbnRzTGF6eUxvYWRpbmciO2I6MDtzOjEwOiIAKgBwZXJQYWdlIjtpOjE1O3M6NjoiZXhpc3RzIjtiOjE7czoxODoid2FzUmVjZW50bHlDcmVhdGVkIjtiOjA7czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO3M6MTM6IgAqAGF0dHJpYnV0ZXMiO2E6Njp7czoyOiJpZCI7aToxMzI7czoxMjoibWVudV9tYWluX2lkIjtpOjI0O3M6NjoibG9jYWxlIjtzOjI6ImVuIjtzOjQ6ImRhdGEiO3M6NTY6InsiaW5mbyI6IG51bGwsICJ0aXRsZSI6ICJBYm91dCB1cyIsICJkZXNjcmlwdGlvbiI6IG51bGx9IjtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTE0IDEwOjM2OjM1IjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIyIDA2OjI0OjQ2Ijt9czoxMToiACoAb3JpZ2luYWwiO2E6Njp7czoyOiJpZCI7aToxMzI7czoxMjoibWVudV9tYWluX2lkIjtpOjI0O3M6NjoibG9jYWxlIjtzOjI6ImVuIjtzOjQ6ImRhdGEiO3M6NTY6InsiaW5mbyI6IG51bGwsICJ0aXRsZSI6ICJBYm91dCB1cyIsICJkZXNjcmlwdGlvbiI6IG51bGx9IjtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTE0IDEwOjM2OjM1IjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIyIDA2OjI0OjQ2Ijt9czoxMDoiACoAY2hhbmdlcyI7YTowOnt9czoxMToiACoAcHJldmlvdXMiO2E6MDp7fXM6ODoiACoAY2FzdHMiO2E6MDp7fXM6MTc6IgAqAGNsYXNzQ2FzdENhY2hlIjthOjA6e31zOjIxOiIAKgBhdHRyaWJ1dGVDYXN0Q2FjaGUiO2E6MDp7fXM6MTM6IgAqAGRhdGVGb3JtYXQiO047czoxMDoiACoAYXBwZW5kcyI7YTowOnt9czoxOToiACoAZGlzcGF0Y2hlc0V2ZW50cyI7YTowOnt9czoxNDoiACoAb2JzZXJ2YWJsZXMiO2E6MDp7fXM6MTI6IgAqAHJlbGF0aW9ucyI7YTowOnt9czoxMDoiACoAdG91Y2hlcyI7YTowOnt9czoyNzoiACoAcmVsYXRpb25BdXRvbG9hZENhbGxiYWNrIjtOO3M6MjY6IgAqAHJlbGF0aW9uQXV0b2xvYWRDb250ZXh0IjtOO3M6MTA6InRpbWVzdGFtcHMiO2I6MTtzOjEzOiJ1c2VzVW5pcXVlSWRzIjtiOjA7czo5OiIAKgBoaWRkZW4iO2E6MDp7fXM6MTA6IgAqAHZpc2libGUiO2E6MDp7fXM6MTE6IgAqAGZpbGxhYmxlIjthOjM6e2k6MDtzOjEyOiJtZW51X21haW5faWQiO2k6MTtzOjY6ImxvY2FsZSI7aToyO3M6NDoiZGF0YSI7fXM6MTA6IgAqAGd1YXJkZWQiO2E6MTp7aTowO3M6MToiKiI7fX19czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO31zOjk6ImNoaWxkcmVucyI7TzozOToiSWxsdW1pbmF0ZVxEYXRhYmFzZVxFbG9xdWVudFxDb2xsZWN0aW9uIjoyOntzOjg6IgAqAGl0ZW1zIjthOjA6e31zOjI4OiIAKgBlc2NhcGVXaGVuQ2FzdGluZ1RvU3RyaW5nIjtiOjA7fX1zOjEwOiIAKgB0b3VjaGVzIjthOjA6e31zOjI3OiIAKgByZWxhdGlvbkF1dG9sb2FkQ2FsbGJhY2siO047czoyNjoiACoAcmVsYXRpb25BdXRvbG9hZENvbnRleHQiO047czoxMDoidGltZXN0YW1wcyI7YjoxO3M6MTM6InVzZXNVbmlxdWVJZHMiO2I6MDtzOjk6IgAqAGhpZGRlbiI7YTowOnt9czoxMDoiACoAdmlzaWJsZSI7YTowOnt9czoxMToiACoAZmlsbGFibGUiO2E6OTp7aTowO3M6NDoidHlwZSI7aToxO3M6NDoic2x1ZyI7aToyO3M6MzoidXJsIjtpOjM7czo0OiJ0ZXN0IjtpOjQ7czoxMDoic2hvd19hZG1pbiI7aTo1O3M6MTA6InNvcnRfb3JkZXIiO2k6NjtzOjQ6Imljb24iO2k6NztzOjY6InN0YXR1cyI7aTo4O3M6OToicGFyZW50X2lkIjt9czoxMDoiACoAZ3VhcmRlZCI7YToxOntpOjA7czoxOiIqIjt9czoxOToiACoAdHJhbnNsYXRpb25DYWNoZSI7Tjt9aToxO086MTk6IkFwcFxNb2RlbHNcTWVudU1haW4iOjM0OntzOjEzOiIAKgBjb25uZWN0aW9uIjtzOjU6InBnc3FsIjtzOjg6IgAqAHRhYmxlIjtzOjEwOiJtZW51X21haW5zIjtzOjEzOiIAKgBwcmltYXJ5S2V5IjtzOjI6ImlkIjtzOjEwOiIAKgBrZXlUeXBlIjtzOjM6ImludCI7czoxMjoiaW5jcmVtZW50aW5nIjtiOjE7czo3OiIAKgB3aXRoIjthOjA6e31zOjEyOiIAKgB3aXRoQ291bnQiO2E6MDp7fXM6MTk6InByZXZlbnRzTGF6eUxvYWRpbmciO2I6MDtzOjEwOiIAKgBwZXJQYWdlIjtpOjE1O3M6NjoiZXhpc3RzIjtiOjE7czoxODoid2FzUmVjZW50bHlDcmVhdGVkIjtiOjA7czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO3M6MTM6IgAqAGF0dHJpYnV0ZXMiO2E6MTI6e3M6MjoiaWQiO2k6MTQ7czo0OiJ0eXBlIjtzOjQ6InBhZ2UiO3M6NDoic2x1ZyI7czoxMDoibGVhZGVyc2hpcCI7czozOiJ1cmwiO047czo0OiJ0ZXN0IjtiOjA7czoxMDoic2hvd19hZG1pbiI7YjoxO3M6MTA6InNvcnRfb3JkZXIiO2k6MTQ7czo0OiJpY29uIjtOO3M6Njoic3RhdHVzIjtiOjE7czo5OiJwYXJlbnRfaWQiO2k6MTM7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNS0xMi0yMyAwNToxMzo0OCI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMiAwNjoyODoxNiI7fXM6MTE6IgAqAG9yaWdpbmFsIjthOjEyOntzOjI6ImlkIjtpOjE0O3M6NDoidHlwZSI7czo0OiJwYWdlIjtzOjQ6InNsdWciO3M6MTA6ImxlYWRlcnNoaXAiO3M6MzoidXJsIjtOO3M6NDoidGVzdCI7YjowO3M6MTA6InNob3dfYWRtaW4iO2I6MTtzOjEwOiJzb3J0X29yZGVyIjtpOjE0O3M6NDoiaWNvbiI7TjtzOjY6InN0YXR1cyI7YjoxO3M6OToicGFyZW50X2lkIjtpOjEzO3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjUtMTItMjMgMDU6MTM6NDgiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDEtMjIgMDY6Mjg6MTYiO31zOjEwOiIAKgBjaGFuZ2VzIjthOjA6e31zOjExOiIAKgBwcmV2aW91cyI7YTowOnt9czo4OiIAKgBjYXN0cyI7YTowOnt9czoxNzoiACoAY2xhc3NDYXN0Q2FjaGUiO2E6MDp7fXM6MjE6IgAqAGF0dHJpYnV0ZUNhc3RDYWNoZSI7YTowOnt9czoxMzoiACoAZGF0ZUZvcm1hdCI7TjtzOjEwOiIAKgBhcHBlbmRzIjthOjA6e31zOjE5OiIAKgBkaXNwYXRjaGVzRXZlbnRzIjthOjA6e31zOjE0OiIAKgBvYnNlcnZhYmxlcyI7YTowOnt9czoxMjoiACoAcmVsYXRpb25zIjthOjI6e3M6MTI6InRyYW5zbGF0aW9ucyI7TzozOToiSWxsdW1pbmF0ZVxEYXRhYmFzZVxFbG9xdWVudFxDb2xsZWN0aW9uIjoyOntzOjg6IgAqAGl0ZW1zIjthOjM6e2k6MDtPOjMwOiJBcHBcTW9kZWxzXE1lbnVNYWluVHJhbnNsYXRpb24iOjMzOntzOjEzOiIAKgBjb25uZWN0aW9uIjtzOjU6InBnc3FsIjtzOjg6IgAqAHRhYmxlIjtzOjIyOiJtZW51X21haW5fdHJhbnNsYXRpb25zIjtzOjEzOiIAKgBwcmltYXJ5S2V5IjtzOjI6ImlkIjtzOjEwOiIAKgBrZXlUeXBlIjtzOjM6ImludCI7czoxMjoiaW5jcmVtZW50aW5nIjtiOjE7czo3OiIAKgB3aXRoIjthOjA6e31zOjEyOiIAKgB3aXRoQ291bnQiO2E6MDp7fXM6MTk6InByZXZlbnRzTGF6eUxvYWRpbmciO2I6MDtzOjEwOiIAKgBwZXJQYWdlIjtpOjE1O3M6NjoiZXhpc3RzIjtiOjE7czoxODoid2FzUmVjZW50bHlDcmVhdGVkIjtiOjA7czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO3M6MTM6IgAqAGF0dHJpYnV0ZXMiO2E6Njp7czoyOiJpZCI7aToyODtzOjEyOiJtZW51X21haW5faWQiO2k6MTQ7czo2OiJsb2NhbGUiO3M6MjoicnUiO3M6NDoiZGF0YSI7czo2NjoieyJpbmZvIjogbnVsbCwgInRpdGxlIjogItCb0LjQtNC10YDRgdGC0LLQviIsICJkZXNjcmlwdGlvbiI6IG51bGx9IjtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI1LTEyLTIzIDA1OjEzOjQ4IjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIyIDA2OjI4OjE2Ijt9czoxMToiACoAb3JpZ2luYWwiO2E6Njp7czoyOiJpZCI7aToyODtzOjEyOiJtZW51X21haW5faWQiO2k6MTQ7czo2OiJsb2NhbGUiO3M6MjoicnUiO3M6NDoiZGF0YSI7czo2NjoieyJpbmZvIjogbnVsbCwgInRpdGxlIjogItCb0LjQtNC10YDRgdGC0LLQviIsICJkZXNjcmlwdGlvbiI6IG51bGx9IjtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI1LTEyLTIzIDA1OjEzOjQ4IjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIyIDA2OjI4OjE2Ijt9czoxMDoiACoAY2hhbmdlcyI7YTowOnt9czoxMToiACoAcHJldmlvdXMiO2E6MDp7fXM6ODoiACoAY2FzdHMiO2E6MDp7fXM6MTc6IgAqAGNsYXNzQ2FzdENhY2hlIjthOjA6e31zOjIxOiIAKgBhdHRyaWJ1dGVDYXN0Q2FjaGUiO2E6MDp7fXM6MTM6IgAqAGRhdGVGb3JtYXQiO047czoxMDoiACoAYXBwZW5kcyI7YTowOnt9czoxOToiACoAZGlzcGF0Y2hlc0V2ZW50cyI7YTowOnt9czoxNDoiACoAb2JzZXJ2YWJsZXMiO2E6MDp7fXM6MTI6IgAqAHJlbGF0aW9ucyI7YTowOnt9czoxMDoiACoAdG91Y2hlcyI7YTowOnt9czoyNzoiACoAcmVsYXRpb25BdXRvbG9hZENhbGxiYWNrIjtOO3M6MjY6IgAqAHJlbGF0aW9uQXV0b2xvYWRDb250ZXh0IjtOO3M6MTA6InRpbWVzdGFtcHMiO2I6MTtzOjEzOiJ1c2VzVW5pcXVlSWRzIjtiOjA7czo5OiIAKgBoaWRkZW4iO2E6MDp7fXM6MTA6IgAqAHZpc2libGUiO2E6MDp7fXM6MTE6IgAqAGZpbGxhYmxlIjthOjM6e2k6MDtzOjEyOiJtZW51X21haW5faWQiO2k6MTtzOjY6ImxvY2FsZSI7aToyO3M6NDoiZGF0YSI7fXM6MTA6IgAqAGd1YXJkZWQiO2E6MTp7aTowO3M6MToiKiI7fX1pOjE7TzozMDoiQXBwXE1vZGVsc1xNZW51TWFpblRyYW5zbGF0aW9uIjozMzp7czoxMzoiACoAY29ubmVjdGlvbiI7czo1OiJwZ3NxbCI7czo4OiIAKgB0YWJsZSI7czoyMjoibWVudV9tYWluX3RyYW5zbGF0aW9ucyI7czoxMzoiACoAcHJpbWFyeUtleSI7czoyOiJpZCI7czoxMDoiACoAa2V5VHlwZSI7czozOiJpbnQiO3M6MTI6ImluY3JlbWVudGluZyI7YjoxO3M6NzoiACoAd2l0aCI7YTowOnt9czoxMjoiACoAd2l0aENvdW50IjthOjA6e31zOjE5OiJwcmV2ZW50c0xhenlMb2FkaW5nIjtiOjA7czoxMDoiACoAcGVyUGFnZSI7aToxNTtzOjY6ImV4aXN0cyI7YjoxO3M6MTg6Indhc1JlY2VudGx5Q3JlYXRlZCI7YjowO3M6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDtzOjEzOiIAKgBhdHRyaWJ1dGVzIjthOjY6e3M6MjoiaWQiO2k6Mjc7czoxMjoibWVudV9tYWluX2lkIjtpOjE0O3M6NjoibG9jYWxlIjtzOjI6InV6IjtzOjQ6ImRhdGEiO3M6NTg6InsiaW5mbyI6IG51bGwsICJ0aXRsZSI6ICJSYWhiYXJpeWF0IiwgImRlc2NyaXB0aW9uIjogbnVsbH0iO3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjUtMTItMjMgMDU6MTM6NDgiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDEtMjIgMDY6Mjg6MTYiO31zOjExOiIAKgBvcmlnaW5hbCI7YTo2OntzOjI6ImlkIjtpOjI3O3M6MTI6Im1lbnVfbWFpbl9pZCI7aToxNDtzOjY6ImxvY2FsZSI7czoyOiJ1eiI7czo0OiJkYXRhIjtzOjU4OiJ7ImluZm8iOiBudWxsLCAidGl0bGUiOiAiUmFoYmFyaXlhdCIsICJkZXNjcmlwdGlvbiI6IG51bGx9IjtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI1LTEyLTIzIDA1OjEzOjQ4IjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIyIDA2OjI4OjE2Ijt9czoxMDoiACoAY2hhbmdlcyI7YTowOnt9czoxMToiACoAcHJldmlvdXMiO2E6MDp7fXM6ODoiACoAY2FzdHMiO2E6MDp7fXM6MTc6IgAqAGNsYXNzQ2FzdENhY2hlIjthOjA6e31zOjIxOiIAKgBhdHRyaWJ1dGVDYXN0Q2FjaGUiO2E6MDp7fXM6MTM6IgAqAGRhdGVGb3JtYXQiO047czoxMDoiACoAYXBwZW5kcyI7YTowOnt9czoxOToiACoAZGlzcGF0Y2hlc0V2ZW50cyI7YTowOnt9czoxNDoiACoAb2JzZXJ2YWJsZXMiO2E6MDp7fXM6MTI6IgAqAHJlbGF0aW9ucyI7YTowOnt9czoxMDoiACoAdG91Y2hlcyI7YTowOnt9czoyNzoiACoAcmVsYXRpb25BdXRvbG9hZENhbGxiYWNrIjtOO3M6MjY6IgAqAHJlbGF0aW9uQXV0b2xvYWRDb250ZXh0IjtOO3M6MTA6InRpbWVzdGFtcHMiO2I6MTtzOjEzOiJ1c2VzVW5pcXVlSWRzIjtiOjA7czo5OiIAKgBoaWRkZW4iO2E6MDp7fXM6MTA6IgAqAHZpc2libGUiO2E6MDp7fXM6MTE6IgAqAGZpbGxhYmxlIjthOjM6e2k6MDtzOjEyOiJtZW51X21haW5faWQiO2k6MTtzOjY6ImxvY2FsZSI7aToyO3M6NDoiZGF0YSI7fXM6MTA6IgAqAGd1YXJkZWQiO2E6MTp7aTowO3M6MToiKiI7fX1pOjI7TzozMDoiQXBwXE1vZGVsc1xNZW51TWFpblRyYW5zbGF0aW9uIjozMzp7czoxMzoiACoAY29ubmVjdGlvbiI7czo1OiJwZ3NxbCI7czo4OiIAKgB0YWJsZSI7czoyMjoibWVudV9tYWluX3RyYW5zbGF0aW9ucyI7czoxMzoiACoAcHJpbWFyeUtleSI7czoyOiJpZCI7czoxMDoiACoAa2V5VHlwZSI7czozOiJpbnQiO3M6MTI6ImluY3JlbWVudGluZyI7YjoxO3M6NzoiACoAd2l0aCI7YTowOnt9czoxMjoiACoAd2l0aENvdW50IjthOjA6e31zOjE5OiJwcmV2ZW50c0xhenlMb2FkaW5nIjtiOjA7czoxMDoiACoAcGVyUGFnZSI7aToxNTtzOjY6ImV4aXN0cyI7YjoxO3M6MTg6Indhc1JlY2VudGx5Q3JlYXRlZCI7YjowO3M6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDtzOjEzOiIAKgBhdHRyaWJ1dGVzIjthOjY6e3M6MjoiaWQiO2k6MTMzO3M6MTI6Im1lbnVfbWFpbl9pZCI7aToxNDtzOjY6ImxvY2FsZSI7czoyOiJlbiI7czo0OiJkYXRhIjtzOjU4OiJ7ImluZm8iOiBudWxsLCAidGl0bGUiOiAiTGVhZGVyc2hpcCIsICJkZXNjcmlwdGlvbiI6IG51bGx9IjtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTE0IDEwOjM3OjA0IjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIyIDA2OjI4OjE2Ijt9czoxMToiACoAb3JpZ2luYWwiO2E6Njp7czoyOiJpZCI7aToxMzM7czoxMjoibWVudV9tYWluX2lkIjtpOjE0O3M6NjoibG9jYWxlIjtzOjI6ImVuIjtzOjQ6ImRhdGEiO3M6NTg6InsiaW5mbyI6IG51bGwsICJ0aXRsZSI6ICJMZWFkZXJzaGlwIiwgImRlc2NyaXB0aW9uIjogbnVsbH0iO3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjYtMDEtMTQgMTA6Mzc6MDQiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDEtMjIgMDY6Mjg6MTYiO31zOjEwOiIAKgBjaGFuZ2VzIjthOjA6e31zOjExOiIAKgBwcmV2aW91cyI7YTowOnt9czo4OiIAKgBjYXN0cyI7YTowOnt9czoxNzoiACoAY2xhc3NDYXN0Q2FjaGUiO2E6MDp7fXM6MjE6IgAqAGF0dHJpYnV0ZUNhc3RDYWNoZSI7YTowOnt9czoxMzoiACoAZGF0ZUZvcm1hdCI7TjtzOjEwOiIAKgBhcHBlbmRzIjthOjA6e31zOjE5OiIAKgBkaXNwYXRjaGVzRXZlbnRzIjthOjA6e31zOjE0OiIAKgBvYnNlcnZhYmxlcyI7YTowOnt9czoxMjoiACoAcmVsYXRpb25zIjthOjA6e31zOjEwOiIAKgB0b3VjaGVzIjthOjA6e31zOjI3OiIAKgByZWxhdGlvbkF1dG9sb2FkQ2FsbGJhY2siO047czoyNjoiACoAcmVsYXRpb25BdXRvbG9hZENvbnRleHQiO047czoxMDoidGltZXN0YW1wcyI7YjoxO3M6MTM6InVzZXNVbmlxdWVJZHMiO2I6MDtzOjk6IgAqAGhpZGRlbiI7YTowOnt9czoxMDoiACoAdmlzaWJsZSI7YTowOnt9czoxMToiACoAZmlsbGFibGUiO2E6Mzp7aTowO3M6MTI6Im1lbnVfbWFpbl9pZCI7aToxO3M6NjoibG9jYWxlIjtpOjI7czo0OiJkYXRhIjt9czoxMDoiACoAZ3VhcmRlZCI7YToxOntpOjA7czoxOiIqIjt9fX1zOjI4OiIAKgBlc2NhcGVXaGVuQ2FzdGluZ1RvU3RyaW5nIjtiOjA7fXM6OToiY2hpbGRyZW5zIjtPOjM5OiJJbGx1bWluYXRlXERhdGFiYXNlXEVsb3F1ZW50XENvbGxlY3Rpb24iOjI6e3M6ODoiACoAaXRlbXMiO2E6MDp7fXM6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDt9fXM6MTA6IgAqAHRvdWNoZXMiO2E6MDp7fXM6Mjc6IgAqAHJlbGF0aW9uQXV0b2xvYWRDYWxsYmFjayI7TjtzOjI2OiIAKgByZWxhdGlvbkF1dG9sb2FkQ29udGV4dCI7TjtzOjEwOiJ0aW1lc3RhbXBzIjtiOjE7czoxMzoidXNlc1VuaXF1ZUlkcyI7YjowO3M6OToiACoAaGlkZGVuIjthOjA6e31zOjEwOiIAKgB2aXNpYmxlIjthOjA6e31zOjExOiIAKgBmaWxsYWJsZSI7YTo5OntpOjA7czo0OiJ0eXBlIjtpOjE7czo0OiJzbHVnIjtpOjI7czozOiJ1cmwiO2k6MztzOjQ6InRlc3QiO2k6NDtzOjEwOiJzaG93X2FkbWluIjtpOjU7czoxMDoic29ydF9vcmRlciI7aTo2O3M6NDoiaWNvbiI7aTo3O3M6Njoic3RhdHVzIjtpOjg7czo5OiJwYXJlbnRfaWQiO31zOjEwOiIAKgBndWFyZGVkIjthOjE6e2k6MDtzOjE6IioiO31zOjE5OiIAKgB0cmFuc2xhdGlvbkNhY2hlIjtOO31pOjI7TzoxOToiQXBwXE1vZGVsc1xNZW51TWFpbiI6MzQ6e3M6MTM6IgAqAGNvbm5lY3Rpb24iO3M6NToicGdzcWwiO3M6ODoiACoAdGFibGUiO3M6MTA6Im1lbnVfbWFpbnMiO3M6MTM6IgAqAHByaW1hcnlLZXkiO3M6MjoiaWQiO3M6MTA6IgAqAGtleVR5cGUiO3M6MzoiaW50IjtzOjEyOiJpbmNyZW1lbnRpbmciO2I6MTtzOjc6IgAqAHdpdGgiO2E6MDp7fXM6MTI6IgAqAHdpdGhDb3VudCI7YTowOnt9czoxOToicHJldmVudHNMYXp5TG9hZGluZyI7YjowO3M6MTA6IgAqAHBlclBhZ2UiO2k6MTU7czo2OiJleGlzdHMiO2I6MTtzOjE4OiJ3YXNSZWNlbnRseUNyZWF0ZWQiO2I6MDtzOjI4OiIAKgBlc2NhcGVXaGVuQ2FzdGluZ1RvU3RyaW5nIjtiOjA7czoxMzoiACoAYXR0cmlidXRlcyI7YToxMjp7czoyOiJpZCI7aToxNTtzOjQ6InR5cGUiO3M6NDoicGFnZSI7czo0OiJzbHVnIjtzOjEwOiJkaXJlY3Rpb25zIjtzOjM6InVybCI7TjtzOjQ6InRlc3QiO2I6MDtzOjEwOiJzaG93X2FkbWluIjtiOjE7czoxMDoic29ydF9vcmRlciI7aToxNTtzOjQ6Imljb24iO047czo2OiJzdGF0dXMiO2I6MTtzOjk6InBhcmVudF9pZCI7aToxMztzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI1LTEyLTIzIDA1OjE0OjE3IjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIyIDA2OjI4OjM5Ijt9czoxMToiACoAb3JpZ2luYWwiO2E6MTI6e3M6MjoiaWQiO2k6MTU7czo0OiJ0eXBlIjtzOjQ6InBhZ2UiO3M6NDoic2x1ZyI7czoxMDoiZGlyZWN0aW9ucyI7czozOiJ1cmwiO047czo0OiJ0ZXN0IjtiOjA7czoxMDoic2hvd19hZG1pbiI7YjoxO3M6MTA6InNvcnRfb3JkZXIiO2k6MTU7czo0OiJpY29uIjtOO3M6Njoic3RhdHVzIjtiOjE7czo5OiJwYXJlbnRfaWQiO2k6MTM7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNS0xMi0yMyAwNToxNDoxNyI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMiAwNjoyODozOSI7fXM6MTA6IgAqAGNoYW5nZXMiO2E6MDp7fXM6MTE6IgAqAHByZXZpb3VzIjthOjA6e31zOjg6IgAqAGNhc3RzIjthOjA6e31zOjE3OiIAKgBjbGFzc0Nhc3RDYWNoZSI7YTowOnt9czoyMToiACoAYXR0cmlidXRlQ2FzdENhY2hlIjthOjA6e31zOjEzOiIAKgBkYXRlRm9ybWF0IjtOO3M6MTA6IgAqAGFwcGVuZHMiO2E6MDp7fXM6MTk6IgAqAGRpc3BhdGNoZXNFdmVudHMiO2E6MDp7fXM6MTQ6IgAqAG9ic2VydmFibGVzIjthOjA6e31zOjEyOiIAKgByZWxhdGlvbnMiO2E6Mjp7czoxMjoidHJhbnNsYXRpb25zIjtPOjM5OiJJbGx1bWluYXRlXERhdGFiYXNlXEVsb3F1ZW50XENvbGxlY3Rpb24iOjI6e3M6ODoiACoAaXRlbXMiO2E6Mzp7aTowO086MzA6IkFwcFxNb2RlbHNcTWVudU1haW5UcmFuc2xhdGlvbiI6MzM6e3M6MTM6IgAqAGNvbm5lY3Rpb24iO3M6NToicGdzcWwiO3M6ODoiACoAdGFibGUiO3M6MjI6Im1lbnVfbWFpbl90cmFuc2xhdGlvbnMiO3M6MTM6IgAqAHByaW1hcnlLZXkiO3M6MjoiaWQiO3M6MTA6IgAqAGtleVR5cGUiO3M6MzoiaW50IjtzOjEyOiJpbmNyZW1lbnRpbmciO2I6MTtzOjc6IgAqAHdpdGgiO2E6MDp7fXM6MTI6IgAqAHdpdGhDb3VudCI7YTowOnt9czoxOToicHJldmVudHNMYXp5TG9hZGluZyI7YjowO3M6MTA6IgAqAHBlclBhZ2UiO2k6MTU7czo2OiJleGlzdHMiO2I6MTtzOjE4OiJ3YXNSZWNlbnRseUNyZWF0ZWQiO2I6MDtzOjI4OiIAKgBlc2NhcGVXaGVuQ2FzdGluZ1RvU3RyaW5nIjtiOjA7czoxMzoiACoAYXR0cmlidXRlcyI7YTo2OntzOjI6ImlkIjtpOjI5O3M6MTI6Im1lbnVfbWFpbl9pZCI7aToxNTtzOjY6ImxvY2FsZSI7czoyOiJ1eiI7czo0OiJkYXRhIjtzOjc5OiJ7ImluZm8iOiBudWxsLCAidGl0bGUiOiAiRm9uZG5pbmcgYXNvc2l5IHlv4oCZbmFsaXNobGFyaSIsICJkZXNjcmlwdGlvbiI6IG51bGx9IjtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI1LTEyLTIzIDA1OjE0OjE4IjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIyIDA2OjI4OjM5Ijt9czoxMToiACoAb3JpZ2luYWwiO2E6Njp7czoyOiJpZCI7aToyOTtzOjEyOiJtZW51X21haW5faWQiO2k6MTU7czo2OiJsb2NhbGUiO3M6MjoidXoiO3M6NDoiZGF0YSI7czo3OToieyJpbmZvIjogbnVsbCwgInRpdGxlIjogIkZvbmRuaW5nIGFzb3NpeSB5b+KAmW5hbGlzaGxhcmkiLCAiZGVzY3JpcHRpb24iOiBudWxsfSI7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNS0xMi0yMyAwNToxNDoxOCI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMiAwNjoyODozOSI7fXM6MTA6IgAqAGNoYW5nZXMiO2E6MDp7fXM6MTE6IgAqAHByZXZpb3VzIjthOjA6e31zOjg6IgAqAGNhc3RzIjthOjA6e31zOjE3OiIAKgBjbGFzc0Nhc3RDYWNoZSI7YTowOnt9czoyMToiACoAYXR0cmlidXRlQ2FzdENhY2hlIjthOjA6e31zOjEzOiIAKgBkYXRlRm9ybWF0IjtOO3M6MTA6IgAqAGFwcGVuZHMiO2E6MDp7fXM6MTk6IgAqAGRpc3BhdGNoZXNFdmVudHMiO2E6MDp7fXM6MTQ6IgAqAG9ic2VydmFibGVzIjthOjA6e31zOjEyOiIAKgByZWxhdGlvbnMiO2E6MDp7fXM6MTA6IgAqAHRvdWNoZXMiO2E6MDp7fXM6Mjc6IgAqAHJlbGF0aW9uQXV0b2xvYWRDYWxsYmFjayI7TjtzOjI2OiIAKgByZWxhdGlvbkF1dG9sb2FkQ29udGV4dCI7TjtzOjEwOiJ0aW1lc3RhbXBzIjtiOjE7czoxMzoidXNlc1VuaXF1ZUlkcyI7YjowO3M6OToiACoAaGlkZGVuIjthOjA6e31zOjEwOiIAKgB2aXNpYmxlIjthOjA6e31zOjExOiIAKgBmaWxsYWJsZSI7YTozOntpOjA7czoxMjoibWVudV9tYWluX2lkIjtpOjE7czo2OiJsb2NhbGUiO2k6MjtzOjQ6ImRhdGEiO31zOjEwOiIAKgBndWFyZGVkIjthOjE6e2k6MDtzOjE6IioiO319aToxO086MzA6IkFwcFxNb2RlbHNcTWVudU1haW5UcmFuc2xhdGlvbiI6MzM6e3M6MTM6IgAqAGNvbm5lY3Rpb24iO3M6NToicGdzcWwiO3M6ODoiACoAdGFibGUiO3M6MjI6Im1lbnVfbWFpbl90cmFuc2xhdGlvbnMiO3M6MTM6IgAqAHByaW1hcnlLZXkiO3M6MjoiaWQiO3M6MTA6IgAqAGtleVR5cGUiO3M6MzoiaW50IjtzOjEyOiJpbmNyZW1lbnRpbmciO2I6MTtzOjc6IgAqAHdpdGgiO2E6MDp7fXM6MTI6IgAqAHdpdGhDb3VudCI7YTowOnt9czoxOToicHJldmVudHNMYXp5TG9hZGluZyI7YjowO3M6MTA6IgAqAHBlclBhZ2UiO2k6MTU7czo2OiJleGlzdHMiO2I6MTtzOjE4OiJ3YXNSZWNlbnRseUNyZWF0ZWQiO2I6MDtzOjI4OiIAKgBlc2NhcGVXaGVuQ2FzdGluZ1RvU3RyaW5nIjtiOjA7czoxMzoiACoAYXR0cmlidXRlcyI7YTo2OntzOjI6ImlkIjtpOjMwO3M6MTI6Im1lbnVfbWFpbl9pZCI7aToxNTtzOjY6ImxvY2FsZSI7czoyOiJydSI7czo0OiJkYXRhIjtzOjEyMzoieyJpbmZvIjogbnVsbCwgInRpdGxlIjogItCe0YHQvdC+0LLQvdGL0LUg0L3QsNC/0YDQsNCy0LvQtdC90LjRjyDQtNC10Y/RgtC10LvRjNC90L7RgdGC0Lgg0YTQvtC90LTQsCIsICJkZXNjcmlwdGlvbiI6IG51bGx9IjtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI1LTEyLTIzIDA1OjE0OjE4IjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIyIDA2OjI4OjM5Ijt9czoxMToiACoAb3JpZ2luYWwiO2E6Njp7czoyOiJpZCI7aTozMDtzOjEyOiJtZW51X21haW5faWQiO2k6MTU7czo2OiJsb2NhbGUiO3M6MjoicnUiO3M6NDoiZGF0YSI7czoxMjM6InsiaW5mbyI6IG51bGwsICJ0aXRsZSI6ICLQntGB0L3QvtCy0L3Ri9C1INC90LDQv9GA0LDQstC70LXQvdC40Y8g0LTQtdGP0YLQtdC70YzQvdC+0YHRgtC4INGE0L7QvdC00LAiLCAiZGVzY3JpcHRpb24iOiBudWxsfSI7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNS0xMi0yMyAwNToxNDoxOCI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMiAwNjoyODozOSI7fXM6MTA6IgAqAGNoYW5nZXMiO2E6MDp7fXM6MTE6IgAqAHByZXZpb3VzIjthOjA6e31zOjg6IgAqAGNhc3RzIjthOjA6e31zOjE3OiIAKgBjbGFzc0Nhc3RDYWNoZSI7YTowOnt9czoyMToiACoAYXR0cmlidXRlQ2FzdENhY2hlIjthOjA6e31zOjEzOiIAKgBkYXRlRm9ybWF0IjtOO3M6MTA6IgAqAGFwcGVuZHMiO2E6MDp7fXM6MTk6IgAqAGRpc3BhdGNoZXNFdmVudHMiO2E6MDp7fXM6MTQ6IgAqAG9ic2VydmFibGVzIjthOjA6e31zOjEyOiIAKgByZWxhdGlvbnMiO2E6MDp7fXM6MTA6IgAqAHRvdWNoZXMiO2E6MDp7fXM6Mjc6IgAqAHJlbGF0aW9uQXV0b2xvYWRDYWxsYmFjayI7TjtzOjI2OiIAKgByZWxhdGlvbkF1dG9sb2FkQ29udGV4dCI7TjtzOjEwOiJ0aW1lc3RhbXBzIjtiOjE7czoxMzoidXNlc1VuaXF1ZUlkcyI7YjowO3M6OToiACoAaGlkZGVuIjthOjA6e31zOjEwOiIAKgB2aXNpYmxlIjthOjA6e31zOjExOiIAKgBmaWxsYWJsZSI7YTozOntpOjA7czoxMjoibWVudV9tYWluX2lkIjtpOjE7czo2OiJsb2NhbGUiO2k6MjtzOjQ6ImRhdGEiO31zOjEwOiIAKgBndWFyZGVkIjthOjE6e2k6MDtzOjE6IioiO319aToyO086MzA6IkFwcFxNb2RlbHNcTWVudU1haW5UcmFuc2xhdGlvbiI6MzM6e3M6MTM6IgAqAGNvbm5lY3Rpb24iO3M6NToicGdzcWwiO3M6ODoiACoAdGFibGUiO3M6MjI6Im1lbnVfbWFpbl90cmFuc2xhdGlvbnMiO3M6MTM6IgAqAHByaW1hcnlLZXkiO3M6MjoiaWQiO3M6MTA6IgAqAGtleVR5cGUiO3M6MzoiaW50IjtzOjEyOiJpbmNyZW1lbnRpbmciO2I6MTtzOjc6IgAqAHdpdGgiO2E6MDp7fXM6MTI6IgAqAHdpdGhDb3VudCI7YTowOnt9czoxOToicHJldmVudHNMYXp5TG9hZGluZyI7YjowO3M6MTA6IgAqAHBlclBhZ2UiO2k6MTU7czo2OiJleGlzdHMiO2I6MTtzOjE4OiJ3YXNSZWNlbnRseUNyZWF0ZWQiO2I6MDtzOjI4OiIAKgBlc2NhcGVXaGVuQ2FzdGluZ1RvU3RyaW5nIjtiOjA7czoxMzoiACoAYXR0cmlidXRlcyI7YTo2OntzOjI6ImlkIjtpOjEzNDtzOjEyOiJtZW51X21haW5faWQiO2k6MTU7czo2OiJsb2NhbGUiO3M6MjoiZW4iO3M6NDoiZGF0YSI7czo3NToieyJpbmZvIjogbnVsbCwgInRpdGxlIjogIk1haW4gZGlyZWN0aW9ucyBvZiB0aGUgZnVuZCIsICJkZXNjcmlwdGlvbiI6IG51bGx9IjtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTE0IDEwOjM3OjUzIjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIyIDA2OjI4OjM5Ijt9czoxMToiACoAb3JpZ2luYWwiO2E6Njp7czoyOiJpZCI7aToxMzQ7czoxMjoibWVudV9tYWluX2lkIjtpOjE1O3M6NjoibG9jYWxlIjtzOjI6ImVuIjtzOjQ6ImRhdGEiO3M6NzU6InsiaW5mbyI6IG51bGwsICJ0aXRsZSI6ICJNYWluIGRpcmVjdGlvbnMgb2YgdGhlIGZ1bmQiLCAiZGVzY3JpcHRpb24iOiBudWxsfSI7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNi0wMS0xNCAxMDozNzo1MyI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMiAwNjoyODozOSI7fXM6MTA6IgAqAGNoYW5nZXMiO2E6MDp7fXM6MTE6IgAqAHByZXZpb3VzIjthOjA6e31zOjg6IgAqAGNhc3RzIjthOjA6e31zOjE3OiIAKgBjbGFzc0Nhc3RDYWNoZSI7YTowOnt9czoyMToiACoAYXR0cmlidXRlQ2FzdENhY2hlIjthOjA6e31zOjEzOiIAKgBkYXRlRm9ybWF0IjtOO3M6MTA6IgAqAGFwcGVuZHMiO2E6MDp7fXM6MTk6IgAqAGRpc3BhdGNoZXNFdmVudHMiO2E6MDp7fXM6MTQ6IgAqAG9ic2VydmFibGVzIjthOjA6e31zOjEyOiIAKgByZWxhdGlvbnMiO2E6MDp7fXM6MTA6IgAqAHRvdWNoZXMiO2E6MDp7fXM6Mjc6IgAqAHJlbGF0aW9uQXV0b2xvYWRDYWxsYmFjayI7TjtzOjI2OiIAKgByZWxhdGlvbkF1dG9sb2FkQ29udGV4dCI7TjtzOjEwOiJ0aW1lc3RhbXBzIjtiOjE7czoxMzoidXNlc1VuaXF1ZUlkcyI7YjowO3M6OToiACoAaGlkZGVuIjthOjA6e31zOjEwOiIAKgB2aXNpYmxlIjthOjA6e31zOjExOiIAKgBmaWxsYWJsZSI7YTozOntpOjA7czoxMjoibWVudV9tYWluX2lkIjtpOjE7czo2OiJsb2NhbGUiO2k6MjtzOjQ6ImRhdGEiO31zOjEwOiIAKgBndWFyZGVkIjthOjE6e2k6MDtzOjE6IioiO319fXM6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDt9czo5OiJjaGlsZHJlbnMiO086Mzk6IklsbHVtaW5hdGVcRGF0YWJhc2VcRWxvcXVlbnRcQ29sbGVjdGlvbiI6Mjp7czo4OiIAKgBpdGVtcyI7YTowOnt9czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO319czoxMDoiACoAdG91Y2hlcyI7YTowOnt9czoyNzoiACoAcmVsYXRpb25BdXRvbG9hZENhbGxiYWNrIjtOO3M6MjY6IgAqAHJlbGF0aW9uQXV0b2xvYWRDb250ZXh0IjtOO3M6MTA6InRpbWVzdGFtcHMiO2I6MTtzOjEzOiJ1c2VzVW5pcXVlSWRzIjtiOjA7czo5OiIAKgBoaWRkZW4iO2E6MDp7fXM6MTA6IgAqAHZpc2libGUiO2E6MDp7fXM6MTE6IgAqAGZpbGxhYmxlIjthOjk6e2k6MDtzOjQ6InR5cGUiO2k6MTtzOjQ6InNsdWciO2k6MjtzOjM6InVybCI7aTozO3M6NDoidGVzdCI7aTo0O3M6MTA6InNob3dfYWRtaW4iO2k6NTtzOjEwOiJzb3J0X29yZGVyIjtpOjY7czo0OiJpY29uIjtpOjc7czo2OiJzdGF0dXMiO2k6ODtzOjk6InBhcmVudF9pZCI7fXM6MTA6IgAqAGd1YXJkZWQiO2E6MTp7aTowO3M6MToiKiI7fXM6MTk6IgAqAHRyYW5zbGF0aW9uQ2FjaGUiO047fWk6MztPOjE5OiJBcHBcTW9kZWxzXE1lbnVNYWluIjozNDp7czoxMzoiACoAY29ubmVjdGlvbiI7czo1OiJwZ3NxbCI7czo4OiIAKgB0YWJsZSI7czoxMDoibWVudV9tYWlucyI7czoxMzoiACoAcHJpbWFyeUtleSI7czoyOiJpZCI7czoxMDoiACoAa2V5VHlwZSI7czozOiJpbnQiO3M6MTI6ImluY3JlbWVudGluZyI7YjoxO3M6NzoiACoAd2l0aCI7YTowOnt9czoxMjoiACoAd2l0aENvdW50IjthOjA6e31zOjE5OiJwcmV2ZW50c0xhenlMb2FkaW5nIjtiOjA7czoxMDoiACoAcGVyUGFnZSI7aToxNTtzOjY6ImV4aXN0cyI7YjoxO3M6MTg6Indhc1JlY2VudGx5Q3JlYXRlZCI7YjowO3M6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDtzOjEzOiIAKgBhdHRyaWJ1dGVzIjthOjEyOntzOjI6ImlkIjtpOjE2O3M6NDoidHlwZSI7czo0OiJwYWdlIjtzOjQ6InNsdWciO3M6MzoiZmFxIjtzOjM6InVybCI7TjtzOjQ6InRlc3QiO2I6MDtzOjEwOiJzaG93X2FkbWluIjtiOjE7czoxMDoic29ydF9vcmRlciI7aToxNjtzOjQ6Imljb24iO047czo2OiJzdGF0dXMiO2I6MTtzOjk6InBhcmVudF9pZCI7aToxMztzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI1LTEyLTIzIDA1OjE0OjUyIjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI1LTEyLTIzIDA1OjE0OjUyIjt9czoxMToiACoAb3JpZ2luYWwiO2E6MTI6e3M6MjoiaWQiO2k6MTY7czo0OiJ0eXBlIjtzOjQ6InBhZ2UiO3M6NDoic2x1ZyI7czozOiJmYXEiO3M6MzoidXJsIjtOO3M6NDoidGVzdCI7YjowO3M6MTA6InNob3dfYWRtaW4iO2I6MTtzOjEwOiJzb3J0X29yZGVyIjtpOjE2O3M6NDoiaWNvbiI7TjtzOjY6InN0YXR1cyI7YjoxO3M6OToicGFyZW50X2lkIjtpOjEzO3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjUtMTItMjMgMDU6MTQ6NTIiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjUtMTItMjMgMDU6MTQ6NTIiO31zOjEwOiIAKgBjaGFuZ2VzIjthOjA6e31zOjExOiIAKgBwcmV2aW91cyI7YTowOnt9czo4OiIAKgBjYXN0cyI7YTowOnt9czoxNzoiACoAY2xhc3NDYXN0Q2FjaGUiO2E6MDp7fXM6MjE6IgAqAGF0dHJpYnV0ZUNhc3RDYWNoZSI7YTowOnt9czoxMzoiACoAZGF0ZUZvcm1hdCI7TjtzOjEwOiIAKgBhcHBlbmRzIjthOjA6e31zOjE5OiIAKgBkaXNwYXRjaGVzRXZlbnRzIjthOjA6e31zOjE0OiIAKgBvYnNlcnZhYmxlcyI7YTowOnt9czoxMjoiACoAcmVsYXRpb25zIjthOjI6e3M6MTI6InRyYW5zbGF0aW9ucyI7TzozOToiSWxsdW1pbmF0ZVxEYXRhYmFzZVxFbG9xdWVudFxDb2xsZWN0aW9uIjoyOntzOjg6IgAqAGl0ZW1zIjthOjM6e2k6MDtPOjMwOiJBcHBcTW9kZWxzXE1lbnVNYWluVHJhbnNsYXRpb24iOjMzOntzOjEzOiIAKgBjb25uZWN0aW9uIjtzOjU6InBnc3FsIjtzOjg6IgAqAHRhYmxlIjtzOjIyOiJtZW51X21haW5fdHJhbnNsYXRpb25zIjtzOjEzOiIAKgBwcmltYXJ5S2V5IjtzOjI6ImlkIjtzOjEwOiIAKgBrZXlUeXBlIjtzOjM6ImludCI7czoxMjoiaW5jcmVtZW50aW5nIjtiOjE7czo3OiIAKgB3aXRoIjthOjA6e31zOjEyOiIAKgB3aXRoQ291bnQiO2E6MDp7fXM6MTk6InByZXZlbnRzTGF6eUxvYWRpbmciO2I6MDtzOjEwOiIAKgBwZXJQYWdlIjtpOjE1O3M6NjoiZXhpc3RzIjtiOjE7czoxODoid2FzUmVjZW50bHlDcmVhdGVkIjtiOjA7czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO3M6MTM6IgAqAGF0dHJpYnV0ZXMiO2E6Njp7czoyOiJpZCI7aTozMTtzOjEyOiJtZW51X21haW5faWQiO2k6MTY7czo2OiJsb2NhbGUiO3M6MjoidXoiO3M6NDoiZGF0YSI7czo1MToieyJpbmZvIjogbnVsbCwgInRpdGxlIjogIkZBUSIsICJkZXNjcmlwdGlvbiI6IG51bGx9IjtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI1LTEyLTIzIDA1OjE0OjUyIjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIxIDE5OjU0OjA4Ijt9czoxMToiACoAb3JpZ2luYWwiO2E6Njp7czoyOiJpZCI7aTozMTtzOjEyOiJtZW51X21haW5faWQiO2k6MTY7czo2OiJsb2NhbGUiO3M6MjoidXoiO3M6NDoiZGF0YSI7czo1MToieyJpbmZvIjogbnVsbCwgInRpdGxlIjogIkZBUSIsICJkZXNjcmlwdGlvbiI6IG51bGx9IjtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI1LTEyLTIzIDA1OjE0OjUyIjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIxIDE5OjU0OjA4Ijt9czoxMDoiACoAY2hhbmdlcyI7YTowOnt9czoxMToiACoAcHJldmlvdXMiO2E6MDp7fXM6ODoiACoAY2FzdHMiO2E6MDp7fXM6MTc6IgAqAGNsYXNzQ2FzdENhY2hlIjthOjA6e31zOjIxOiIAKgBhdHRyaWJ1dGVDYXN0Q2FjaGUiO2E6MDp7fXM6MTM6IgAqAGRhdGVGb3JtYXQiO047czoxMDoiACoAYXBwZW5kcyI7YTowOnt9czoxOToiACoAZGlzcGF0Y2hlc0V2ZW50cyI7YTowOnt9czoxNDoiACoAb2JzZXJ2YWJsZXMiO2E6MDp7fXM6MTI6IgAqAHJlbGF0aW9ucyI7YTowOnt9czoxMDoiACoAdG91Y2hlcyI7YTowOnt9czoyNzoiACoAcmVsYXRpb25BdXRvbG9hZENhbGxiYWNrIjtOO3M6MjY6IgAqAHJlbGF0aW9uQXV0b2xvYWRDb250ZXh0IjtOO3M6MTA6InRpbWVzdGFtcHMiO2I6MTtzOjEzOiJ1c2VzVW5pcXVlSWRzIjtiOjA7czo5OiIAKgBoaWRkZW4iO2E6MDp7fXM6MTA6IgAqAHZpc2libGUiO2E6MDp7fXM6MTE6IgAqAGZpbGxhYmxlIjthOjM6e2k6MDtzOjEyOiJtZW51X21haW5faWQiO2k6MTtzOjY6ImxvY2FsZSI7aToyO3M6NDoiZGF0YSI7fXM6MTA6IgAqAGd1YXJkZWQiO2E6MTp7aTowO3M6MToiKiI7fX1pOjE7TzozMDoiQXBwXE1vZGVsc1xNZW51TWFpblRyYW5zbGF0aW9uIjozMzp7czoxMzoiACoAY29ubmVjdGlvbiI7czo1OiJwZ3NxbCI7czo4OiIAKgB0YWJsZSI7czoyMjoibWVudV9tYWluX3RyYW5zbGF0aW9ucyI7czoxMzoiACoAcHJpbWFyeUtleSI7czoyOiJpZCI7czoxMDoiACoAa2V5VHlwZSI7czozOiJpbnQiO3M6MTI6ImluY3JlbWVudGluZyI7YjoxO3M6NzoiACoAd2l0aCI7YTowOnt9czoxMjoiACoAd2l0aENvdW50IjthOjA6e31zOjE5OiJwcmV2ZW50c0xhenlMb2FkaW5nIjtiOjA7czoxMDoiACoAcGVyUGFnZSI7aToxNTtzOjY6ImV4aXN0cyI7YjoxO3M6MTg6Indhc1JlY2VudGx5Q3JlYXRlZCI7YjowO3M6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDtzOjEzOiIAKgBhdHRyaWJ1dGVzIjthOjY6e3M6MjoiaWQiO2k6MzI7czoxMjoibWVudV9tYWluX2lkIjtpOjE2O3M6NjoibG9jYWxlIjtzOjI6InJ1IjtzOjQ6ImRhdGEiO3M6NTE6InsiaW5mbyI6IG51bGwsICJ0aXRsZSI6ICJGQVEiLCAiZGVzY3JpcHRpb24iOiBudWxsfSI7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNS0xMi0yMyAwNToxNDo1MiI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMSAxOTo1NDowOCI7fXM6MTE6IgAqAG9yaWdpbmFsIjthOjY6e3M6MjoiaWQiO2k6MzI7czoxMjoibWVudV9tYWluX2lkIjtpOjE2O3M6NjoibG9jYWxlIjtzOjI6InJ1IjtzOjQ6ImRhdGEiO3M6NTE6InsiaW5mbyI6IG51bGwsICJ0aXRsZSI6ICJGQVEiLCAiZGVzY3JpcHRpb24iOiBudWxsfSI7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNS0xMi0yMyAwNToxNDo1MiI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMSAxOTo1NDowOCI7fXM6MTA6IgAqAGNoYW5nZXMiO2E6MDp7fXM6MTE6IgAqAHByZXZpb3VzIjthOjA6e31zOjg6IgAqAGNhc3RzIjthOjA6e31zOjE3OiIAKgBjbGFzc0Nhc3RDYWNoZSI7YTowOnt9czoyMToiACoAYXR0cmlidXRlQ2FzdENhY2hlIjthOjA6e31zOjEzOiIAKgBkYXRlRm9ybWF0IjtOO3M6MTA6IgAqAGFwcGVuZHMiO2E6MDp7fXM6MTk6IgAqAGRpc3BhdGNoZXNFdmVudHMiO2E6MDp7fXM6MTQ6IgAqAG9ic2VydmFibGVzIjthOjA6e31zOjEyOiIAKgByZWxhdGlvbnMiO2E6MDp7fXM6MTA6IgAqAHRvdWNoZXMiO2E6MDp7fXM6Mjc6IgAqAHJlbGF0aW9uQXV0b2xvYWRDYWxsYmFjayI7TjtzOjI2OiIAKgByZWxhdGlvbkF1dG9sb2FkQ29udGV4dCI7TjtzOjEwOiJ0aW1lc3RhbXBzIjtiOjE7czoxMzoidXNlc1VuaXF1ZUlkcyI7YjowO3M6OToiACoAaGlkZGVuIjthOjA6e31zOjEwOiIAKgB2aXNpYmxlIjthOjA6e31zOjExOiIAKgBmaWxsYWJsZSI7YTozOntpOjA7czoxMjoibWVudV9tYWluX2lkIjtpOjE7czo2OiJsb2NhbGUiO2k6MjtzOjQ6ImRhdGEiO31zOjEwOiIAKgBndWFyZGVkIjthOjE6e2k6MDtzOjE6IioiO319aToyO086MzA6IkFwcFxNb2RlbHNcTWVudU1haW5UcmFuc2xhdGlvbiI6MzM6e3M6MTM6IgAqAGNvbm5lY3Rpb24iO3M6NToicGdzcWwiO3M6ODoiACoAdGFibGUiO3M6MjI6Im1lbnVfbWFpbl90cmFuc2xhdGlvbnMiO3M6MTM6IgAqAHByaW1hcnlLZXkiO3M6MjoiaWQiO3M6MTA6IgAqAGtleVR5cGUiO3M6MzoiaW50IjtzOjEyOiJpbmNyZW1lbnRpbmciO2I6MTtzOjc6IgAqAHdpdGgiO2E6MDp7fXM6MTI6IgAqAHdpdGhDb3VudCI7YTowOnt9czoxOToicHJldmVudHNMYXp5TG9hZGluZyI7YjowO3M6MTA6IgAqAHBlclBhZ2UiO2k6MTU7czo2OiJleGlzdHMiO2I6MTtzOjE4OiJ3YXNSZWNlbnRseUNyZWF0ZWQiO2I6MDtzOjI4OiIAKgBlc2NhcGVXaGVuQ2FzdGluZ1RvU3RyaW5nIjtiOjA7czoxMzoiACoAYXR0cmlidXRlcyI7YTo2OntzOjI6ImlkIjtpOjE0NjtzOjEyOiJtZW51X21haW5faWQiO2k6MTY7czo2OiJsb2NhbGUiO3M6MjoiZW4iO3M6NDoiZGF0YSI7czo1MToieyJpbmZvIjogbnVsbCwgInRpdGxlIjogIkZBUSIsICJkZXNjcmlwdGlvbiI6IG51bGx9IjtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIxIDE5OjU0OjA4IjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIxIDE5OjU0OjA4Ijt9czoxMToiACoAb3JpZ2luYWwiO2E6Njp7czoyOiJpZCI7aToxNDY7czoxMjoibWVudV9tYWluX2lkIjtpOjE2O3M6NjoibG9jYWxlIjtzOjI6ImVuIjtzOjQ6ImRhdGEiO3M6NTE6InsiaW5mbyI6IG51bGwsICJ0aXRsZSI6ICJGQVEiLCAiZGVzY3JpcHRpb24iOiBudWxsfSI7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMSAxOTo1NDowOCI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMSAxOTo1NDowOCI7fXM6MTA6IgAqAGNoYW5nZXMiO2E6MDp7fXM6MTE6IgAqAHByZXZpb3VzIjthOjA6e31zOjg6IgAqAGNhc3RzIjthOjA6e31zOjE3OiIAKgBjbGFzc0Nhc3RDYWNoZSI7YTowOnt9czoyMToiACoAYXR0cmlidXRlQ2FzdENhY2hlIjthOjA6e31zOjEzOiIAKgBkYXRlRm9ybWF0IjtOO3M6MTA6IgAqAGFwcGVuZHMiO2E6MDp7fXM6MTk6IgAqAGRpc3BhdGNoZXNFdmVudHMiO2E6MDp7fXM6MTQ6IgAqAG9ic2VydmFibGVzIjthOjA6e31zOjEyOiIAKgByZWxhdGlvbnMiO2E6MDp7fXM6MTA6IgAqAHRvdWNoZXMiO2E6MDp7fXM6Mjc6IgAqAHJlbGF0aW9uQXV0b2xvYWRDYWxsYmFjayI7TjtzOjI2OiIAKgByZWxhdGlvbkF1dG9sb2FkQ29udGV4dCI7TjtzOjEwOiJ0aW1lc3RhbXBzIjtiOjE7czoxMzoidXNlc1VuaXF1ZUlkcyI7YjowO3M6OToiACoAaGlkZGVuIjthOjA6e31zOjEwOiIAKgB2aXNpYmxlIjthOjA6e31zOjExOiIAKgBmaWxsYWJsZSI7YTozOntpOjA7czoxMjoibWVudV9tYWluX2lkIjtpOjE7czo2OiJsb2NhbGUiO2k6MjtzOjQ6ImRhdGEiO31zOjEwOiIAKgBndWFyZGVkIjthOjE6e2k6MDtzOjE6IioiO319fXM6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDt9czo5OiJjaGlsZHJlbnMiO086Mzk6IklsbHVtaW5hdGVcRGF0YWJhc2VcRWxvcXVlbnRcQ29sbGVjdGlvbiI6Mjp7czo4OiIAKgBpdGVtcyI7YTowOnt9czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO319czoxMDoiACoAdG91Y2hlcyI7YTowOnt9czoyNzoiACoAcmVsYXRpb25BdXRvbG9hZENhbGxiYWNrIjtOO3M6MjY6IgAqAHJlbGF0aW9uQXV0b2xvYWRDb250ZXh0IjtOO3M6MTA6InRpbWVzdGFtcHMiO2I6MTtzOjEzOiJ1c2VzVW5pcXVlSWRzIjtiOjA7czo5OiIAKgBoaWRkZW4iO2E6MDp7fXM6MTA6IgAqAHZpc2libGUiO2E6MDp7fXM6MTE6IgAqAGZpbGxhYmxlIjthOjk6e2k6MDtzOjQ6InR5cGUiO2k6MTtzOjQ6InNsdWciO2k6MjtzOjM6InVybCI7aTozO3M6NDoidGVzdCI7aTo0O3M6MTA6InNob3dfYWRtaW4iO2k6NTtzOjEwOiJzb3J0X29yZGVyIjtpOjY7czo0OiJpY29uIjtpOjc7czo2OiJzdGF0dXMiO2k6ODtzOjk6InBhcmVudF9pZCI7fXM6MTA6IgAqAGd1YXJkZWQiO2E6MTp7aTowO3M6MToiKiI7fXM6MTk6IgAqAHRyYW5zbGF0aW9uQ2FjaGUiO047fX1zOjI4OiIAKgBlc2NhcGVXaGVuQ2FzdGluZ1RvU3RyaW5nIjtiOjA7fXM6MTI6InRyYW5zbGF0aW9ucyI7TzozOToiSWxsdW1pbmF0ZVxEYXRhYmFzZVxFbG9xdWVudFxDb2xsZWN0aW9uIjoyOntzOjg6IgAqAGl0ZW1zIjthOjM6e2k6MDtPOjMwOiJBcHBcTW9kZWxzXE1lbnVNYWluVHJhbnNsYXRpb24iOjMzOntzOjEzOiIAKgBjb25uZWN0aW9uIjtzOjU6InBnc3FsIjtzOjg6IgAqAHRhYmxlIjtzOjIyOiJtZW51X21haW5fdHJhbnNsYXRpb25zIjtzOjEzOiIAKgBwcmltYXJ5S2V5IjtzOjI6ImlkIjtzOjEwOiIAKgBrZXlUeXBlIjtzOjM6ImludCI7czoxMjoiaW5jcmVtZW50aW5nIjtiOjE7czo3OiIAKgB3aXRoIjthOjA6e31zOjEyOiIAKgB3aXRoQ291bnQiO2E6MDp7fXM6MTk6InByZXZlbnRzTGF6eUxvYWRpbmciO2I6MDtzOjEwOiIAKgBwZXJQYWdlIjtpOjE1O3M6NjoiZXhpc3RzIjtiOjE7czoxODoid2FzUmVjZW50bHlDcmVhdGVkIjtiOjA7czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO3M6MTM6IgAqAGF0dHJpYnV0ZXMiO2E6Njp7czoyOiJpZCI7aToyNTtzOjEyOiJtZW51X21haW5faWQiO2k6MTM7czo2OiJsb2NhbGUiO3M6MjoidXoiO3M6NDoiZGF0YSI7czo2MToieyJpbmZvIjogbnVsbCwgInRpdGxlIjogIkJpeiBoYXFpbWl6ZGEiLCAiZGVzY3JpcHRpb24iOiBudWxsfSI7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNS0xMi0yMyAwNToxMzoyNCI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMSAxOTo1MDoyOCI7fXM6MTE6IgAqAG9yaWdpbmFsIjthOjY6e3M6MjoiaWQiO2k6MjU7czoxMjoibWVudV9tYWluX2lkIjtpOjEzO3M6NjoibG9jYWxlIjtzOjI6InV6IjtzOjQ6ImRhdGEiO3M6NjE6InsiaW5mbyI6IG51bGwsICJ0aXRsZSI6ICJCaXogaGFxaW1pemRhIiwgImRlc2NyaXB0aW9uIjogbnVsbH0iO3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjUtMTItMjMgMDU6MTM6MjQiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDEtMjEgMTk6NTA6MjgiO31zOjEwOiIAKgBjaGFuZ2VzIjthOjA6e31zOjExOiIAKgBwcmV2aW91cyI7YTowOnt9czo4OiIAKgBjYXN0cyI7YTowOnt9czoxNzoiACoAY2xhc3NDYXN0Q2FjaGUiO2E6MDp7fXM6MjE6IgAqAGF0dHJpYnV0ZUNhc3RDYWNoZSI7YTowOnt9czoxMzoiACoAZGF0ZUZvcm1hdCI7TjtzOjEwOiIAKgBhcHBlbmRzIjthOjA6e31zOjE5OiIAKgBkaXNwYXRjaGVzRXZlbnRzIjthOjA6e31zOjE0OiIAKgBvYnNlcnZhYmxlcyI7YTowOnt9czoxMjoiACoAcmVsYXRpb25zIjthOjA6e31zOjEwOiIAKgB0b3VjaGVzIjthOjA6e31zOjI3OiIAKgByZWxhdGlvbkF1dG9sb2FkQ2FsbGJhY2siO047czoyNjoiACoAcmVsYXRpb25BdXRvbG9hZENvbnRleHQiO047czoxMDoidGltZXN0YW1wcyI7YjoxO3M6MTM6InVzZXNVbmlxdWVJZHMiO2I6MDtzOjk6IgAqAGhpZGRlbiI7YTowOnt9czoxMDoiACoAdmlzaWJsZSI7YTowOnt9czoxMToiACoAZmlsbGFibGUiO2E6Mzp7aTowO3M6MTI6Im1lbnVfbWFpbl9pZCI7aToxO3M6NjoibG9jYWxlIjtpOjI7czo0OiJkYXRhIjt9czoxMDoiACoAZ3VhcmRlZCI7YToxOntpOjA7czoxOiIqIjt9fWk6MTtPOjMwOiJBcHBcTW9kZWxzXE1lbnVNYWluVHJhbnNsYXRpb24iOjMzOntzOjEzOiIAKgBjb25uZWN0aW9uIjtzOjU6InBnc3FsIjtzOjg6IgAqAHRhYmxlIjtzOjIyOiJtZW51X21haW5fdHJhbnNsYXRpb25zIjtzOjEzOiIAKgBwcmltYXJ5S2V5IjtzOjI6ImlkIjtzOjEwOiIAKgBrZXlUeXBlIjtzOjM6ImludCI7czoxMjoiaW5jcmVtZW50aW5nIjtiOjE7czo3OiIAKgB3aXRoIjthOjA6e31zOjEyOiIAKgB3aXRoQ291bnQiO2E6MDp7fXM6MTk6InByZXZlbnRzTGF6eUxvYWRpbmciO2I6MDtzOjEwOiIAKgBwZXJQYWdlIjtpOjE1O3M6NjoiZXhpc3RzIjtiOjE7czoxODoid2FzUmVjZW50bHlDcmVhdGVkIjtiOjA7czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO3M6MTM6IgAqAGF0dHJpYnV0ZXMiO2E6Njp7czoyOiJpZCI7aToyNjtzOjEyOiJtZW51X21haW5faWQiO2k6MTM7czo2OiJsb2NhbGUiO3M6MjoicnUiO3M6NDoiZGF0YSI7czo1ODoieyJpbmZvIjogbnVsbCwgInRpdGxlIjogItCeICDQvdCw0YEiLCAiZGVzY3JpcHRpb24iOiBudWxsfSI7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNS0xMi0yMyAwNToxMzoyNCI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMSAxOTo1MDoyOCI7fXM6MTE6IgAqAG9yaWdpbmFsIjthOjY6e3M6MjoiaWQiO2k6MjY7czoxMjoibWVudV9tYWluX2lkIjtpOjEzO3M6NjoibG9jYWxlIjtzOjI6InJ1IjtzOjQ6ImRhdGEiO3M6NTg6InsiaW5mbyI6IG51bGwsICJ0aXRsZSI6ICLQniAg0L3QsNGBIiwgImRlc2NyaXB0aW9uIjogbnVsbH0iO3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjUtMTItMjMgMDU6MTM6MjQiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDEtMjEgMTk6NTA6MjgiO31zOjEwOiIAKgBjaGFuZ2VzIjthOjA6e31zOjExOiIAKgBwcmV2aW91cyI7YTowOnt9czo4OiIAKgBjYXN0cyI7YTowOnt9czoxNzoiACoAY2xhc3NDYXN0Q2FjaGUiO2E6MDp7fXM6MjE6IgAqAGF0dHJpYnV0ZUNhc3RDYWNoZSI7YTowOnt9czoxMzoiACoAZGF0ZUZvcm1hdCI7TjtzOjEwOiIAKgBhcHBlbmRzIjthOjA6e31zOjE5OiIAKgBkaXNwYXRjaGVzRXZlbnRzIjthOjA6e31zOjE0OiIAKgBvYnNlcnZhYmxlcyI7YTowOnt9czoxMjoiACoAcmVsYXRpb25zIjthOjA6e31zOjEwOiIAKgB0b3VjaGVzIjthOjA6e31zOjI3OiIAKgByZWxhdGlvbkF1dG9sb2FkQ2FsbGJhY2siO047czoyNjoiACoAcmVsYXRpb25BdXRvbG9hZENvbnRleHQiO047czoxMDoidGltZXN0YW1wcyI7YjoxO3M6MTM6InVzZXNVbmlxdWVJZHMiO2I6MDtzOjk6IgAqAGhpZGRlbiI7YTowOnt9czoxMDoiACoAdmlzaWJsZSI7YTowOnt9czoxMToiACoAZmlsbGFibGUiO2E6Mzp7aTowO3M6MTI6Im1lbnVfbWFpbl9pZCI7aToxO3M6NjoibG9jYWxlIjtpOjI7czo0OiJkYXRhIjt9czoxMDoiACoAZ3VhcmRlZCI7YToxOntpOjA7czoxOiIqIjt9fWk6MjtPOjMwOiJBcHBcTW9kZWxzXE1lbnVNYWluVHJhbnNsYXRpb24iOjMzOntzOjEzOiIAKgBjb25uZWN0aW9uIjtzOjU6InBnc3FsIjtzOjg6IgAqAHRhYmxlIjtzOjIyOiJtZW51X21haW5fdHJhbnNsYXRpb25zIjtzOjEzOiIAKgBwcmltYXJ5S2V5IjtzOjI6ImlkIjtzOjEwOiIAKgBrZXlUeXBlIjtzOjM6ImludCI7czoxMjoiaW5jcmVtZW50aW5nIjtiOjE7czo3OiIAKgB3aXRoIjthOjA6e31zOjEyOiIAKgB3aXRoQ291bnQiO2E6MDp7fXM6MTk6InByZXZlbnRzTGF6eUxvYWRpbmciO2I6MDtzOjEwOiIAKgBwZXJQYWdlIjtpOjE1O3M6NjoiZXhpc3RzIjtiOjE7czoxODoid2FzUmVjZW50bHlDcmVhdGVkIjtiOjA7czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO3M6MTM6IgAqAGF0dHJpYnV0ZXMiO2E6Njp7czoyOiJpZCI7aToxNDU7czoxMjoibWVudV9tYWluX2lkIjtpOjEzO3M6NjoibG9jYWxlIjtzOjI6ImVuIjtzOjQ6ImRhdGEiO3M6NTY6InsiaW5mbyI6IG51bGwsICJ0aXRsZSI6ICJBYm91dCB1cyIsICJkZXNjcmlwdGlvbiI6IG51bGx9IjtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIxIDE5OjUwOjI4IjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIxIDE5OjUwOjI4Ijt9czoxMToiACoAb3JpZ2luYWwiO2E6Njp7czoyOiJpZCI7aToxNDU7czoxMjoibWVudV9tYWluX2lkIjtpOjEzO3M6NjoibG9jYWxlIjtzOjI6ImVuIjtzOjQ6ImRhdGEiO3M6NTY6InsiaW5mbyI6IG51bGwsICJ0aXRsZSI6ICJBYm91dCB1cyIsICJkZXNjcmlwdGlvbiI6IG51bGx9IjtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIxIDE5OjUwOjI4IjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIxIDE5OjUwOjI4Ijt9czoxMDoiACoAY2hhbmdlcyI7YTowOnt9czoxMToiACoAcHJldmlvdXMiO2E6MDp7fXM6ODoiACoAY2FzdHMiO2E6MDp7fXM6MTc6IgAqAGNsYXNzQ2FzdENhY2hlIjthOjA6e31zOjIxOiIAKgBhdHRyaWJ1dGVDYXN0Q2FjaGUiO2E6MDp7fXM6MTM6IgAqAGRhdGVGb3JtYXQiO047czoxMDoiACoAYXBwZW5kcyI7YTowOnt9czoxOToiACoAZGlzcGF0Y2hlc0V2ZW50cyI7YTowOnt9czoxNDoiACoAb2JzZXJ2YWJsZXMiO2E6MDp7fXM6MTI6IgAqAHJlbGF0aW9ucyI7YTowOnt9czoxMDoiACoAdG91Y2hlcyI7YTowOnt9czoyNzoiACoAcmVsYXRpb25BdXRvbG9hZENhbGxiYWNrIjtOO3M6MjY6IgAqAHJlbGF0aW9uQXV0b2xvYWRDb250ZXh0IjtOO3M6MTA6InRpbWVzdGFtcHMiO2I6MTtzOjEzOiJ1c2VzVW5pcXVlSWRzIjtiOjA7czo5OiIAKgBoaWRkZW4iO2E6MDp7fXM6MTA6IgAqAHZpc2libGUiO2E6MDp7fXM6MTE6IgAqAGZpbGxhYmxlIjthOjM6e2k6MDtzOjEyOiJtZW51X21haW5faWQiO2k6MTtzOjY6ImxvY2FsZSI7aToyO3M6NDoiZGF0YSI7fXM6MTA6IgAqAGd1YXJkZWQiO2E6MTp7aTowO3M6MToiKiI7fX19czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO319czoxMDoiACoAdG91Y2hlcyI7YTowOnt9czoyNzoiACoAcmVsYXRpb25BdXRvbG9hZENhbGxiYWNrIjtOO3M6MjY6IgAqAHJlbGF0aW9uQXV0b2xvYWRDb250ZXh0IjtOO3M6MTA6InRpbWVzdGFtcHMiO2I6MTtzOjEzOiJ1c2VzVW5pcXVlSWRzIjtiOjA7czo5OiIAKgBoaWRkZW4iO2E6MDp7fXM6MTA6IgAqAHZpc2libGUiO2E6MDp7fXM6MTE6IgAqAGZpbGxhYmxlIjthOjk6e2k6MDtzOjQ6InR5cGUiO2k6MTtzOjQ6InNsdWciO2k6MjtzOjM6InVybCI7aTozO3M6NDoidGVzdCI7aTo0O3M6MTA6InNob3dfYWRtaW4iO2k6NTtzOjEwOiJzb3J0X29yZGVyIjtpOjY7czo0OiJpY29uIjtpOjc7czo2OiJzdGF0dXMiO2k6ODtzOjk6InBhcmVudF9pZCI7fXM6MTA6IgAqAGd1YXJkZWQiO2E6MTp7aTowO3M6MToiKiI7fXM6MTk6IgAqAHRyYW5zbGF0aW9uQ2FjaGUiO047fWk6MjtPOjE5OiJBcHBcTW9kZWxzXE1lbnVNYWluIjozNDp7czoxMzoiACoAY29ubmVjdGlvbiI7czo1OiJwZ3NxbCI7czo4OiIAKgB0YWJsZSI7czoxMDoibWVudV9tYWlucyI7czoxMzoiACoAcHJpbWFyeUtleSI7czoyOiJpZCI7czoxMDoiACoAa2V5VHlwZSI7czozOiJpbnQiO3M6MTI6ImluY3JlbWVudGluZyI7YjoxO3M6NzoiACoAd2l0aCI7YTowOnt9czoxMjoiACoAd2l0aENvdW50IjthOjA6e31zOjE5OiJwcmV2ZW50c0xhenlMb2FkaW5nIjtiOjA7czoxMDoiACoAcGVyUGFnZSI7aToxNTtzOjY6ImV4aXN0cyI7YjoxO3M6MTg6Indhc1JlY2VudGx5Q3JlYXRlZCI7YjowO3M6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDtzOjEzOiIAKgBhdHRyaWJ1dGVzIjthOjEyOntzOjI6ImlkIjtpOjIwO3M6NDoidHlwZSI7czo0OiJwYWdlIjtzOjQ6InNsdWciO3M6MTI6ImJpcmxhc2htYWxhciI7czozOiJ1cmwiO047czo0OiJ0ZXN0IjtiOjA7czoxMDoic2hvd19hZG1pbiI7YjoxO3M6MTA6InNvcnRfb3JkZXIiO2k6NDtzOjQ6Imljb24iO047czo2OiJzdGF0dXMiO2I6MTtzOjk6InBhcmVudF9pZCI7TjtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI1LTEyLTIzIDA1OjM2OjMxIjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIyIDE1OjEwOjM1Ijt9czoxMToiACoAb3JpZ2luYWwiO2E6MTI6e3M6MjoiaWQiO2k6MjA7czo0OiJ0eXBlIjtzOjQ6InBhZ2UiO3M6NDoic2x1ZyI7czoxMjoiYmlybGFzaG1hbGFyIjtzOjM6InVybCI7TjtzOjQ6InRlc3QiO2I6MDtzOjEwOiJzaG93X2FkbWluIjtiOjE7czoxMDoic29ydF9vcmRlciI7aTo0O3M6NDoiaWNvbiI7TjtzOjY6InN0YXR1cyI7YjoxO3M6OToicGFyZW50X2lkIjtOO3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjUtMTItMjMgMDU6MzY6MzEiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDEtMjIgMTU6MTA6MzUiO31zOjEwOiIAKgBjaGFuZ2VzIjthOjA6e31zOjExOiIAKgBwcmV2aW91cyI7YTowOnt9czo4OiIAKgBjYXN0cyI7YTowOnt9czoxNzoiACoAY2xhc3NDYXN0Q2FjaGUiO2E6MDp7fXM6MjE6IgAqAGF0dHJpYnV0ZUNhc3RDYWNoZSI7YTowOnt9czoxMzoiACoAZGF0ZUZvcm1hdCI7TjtzOjEwOiIAKgBhcHBlbmRzIjthOjA6e31zOjE5OiIAKgBkaXNwYXRjaGVzRXZlbnRzIjthOjA6e31zOjE0OiIAKgBvYnNlcnZhYmxlcyI7YTowOnt9czoxMjoiACoAcmVsYXRpb25zIjthOjI6e3M6OToiY2hpbGRyZW5zIjtPOjM5OiJJbGx1bWluYXRlXERhdGFiYXNlXEVsb3F1ZW50XENvbGxlY3Rpb24iOjI6e3M6ODoiACoAaXRlbXMiO2E6MTp7aTowO086MTk6IkFwcFxNb2RlbHNcTWVudU1haW4iOjM0OntzOjEzOiIAKgBjb25uZWN0aW9uIjtzOjU6InBnc3FsIjtzOjg6IgAqAHRhYmxlIjtzOjEwOiJtZW51X21haW5zIjtzOjEzOiIAKgBwcmltYXJ5S2V5IjtzOjI6ImlkIjtzOjEwOiIAKgBrZXlUeXBlIjtzOjM6ImludCI7czoxMjoiaW5jcmVtZW50aW5nIjtiOjE7czo3OiIAKgB3aXRoIjthOjA6e31zOjEyOiIAKgB3aXRoQ291bnQiO2E6MDp7fXM6MTk6InByZXZlbnRzTGF6eUxvYWRpbmciO2I6MDtzOjEwOiIAKgBwZXJQYWdlIjtpOjE1O3M6NjoiZXhpc3RzIjtiOjE7czoxODoid2FzUmVjZW50bHlDcmVhdGVkIjtiOjA7czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO3M6MTM6IgAqAGF0dHJpYnV0ZXMiO2E6MTI6e3M6MjoiaWQiO2k6MjE7czo0OiJ0eXBlIjtzOjQ6InBhZ2UiO3M6NDoic2x1ZyI7czoxMjoiYXNzb2NpYXRpb25zIjtzOjM6InVybCI7TjtzOjQ6InRlc3QiO2I6MDtzOjEwOiJzaG93X2FkbWluIjtiOjE7czoxMDoic29ydF9vcmRlciI7aToyMTtzOjQ6Imljb24iO047czo2OiJzdGF0dXMiO2I6MTtzOjk6InBhcmVudF9pZCI7aToyMDtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI1LTEyLTIzIDA1OjM2OjQ5IjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTE0IDEwOjM4OjM4Ijt9czoxMToiACoAb3JpZ2luYWwiO2E6MTI6e3M6MjoiaWQiO2k6MjE7czo0OiJ0eXBlIjtzOjQ6InBhZ2UiO3M6NDoic2x1ZyI7czoxMjoiYXNzb2NpYXRpb25zIjtzOjM6InVybCI7TjtzOjQ6InRlc3QiO2I6MDtzOjEwOiJzaG93X2FkbWluIjtiOjE7czoxMDoic29ydF9vcmRlciI7aToyMTtzOjQ6Imljb24iO047czo2OiJzdGF0dXMiO2I6MTtzOjk6InBhcmVudF9pZCI7aToyMDtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI1LTEyLTIzIDA1OjM2OjQ5IjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTE0IDEwOjM4OjM4Ijt9czoxMDoiACoAY2hhbmdlcyI7YTowOnt9czoxMToiACoAcHJldmlvdXMiO2E6MDp7fXM6ODoiACoAY2FzdHMiO2E6MDp7fXM6MTc6IgAqAGNsYXNzQ2FzdENhY2hlIjthOjA6e31zOjIxOiIAKgBhdHRyaWJ1dGVDYXN0Q2FjaGUiO2E6MDp7fXM6MTM6IgAqAGRhdGVGb3JtYXQiO047czoxMDoiACoAYXBwZW5kcyI7YTowOnt9czoxOToiACoAZGlzcGF0Y2hlc0V2ZW50cyI7YTowOnt9czoxNDoiACoAb2JzZXJ2YWJsZXMiO2E6MDp7fXM6MTI6IgAqAHJlbGF0aW9ucyI7YToyOntzOjEyOiJ0cmFuc2xhdGlvbnMiO086Mzk6IklsbHVtaW5hdGVcRGF0YWJhc2VcRWxvcXVlbnRcQ29sbGVjdGlvbiI6Mjp7czo4OiIAKgBpdGVtcyI7YTozOntpOjA7TzozMDoiQXBwXE1vZGVsc1xNZW51TWFpblRyYW5zbGF0aW9uIjozMzp7czoxMzoiACoAY29ubmVjdGlvbiI7czo1OiJwZ3NxbCI7czo4OiIAKgB0YWJsZSI7czoyMjoibWVudV9tYWluX3RyYW5zbGF0aW9ucyI7czoxMzoiACoAcHJpbWFyeUtleSI7czoyOiJpZCI7czoxMDoiACoAa2V5VHlwZSI7czozOiJpbnQiO3M6MTI6ImluY3JlbWVudGluZyI7YjoxO3M6NzoiACoAd2l0aCI7YTowOnt9czoxMjoiACoAd2l0aENvdW50IjthOjA6e31zOjE5OiJwcmV2ZW50c0xhenlMb2FkaW5nIjtiOjA7czoxMDoiACoAcGVyUGFnZSI7aToxNTtzOjY6ImV4aXN0cyI7YjoxO3M6MTg6Indhc1JlY2VudGx5Q3JlYXRlZCI7YjowO3M6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDtzOjEzOiIAKgBhdHRyaWJ1dGVzIjthOjY6e3M6MjoiaWQiO2k6NDE7czoxMjoibWVudV9tYWluX2lkIjtpOjIxO3M6NjoibG9jYWxlIjtzOjI6InV6IjtzOjQ6ImRhdGEiO3M6Njg6InsiaW5mbyI6IG51bGwsICJ0aXRsZSI6ICJKYW1vYXQgYmlybGFzaG1hbGFyaSIsICJkZXNjcmlwdGlvbiI6IG51bGx9IjtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI1LTEyLTIzIDA1OjM2OjQ5IjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIxIDE5OjU1OjE0Ijt9czoxMToiACoAb3JpZ2luYWwiO2E6Njp7czoyOiJpZCI7aTo0MTtzOjEyOiJtZW51X21haW5faWQiO2k6MjE7czo2OiJsb2NhbGUiO3M6MjoidXoiO3M6NDoiZGF0YSI7czo2ODoieyJpbmZvIjogbnVsbCwgInRpdGxlIjogIkphbW9hdCBiaXJsYXNobWFsYXJpIiwgImRlc2NyaXB0aW9uIjogbnVsbH0iO3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjUtMTItMjMgMDU6MzY6NDkiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDEtMjEgMTk6NTU6MTQiO31zOjEwOiIAKgBjaGFuZ2VzIjthOjA6e31zOjExOiIAKgBwcmV2aW91cyI7YTowOnt9czo4OiIAKgBjYXN0cyI7YTowOnt9czoxNzoiACoAY2xhc3NDYXN0Q2FjaGUiO2E6MDp7fXM6MjE6IgAqAGF0dHJpYnV0ZUNhc3RDYWNoZSI7YTowOnt9czoxMzoiACoAZGF0ZUZvcm1hdCI7TjtzOjEwOiIAKgBhcHBlbmRzIjthOjA6e31zOjE5OiIAKgBkaXNwYXRjaGVzRXZlbnRzIjthOjA6e31zOjE0OiIAKgBvYnNlcnZhYmxlcyI7YTowOnt9czoxMjoiACoAcmVsYXRpb25zIjthOjA6e31zOjEwOiIAKgB0b3VjaGVzIjthOjA6e31zOjI3OiIAKgByZWxhdGlvbkF1dG9sb2FkQ2FsbGJhY2siO047czoyNjoiACoAcmVsYXRpb25BdXRvbG9hZENvbnRleHQiO047czoxMDoidGltZXN0YW1wcyI7YjoxO3M6MTM6InVzZXNVbmlxdWVJZHMiO2I6MDtzOjk6IgAqAGhpZGRlbiI7YTowOnt9czoxMDoiACoAdmlzaWJsZSI7YTowOnt9czoxMToiACoAZmlsbGFibGUiO2E6Mzp7aTowO3M6MTI6Im1lbnVfbWFpbl9pZCI7aToxO3M6NjoibG9jYWxlIjtpOjI7czo0OiJkYXRhIjt9czoxMDoiACoAZ3VhcmRlZCI7YToxOntpOjA7czoxOiIqIjt9fWk6MTtPOjMwOiJBcHBcTW9kZWxzXE1lbnVNYWluVHJhbnNsYXRpb24iOjMzOntzOjEzOiIAKgBjb25uZWN0aW9uIjtzOjU6InBnc3FsIjtzOjg6IgAqAHRhYmxlIjtzOjIyOiJtZW51X21haW5fdHJhbnNsYXRpb25zIjtzOjEzOiIAKgBwcmltYXJ5S2V5IjtzOjI6ImlkIjtzOjEwOiIAKgBrZXlUeXBlIjtzOjM6ImludCI7czoxMjoiaW5jcmVtZW50aW5nIjtiOjE7czo3OiIAKgB3aXRoIjthOjA6e31zOjEyOiIAKgB3aXRoQ291bnQiO2E6MDp7fXM6MTk6InByZXZlbnRzTGF6eUxvYWRpbmciO2I6MDtzOjEwOiIAKgBwZXJQYWdlIjtpOjE1O3M6NjoiZXhpc3RzIjtiOjE7czoxODoid2FzUmVjZW50bHlDcmVhdGVkIjtiOjA7czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO3M6MTM6IgAqAGF0dHJpYnV0ZXMiO2E6Njp7czoyOiJpZCI7aTo0MjtzOjEyOiJtZW51X21haW5faWQiO2k6MjE7czo2OiJsb2NhbGUiO3M6MjoicnUiO3M6NDoiZGF0YSI7czo5NToieyJpbmZvIjogbnVsbCwgInRpdGxlIjogItCe0LHRidC10YHRgtCy0LXQvdC90YvQtSDQvtCx0YrQtdC00LjQvdC10L3QuNGPIiwgImRlc2NyaXB0aW9uIjogbnVsbH0iO3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjUtMTItMjMgMDU6MzY6NDkiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDEtMjEgMTk6NTU6MTQiO31zOjExOiIAKgBvcmlnaW5hbCI7YTo2OntzOjI6ImlkIjtpOjQyO3M6MTI6Im1lbnVfbWFpbl9pZCI7aToyMTtzOjY6ImxvY2FsZSI7czoyOiJydSI7czo0OiJkYXRhIjtzOjk1OiJ7ImluZm8iOiBudWxsLCAidGl0bGUiOiAi0J7QsdGJ0LXRgdGC0LLQtdC90L3Ri9C1INC+0LHRitC10LTQuNC90LXQvdC40Y8iLCAiZGVzY3JpcHRpb24iOiBudWxsfSI7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNS0xMi0yMyAwNTozNjo0OSI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMSAxOTo1NToxNCI7fXM6MTA6IgAqAGNoYW5nZXMiO2E6MDp7fXM6MTE6IgAqAHByZXZpb3VzIjthOjA6e31zOjg6IgAqAGNhc3RzIjthOjA6e31zOjE3OiIAKgBjbGFzc0Nhc3RDYWNoZSI7YTowOnt9czoyMToiACoAYXR0cmlidXRlQ2FzdENhY2hlIjthOjA6e31zOjEzOiIAKgBkYXRlRm9ybWF0IjtOO3M6MTA6IgAqAGFwcGVuZHMiO2E6MDp7fXM6MTk6IgAqAGRpc3BhdGNoZXNFdmVudHMiO2E6MDp7fXM6MTQ6IgAqAG9ic2VydmFibGVzIjthOjA6e31zOjEyOiIAKgByZWxhdGlvbnMiO2E6MDp7fXM6MTA6IgAqAHRvdWNoZXMiO2E6MDp7fXM6Mjc6IgAqAHJlbGF0aW9uQXV0b2xvYWRDYWxsYmFjayI7TjtzOjI2OiIAKgByZWxhdGlvbkF1dG9sb2FkQ29udGV4dCI7TjtzOjEwOiJ0aW1lc3RhbXBzIjtiOjE7czoxMzoidXNlc1VuaXF1ZUlkcyI7YjowO3M6OToiACoAaGlkZGVuIjthOjA6e31zOjEwOiIAKgB2aXNpYmxlIjthOjA6e31zOjExOiIAKgBmaWxsYWJsZSI7YTozOntpOjA7czoxMjoibWVudV9tYWluX2lkIjtpOjE7czo2OiJsb2NhbGUiO2k6MjtzOjQ6ImRhdGEiO31zOjEwOiIAKgBndWFyZGVkIjthOjE6e2k6MDtzOjE6IioiO319aToyO086MzA6IkFwcFxNb2RlbHNcTWVudU1haW5UcmFuc2xhdGlvbiI6MzM6e3M6MTM6IgAqAGNvbm5lY3Rpb24iO3M6NToicGdzcWwiO3M6ODoiACoAdGFibGUiO3M6MjI6Im1lbnVfbWFpbl90cmFuc2xhdGlvbnMiO3M6MTM6IgAqAHByaW1hcnlLZXkiO3M6MjoiaWQiO3M6MTA6IgAqAGtleVR5cGUiO3M6MzoiaW50IjtzOjEyOiJpbmNyZW1lbnRpbmciO2I6MTtzOjc6IgAqAHdpdGgiO2E6MDp7fXM6MTI6IgAqAHdpdGhDb3VudCI7YTowOnt9czoxOToicHJldmVudHNMYXp5TG9hZGluZyI7YjowO3M6MTA6IgAqAHBlclBhZ2UiO2k6MTU7czo2OiJleGlzdHMiO2I6MTtzOjE4OiJ3YXNSZWNlbnRseUNyZWF0ZWQiO2I6MDtzOjI4OiIAKgBlc2NhcGVXaGVuQ2FzdGluZ1RvU3RyaW5nIjtiOjA7czoxMzoiACoAYXR0cmlidXRlcyI7YTo2OntzOjI6ImlkIjtpOjEzNTtzOjEyOiJtZW51X21haW5faWQiO2k6MjE7czo2OiJsb2NhbGUiO3M6MjoiZW4iO3M6NDoiZGF0YSI7czo2NzoieyJpbmZvIjogbnVsbCwgInRpdGxlIjogIlB1YmxpYyBhc3NvY2lhdGlvbnMiLCAiZGVzY3JpcHRpb24iOiBudWxsfSI7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNi0wMS0xNCAxMDozODozOSI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMSAxOTo1NToxNCI7fXM6MTE6IgAqAG9yaWdpbmFsIjthOjY6e3M6MjoiaWQiO2k6MTM1O3M6MTI6Im1lbnVfbWFpbl9pZCI7aToyMTtzOjY6ImxvY2FsZSI7czoyOiJlbiI7czo0OiJkYXRhIjtzOjY3OiJ7ImluZm8iOiBudWxsLCAidGl0bGUiOiAiUHVibGljIGFzc29jaWF0aW9ucyIsICJkZXNjcmlwdGlvbiI6IG51bGx9IjtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTE0IDEwOjM4OjM5IjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIxIDE5OjU1OjE0Ijt9czoxMDoiACoAY2hhbmdlcyI7YTowOnt9czoxMToiACoAcHJldmlvdXMiO2E6MDp7fXM6ODoiACoAY2FzdHMiO2E6MDp7fXM6MTc6IgAqAGNsYXNzQ2FzdENhY2hlIjthOjA6e31zOjIxOiIAKgBhdHRyaWJ1dGVDYXN0Q2FjaGUiO2E6MDp7fXM6MTM6IgAqAGRhdGVGb3JtYXQiO047czoxMDoiACoAYXBwZW5kcyI7YTowOnt9czoxOToiACoAZGlzcGF0Y2hlc0V2ZW50cyI7YTowOnt9czoxNDoiACoAb2JzZXJ2YWJsZXMiO2E6MDp7fXM6MTI6IgAqAHJlbGF0aW9ucyI7YTowOnt9czoxMDoiACoAdG91Y2hlcyI7YTowOnt9czoyNzoiACoAcmVsYXRpb25BdXRvbG9hZENhbGxiYWNrIjtOO3M6MjY6IgAqAHJlbGF0aW9uQXV0b2xvYWRDb250ZXh0IjtOO3M6MTA6InRpbWVzdGFtcHMiO2I6MTtzOjEzOiJ1c2VzVW5pcXVlSWRzIjtiOjA7czo5OiIAKgBoaWRkZW4iO2E6MDp7fXM6MTA6IgAqAHZpc2libGUiO2E6MDp7fXM6MTE6IgAqAGZpbGxhYmxlIjthOjM6e2k6MDtzOjEyOiJtZW51X21haW5faWQiO2k6MTtzOjY6ImxvY2FsZSI7aToyO3M6NDoiZGF0YSI7fXM6MTA6IgAqAGd1YXJkZWQiO2E6MTp7aTowO3M6MToiKiI7fX19czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO31zOjk6ImNoaWxkcmVucyI7TzozOToiSWxsdW1pbmF0ZVxEYXRhYmFzZVxFbG9xdWVudFxDb2xsZWN0aW9uIjoyOntzOjg6IgAqAGl0ZW1zIjthOjA6e31zOjI4OiIAKgBlc2NhcGVXaGVuQ2FzdGluZ1RvU3RyaW5nIjtiOjA7fX1zOjEwOiIAKgB0b3VjaGVzIjthOjA6e31zOjI3OiIAKgByZWxhdGlvbkF1dG9sb2FkQ2FsbGJhY2siO047czoyNjoiACoAcmVsYXRpb25BdXRvbG9hZENvbnRleHQiO047czoxMDoidGltZXN0YW1wcyI7YjoxO3M6MTM6InVzZXNVbmlxdWVJZHMiO2I6MDtzOjk6IgAqAGhpZGRlbiI7YTowOnt9czoxMDoiACoAdmlzaWJsZSI7YTowOnt9czoxMToiACoAZmlsbGFibGUiO2E6OTp7aTowO3M6NDoidHlwZSI7aToxO3M6NDoic2x1ZyI7aToyO3M6MzoidXJsIjtpOjM7czo0OiJ0ZXN0IjtpOjQ7czoxMDoic2hvd19hZG1pbiI7aTo1O3M6MTA6InNvcnRfb3JkZXIiO2k6NjtzOjQ6Imljb24iO2k6NztzOjY6InN0YXR1cyI7aTo4O3M6OToicGFyZW50X2lkIjt9czoxMDoiACoAZ3VhcmRlZCI7YToxOntpOjA7czoxOiIqIjt9czoxOToiACoAdHJhbnNsYXRpb25DYWNoZSI7Tjt9fXM6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDt9czoxMjoidHJhbnNsYXRpb25zIjtPOjM5OiJJbGx1bWluYXRlXERhdGFiYXNlXEVsb3F1ZW50XENvbGxlY3Rpb24iOjI6e3M6ODoiACoAaXRlbXMiO2E6Mzp7aTowO086MzA6IkFwcFxNb2RlbHNcTWVudU1haW5UcmFuc2xhdGlvbiI6MzM6e3M6MTM6IgAqAGNvbm5lY3Rpb24iO3M6NToicGdzcWwiO3M6ODoiACoAdGFibGUiO3M6MjI6Im1lbnVfbWFpbl90cmFuc2xhdGlvbnMiO3M6MTM6IgAqAHByaW1hcnlLZXkiO3M6MjoiaWQiO3M6MTA6IgAqAGtleVR5cGUiO3M6MzoiaW50IjtzOjEyOiJpbmNyZW1lbnRpbmciO2I6MTtzOjc6IgAqAHdpdGgiO2E6MDp7fXM6MTI6IgAqAHdpdGhDb3VudCI7YTowOnt9czoxOToicHJldmVudHNMYXp5TG9hZGluZyI7YjowO3M6MTA6IgAqAHBlclBhZ2UiO2k6MTU7czo2OiJleGlzdHMiO2I6MTtzOjE4OiJ3YXNSZWNlbnRseUNyZWF0ZWQiO2I6MDtzOjI4OiIAKgBlc2NhcGVXaGVuQ2FzdGluZ1RvU3RyaW5nIjtiOjA7czoxMzoiACoAYXR0cmlidXRlcyI7YTo2OntzOjI6ImlkIjtpOjM5O3M6MTI6Im1lbnVfbWFpbl9pZCI7aToyMDtzOjY6ImxvY2FsZSI7czoyOiJ1eiI7czo0OiJkYXRhIjtzOjYwOiJ7ImluZm8iOiBudWxsLCAidGl0bGUiOiAiQmlybGFzaG1hbGFyIiwgImRlc2NyaXB0aW9uIjogbnVsbH0iO3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjUtMTItMjMgMDU6MzY6MzEiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDEtMjEgMTk6NTQ6MzgiO31zOjExOiIAKgBvcmlnaW5hbCI7YTo2OntzOjI6ImlkIjtpOjM5O3M6MTI6Im1lbnVfbWFpbl9pZCI7aToyMDtzOjY6ImxvY2FsZSI7czoyOiJ1eiI7czo0OiJkYXRhIjtzOjYwOiJ7ImluZm8iOiBudWxsLCAidGl0bGUiOiAiQmlybGFzaG1hbGFyIiwgImRlc2NyaXB0aW9uIjogbnVsbH0iO3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjUtMTItMjMgMDU6MzY6MzEiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDEtMjEgMTk6NTQ6MzgiO31zOjEwOiIAKgBjaGFuZ2VzIjthOjA6e31zOjExOiIAKgBwcmV2aW91cyI7YTowOnt9czo4OiIAKgBjYXN0cyI7YTowOnt9czoxNzoiACoAY2xhc3NDYXN0Q2FjaGUiO2E6MDp7fXM6MjE6IgAqAGF0dHJpYnV0ZUNhc3RDYWNoZSI7YTowOnt9czoxMzoiACoAZGF0ZUZvcm1hdCI7TjtzOjEwOiIAKgBhcHBlbmRzIjthOjA6e31zOjE5OiIAKgBkaXNwYXRjaGVzRXZlbnRzIjthOjA6e31zOjE0OiIAKgBvYnNlcnZhYmxlcyI7YTowOnt9czoxMjoiACoAcmVsYXRpb25zIjthOjA6e31zOjEwOiIAKgB0b3VjaGVzIjthOjA6e31zOjI3OiIAKgByZWxhdGlvbkF1dG9sb2FkQ2FsbGJhY2siO047czoyNjoiACoAcmVsYXRpb25BdXRvbG9hZENvbnRleHQiO047czoxMDoidGltZXN0YW1wcyI7YjoxO3M6MTM6InVzZXNVbmlxdWVJZHMiO2I6MDtzOjk6IgAqAGhpZGRlbiI7YTowOnt9czoxMDoiACoAdmlzaWJsZSI7YTowOnt9czoxMToiACoAZmlsbGFibGUiO2E6Mzp7aTowO3M6MTI6Im1lbnVfbWFpbl9pZCI7aToxO3M6NjoibG9jYWxlIjtpOjI7czo0OiJkYXRhIjt9czoxMDoiACoAZ3VhcmRlZCI7YToxOntpOjA7czoxOiIqIjt9fWk6MTtPOjMwOiJBcHBcTW9kZWxzXE1lbnVNYWluVHJhbnNsYXRpb24iOjMzOntzOjEzOiIAKgBjb25uZWN0aW9uIjtzOjU6InBnc3FsIjtzOjg6IgAqAHRhYmxlIjtzOjIyOiJtZW51X21haW5fdHJhbnNsYXRpb25zIjtzOjEzOiIAKgBwcmltYXJ5S2V5IjtzOjI6ImlkIjtzOjEwOiIAKgBrZXlUeXBlIjtzOjM6ImludCI7czoxMjoiaW5jcmVtZW50aW5nIjtiOjE7czo3OiIAKgB3aXRoIjthOjA6e31zOjEyOiIAKgB3aXRoQ291bnQiO2E6MDp7fXM6MTk6InByZXZlbnRzTGF6eUxvYWRpbmciO2I6MDtzOjEwOiIAKgBwZXJQYWdlIjtpOjE1O3M6NjoiZXhpc3RzIjtiOjE7czoxODoid2FzUmVjZW50bHlDcmVhdGVkIjtiOjA7czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO3M6MTM6IgAqAGF0dHJpYnV0ZXMiO2E6Njp7czoyOiJpZCI7aTo0MDtzOjEyOiJtZW51X21haW5faWQiO2k6MjA7czo2OiJsb2NhbGUiO3M6MjoicnUiO3M6NDoiZGF0YSI7czo2ODoieyJpbmZvIjogbnVsbCwgInRpdGxlIjogItCQ0YHRgdC+0YbQuNCw0YbQuNC4IiwgImRlc2NyaXB0aW9uIjogbnVsbH0iO3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjUtMTItMjMgMDU6MzY6MzEiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDEtMjEgMTk6NTQ6MzgiO31zOjExOiIAKgBvcmlnaW5hbCI7YTo2OntzOjI6ImlkIjtpOjQwO3M6MTI6Im1lbnVfbWFpbl9pZCI7aToyMDtzOjY6ImxvY2FsZSI7czoyOiJydSI7czo0OiJkYXRhIjtzOjY4OiJ7ImluZm8iOiBudWxsLCAidGl0bGUiOiAi0JDRgdGB0L7RhtC40LDRhtC40LgiLCAiZGVzY3JpcHRpb24iOiBudWxsfSI7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNS0xMi0yMyAwNTozNjozMSI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMSAxOTo1NDozOCI7fXM6MTA6IgAqAGNoYW5nZXMiO2E6MDp7fXM6MTE6IgAqAHByZXZpb3VzIjthOjA6e31zOjg6IgAqAGNhc3RzIjthOjA6e31zOjE3OiIAKgBjbGFzc0Nhc3RDYWNoZSI7YTowOnt9czoyMToiACoAYXR0cmlidXRlQ2FzdENhY2hlIjthOjA6e31zOjEzOiIAKgBkYXRlRm9ybWF0IjtOO3M6MTA6IgAqAGFwcGVuZHMiO2E6MDp7fXM6MTk6IgAqAGRpc3BhdGNoZXNFdmVudHMiO2E6MDp7fXM6MTQ6IgAqAG9ic2VydmFibGVzIjthOjA6e31zOjEyOiIAKgByZWxhdGlvbnMiO2E6MDp7fXM6MTA6IgAqAHRvdWNoZXMiO2E6MDp7fXM6Mjc6IgAqAHJlbGF0aW9uQXV0b2xvYWRDYWxsYmFjayI7TjtzOjI2OiIAKgByZWxhdGlvbkF1dG9sb2FkQ29udGV4dCI7TjtzOjEwOiJ0aW1lc3RhbXBzIjtiOjE7czoxMzoidXNlc1VuaXF1ZUlkcyI7YjowO3M6OToiACoAaGlkZGVuIjthOjA6e31zOjEwOiIAKgB2aXNpYmxlIjthOjA6e31zOjExOiIAKgBmaWxsYWJsZSI7YTozOntpOjA7czoxMjoibWVudV9tYWluX2lkIjtpOjE7czo2OiJsb2NhbGUiO2k6MjtzOjQ6ImRhdGEiO31zOjEwOiIAKgBndWFyZGVkIjthOjE6e2k6MDtzOjE6IioiO319aToyO086MzA6IkFwcFxNb2RlbHNcTWVudU1haW5UcmFuc2xhdGlvbiI6MzM6e3M6MTM6IgAqAGNvbm5lY3Rpb24iO3M6NToicGdzcWwiO3M6ODoiACoAdGFibGUiO3M6MjI6Im1lbnVfbWFpbl90cmFuc2xhdGlvbnMiO3M6MTM6IgAqAHByaW1hcnlLZXkiO3M6MjoiaWQiO3M6MTA6IgAqAGtleVR5cGUiO3M6MzoiaW50IjtzOjEyOiJpbmNyZW1lbnRpbmciO2I6MTtzOjc6IgAqAHdpdGgiO2E6MDp7fXM6MTI6IgAqAHdpdGhDb3VudCI7YTowOnt9czoxOToicHJldmVudHNMYXp5TG9hZGluZyI7YjowO3M6MTA6IgAqAHBlclBhZ2UiO2k6MTU7czo2OiJleGlzdHMiO2I6MTtzOjE4OiJ3YXNSZWNlbnRseUNyZWF0ZWQiO2I6MDtzOjI4OiIAKgBlc2NhcGVXaGVuQ2FzdGluZ1RvU3RyaW5nIjtiOjA7czoxMzoiACoAYXR0cmlidXRlcyI7YTo2OntzOjI6ImlkIjtpOjE0NztzOjEyOiJtZW51X21haW5faWQiO2k6MjA7czo2OiJsb2NhbGUiO3M6MjoiZW4iO3M6NDoiZGF0YSI7czo2MDoieyJpbmZvIjogbnVsbCwgInRpdGxlIjogIkFzc29jaWF0aW9ucyIsICJkZXNjcmlwdGlvbiI6IG51bGx9IjtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIxIDE5OjU0OjM4IjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIxIDE5OjU0OjM4Ijt9czoxMToiACoAb3JpZ2luYWwiO2E6Njp7czoyOiJpZCI7aToxNDc7czoxMjoibWVudV9tYWluX2lkIjtpOjIwO3M6NjoibG9jYWxlIjtzOjI6ImVuIjtzOjQ6ImRhdGEiO3M6NjA6InsiaW5mbyI6IG51bGwsICJ0aXRsZSI6ICJBc3NvY2lhdGlvbnMiLCAiZGVzY3JpcHRpb24iOiBudWxsfSI7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMSAxOTo1NDozOCI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMSAxOTo1NDozOCI7fXM6MTA6IgAqAGNoYW5nZXMiO2E6MDp7fXM6MTE6IgAqAHByZXZpb3VzIjthOjA6e31zOjg6IgAqAGNhc3RzIjthOjA6e31zOjE3OiIAKgBjbGFzc0Nhc3RDYWNoZSI7YTowOnt9czoyMToiACoAYXR0cmlidXRlQ2FzdENhY2hlIjthOjA6e31zOjEzOiIAKgBkYXRlRm9ybWF0IjtOO3M6MTA6IgAqAGFwcGVuZHMiO2E6MDp7fXM6MTk6IgAqAGRpc3BhdGNoZXNFdmVudHMiO2E6MDp7fXM6MTQ6IgAqAG9ic2VydmFibGVzIjthOjA6e31zOjEyOiIAKgByZWxhdGlvbnMiO2E6MDp7fXM6MTA6IgAqAHRvdWNoZXMiO2E6MDp7fXM6Mjc6IgAqAHJlbGF0aW9uQXV0b2xvYWRDYWxsYmFjayI7TjtzOjI2OiIAKgByZWxhdGlvbkF1dG9sb2FkQ29udGV4dCI7TjtzOjEwOiJ0aW1lc3RhbXBzIjtiOjE7czoxMzoidXNlc1VuaXF1ZUlkcyI7YjowO3M6OToiACoAaGlkZGVuIjthOjA6e31zOjEwOiIAKgB2aXNpYmxlIjthOjA6e31zOjExOiIAKgBmaWxsYWJsZSI7YTozOntpOjA7czoxMjoibWVudV9tYWluX2lkIjtpOjE7czo2OiJsb2NhbGUiO2k6MjtzOjQ6ImRhdGEiO31zOjEwOiIAKgBndWFyZGVkIjthOjE6e2k6MDtzOjE6IioiO319fXM6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDt9fXM6MTA6IgAqAHRvdWNoZXMiO2E6MDp7fXM6Mjc6IgAqAHJlbGF0aW9uQXV0b2xvYWRDYWxsYmFjayI7TjtzOjI2OiIAKgByZWxhdGlvbkF1dG9sb2FkQ29udGV4dCI7TjtzOjEwOiJ0aW1lc3RhbXBzIjtiOjE7czoxMzoidXNlc1VuaXF1ZUlkcyI7YjowO3M6OToiACoAaGlkZGVuIjthOjA6e31zOjEwOiIAKgB2aXNpYmxlIjthOjA6e31zOjExOiIAKgBmaWxsYWJsZSI7YTo5OntpOjA7czo0OiJ0eXBlIjtpOjE7czo0OiJzbHVnIjtpOjI7czozOiJ1cmwiO2k6MztzOjQ6InRlc3QiO2k6NDtzOjEwOiJzaG93X2FkbWluIjtpOjU7czoxMDoic29ydF9vcmRlciI7aTo2O3M6NDoiaWNvbiI7aTo3O3M6Njoic3RhdHVzIjtpOjg7czo5OiJwYXJlbnRfaWQiO31zOjEwOiIAKgBndWFyZGVkIjthOjE6e2k6MDtzOjE6IioiO31zOjE5OiIAKgB0cmFuc2xhdGlvbkNhY2hlIjtOO31pOjM7TzoxOToiQXBwXE1vZGVsc1xNZW51TWFpbiI6MzQ6e3M6MTM6IgAqAGNvbm5lY3Rpb24iO3M6NToicGdzcWwiO3M6ODoiACoAdGFibGUiO3M6MTA6Im1lbnVfbWFpbnMiO3M6MTM6IgAqAHByaW1hcnlLZXkiO3M6MjoiaWQiO3M6MTA6IgAqAGtleVR5cGUiO3M6MzoiaW50IjtzOjEyOiJpbmNyZW1lbnRpbmciO2I6MTtzOjc6IgAqAHdpdGgiO2E6MDp7fXM6MTI6IgAqAHdpdGhDb3VudCI7YTowOnt9czoxOToicHJldmVudHNMYXp5TG9hZGluZyI7YjowO3M6MTA6IgAqAHBlclBhZ2UiO2k6MTU7czo2OiJleGlzdHMiO2I6MTtzOjE4OiJ3YXNSZWNlbnRseUNyZWF0ZWQiO2I6MDtzOjI4OiIAKgBlc2NhcGVXaGVuQ2FzdGluZ1RvU3RyaW5nIjtiOjA7czoxMzoiACoAYXR0cmlidXRlcyI7YToxMjp7czoyOiJpZCI7aTozNztzOjQ6InR5cGUiO3M6ODoiY2F0ZWdvcnkiO3M6NDoic2x1ZyI7czo5OiJsb3lpaGFsYXIiO3M6MzoidXJsIjtOO3M6NDoidGVzdCI7YjowO3M6MTA6InNob3dfYWRtaW4iO2I6MTtzOjEwOiJzb3J0X29yZGVyIjtpOjU7czo0OiJpY29uIjtOO3M6Njoic3RhdHVzIjtiOjE7czo5OiJwYXJlbnRfaWQiO047czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNS0xMi0yOSAxMTo0NjozMCI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMiAxNToxMDozNSI7fXM6MTE6IgAqAG9yaWdpbmFsIjthOjEyOntzOjI6ImlkIjtpOjM3O3M6NDoidHlwZSI7czo4OiJjYXRlZ29yeSI7czo0OiJzbHVnIjtzOjk6ImxveWloYWxhciI7czozOiJ1cmwiO047czo0OiJ0ZXN0IjtiOjA7czoxMDoic2hvd19hZG1pbiI7YjoxO3M6MTA6InNvcnRfb3JkZXIiO2k6NTtzOjQ6Imljb24iO047czo2OiJzdGF0dXMiO2I6MTtzOjk6InBhcmVudF9pZCI7TjtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI1LTEyLTI5IDExOjQ2OjMwIjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIyIDE1OjEwOjM1Ijt9czoxMDoiACoAY2hhbmdlcyI7YTowOnt9czoxMToiACoAcHJldmlvdXMiO2E6MDp7fXM6ODoiACoAY2FzdHMiO2E6MDp7fXM6MTc6IgAqAGNsYXNzQ2FzdENhY2hlIjthOjA6e31zOjIxOiIAKgBhdHRyaWJ1dGVDYXN0Q2FjaGUiO2E6MDp7fXM6MTM6IgAqAGRhdGVGb3JtYXQiO047czoxMDoiACoAYXBwZW5kcyI7YTowOnt9czoxOToiACoAZGlzcGF0Y2hlc0V2ZW50cyI7YTowOnt9czoxNDoiACoAb2JzZXJ2YWJsZXMiO2E6MDp7fXM6MTI6IgAqAHJlbGF0aW9ucyI7YToyOntzOjk6ImNoaWxkcmVucyI7TzozOToiSWxsdW1pbmF0ZVxEYXRhYmFzZVxFbG9xdWVudFxDb2xsZWN0aW9uIjoyOntzOjg6IgAqAGl0ZW1zIjthOjE6e2k6MDtPOjE5OiJBcHBcTW9kZWxzXE1lbnVNYWluIjozNDp7czoxMzoiACoAY29ubmVjdGlvbiI7czo1OiJwZ3NxbCI7czo4OiIAKgB0YWJsZSI7czoxMDoibWVudV9tYWlucyI7czoxMzoiACoAcHJpbWFyeUtleSI7czoyOiJpZCI7czoxMDoiACoAa2V5VHlwZSI7czozOiJpbnQiO3M6MTI6ImluY3JlbWVudGluZyI7YjoxO3M6NzoiACoAd2l0aCI7YTowOnt9czoxMjoiACoAd2l0aENvdW50IjthOjA6e31zOjE5OiJwcmV2ZW50c0xhenlMb2FkaW5nIjtiOjA7czoxMDoiACoAcGVyUGFnZSI7aToxNTtzOjY6ImV4aXN0cyI7YjoxO3M6MTg6Indhc1JlY2VudGx5Q3JlYXRlZCI7YjowO3M6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDtzOjEzOiIAKgBhdHRyaWJ1dGVzIjthOjEyOntzOjI6ImlkIjtpOjM4O3M6NDoidHlwZSI7czo0OiJwYWdlIjtzOjQ6InNsdWciO3M6ODoicHJvamVjdHMiO3M6MzoidXJsIjtOO3M6NDoidGVzdCI7YjowO3M6MTA6InNob3dfYWRtaW4iO2I6MTtzOjEwOiJzb3J0X29yZGVyIjtpOjM4O3M6NDoiaWNvbiI7TjtzOjY6InN0YXR1cyI7YjoxO3M6OToicGFyZW50X2lkIjtpOjM3O3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjUtMTItMjkgMTE6NDc6MDEiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDEtMTQgMTA6Mzg6NTkiO31zOjExOiIAKgBvcmlnaW5hbCI7YToxMjp7czoyOiJpZCI7aTozODtzOjQ6InR5cGUiO3M6NDoicGFnZSI7czo0OiJzbHVnIjtzOjg6InByb2plY3RzIjtzOjM6InVybCI7TjtzOjQ6InRlc3QiO2I6MDtzOjEwOiJzaG93X2FkbWluIjtiOjE7czoxMDoic29ydF9vcmRlciI7aTozODtzOjQ6Imljb24iO047czo2OiJzdGF0dXMiO2I6MTtzOjk6InBhcmVudF9pZCI7aTozNztzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI1LTEyLTI5IDExOjQ3OjAxIjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTE0IDEwOjM4OjU5Ijt9czoxMDoiACoAY2hhbmdlcyI7YTowOnt9czoxMToiACoAcHJldmlvdXMiO2E6MDp7fXM6ODoiACoAY2FzdHMiO2E6MDp7fXM6MTc6IgAqAGNsYXNzQ2FzdENhY2hlIjthOjA6e31zOjIxOiIAKgBhdHRyaWJ1dGVDYXN0Q2FjaGUiO2E6MDp7fXM6MTM6IgAqAGRhdGVGb3JtYXQiO047czoxMDoiACoAYXBwZW5kcyI7YTowOnt9czoxOToiACoAZGlzcGF0Y2hlc0V2ZW50cyI7YTowOnt9czoxNDoiACoAb2JzZXJ2YWJsZXMiO2E6MDp7fXM6MTI6IgAqAHJlbGF0aW9ucyI7YToyOntzOjEyOiJ0cmFuc2xhdGlvbnMiO086Mzk6IklsbHVtaW5hdGVcRGF0YWJhc2VcRWxvcXVlbnRcQ29sbGVjdGlvbiI6Mjp7czo4OiIAKgBpdGVtcyI7YTozOntpOjA7TzozMDoiQXBwXE1vZGVsc1xNZW51TWFpblRyYW5zbGF0aW9uIjozMzp7czoxMzoiACoAY29ubmVjdGlvbiI7czo1OiJwZ3NxbCI7czo4OiIAKgB0YWJsZSI7czoyMjoibWVudV9tYWluX3RyYW5zbGF0aW9ucyI7czoxMzoiACoAcHJpbWFyeUtleSI7czoyOiJpZCI7czoxMDoiACoAa2V5VHlwZSI7czozOiJpbnQiO3M6MTI6ImluY3JlbWVudGluZyI7YjoxO3M6NzoiACoAd2l0aCI7YTowOnt9czoxMjoiACoAd2l0aENvdW50IjthOjA6e31zOjE5OiJwcmV2ZW50c0xhenlMb2FkaW5nIjtiOjA7czoxMDoiACoAcGVyUGFnZSI7aToxNTtzOjY6ImV4aXN0cyI7YjoxO3M6MTg6Indhc1JlY2VudGx5Q3JlYXRlZCI7YjowO3M6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDtzOjEzOiIAKgBhdHRyaWJ1dGVzIjthOjY6e3M6MjoiaWQiO2k6ODc7czoxMjoibWVudV9tYWluX2lkIjtpOjM4O3M6NjoibG9jYWxlIjtzOjI6InV6IjtzOjQ6ImRhdGEiO3M6NjQ6InsiaW5mbyI6IG51bGwsICJ0aXRsZSI6ICJCYXJjaGEgTG95aWhhbGFyIiwgImRlc2NyaXB0aW9uIjogbnVsbH0iO3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjUtMTItMjkgMTE6NDc6MDEiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDEtMjEgMTk6NTY6MTciO31zOjExOiIAKgBvcmlnaW5hbCI7YTo2OntzOjI6ImlkIjtpOjg3O3M6MTI6Im1lbnVfbWFpbl9pZCI7aTozODtzOjY6ImxvY2FsZSI7czoyOiJ1eiI7czo0OiJkYXRhIjtzOjY0OiJ7ImluZm8iOiBudWxsLCAidGl0bGUiOiAiQmFyY2hhIExveWloYWxhciIsICJkZXNjcmlwdGlvbiI6IG51bGx9IjtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI1LTEyLTI5IDExOjQ3OjAxIjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIxIDE5OjU2OjE3Ijt9czoxMDoiACoAY2hhbmdlcyI7YTowOnt9czoxMToiACoAcHJldmlvdXMiO2E6MDp7fXM6ODoiACoAY2FzdHMiO2E6MDp7fXM6MTc6IgAqAGNsYXNzQ2FzdENhY2hlIjthOjA6e31zOjIxOiIAKgBhdHRyaWJ1dGVDYXN0Q2FjaGUiO2E6MDp7fXM6MTM6IgAqAGRhdGVGb3JtYXQiO047czoxMDoiACoAYXBwZW5kcyI7YTowOnt9czoxOToiACoAZGlzcGF0Y2hlc0V2ZW50cyI7YTowOnt9czoxNDoiACoAb2JzZXJ2YWJsZXMiO2E6MDp7fXM6MTI6IgAqAHJlbGF0aW9ucyI7YTowOnt9czoxMDoiACoAdG91Y2hlcyI7YTowOnt9czoyNzoiACoAcmVsYXRpb25BdXRvbG9hZENhbGxiYWNrIjtOO3M6MjY6IgAqAHJlbGF0aW9uQXV0b2xvYWRDb250ZXh0IjtOO3M6MTA6InRpbWVzdGFtcHMiO2I6MTtzOjEzOiJ1c2VzVW5pcXVlSWRzIjtiOjA7czo5OiIAKgBoaWRkZW4iO2E6MDp7fXM6MTA6IgAqAHZpc2libGUiO2E6MDp7fXM6MTE6IgAqAGZpbGxhYmxlIjthOjM6e2k6MDtzOjEyOiJtZW51X21haW5faWQiO2k6MTtzOjY6ImxvY2FsZSI7aToyO3M6NDoiZGF0YSI7fXM6MTA6IgAqAGd1YXJkZWQiO2E6MTp7aTowO3M6MToiKiI7fX1pOjE7TzozMDoiQXBwXE1vZGVsc1xNZW51TWFpblRyYW5zbGF0aW9uIjozMzp7czoxMzoiACoAY29ubmVjdGlvbiI7czo1OiJwZ3NxbCI7czo4OiIAKgB0YWJsZSI7czoyMjoibWVudV9tYWluX3RyYW5zbGF0aW9ucyI7czoxMzoiACoAcHJpbWFyeUtleSI7czoyOiJpZCI7czoxMDoiACoAa2V5VHlwZSI7czozOiJpbnQiO3M6MTI6ImluY3JlbWVudGluZyI7YjoxO3M6NzoiACoAd2l0aCI7YTowOnt9czoxMjoiACoAd2l0aENvdW50IjthOjA6e31zOjE5OiJwcmV2ZW50c0xhenlMb2FkaW5nIjtiOjA7czoxMDoiACoAcGVyUGFnZSI7aToxNTtzOjY6ImV4aXN0cyI7YjoxO3M6MTg6Indhc1JlY2VudGx5Q3JlYXRlZCI7YjowO3M6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDtzOjEzOiIAKgBhdHRyaWJ1dGVzIjthOjY6e3M6MjoiaWQiO2k6ODk7czoxMjoibWVudV9tYWluX2lkIjtpOjM4O3M6NjoibG9jYWxlIjtzOjI6ImVuIjtzOjQ6ImRhdGEiO3M6NjA6InsiaW5mbyI6IG51bGwsICJ0aXRsZSI6ICJBbGwgUHJvamVjdHMiLCAiZGVzY3JpcHRpb24iOiBudWxsfSI7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNS0xMi0yOSAxMTo0NzowMSI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMSAxOTo1NjoxNyI7fXM6MTE6IgAqAG9yaWdpbmFsIjthOjY6e3M6MjoiaWQiO2k6ODk7czoxMjoibWVudV9tYWluX2lkIjtpOjM4O3M6NjoibG9jYWxlIjtzOjI6ImVuIjtzOjQ6ImRhdGEiO3M6NjA6InsiaW5mbyI6IG51bGwsICJ0aXRsZSI6ICJBbGwgUHJvamVjdHMiLCAiZGVzY3JpcHRpb24iOiBudWxsfSI7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNS0xMi0yOSAxMTo0NzowMSI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMSAxOTo1NjoxNyI7fXM6MTA6IgAqAGNoYW5nZXMiO2E6MDp7fXM6MTE6IgAqAHByZXZpb3VzIjthOjA6e31zOjg6IgAqAGNhc3RzIjthOjA6e31zOjE3OiIAKgBjbGFzc0Nhc3RDYWNoZSI7YTowOnt9czoyMToiACoAYXR0cmlidXRlQ2FzdENhY2hlIjthOjA6e31zOjEzOiIAKgBkYXRlRm9ybWF0IjtOO3M6MTA6IgAqAGFwcGVuZHMiO2E6MDp7fXM6MTk6IgAqAGRpc3BhdGNoZXNFdmVudHMiO2E6MDp7fXM6MTQ6IgAqAG9ic2VydmFibGVzIjthOjA6e31zOjEyOiIAKgByZWxhdGlvbnMiO2E6MDp7fXM6MTA6IgAqAHRvdWNoZXMiO2E6MDp7fXM6Mjc6IgAqAHJlbGF0aW9uQXV0b2xvYWRDYWxsYmFjayI7TjtzOjI2OiIAKgByZWxhdGlvbkF1dG9sb2FkQ29udGV4dCI7TjtzOjEwOiJ0aW1lc3RhbXBzIjtiOjE7czoxMzoidXNlc1VuaXF1ZUlkcyI7YjowO3M6OToiACoAaGlkZGVuIjthOjA6e31zOjEwOiIAKgB2aXNpYmxlIjthOjA6e31zOjExOiIAKgBmaWxsYWJsZSI7YTozOntpOjA7czoxMjoibWVudV9tYWluX2lkIjtpOjE7czo2OiJsb2NhbGUiO2k6MjtzOjQ6ImRhdGEiO31zOjEwOiIAKgBndWFyZGVkIjthOjE6e2k6MDtzOjE6IioiO319aToyO086MzA6IkFwcFxNb2RlbHNcTWVudU1haW5UcmFuc2xhdGlvbiI6MzM6e3M6MTM6IgAqAGNvbm5lY3Rpb24iO3M6NToicGdzcWwiO3M6ODoiACoAdGFibGUiO3M6MjI6Im1lbnVfbWFpbl90cmFuc2xhdGlvbnMiO3M6MTM6IgAqAHByaW1hcnlLZXkiO3M6MjoiaWQiO3M6MTA6IgAqAGtleVR5cGUiO3M6MzoiaW50IjtzOjEyOiJpbmNyZW1lbnRpbmciO2I6MTtzOjc6IgAqAHdpdGgiO2E6MDp7fXM6MTI6IgAqAHdpdGhDb3VudCI7YTowOnt9czoxOToicHJldmVudHNMYXp5TG9hZGluZyI7YjowO3M6MTA6IgAqAHBlclBhZ2UiO2k6MTU7czo2OiJleGlzdHMiO2I6MTtzOjE4OiJ3YXNSZWNlbnRseUNyZWF0ZWQiO2I6MDtzOjI4OiIAKgBlc2NhcGVXaGVuQ2FzdGluZ1RvU3RyaW5nIjtiOjA7czoxMzoiACoAYXR0cmlidXRlcyI7YTo2OntzOjI6ImlkIjtpOjg4O3M6MTI6Im1lbnVfbWFpbl9pZCI7aTozODtzOjY6ImxvY2FsZSI7czoyOiJydSI7czo0OiJkYXRhIjtzOjY5OiJ7ImluZm8iOiBudWxsLCAidGl0bGUiOiAi0JLRgdC1INC/0YDQvtC10LrRgtGLIiwgImRlc2NyaXB0aW9uIjogbnVsbH0iO3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjUtMTItMjkgMTE6NDc6MDEiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDEtMjEgMTk6NTY6MTciO31zOjExOiIAKgBvcmlnaW5hbCI7YTo2OntzOjI6ImlkIjtpOjg4O3M6MTI6Im1lbnVfbWFpbl9pZCI7aTozODtzOjY6ImxvY2FsZSI7czoyOiJydSI7czo0OiJkYXRhIjtzOjY5OiJ7ImluZm8iOiBudWxsLCAidGl0bGUiOiAi0JLRgdC1INC/0YDQvtC10LrRgtGLIiwgImRlc2NyaXB0aW9uIjogbnVsbH0iO3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjUtMTItMjkgMTE6NDc6MDEiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDEtMjEgMTk6NTY6MTciO31zOjEwOiIAKgBjaGFuZ2VzIjthOjA6e31zOjExOiIAKgBwcmV2aW91cyI7YTowOnt9czo4OiIAKgBjYXN0cyI7YTowOnt9czoxNzoiACoAY2xhc3NDYXN0Q2FjaGUiO2E6MDp7fXM6MjE6IgAqAGF0dHJpYnV0ZUNhc3RDYWNoZSI7YTowOnt9czoxMzoiACoAZGF0ZUZvcm1hdCI7TjtzOjEwOiIAKgBhcHBlbmRzIjthOjA6e31zOjE5OiIAKgBkaXNwYXRjaGVzRXZlbnRzIjthOjA6e31zOjE0OiIAKgBvYnNlcnZhYmxlcyI7YTowOnt9czoxMjoiACoAcmVsYXRpb25zIjthOjA6e31zOjEwOiIAKgB0b3VjaGVzIjthOjA6e31zOjI3OiIAKgByZWxhdGlvbkF1dG9sb2FkQ2FsbGJhY2siO047czoyNjoiACoAcmVsYXRpb25BdXRvbG9hZENvbnRleHQiO047czoxMDoidGltZXN0YW1wcyI7YjoxO3M6MTM6InVzZXNVbmlxdWVJZHMiO2I6MDtzOjk6IgAqAGhpZGRlbiI7YTowOnt9czoxMDoiACoAdmlzaWJsZSI7YTowOnt9czoxMToiACoAZmlsbGFibGUiO2E6Mzp7aTowO3M6MTI6Im1lbnVfbWFpbl9pZCI7aToxO3M6NjoibG9jYWxlIjtpOjI7czo0OiJkYXRhIjt9czoxMDoiACoAZ3VhcmRlZCI7YToxOntpOjA7czoxOiIqIjt9fX1zOjI4OiIAKgBlc2NhcGVXaGVuQ2FzdGluZ1RvU3RyaW5nIjtiOjA7fXM6OToiY2hpbGRyZW5zIjtPOjM5OiJJbGx1bWluYXRlXERhdGFiYXNlXEVsb3F1ZW50XENvbGxlY3Rpb24iOjI6e3M6ODoiACoAaXRlbXMiO2E6MDp7fXM6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDt9fXM6MTA6IgAqAHRvdWNoZXMiO2E6MDp7fXM6Mjc6IgAqAHJlbGF0aW9uQXV0b2xvYWRDYWxsYmFjayI7TjtzOjI2OiIAKgByZWxhdGlvbkF1dG9sb2FkQ29udGV4dCI7TjtzOjEwOiJ0aW1lc3RhbXBzIjtiOjE7czoxMzoidXNlc1VuaXF1ZUlkcyI7YjowO3M6OToiACoAaGlkZGVuIjthOjA6e31zOjEwOiIAKgB2aXNpYmxlIjthOjA6e31zOjExOiIAKgBmaWxsYWJsZSI7YTo5OntpOjA7czo0OiJ0eXBlIjtpOjE7czo0OiJzbHVnIjtpOjI7czozOiJ1cmwiO2k6MztzOjQ6InRlc3QiO2k6NDtzOjEwOiJzaG93X2FkbWluIjtpOjU7czoxMDoic29ydF9vcmRlciI7aTo2O3M6NDoiaWNvbiI7aTo3O3M6Njoic3RhdHVzIjtpOjg7czo5OiJwYXJlbnRfaWQiO31zOjEwOiIAKgBndWFyZGVkIjthOjE6e2k6MDtzOjE6IioiO31zOjE5OiIAKgB0cmFuc2xhdGlvbkNhY2hlIjtOO319czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO31zOjEyOiJ0cmFuc2xhdGlvbnMiO086Mzk6IklsbHVtaW5hdGVcRGF0YWJhc2VcRWxvcXVlbnRcQ29sbGVjdGlvbiI6Mjp7czo4OiIAKgBpdGVtcyI7YTozOntpOjA7TzozMDoiQXBwXE1vZGVsc1xNZW51TWFpblRyYW5zbGF0aW9uIjozMzp7czoxMzoiACoAY29ubmVjdGlvbiI7czo1OiJwZ3NxbCI7czo4OiIAKgB0YWJsZSI7czoyMjoibWVudV9tYWluX3RyYW5zbGF0aW9ucyI7czoxMzoiACoAcHJpbWFyeUtleSI7czoyOiJpZCI7czoxMDoiACoAa2V5VHlwZSI7czozOiJpbnQiO3M6MTI6ImluY3JlbWVudGluZyI7YjoxO3M6NzoiACoAd2l0aCI7YTowOnt9czoxMjoiACoAd2l0aENvdW50IjthOjA6e31zOjE5OiJwcmV2ZW50c0xhenlMb2FkaW5nIjtiOjA7czoxMDoiACoAcGVyUGFnZSI7aToxNTtzOjY6ImV4aXN0cyI7YjoxO3M6MTg6Indhc1JlY2VudGx5Q3JlYXRlZCI7YjowO3M6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDtzOjEzOiIAKgBhdHRyaWJ1dGVzIjthOjY6e3M6MjoiaWQiO2k6ODQ7czoxMjoibWVudV9tYWluX2lkIjtpOjM3O3M6NjoibG9jYWxlIjtzOjI6InV6IjtzOjQ6ImRhdGEiO3M6NTc6InsiaW5mbyI6IG51bGwsICJ0aXRsZSI6ICJMb3lpaGFsYXIiLCAiZGVzY3JpcHRpb24iOiBudWxsfSI7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNS0xMi0yOSAxMTo0NjozMCI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMSAxOTo1NTo0OCI7fXM6MTE6IgAqAG9yaWdpbmFsIjthOjY6e3M6MjoiaWQiO2k6ODQ7czoxMjoibWVudV9tYWluX2lkIjtpOjM3O3M6NjoibG9jYWxlIjtzOjI6InV6IjtzOjQ6ImRhdGEiO3M6NTc6InsiaW5mbyI6IG51bGwsICJ0aXRsZSI6ICJMb3lpaGFsYXIiLCAiZGVzY3JpcHRpb24iOiBudWxsfSI7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNS0xMi0yOSAxMTo0NjozMCI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMSAxOTo1NTo0OCI7fXM6MTA6IgAqAGNoYW5nZXMiO2E6MDp7fXM6MTE6IgAqAHByZXZpb3VzIjthOjA6e31zOjg6IgAqAGNhc3RzIjthOjA6e31zOjE3OiIAKgBjbGFzc0Nhc3RDYWNoZSI7YTowOnt9czoyMToiACoAYXR0cmlidXRlQ2FzdENhY2hlIjthOjA6e31zOjEzOiIAKgBkYXRlRm9ybWF0IjtOO3M6MTA6IgAqAGFwcGVuZHMiO2E6MDp7fXM6MTk6IgAqAGRpc3BhdGNoZXNFdmVudHMiO2E6MDp7fXM6MTQ6IgAqAG9ic2VydmFibGVzIjthOjA6e31zOjEyOiIAKgByZWxhdGlvbnMiO2E6MDp7fXM6MTA6IgAqAHRvdWNoZXMiO2E6MDp7fXM6Mjc6IgAqAHJlbGF0aW9uQXV0b2xvYWRDYWxsYmFjayI7TjtzOjI2OiIAKgByZWxhdGlvbkF1dG9sb2FkQ29udGV4dCI7TjtzOjEwOiJ0aW1lc3RhbXBzIjtiOjE7czoxMzoidXNlc1VuaXF1ZUlkcyI7YjowO3M6OToiACoAaGlkZGVuIjthOjA6e31zOjEwOiIAKgB2aXNpYmxlIjthOjA6e31zOjExOiIAKgBmaWxsYWJsZSI7YTozOntpOjA7czoxMjoibWVudV9tYWluX2lkIjtpOjE7czo2OiJsb2NhbGUiO2k6MjtzOjQ6ImRhdGEiO31zOjEwOiIAKgBndWFyZGVkIjthOjE6e2k6MDtzOjE6IioiO319aToxO086MzA6IkFwcFxNb2RlbHNcTWVudU1haW5UcmFuc2xhdGlvbiI6MzM6e3M6MTM6IgAqAGNvbm5lY3Rpb24iO3M6NToicGdzcWwiO3M6ODoiACoAdGFibGUiO3M6MjI6Im1lbnVfbWFpbl90cmFuc2xhdGlvbnMiO3M6MTM6IgAqAHByaW1hcnlLZXkiO3M6MjoiaWQiO3M6MTA6IgAqAGtleVR5cGUiO3M6MzoiaW50IjtzOjEyOiJpbmNyZW1lbnRpbmciO2I6MTtzOjc6IgAqAHdpdGgiO2E6MDp7fXM6MTI6IgAqAHdpdGhDb3VudCI7YTowOnt9czoxOToicHJldmVudHNMYXp5TG9hZGluZyI7YjowO3M6MTA6IgAqAHBlclBhZ2UiO2k6MTU7czo2OiJleGlzdHMiO2I6MTtzOjE4OiJ3YXNSZWNlbnRseUNyZWF0ZWQiO2I6MDtzOjI4OiIAKgBlc2NhcGVXaGVuQ2FzdGluZ1RvU3RyaW5nIjtiOjA7czoxMzoiACoAYXR0cmlidXRlcyI7YTo2OntzOjI6ImlkIjtpOjg1O3M6MTI6Im1lbnVfbWFpbl9pZCI7aTozNztzOjY6ImxvY2FsZSI7czoyOiJydSI7czo0OiJkYXRhIjtzOjYyOiJ7ImluZm8iOiBudWxsLCAidGl0bGUiOiAi0J/RgNC+0LXQutGC0YsiLCAiZGVzY3JpcHRpb24iOiBudWxsfSI7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNS0xMi0yOSAxMTo0NjozMCI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMSAxOTo1NTo0OCI7fXM6MTE6IgAqAG9yaWdpbmFsIjthOjY6e3M6MjoiaWQiO2k6ODU7czoxMjoibWVudV9tYWluX2lkIjtpOjM3O3M6NjoibG9jYWxlIjtzOjI6InJ1IjtzOjQ6ImRhdGEiO3M6NjI6InsiaW5mbyI6IG51bGwsICJ0aXRsZSI6ICLQn9GA0L7QtdC60YLRiyIsICJkZXNjcmlwdGlvbiI6IG51bGx9IjtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI1LTEyLTI5IDExOjQ2OjMwIjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIxIDE5OjU1OjQ4Ijt9czoxMDoiACoAY2hhbmdlcyI7YTowOnt9czoxMToiACoAcHJldmlvdXMiO2E6MDp7fXM6ODoiACoAY2FzdHMiO2E6MDp7fXM6MTc6IgAqAGNsYXNzQ2FzdENhY2hlIjthOjA6e31zOjIxOiIAKgBhdHRyaWJ1dGVDYXN0Q2FjaGUiO2E6MDp7fXM6MTM6IgAqAGRhdGVGb3JtYXQiO047czoxMDoiACoAYXBwZW5kcyI7YTowOnt9czoxOToiACoAZGlzcGF0Y2hlc0V2ZW50cyI7YTowOnt9czoxNDoiACoAb2JzZXJ2YWJsZXMiO2E6MDp7fXM6MTI6IgAqAHJlbGF0aW9ucyI7YTowOnt9czoxMDoiACoAdG91Y2hlcyI7YTowOnt9czoyNzoiACoAcmVsYXRpb25BdXRvbG9hZENhbGxiYWNrIjtOO3M6MjY6IgAqAHJlbGF0aW9uQXV0b2xvYWRDb250ZXh0IjtOO3M6MTA6InRpbWVzdGFtcHMiO2I6MTtzOjEzOiJ1c2VzVW5pcXVlSWRzIjtiOjA7czo5OiIAKgBoaWRkZW4iO2E6MDp7fXM6MTA6IgAqAHZpc2libGUiO2E6MDp7fXM6MTE6IgAqAGZpbGxhYmxlIjthOjM6e2k6MDtzOjEyOiJtZW51X21haW5faWQiO2k6MTtzOjY6ImxvY2FsZSI7aToyO3M6NDoiZGF0YSI7fXM6MTA6IgAqAGd1YXJkZWQiO2E6MTp7aTowO3M6MToiKiI7fX1pOjI7TzozMDoiQXBwXE1vZGVsc1xNZW51TWFpblRyYW5zbGF0aW9uIjozMzp7czoxMzoiACoAY29ubmVjdGlvbiI7czo1OiJwZ3NxbCI7czo4OiIAKgB0YWJsZSI7czoyMjoibWVudV9tYWluX3RyYW5zbGF0aW9ucyI7czoxMzoiACoAcHJpbWFyeUtleSI7czoyOiJpZCI7czoxMDoiACoAa2V5VHlwZSI7czozOiJpbnQiO3M6MTI6ImluY3JlbWVudGluZyI7YjoxO3M6NzoiACoAd2l0aCI7YTowOnt9czoxMjoiACoAd2l0aENvdW50IjthOjA6e31zOjE5OiJwcmV2ZW50c0xhenlMb2FkaW5nIjtiOjA7czoxMDoiACoAcGVyUGFnZSI7aToxNTtzOjY6ImV4aXN0cyI7YjoxO3M6MTg6Indhc1JlY2VudGx5Q3JlYXRlZCI7YjowO3M6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDtzOjEzOiIAKgBhdHRyaWJ1dGVzIjthOjY6e3M6MjoiaWQiO2k6ODY7czoxMjoibWVudV9tYWluX2lkIjtpOjM3O3M6NjoibG9jYWxlIjtzOjI6ImVuIjtzOjQ6ImRhdGEiO3M6NTY6InsiaW5mbyI6IG51bGwsICJ0aXRsZSI6ICJQcm9qZWN0cyIsICJkZXNjcmlwdGlvbiI6IG51bGx9IjtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI1LTEyLTI5IDExOjQ2OjMwIjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIxIDE5OjU1OjQ4Ijt9czoxMToiACoAb3JpZ2luYWwiO2E6Njp7czoyOiJpZCI7aTo4NjtzOjEyOiJtZW51X21haW5faWQiO2k6Mzc7czo2OiJsb2NhbGUiO3M6MjoiZW4iO3M6NDoiZGF0YSI7czo1NjoieyJpbmZvIjogbnVsbCwgInRpdGxlIjogIlByb2plY3RzIiwgImRlc2NyaXB0aW9uIjogbnVsbH0iO3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjUtMTItMjkgMTE6NDY6MzAiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDEtMjEgMTk6NTU6NDgiO31zOjEwOiIAKgBjaGFuZ2VzIjthOjA6e31zOjExOiIAKgBwcmV2aW91cyI7YTowOnt9czo4OiIAKgBjYXN0cyI7YTowOnt9czoxNzoiACoAY2xhc3NDYXN0Q2FjaGUiO2E6MDp7fXM6MjE6IgAqAGF0dHJpYnV0ZUNhc3RDYWNoZSI7YTowOnt9czoxMzoiACoAZGF0ZUZvcm1hdCI7TjtzOjEwOiIAKgBhcHBlbmRzIjthOjA6e31zOjE5OiIAKgBkaXNwYXRjaGVzRXZlbnRzIjthOjA6e31zOjE0OiIAKgBvYnNlcnZhYmxlcyI7YTowOnt9czoxMjoiACoAcmVsYXRpb25zIjthOjA6e31zOjEwOiIAKgB0b3VjaGVzIjthOjA6e31zOjI3OiIAKgByZWxhdGlvbkF1dG9sb2FkQ2FsbGJhY2siO047czoyNjoiACoAcmVsYXRpb25BdXRvbG9hZENvbnRleHQiO047czoxMDoidGltZXN0YW1wcyI7YjoxO3M6MTM6InVzZXNVbmlxdWVJZHMiO2I6MDtzOjk6IgAqAGhpZGRlbiI7YTowOnt9czoxMDoiACoAdmlzaWJsZSI7YTowOnt9czoxMToiACoAZmlsbGFibGUiO2E6Mzp7aTowO3M6MTI6Im1lbnVfbWFpbl9pZCI7aToxO3M6NjoibG9jYWxlIjtpOjI7czo0OiJkYXRhIjt9czoxMDoiACoAZ3VhcmRlZCI7YToxOntpOjA7czoxOiIqIjt9fX1zOjI4OiIAKgBlc2NhcGVXaGVuQ2FzdGluZ1RvU3RyaW5nIjtiOjA7fX1zOjEwOiIAKgB0b3VjaGVzIjthOjA6e31zOjI3OiIAKgByZWxhdGlvbkF1dG9sb2FkQ2FsbGJhY2siO047czoyNjoiACoAcmVsYXRpb25BdXRvbG9hZENvbnRleHQiO047czoxMDoidGltZXN0YW1wcyI7YjoxO3M6MTM6InVzZXNVbmlxdWVJZHMiO2I6MDtzOjk6IgAqAGhpZGRlbiI7YTowOnt9czoxMDoiACoAdmlzaWJsZSI7YTowOnt9czoxMToiACoAZmlsbGFibGUiO2E6OTp7aTowO3M6NDoidHlwZSI7aToxO3M6NDoic2x1ZyI7aToyO3M6MzoidXJsIjtpOjM7czo0OiJ0ZXN0IjtpOjQ7czoxMDoic2hvd19hZG1pbiI7aTo1O3M6MTA6InNvcnRfb3JkZXIiO2k6NjtzOjQ6Imljb24iO2k6NztzOjY6InN0YXR1cyI7aTo4O3M6OToicGFyZW50X2lkIjt9czoxMDoiACoAZ3VhcmRlZCI7YToxOntpOjA7czoxOiIqIjt9czoxOToiACoAdHJhbnNsYXRpb25DYWNoZSI7Tjt9aTo0O086MTk6IkFwcFxNb2RlbHNcTWVudU1haW4iOjM0OntzOjEzOiIAKgBjb25uZWN0aW9uIjtzOjU6InBnc3FsIjtzOjg6IgAqAHRhYmxlIjtzOjEwOiJtZW51X21haW5zIjtzOjEzOiIAKgBwcmltYXJ5S2V5IjtzOjI6ImlkIjtzOjEwOiIAKgBrZXlUeXBlIjtzOjM6ImludCI7czoxMjoiaW5jcmVtZW50aW5nIjtiOjE7czo3OiIAKgB3aXRoIjthOjA6e31zOjEyOiIAKgB3aXRoQ291bnQiO2E6MDp7fXM6MTk6InByZXZlbnRzTGF6eUxvYWRpbmciO2I6MDtzOjEwOiIAKgBwZXJQYWdlIjtpOjE1O3M6NjoiZXhpc3RzIjtiOjE7czoxODoid2FzUmVjZW50bHlDcmVhdGVkIjtiOjA7czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO3M6MTM6IgAqAGF0dHJpYnV0ZXMiO2E6MTI6e3M6MjoiaWQiO2k6MjU7czo0OiJ0eXBlIjtzOjg6ImNhdGVnb3J5IjtzOjQ6InNsdWciO3M6MTg6ImF4Ym9yb3QteGl6bWF0bGFyaSI7czozOiJ1cmwiO047czo0OiJ0ZXN0IjtiOjA7czoxMDoic2hvd19hZG1pbiI7YjoxO3M6MTA6InNvcnRfb3JkZXIiO2k6NjtzOjQ6Imljb24iO047czo2OiJzdGF0dXMiO2I6MTtzOjk6InBhcmVudF9pZCI7TjtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI1LTEyLTIzIDA2OjE4OjI1IjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIyIDE1OjEwOjM1Ijt9czoxMToiACoAb3JpZ2luYWwiO2E6MTI6e3M6MjoiaWQiO2k6MjU7czo0OiJ0eXBlIjtzOjg6ImNhdGVnb3J5IjtzOjQ6InNsdWciO3M6MTg6ImF4Ym9yb3QteGl6bWF0bGFyaSI7czozOiJ1cmwiO047czo0OiJ0ZXN0IjtiOjA7czoxMDoic2hvd19hZG1pbiI7YjoxO3M6MTA6InNvcnRfb3JkZXIiO2k6NjtzOjQ6Imljb24iO047czo2OiJzdGF0dXMiO2I6MTtzOjk6InBhcmVudF9pZCI7TjtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI1LTEyLTIzIDA2OjE4OjI1IjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIyIDE1OjEwOjM1Ijt9czoxMDoiACoAY2hhbmdlcyI7YTowOnt9czoxMToiACoAcHJldmlvdXMiO2E6MDp7fXM6ODoiACoAY2FzdHMiO2E6MDp7fXM6MTc6IgAqAGNsYXNzQ2FzdENhY2hlIjthOjA6e31zOjIxOiIAKgBhdHRyaWJ1dGVDYXN0Q2FjaGUiO2E6MDp7fXM6MTM6IgAqAGRhdGVGb3JtYXQiO047czoxMDoiACoAYXBwZW5kcyI7YTowOnt9czoxOToiACoAZGlzcGF0Y2hlc0V2ZW50cyI7YTowOnt9czoxNDoiACoAb2JzZXJ2YWJsZXMiO2E6MDp7fXM6MTI6IgAqAHJlbGF0aW9ucyI7YToyOntzOjk6ImNoaWxkcmVucyI7TzozOToiSWxsdW1pbmF0ZVxEYXRhYmFzZVxFbG9xdWVudFxDb2xsZWN0aW9uIjoyOntzOjg6IgAqAGl0ZW1zIjthOjQ6e2k6MDtPOjE5OiJBcHBcTW9kZWxzXE1lbnVNYWluIjozNDp7czoxMzoiACoAY29ubmVjdGlvbiI7czo1OiJwZ3NxbCI7czo4OiIAKgB0YWJsZSI7czoxMDoibWVudV9tYWlucyI7czoxMzoiACoAcHJpbWFyeUtleSI7czoyOiJpZCI7czoxMDoiACoAa2V5VHlwZSI7czozOiJpbnQiO3M6MTI6ImluY3JlbWVudGluZyI7YjoxO3M6NzoiACoAd2l0aCI7YTowOnt9czoxMjoiACoAd2l0aENvdW50IjthOjA6e31zOjE5OiJwcmV2ZW50c0xhenlMb2FkaW5nIjtiOjA7czoxMDoiACoAcGVyUGFnZSI7aToxNTtzOjY6ImV4aXN0cyI7YjoxO3M6MTg6Indhc1JlY2VudGx5Q3JlYXRlZCI7YjowO3M6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDtzOjEzOiIAKgBhdHRyaWJ1dGVzIjthOjEyOntzOjI6ImlkIjtpOjI2O3M6NDoidHlwZSI7czo0OiJwYWdlIjtzOjQ6InNsdWciO3M6NDoibmV3cyI7czozOiJ1cmwiO047czo0OiJ0ZXN0IjtiOjA7czoxMDoic2hvd19hZG1pbiI7YjoxO3M6MTA6InNvcnRfb3JkZXIiO2k6MjY7czo0OiJpY29uIjtOO3M6Njoic3RhdHVzIjtiOjE7czo5OiJwYXJlbnRfaWQiO2k6MjU7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNS0xMi0yMyAwNjoxODo0NCI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0xNCAxMDoyNToxMiI7fXM6MTE6IgAqAG9yaWdpbmFsIjthOjEyOntzOjI6ImlkIjtpOjI2O3M6NDoidHlwZSI7czo0OiJwYWdlIjtzOjQ6InNsdWciO3M6NDoibmV3cyI7czozOiJ1cmwiO047czo0OiJ0ZXN0IjtiOjA7czoxMDoic2hvd19hZG1pbiI7YjoxO3M6MTA6InNvcnRfb3JkZXIiO2k6MjY7czo0OiJpY29uIjtOO3M6Njoic3RhdHVzIjtiOjE7czo5OiJwYXJlbnRfaWQiO2k6MjU7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNS0xMi0yMyAwNjoxODo0NCI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0xNCAxMDoyNToxMiI7fXM6MTA6IgAqAGNoYW5nZXMiO2E6MDp7fXM6MTE6IgAqAHByZXZpb3VzIjthOjA6e31zOjg6IgAqAGNhc3RzIjthOjA6e31zOjE3OiIAKgBjbGFzc0Nhc3RDYWNoZSI7YTowOnt9czoyMToiACoAYXR0cmlidXRlQ2FzdENhY2hlIjthOjA6e31zOjEzOiIAKgBkYXRlRm9ybWF0IjtOO3M6MTA6IgAqAGFwcGVuZHMiO2E6MDp7fXM6MTk6IgAqAGRpc3BhdGNoZXNFdmVudHMiO2E6MDp7fXM6MTQ6IgAqAG9ic2VydmFibGVzIjthOjA6e31zOjEyOiIAKgByZWxhdGlvbnMiO2E6Mjp7czoxMjoidHJhbnNsYXRpb25zIjtPOjM5OiJJbGx1bWluYXRlXERhdGFiYXNlXEVsb3F1ZW50XENvbGxlY3Rpb24iOjI6e3M6ODoiACoAaXRlbXMiO2E6Mzp7aTowO086MzA6IkFwcFxNb2RlbHNcTWVudU1haW5UcmFuc2xhdGlvbiI6MzM6e3M6MTM6IgAqAGNvbm5lY3Rpb24iO3M6NToicGdzcWwiO3M6ODoiACoAdGFibGUiO3M6MjI6Im1lbnVfbWFpbl90cmFuc2xhdGlvbnMiO3M6MTM6IgAqAHByaW1hcnlLZXkiO3M6MjoiaWQiO3M6MTA6IgAqAGtleVR5cGUiO3M6MzoiaW50IjtzOjEyOiJpbmNyZW1lbnRpbmciO2I6MTtzOjc6IgAqAHdpdGgiO2E6MDp7fXM6MTI6IgAqAHdpdGhDb3VudCI7YTowOnt9czoxOToicHJldmVudHNMYXp5TG9hZGluZyI7YjowO3M6MTA6IgAqAHBlclBhZ2UiO2k6MTU7czo2OiJleGlzdHMiO2I6MTtzOjE4OiJ3YXNSZWNlbnRseUNyZWF0ZWQiO2I6MDtzOjI4OiIAKgBlc2NhcGVXaGVuQ2FzdGluZ1RvU3RyaW5nIjtiOjA7czoxMzoiACoAYXR0cmlidXRlcyI7YTo2OntzOjI6ImlkIjtpOjUxO3M6MTI6Im1lbnVfbWFpbl9pZCI7aToyNjtzOjY6ImxvY2FsZSI7czoyOiJ1eiI7czo0OiJkYXRhIjtzOjU5OiJ7ImluZm8iOiBudWxsLCAidGl0bGUiOiAiWWFuZ2lsaWtsYXIiLCAiZGVzY3JpcHRpb24iOiBudWxsfSI7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNS0xMi0yMyAwNjoxODo0NCI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMSAxOTo1NzoxNiI7fXM6MTE6IgAqAG9yaWdpbmFsIjthOjY6e3M6MjoiaWQiO2k6NTE7czoxMjoibWVudV9tYWluX2lkIjtpOjI2O3M6NjoibG9jYWxlIjtzOjI6InV6IjtzOjQ6ImRhdGEiO3M6NTk6InsiaW5mbyI6IG51bGwsICJ0aXRsZSI6ICJZYW5naWxpa2xhciIsICJkZXNjcmlwdGlvbiI6IG51bGx9IjtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI1LTEyLTIzIDA2OjE4OjQ0IjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIxIDE5OjU3OjE2Ijt9czoxMDoiACoAY2hhbmdlcyI7YTowOnt9czoxMToiACoAcHJldmlvdXMiO2E6MDp7fXM6ODoiACoAY2FzdHMiO2E6MDp7fXM6MTc6IgAqAGNsYXNzQ2FzdENhY2hlIjthOjA6e31zOjIxOiIAKgBhdHRyaWJ1dGVDYXN0Q2FjaGUiO2E6MDp7fXM6MTM6IgAqAGRhdGVGb3JtYXQiO047czoxMDoiACoAYXBwZW5kcyI7YTowOnt9czoxOToiACoAZGlzcGF0Y2hlc0V2ZW50cyI7YTowOnt9czoxNDoiACoAb2JzZXJ2YWJsZXMiO2E6MDp7fXM6MTI6IgAqAHJlbGF0aW9ucyI7YTowOnt9czoxMDoiACoAdG91Y2hlcyI7YTowOnt9czoyNzoiACoAcmVsYXRpb25BdXRvbG9hZENhbGxiYWNrIjtOO3M6MjY6IgAqAHJlbGF0aW9uQXV0b2xvYWRDb250ZXh0IjtOO3M6MTA6InRpbWVzdGFtcHMiO2I6MTtzOjEzOiJ1c2VzVW5pcXVlSWRzIjtiOjA7czo5OiIAKgBoaWRkZW4iO2E6MDp7fXM6MTA6IgAqAHZpc2libGUiO2E6MDp7fXM6MTE6IgAqAGZpbGxhYmxlIjthOjM6e2k6MDtzOjEyOiJtZW51X21haW5faWQiO2k6MTtzOjY6ImxvY2FsZSI7aToyO3M6NDoiZGF0YSI7fXM6MTA6IgAqAGd1YXJkZWQiO2E6MTp7aTowO3M6MToiKiI7fX1pOjE7TzozMDoiQXBwXE1vZGVsc1xNZW51TWFpblRyYW5zbGF0aW9uIjozMzp7czoxMzoiACoAY29ubmVjdGlvbiI7czo1OiJwZ3NxbCI7czo4OiIAKgB0YWJsZSI7czoyMjoibWVudV9tYWluX3RyYW5zbGF0aW9ucyI7czoxMzoiACoAcHJpbWFyeUtleSI7czoyOiJpZCI7czoxMDoiACoAa2V5VHlwZSI7czozOiJpbnQiO3M6MTI6ImluY3JlbWVudGluZyI7YjoxO3M6NzoiACoAd2l0aCI7YTowOnt9czoxMjoiACoAd2l0aENvdW50IjthOjA6e31zOjE5OiJwcmV2ZW50c0xhenlMb2FkaW5nIjtiOjA7czoxMDoiACoAcGVyUGFnZSI7aToxNTtzOjY6ImV4aXN0cyI7YjoxO3M6MTg6Indhc1JlY2VudGx5Q3JlYXRlZCI7YjowO3M6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDtzOjEzOiIAKgBhdHRyaWJ1dGVzIjthOjY6e3M6MjoiaWQiO2k6NTI7czoxMjoibWVudV9tYWluX2lkIjtpOjI2O3M6NjoibG9jYWxlIjtzOjI6InJ1IjtzOjQ6ImRhdGEiO3M6NjI6InsiaW5mbyI6IG51bGwsICJ0aXRsZSI6ICLQndC+0LLQvtGB0YLQuCIsICJkZXNjcmlwdGlvbiI6IG51bGx9IjtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI1LTEyLTIzIDA2OjE4OjQ0IjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIxIDE5OjU3OjE2Ijt9czoxMToiACoAb3JpZ2luYWwiO2E6Njp7czoyOiJpZCI7aTo1MjtzOjEyOiJtZW51X21haW5faWQiO2k6MjY7czo2OiJsb2NhbGUiO3M6MjoicnUiO3M6NDoiZGF0YSI7czo2MjoieyJpbmZvIjogbnVsbCwgInRpdGxlIjogItCd0L7QstC+0YHRgtC4IiwgImRlc2NyaXB0aW9uIjogbnVsbH0iO3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjUtMTItMjMgMDY6MTg6NDQiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDEtMjEgMTk6NTc6MTYiO31zOjEwOiIAKgBjaGFuZ2VzIjthOjA6e31zOjExOiIAKgBwcmV2aW91cyI7YTowOnt9czo4OiIAKgBjYXN0cyI7YTowOnt9czoxNzoiACoAY2xhc3NDYXN0Q2FjaGUiO2E6MDp7fXM6MjE6IgAqAGF0dHJpYnV0ZUNhc3RDYWNoZSI7YTowOnt9czoxMzoiACoAZGF0ZUZvcm1hdCI7TjtzOjEwOiIAKgBhcHBlbmRzIjthOjA6e31zOjE5OiIAKgBkaXNwYXRjaGVzRXZlbnRzIjthOjA6e31zOjE0OiIAKgBvYnNlcnZhYmxlcyI7YTowOnt9czoxMjoiACoAcmVsYXRpb25zIjthOjA6e31zOjEwOiIAKgB0b3VjaGVzIjthOjA6e31zOjI3OiIAKgByZWxhdGlvbkF1dG9sb2FkQ2FsbGJhY2siO047czoyNjoiACoAcmVsYXRpb25BdXRvbG9hZENvbnRleHQiO047czoxMDoidGltZXN0YW1wcyI7YjoxO3M6MTM6InVzZXNVbmlxdWVJZHMiO2I6MDtzOjk6IgAqAGhpZGRlbiI7YTowOnt9czoxMDoiACoAdmlzaWJsZSI7YTowOnt9czoxMToiACoAZmlsbGFibGUiO2E6Mzp7aTowO3M6MTI6Im1lbnVfbWFpbl9pZCI7aToxO3M6NjoibG9jYWxlIjtpOjI7czo0OiJkYXRhIjt9czoxMDoiACoAZ3VhcmRlZCI7YToxOntpOjA7czoxOiIqIjt9fWk6MjtPOjMwOiJBcHBcTW9kZWxzXE1lbnVNYWluVHJhbnNsYXRpb24iOjMzOntzOjEzOiIAKgBjb25uZWN0aW9uIjtzOjU6InBnc3FsIjtzOjg6IgAqAHRhYmxlIjtzOjIyOiJtZW51X21haW5fdHJhbnNsYXRpb25zIjtzOjEzOiIAKgBwcmltYXJ5S2V5IjtzOjI6ImlkIjtzOjEwOiIAKgBrZXlUeXBlIjtzOjM6ImludCI7czoxMjoiaW5jcmVtZW50aW5nIjtiOjE7czo3OiIAKgB3aXRoIjthOjA6e31zOjEyOiIAKgB3aXRoQ291bnQiO2E6MDp7fXM6MTk6InByZXZlbnRzTGF6eUxvYWRpbmciO2I6MDtzOjEwOiIAKgBwZXJQYWdlIjtpOjE1O3M6NjoiZXhpc3RzIjtiOjE7czoxODoid2FzUmVjZW50bHlDcmVhdGVkIjtiOjA7czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO3M6MTM6IgAqAGF0dHJpYnV0ZXMiO2E6Njp7czoyOiJpZCI7aToxMjc7czoxMjoibWVudV9tYWluX2lkIjtpOjI2O3M6NjoibG9jYWxlIjtzOjI6ImVuIjtzOjQ6ImRhdGEiO3M6NTI6InsiaW5mbyI6IG51bGwsICJ0aXRsZSI6ICJOZXdzIiwgImRlc2NyaXB0aW9uIjogbnVsbH0iO3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjYtMDEtMTQgMDg6Mjg6MjAiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDEtMjEgMTk6NTc6MTYiO31zOjExOiIAKgBvcmlnaW5hbCI7YTo2OntzOjI6ImlkIjtpOjEyNztzOjEyOiJtZW51X21haW5faWQiO2k6MjY7czo2OiJsb2NhbGUiO3M6MjoiZW4iO3M6NDoiZGF0YSI7czo1MjoieyJpbmZvIjogbnVsbCwgInRpdGxlIjogIk5ld3MiLCAiZGVzY3JpcHRpb24iOiBudWxsfSI7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNi0wMS0xNCAwODoyODoyMCI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMSAxOTo1NzoxNiI7fXM6MTA6IgAqAGNoYW5nZXMiO2E6MDp7fXM6MTE6IgAqAHByZXZpb3VzIjthOjA6e31zOjg6IgAqAGNhc3RzIjthOjA6e31zOjE3OiIAKgBjbGFzc0Nhc3RDYWNoZSI7YTowOnt9czoyMToiACoAYXR0cmlidXRlQ2FzdENhY2hlIjthOjA6e31zOjEzOiIAKgBkYXRlRm9ybWF0IjtOO3M6MTA6IgAqAGFwcGVuZHMiO2E6MDp7fXM6MTk6IgAqAGRpc3BhdGNoZXNFdmVudHMiO2E6MDp7fXM6MTQ6IgAqAG9ic2VydmFibGVzIjthOjA6e31zOjEyOiIAKgByZWxhdGlvbnMiO2E6MDp7fXM6MTA6IgAqAHRvdWNoZXMiO2E6MDp7fXM6Mjc6IgAqAHJlbGF0aW9uQXV0b2xvYWRDYWxsYmFjayI7TjtzOjI2OiIAKgByZWxhdGlvbkF1dG9sb2FkQ29udGV4dCI7TjtzOjEwOiJ0aW1lc3RhbXBzIjtiOjE7czoxMzoidXNlc1VuaXF1ZUlkcyI7YjowO3M6OToiACoAaGlkZGVuIjthOjA6e31zOjEwOiIAKgB2aXNpYmxlIjthOjA6e31zOjExOiIAKgBmaWxsYWJsZSI7YTozOntpOjA7czoxMjoibWVudV9tYWluX2lkIjtpOjE7czo2OiJsb2NhbGUiO2k6MjtzOjQ6ImRhdGEiO31zOjEwOiIAKgBndWFyZGVkIjthOjE6e2k6MDtzOjE6IioiO319fXM6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDt9czo5OiJjaGlsZHJlbnMiO086Mzk6IklsbHVtaW5hdGVcRGF0YWJhc2VcRWxvcXVlbnRcQ29sbGVjdGlvbiI6Mjp7czo4OiIAKgBpdGVtcyI7YTowOnt9czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO319czoxMDoiACoAdG91Y2hlcyI7YTowOnt9czoyNzoiACoAcmVsYXRpb25BdXRvbG9hZENhbGxiYWNrIjtOO3M6MjY6IgAqAHJlbGF0aW9uQXV0b2xvYWRDb250ZXh0IjtOO3M6MTA6InRpbWVzdGFtcHMiO2I6MTtzOjEzOiJ1c2VzVW5pcXVlSWRzIjtiOjA7czo5OiIAKgBoaWRkZW4iO2E6MDp7fXM6MTA6IgAqAHZpc2libGUiO2E6MDp7fXM6MTE6IgAqAGZpbGxhYmxlIjthOjk6e2k6MDtzOjQ6InR5cGUiO2k6MTtzOjQ6InNsdWciO2k6MjtzOjM6InVybCI7aTozO3M6NDoidGVzdCI7aTo0O3M6MTA6InNob3dfYWRtaW4iO2k6NTtzOjEwOiJzb3J0X29yZGVyIjtpOjY7czo0OiJpY29uIjtpOjc7czo2OiJzdGF0dXMiO2k6ODtzOjk6InBhcmVudF9pZCI7fXM6MTA6IgAqAGd1YXJkZWQiO2E6MTp7aTowO3M6MToiKiI7fXM6MTk6IgAqAHRyYW5zbGF0aW9uQ2FjaGUiO047fWk6MTtPOjE5OiJBcHBcTW9kZWxzXE1lbnVNYWluIjozNDp7czoxMzoiACoAY29ubmVjdGlvbiI7czo1OiJwZ3NxbCI7czo4OiIAKgB0YWJsZSI7czoxMDoibWVudV9tYWlucyI7czoxMzoiACoAcHJpbWFyeUtleSI7czoyOiJpZCI7czoxMDoiACoAa2V5VHlwZSI7czozOiJpbnQiO3M6MTI6ImluY3JlbWVudGluZyI7YjoxO3M6NzoiACoAd2l0aCI7YTowOnt9czoxMjoiACoAd2l0aENvdW50IjthOjA6e31zOjE5OiJwcmV2ZW50c0xhenlMb2FkaW5nIjtiOjA7czoxMDoiACoAcGVyUGFnZSI7aToxNTtzOjY6ImV4aXN0cyI7YjoxO3M6MTg6Indhc1JlY2VudGx5Q3JlYXRlZCI7YjowO3M6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDtzOjEzOiIAKgBhdHRyaWJ1dGVzIjthOjEyOntzOjI6ImlkIjtpOjI3O3M6NDoidHlwZSI7czo0OiJwYWdlIjtzOjQ6InNsdWciO3M6OToibWVkaWF0ZWthIjtzOjM6InVybCI7TjtzOjQ6InRlc3QiO2I6MDtzOjEwOiJzaG93X2FkbWluIjtiOjE7czoxMDoic29ydF9vcmRlciI7aToyNztzOjQ6Imljb24iO047czo2OiJzdGF0dXMiO2I6MTtzOjk6InBhcmVudF9pZCI7aToyNTtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI1LTEyLTIzIDA2OjE5OjAyIjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI1LTEyLTIzIDA2OjE5OjAyIjt9czoxMToiACoAb3JpZ2luYWwiO2E6MTI6e3M6MjoiaWQiO2k6Mjc7czo0OiJ0eXBlIjtzOjQ6InBhZ2UiO3M6NDoic2x1ZyI7czo5OiJtZWRpYXRla2EiO3M6MzoidXJsIjtOO3M6NDoidGVzdCI7YjowO3M6MTA6InNob3dfYWRtaW4iO2I6MTtzOjEwOiJzb3J0X29yZGVyIjtpOjI3O3M6NDoiaWNvbiI7TjtzOjY6InN0YXR1cyI7YjoxO3M6OToicGFyZW50X2lkIjtpOjI1O3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjUtMTItMjMgMDY6MTk6MDIiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjUtMTItMjMgMDY6MTk6MDIiO31zOjEwOiIAKgBjaGFuZ2VzIjthOjA6e31zOjExOiIAKgBwcmV2aW91cyI7YTowOnt9czo4OiIAKgBjYXN0cyI7YTowOnt9czoxNzoiACoAY2xhc3NDYXN0Q2FjaGUiO2E6MDp7fXM6MjE6IgAqAGF0dHJpYnV0ZUNhc3RDYWNoZSI7YTowOnt9czoxMzoiACoAZGF0ZUZvcm1hdCI7TjtzOjEwOiIAKgBhcHBlbmRzIjthOjA6e31zOjE5OiIAKgBkaXNwYXRjaGVzRXZlbnRzIjthOjA6e31zOjE0OiIAKgBvYnNlcnZhYmxlcyI7YTowOnt9czoxMjoiACoAcmVsYXRpb25zIjthOjI6e3M6MTI6InRyYW5zbGF0aW9ucyI7TzozOToiSWxsdW1pbmF0ZVxEYXRhYmFzZVxFbG9xdWVudFxDb2xsZWN0aW9uIjoyOntzOjg6IgAqAGl0ZW1zIjthOjM6e2k6MDtPOjMwOiJBcHBcTW9kZWxzXE1lbnVNYWluVHJhbnNsYXRpb24iOjMzOntzOjEzOiIAKgBjb25uZWN0aW9uIjtzOjU6InBnc3FsIjtzOjg6IgAqAHRhYmxlIjtzOjIyOiJtZW51X21haW5fdHJhbnNsYXRpb25zIjtzOjEzOiIAKgBwcmltYXJ5S2V5IjtzOjI6ImlkIjtzOjEwOiIAKgBrZXlUeXBlIjtzOjM6ImludCI7czoxMjoiaW5jcmVtZW50aW5nIjtiOjE7czo3OiIAKgB3aXRoIjthOjA6e31zOjEyOiIAKgB3aXRoQ291bnQiO2E6MDp7fXM6MTk6InByZXZlbnRzTGF6eUxvYWRpbmciO2I6MDtzOjEwOiIAKgBwZXJQYWdlIjtpOjE1O3M6NjoiZXhpc3RzIjtiOjE7czoxODoid2FzUmVjZW50bHlDcmVhdGVkIjtiOjA7czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO3M6MTM6IgAqAGF0dHJpYnV0ZXMiO2E6Njp7czoyOiJpZCI7aTo1MztzOjEyOiJtZW51X21haW5faWQiO2k6Mjc7czo2OiJsb2NhbGUiO3M6MjoidXoiO3M6NDoiZGF0YSI7czo1NzoieyJpbmZvIjogbnVsbCwgInRpdGxlIjogIk1lZGlhdGVrYSIsICJkZXNjcmlwdGlvbiI6IG51bGx9IjtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI1LTEyLTIzIDA2OjE5OjAyIjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIxIDE5OjU3OjMxIjt9czoxMToiACoAb3JpZ2luYWwiO2E6Njp7czoyOiJpZCI7aTo1MztzOjEyOiJtZW51X21haW5faWQiO2k6Mjc7czo2OiJsb2NhbGUiO3M6MjoidXoiO3M6NDoiZGF0YSI7czo1NzoieyJpbmZvIjogbnVsbCwgInRpdGxlIjogIk1lZGlhdGVrYSIsICJkZXNjcmlwdGlvbiI6IG51bGx9IjtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI1LTEyLTIzIDA2OjE5OjAyIjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIxIDE5OjU3OjMxIjt9czoxMDoiACoAY2hhbmdlcyI7YTowOnt9czoxMToiACoAcHJldmlvdXMiO2E6MDp7fXM6ODoiACoAY2FzdHMiO2E6MDp7fXM6MTc6IgAqAGNsYXNzQ2FzdENhY2hlIjthOjA6e31zOjIxOiIAKgBhdHRyaWJ1dGVDYXN0Q2FjaGUiO2E6MDp7fXM6MTM6IgAqAGRhdGVGb3JtYXQiO047czoxMDoiACoAYXBwZW5kcyI7YTowOnt9czoxOToiACoAZGlzcGF0Y2hlc0V2ZW50cyI7YTowOnt9czoxNDoiACoAb2JzZXJ2YWJsZXMiO2E6MDp7fXM6MTI6IgAqAHJlbGF0aW9ucyI7YTowOnt9czoxMDoiACoAdG91Y2hlcyI7YTowOnt9czoyNzoiACoAcmVsYXRpb25BdXRvbG9hZENhbGxiYWNrIjtOO3M6MjY6IgAqAHJlbGF0aW9uQXV0b2xvYWRDb250ZXh0IjtOO3M6MTA6InRpbWVzdGFtcHMiO2I6MTtzOjEzOiJ1c2VzVW5pcXVlSWRzIjtiOjA7czo5OiIAKgBoaWRkZW4iO2E6MDp7fXM6MTA6IgAqAHZpc2libGUiO2E6MDp7fXM6MTE6IgAqAGZpbGxhYmxlIjthOjM6e2k6MDtzOjEyOiJtZW51X21haW5faWQiO2k6MTtzOjY6ImxvY2FsZSI7aToyO3M6NDoiZGF0YSI7fXM6MTA6IgAqAGd1YXJkZWQiO2E6MTp7aTowO3M6MToiKiI7fX1pOjE7TzozMDoiQXBwXE1vZGVsc1xNZW51TWFpblRyYW5zbGF0aW9uIjozMzp7czoxMzoiACoAY29ubmVjdGlvbiI7czo1OiJwZ3NxbCI7czo4OiIAKgB0YWJsZSI7czoyMjoibWVudV9tYWluX3RyYW5zbGF0aW9ucyI7czoxMzoiACoAcHJpbWFyeUtleSI7czoyOiJpZCI7czoxMDoiACoAa2V5VHlwZSI7czozOiJpbnQiO3M6MTI6ImluY3JlbWVudGluZyI7YjoxO3M6NzoiACoAd2l0aCI7YTowOnt9czoxMjoiACoAd2l0aENvdW50IjthOjA6e31zOjE5OiJwcmV2ZW50c0xhenlMb2FkaW5nIjtiOjA7czoxMDoiACoAcGVyUGFnZSI7aToxNTtzOjY6ImV4aXN0cyI7YjoxO3M6MTg6Indhc1JlY2VudGx5Q3JlYXRlZCI7YjowO3M6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDtzOjEzOiIAKgBhdHRyaWJ1dGVzIjthOjY6e3M6MjoiaWQiO2k6NTQ7czoxMjoibWVudV9tYWluX2lkIjtpOjI3O3M6NjoibG9jYWxlIjtzOjI6InJ1IjtzOjQ6ImRhdGEiO3M6NTc6InsiaW5mbyI6IG51bGwsICJ0aXRsZSI6ICJNZWRpYXRla2EiLCAiZGVzY3JpcHRpb24iOiBudWxsfSI7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNS0xMi0yMyAwNjoxOTowMiI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMSAxOTo1NzozMSI7fXM6MTE6IgAqAG9yaWdpbmFsIjthOjY6e3M6MjoiaWQiO2k6NTQ7czoxMjoibWVudV9tYWluX2lkIjtpOjI3O3M6NjoibG9jYWxlIjtzOjI6InJ1IjtzOjQ6ImRhdGEiO3M6NTc6InsiaW5mbyI6IG51bGwsICJ0aXRsZSI6ICJNZWRpYXRla2EiLCAiZGVzY3JpcHRpb24iOiBudWxsfSI7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNS0xMi0yMyAwNjoxOTowMiI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMSAxOTo1NzozMSI7fXM6MTA6IgAqAGNoYW5nZXMiO2E6MDp7fXM6MTE6IgAqAHByZXZpb3VzIjthOjA6e31zOjg6IgAqAGNhc3RzIjthOjA6e31zOjE3OiIAKgBjbGFzc0Nhc3RDYWNoZSI7YTowOnt9czoyMToiACoAYXR0cmlidXRlQ2FzdENhY2hlIjthOjA6e31zOjEzOiIAKgBkYXRlRm9ybWF0IjtOO3M6MTA6IgAqAGFwcGVuZHMiO2E6MDp7fXM6MTk6IgAqAGRpc3BhdGNoZXNFdmVudHMiO2E6MDp7fXM6MTQ6IgAqAG9ic2VydmFibGVzIjthOjA6e31zOjEyOiIAKgByZWxhdGlvbnMiO2E6MDp7fXM6MTA6IgAqAHRvdWNoZXMiO2E6MDp7fXM6Mjc6IgAqAHJlbGF0aW9uQXV0b2xvYWRDYWxsYmFjayI7TjtzOjI2OiIAKgByZWxhdGlvbkF1dG9sb2FkQ29udGV4dCI7TjtzOjEwOiJ0aW1lc3RhbXBzIjtiOjE7czoxMzoidXNlc1VuaXF1ZUlkcyI7YjowO3M6OToiACoAaGlkZGVuIjthOjA6e31zOjEwOiIAKgB2aXNpYmxlIjthOjA6e31zOjExOiIAKgBmaWxsYWJsZSI7YTozOntpOjA7czoxMjoibWVudV9tYWluX2lkIjtpOjE7czo2OiJsb2NhbGUiO2k6MjtzOjQ6ImRhdGEiO31zOjEwOiIAKgBndWFyZGVkIjthOjE6e2k6MDtzOjE6IioiO319aToyO086MzA6IkFwcFxNb2RlbHNcTWVudU1haW5UcmFuc2xhdGlvbiI6MzM6e3M6MTM6IgAqAGNvbm5lY3Rpb24iO3M6NToicGdzcWwiO3M6ODoiACoAdGFibGUiO3M6MjI6Im1lbnVfbWFpbl90cmFuc2xhdGlvbnMiO3M6MTM6IgAqAHByaW1hcnlLZXkiO3M6MjoiaWQiO3M6MTA6IgAqAGtleVR5cGUiO3M6MzoiaW50IjtzOjEyOiJpbmNyZW1lbnRpbmciO2I6MTtzOjc6IgAqAHdpdGgiO2E6MDp7fXM6MTI6IgAqAHdpdGhDb3VudCI7YTowOnt9czoxOToicHJldmVudHNMYXp5TG9hZGluZyI7YjowO3M6MTA6IgAqAHBlclBhZ2UiO2k6MTU7czo2OiJleGlzdHMiO2I6MTtzOjE4OiJ3YXNSZWNlbnRseUNyZWF0ZWQiO2I6MDtzOjI4OiIAKgBlc2NhcGVXaGVuQ2FzdGluZ1RvU3RyaW5nIjtiOjA7czoxMzoiACoAYXR0cmlidXRlcyI7YTo2OntzOjI6ImlkIjtpOjE0OTtzOjEyOiJtZW51X21haW5faWQiO2k6Mjc7czo2OiJsb2NhbGUiO3M6MjoiZW4iO3M6NDoiZGF0YSI7czo1NzoieyJpbmZvIjogbnVsbCwgInRpdGxlIjogIk1lZGlhdGVrYSIsICJkZXNjcmlwdGlvbiI6IG51bGx9IjtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIxIDE5OjU3OjMxIjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIxIDE5OjU3OjMxIjt9czoxMToiACoAb3JpZ2luYWwiO2E6Njp7czoyOiJpZCI7aToxNDk7czoxMjoibWVudV9tYWluX2lkIjtpOjI3O3M6NjoibG9jYWxlIjtzOjI6ImVuIjtzOjQ6ImRhdGEiO3M6NTc6InsiaW5mbyI6IG51bGwsICJ0aXRsZSI6ICJNZWRpYXRla2EiLCAiZGVzY3JpcHRpb24iOiBudWxsfSI7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMSAxOTo1NzozMSI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMSAxOTo1NzozMSI7fXM6MTA6IgAqAGNoYW5nZXMiO2E6MDp7fXM6MTE6IgAqAHByZXZpb3VzIjthOjA6e31zOjg6IgAqAGNhc3RzIjthOjA6e31zOjE3OiIAKgBjbGFzc0Nhc3RDYWNoZSI7YTowOnt9czoyMToiACoAYXR0cmlidXRlQ2FzdENhY2hlIjthOjA6e31zOjEzOiIAKgBkYXRlRm9ybWF0IjtOO3M6MTA6IgAqAGFwcGVuZHMiO2E6MDp7fXM6MTk6IgAqAGRpc3BhdGNoZXNFdmVudHMiO2E6MDp7fXM6MTQ6IgAqAG9ic2VydmFibGVzIjthOjA6e31zOjEyOiIAKgByZWxhdGlvbnMiO2E6MDp7fXM6MTA6IgAqAHRvdWNoZXMiO2E6MDp7fXM6Mjc6IgAqAHJlbGF0aW9uQXV0b2xvYWRDYWxsYmFjayI7TjtzOjI2OiIAKgByZWxhdGlvbkF1dG9sb2FkQ29udGV4dCI7TjtzOjEwOiJ0aW1lc3RhbXBzIjtiOjE7czoxMzoidXNlc1VuaXF1ZUlkcyI7YjowO3M6OToiACoAaGlkZGVuIjthOjA6e31zOjEwOiIAKgB2aXNpYmxlIjthOjA6e31zOjExOiIAKgBmaWxsYWJsZSI7YTozOntpOjA7czoxMjoibWVudV9tYWluX2lkIjtpOjE7czo2OiJsb2NhbGUiO2k6MjtzOjQ6ImRhdGEiO31zOjEwOiIAKgBndWFyZGVkIjthOjE6e2k6MDtzOjE6IioiO319fXM6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDt9czo5OiJjaGlsZHJlbnMiO086Mzk6IklsbHVtaW5hdGVcRGF0YWJhc2VcRWxvcXVlbnRcQ29sbGVjdGlvbiI6Mjp7czo4OiIAKgBpdGVtcyI7YTowOnt9czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO319czoxMDoiACoAdG91Y2hlcyI7YTowOnt9czoyNzoiACoAcmVsYXRpb25BdXRvbG9hZENhbGxiYWNrIjtOO3M6MjY6IgAqAHJlbGF0aW9uQXV0b2xvYWRDb250ZXh0IjtOO3M6MTA6InRpbWVzdGFtcHMiO2I6MTtzOjEzOiJ1c2VzVW5pcXVlSWRzIjtiOjA7czo5OiIAKgBoaWRkZW4iO2E6MDp7fXM6MTA6IgAqAHZpc2libGUiO2E6MDp7fXM6MTE6IgAqAGZpbGxhYmxlIjthOjk6e2k6MDtzOjQ6InR5cGUiO2k6MTtzOjQ6InNsdWciO2k6MjtzOjM6InVybCI7aTozO3M6NDoidGVzdCI7aTo0O3M6MTA6InNob3dfYWRtaW4iO2k6NTtzOjEwOiJzb3J0X29yZGVyIjtpOjY7czo0OiJpY29uIjtpOjc7czo2OiJzdGF0dXMiO2k6ODtzOjk6InBhcmVudF9pZCI7fXM6MTA6IgAqAGd1YXJkZWQiO2E6MTp7aTowO3M6MToiKiI7fXM6MTk6IgAqAHRyYW5zbGF0aW9uQ2FjaGUiO047fWk6MjtPOjE5OiJBcHBcTW9kZWxzXE1lbnVNYWluIjozNDp7czoxMzoiACoAY29ubmVjdGlvbiI7czo1OiJwZ3NxbCI7czo4OiIAKgB0YWJsZSI7czoxMDoibWVudV9tYWlucyI7czoxMzoiACoAcHJpbWFyeUtleSI7czoyOiJpZCI7czoxMDoiACoAa2V5VHlwZSI7czozOiJpbnQiO3M6MTI6ImluY3JlbWVudGluZyI7YjoxO3M6NzoiACoAd2l0aCI7YTowOnt9czoxMjoiACoAd2l0aENvdW50IjthOjA6e31zOjE5OiJwcmV2ZW50c0xhenlMb2FkaW5nIjtiOjA7czoxMDoiACoAcGVyUGFnZSI7aToxNTtzOjY6ImV4aXN0cyI7YjoxO3M6MTg6Indhc1JlY2VudGx5Q3JlYXRlZCI7YjowO3M6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDtzOjEzOiIAKgBhdHRyaWJ1dGVzIjthOjEyOntzOjI6ImlkIjtpOjQ1O3M6NDoidHlwZSI7czo0OiJwYWdlIjtzOjQ6InNsdWciO3M6MTA6InZvbHVudGVlcnMiO3M6MzoidXJsIjtOO3M6NDoidGVzdCI7YjowO3M6MTA6InNob3dfYWRtaW4iO2I6MTtzOjEwOiJzb3J0X29yZGVyIjtpOjQ1O3M6NDoiaWNvbiI7TjtzOjY6InN0YXR1cyI7YjoxO3M6OToicGFyZW50X2lkIjtpOjI1O3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjYtMDEtMDUgMDQ6NTQ6MjIiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDEtMjIgMTU6MTA6MzciO31zOjExOiIAKgBvcmlnaW5hbCI7YToxMjp7czoyOiJpZCI7aTo0NTtzOjQ6InR5cGUiO3M6NDoicGFnZSI7czo0OiJzbHVnIjtzOjEwOiJ2b2x1bnRlZXJzIjtzOjM6InVybCI7TjtzOjQ6InRlc3QiO2I6MDtzOjEwOiJzaG93X2FkbWluIjtiOjE7czoxMDoic29ydF9vcmRlciI7aTo0NTtzOjQ6Imljb24iO047czo2OiJzdGF0dXMiO2I6MTtzOjk6InBhcmVudF9pZCI7aToyNTtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTA1IDA0OjU0OjIyIjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIyIDE1OjEwOjM3Ijt9czoxMDoiACoAY2hhbmdlcyI7YTowOnt9czoxMToiACoAcHJldmlvdXMiO2E6MDp7fXM6ODoiACoAY2FzdHMiO2E6MDp7fXM6MTc6IgAqAGNsYXNzQ2FzdENhY2hlIjthOjA6e31zOjIxOiIAKgBhdHRyaWJ1dGVDYXN0Q2FjaGUiO2E6MDp7fXM6MTM6IgAqAGRhdGVGb3JtYXQiO047czoxMDoiACoAYXBwZW5kcyI7YTowOnt9czoxOToiACoAZGlzcGF0Y2hlc0V2ZW50cyI7YTowOnt9czoxNDoiACoAb2JzZXJ2YWJsZXMiO2E6MDp7fXM6MTI6IgAqAHJlbGF0aW9ucyI7YToyOntzOjEyOiJ0cmFuc2xhdGlvbnMiO086Mzk6IklsbHVtaW5hdGVcRGF0YWJhc2VcRWxvcXVlbnRcQ29sbGVjdGlvbiI6Mjp7czo4OiIAKgBpdGVtcyI7YTozOntpOjA7TzozMDoiQXBwXE1vZGVsc1xNZW51TWFpblRyYW5zbGF0aW9uIjozMzp7czoxMzoiACoAY29ubmVjdGlvbiI7czo1OiJwZ3NxbCI7czo4OiIAKgB0YWJsZSI7czoyMjoibWVudV9tYWluX3RyYW5zbGF0aW9ucyI7czoxMzoiACoAcHJpbWFyeUtleSI7czoyOiJpZCI7czoxMDoiACoAa2V5VHlwZSI7czozOiJpbnQiO3M6MTI6ImluY3JlbWVudGluZyI7YjoxO3M6NzoiACoAd2l0aCI7YTowOnt9czoxMjoiACoAd2l0aENvdW50IjthOjA6e31zOjE5OiJwcmV2ZW50c0xhenlMb2FkaW5nIjtiOjA7czoxMDoiACoAcGVyUGFnZSI7aToxNTtzOjY6ImV4aXN0cyI7YjoxO3M6MTg6Indhc1JlY2VudGx5Q3JlYXRlZCI7YjowO3M6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDtzOjEzOiIAKgBhdHRyaWJ1dGVzIjthOjY6e3M6MjoiaWQiO2k6MTA5O3M6MTI6Im1lbnVfbWFpbl9pZCI7aTo0NTtzOjY6ImxvY2FsZSI7czoyOiJ1eiI7czo0OiJkYXRhIjtzOjYzOiJ7ImluZm8iOiBudWxsLCAidGl0bGUiOiAiVm9sb250b3JsYXJpbWl6IiwgImRlc2NyaXB0aW9uIjogbnVsbH0iO3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjYtMDEtMDUgMDQ6NTQ6MjIiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDEtMjEgMTk6NTg6MjgiO31zOjExOiIAKgBvcmlnaW5hbCI7YTo2OntzOjI6ImlkIjtpOjEwOTtzOjEyOiJtZW51X21haW5faWQiO2k6NDU7czo2OiJsb2NhbGUiO3M6MjoidXoiO3M6NDoiZGF0YSI7czo2MzoieyJpbmZvIjogbnVsbCwgInRpdGxlIjogIlZvbG9udG9ybGFyaW1peiIsICJkZXNjcmlwdGlvbiI6IG51bGx9IjtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTA1IDA0OjU0OjIyIjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIxIDE5OjU4OjI4Ijt9czoxMDoiACoAY2hhbmdlcyI7YTowOnt9czoxMToiACoAcHJldmlvdXMiO2E6MDp7fXM6ODoiACoAY2FzdHMiO2E6MDp7fXM6MTc6IgAqAGNsYXNzQ2FzdENhY2hlIjthOjA6e31zOjIxOiIAKgBhdHRyaWJ1dGVDYXN0Q2FjaGUiO2E6MDp7fXM6MTM6IgAqAGRhdGVGb3JtYXQiO047czoxMDoiACoAYXBwZW5kcyI7YTowOnt9czoxOToiACoAZGlzcGF0Y2hlc0V2ZW50cyI7YTowOnt9czoxNDoiACoAb2JzZXJ2YWJsZXMiO2E6MDp7fXM6MTI6IgAqAHJlbGF0aW9ucyI7YTowOnt9czoxMDoiACoAdG91Y2hlcyI7YTowOnt9czoyNzoiACoAcmVsYXRpb25BdXRvbG9hZENhbGxiYWNrIjtOO3M6MjY6IgAqAHJlbGF0aW9uQXV0b2xvYWRDb250ZXh0IjtOO3M6MTA6InRpbWVzdGFtcHMiO2I6MTtzOjEzOiJ1c2VzVW5pcXVlSWRzIjtiOjA7czo5OiIAKgBoaWRkZW4iO2E6MDp7fXM6MTA6IgAqAHZpc2libGUiO2E6MDp7fXM6MTE6IgAqAGZpbGxhYmxlIjthOjM6e2k6MDtzOjEyOiJtZW51X21haW5faWQiO2k6MTtzOjY6ImxvY2FsZSI7aToyO3M6NDoiZGF0YSI7fXM6MTA6IgAqAGd1YXJkZWQiO2E6MTp7aTowO3M6MToiKiI7fX1pOjE7TzozMDoiQXBwXE1vZGVsc1xNZW51TWFpblRyYW5zbGF0aW9uIjozMzp7czoxMzoiACoAY29ubmVjdGlvbiI7czo1OiJwZ3NxbCI7czo4OiIAKgB0YWJsZSI7czoyMjoibWVudV9tYWluX3RyYW5zbGF0aW9ucyI7czoxMzoiACoAcHJpbWFyeUtleSI7czoyOiJpZCI7czoxMDoiACoAa2V5VHlwZSI7czozOiJpbnQiO3M6MTI6ImluY3JlbWVudGluZyI7YjoxO3M6NzoiACoAd2l0aCI7YTowOnt9czoxMjoiACoAd2l0aENvdW50IjthOjA6e31zOjE5OiJwcmV2ZW50c0xhenlMb2FkaW5nIjtiOjA7czoxMDoiACoAcGVyUGFnZSI7aToxNTtzOjY6ImV4aXN0cyI7YjoxO3M6MTg6Indhc1JlY2VudGx5Q3JlYXRlZCI7YjowO3M6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDtzOjEzOiIAKgBhdHRyaWJ1dGVzIjthOjY6e3M6MjoiaWQiO2k6MTEwO3M6MTI6Im1lbnVfbWFpbl9pZCI7aTo0NTtzOjY6ImxvY2FsZSI7czoyOiJydSI7czo0OiJkYXRhIjtzOjc1OiJ7ImluZm8iOiBudWxsLCAidGl0bGUiOiAi0J3QsNGI0Lgg0LLQvtC70L7QvdGC0LXRgNGLIiwgImRlc2NyaXB0aW9uIjogbnVsbH0iO3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjYtMDEtMDUgMDQ6NTQ6MjIiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDEtMjEgMTk6NTg6MjgiO31zOjExOiIAKgBvcmlnaW5hbCI7YTo2OntzOjI6ImlkIjtpOjExMDtzOjEyOiJtZW51X21haW5faWQiO2k6NDU7czo2OiJsb2NhbGUiO3M6MjoicnUiO3M6NDoiZGF0YSI7czo3NToieyJpbmZvIjogbnVsbCwgInRpdGxlIjogItCd0LDRiNC4INCy0L7Qu9C+0L3RgtC10YDRiyIsICJkZXNjcmlwdGlvbiI6IG51bGx9IjtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTA1IDA0OjU0OjIyIjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIxIDE5OjU4OjI4Ijt9czoxMDoiACoAY2hhbmdlcyI7YTowOnt9czoxMToiACoAcHJldmlvdXMiO2E6MDp7fXM6ODoiACoAY2FzdHMiO2E6MDp7fXM6MTc6IgAqAGNsYXNzQ2FzdENhY2hlIjthOjA6e31zOjIxOiIAKgBhdHRyaWJ1dGVDYXN0Q2FjaGUiO2E6MDp7fXM6MTM6IgAqAGRhdGVGb3JtYXQiO047czoxMDoiACoAYXBwZW5kcyI7YTowOnt9czoxOToiACoAZGlzcGF0Y2hlc0V2ZW50cyI7YTowOnt9czoxNDoiACoAb2JzZXJ2YWJsZXMiO2E6MDp7fXM6MTI6IgAqAHJlbGF0aW9ucyI7YTowOnt9czoxMDoiACoAdG91Y2hlcyI7YTowOnt9czoyNzoiACoAcmVsYXRpb25BdXRvbG9hZENhbGxiYWNrIjtOO3M6MjY6IgAqAHJlbGF0aW9uQXV0b2xvYWRDb250ZXh0IjtOO3M6MTA6InRpbWVzdGFtcHMiO2I6MTtzOjEzOiJ1c2VzVW5pcXVlSWRzIjtiOjA7czo5OiIAKgBoaWRkZW4iO2E6MDp7fXM6MTA6IgAqAHZpc2libGUiO2E6MDp7fXM6MTE6IgAqAGZpbGxhYmxlIjthOjM6e2k6MDtzOjEyOiJtZW51X21haW5faWQiO2k6MTtzOjY6ImxvY2FsZSI7aToyO3M6NDoiZGF0YSI7fXM6MTA6IgAqAGd1YXJkZWQiO2E6MTp7aTowO3M6MToiKiI7fX1pOjI7TzozMDoiQXBwXE1vZGVsc1xNZW51TWFpblRyYW5zbGF0aW9uIjozMzp7czoxMzoiACoAY29ubmVjdGlvbiI7czo1OiJwZ3NxbCI7czo4OiIAKgB0YWJsZSI7czoyMjoibWVudV9tYWluX3RyYW5zbGF0aW9ucyI7czoxMzoiACoAcHJpbWFyeUtleSI7czoyOiJpZCI7czoxMDoiACoAa2V5VHlwZSI7czozOiJpbnQiO3M6MTI6ImluY3JlbWVudGluZyI7YjoxO3M6NzoiACoAd2l0aCI7YTowOnt9czoxMjoiACoAd2l0aENvdW50IjthOjA6e31zOjE5OiJwcmV2ZW50c0xhenlMb2FkaW5nIjtiOjA7czoxMDoiACoAcGVyUGFnZSI7aToxNTtzOjY6ImV4aXN0cyI7YjoxO3M6MTg6Indhc1JlY2VudGx5Q3JlYXRlZCI7YjowO3M6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDtzOjEzOiIAKgBhdHRyaWJ1dGVzIjthOjY6e3M6MjoiaWQiO2k6MTExO3M6MTI6Im1lbnVfbWFpbl9pZCI7aTo0NTtzOjY6ImxvY2FsZSI7czoyOiJlbiI7czo0OiJkYXRhIjtzOjYyOiJ7ImluZm8iOiBudWxsLCAidGl0bGUiOiAiT3VyIHZvbHVudGVlcnMiLCAiZGVzY3JpcHRpb24iOiBudWxsfSI7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNi0wMS0wNSAwNDo1NDoyMiI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMSAxOTo1ODoyOCI7fXM6MTE6IgAqAG9yaWdpbmFsIjthOjY6e3M6MjoiaWQiO2k6MTExO3M6MTI6Im1lbnVfbWFpbl9pZCI7aTo0NTtzOjY6ImxvY2FsZSI7czoyOiJlbiI7czo0OiJkYXRhIjtzOjYyOiJ7ImluZm8iOiBudWxsLCAidGl0bGUiOiAiT3VyIHZvbHVudGVlcnMiLCAiZGVzY3JpcHRpb24iOiBudWxsfSI7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNi0wMS0wNSAwNDo1NDoyMiI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMSAxOTo1ODoyOCI7fXM6MTA6IgAqAGNoYW5nZXMiO2E6MDp7fXM6MTE6IgAqAHByZXZpb3VzIjthOjA6e31zOjg6IgAqAGNhc3RzIjthOjA6e31zOjE3OiIAKgBjbGFzc0Nhc3RDYWNoZSI7YTowOnt9czoyMToiACoAYXR0cmlidXRlQ2FzdENhY2hlIjthOjA6e31zOjEzOiIAKgBkYXRlRm9ybWF0IjtOO3M6MTA6IgAqAGFwcGVuZHMiO2E6MDp7fXM6MTk6IgAqAGRpc3BhdGNoZXNFdmVudHMiO2E6MDp7fXM6MTQ6IgAqAG9ic2VydmFibGVzIjthOjA6e31zOjEyOiIAKgByZWxhdGlvbnMiO2E6MDp7fXM6MTA6IgAqAHRvdWNoZXMiO2E6MDp7fXM6Mjc6IgAqAHJlbGF0aW9uQXV0b2xvYWRDYWxsYmFjayI7TjtzOjI2OiIAKgByZWxhdGlvbkF1dG9sb2FkQ29udGV4dCI7TjtzOjEwOiJ0aW1lc3RhbXBzIjtiOjE7czoxMzoidXNlc1VuaXF1ZUlkcyI7YjowO3M6OToiACoAaGlkZGVuIjthOjA6e31zOjEwOiIAKgB2aXNpYmxlIjthOjA6e31zOjExOiIAKgBmaWxsYWJsZSI7YTozOntpOjA7czoxMjoibWVudV9tYWluX2lkIjtpOjE7czo2OiJsb2NhbGUiO2k6MjtzOjQ6ImRhdGEiO31zOjEwOiIAKgBndWFyZGVkIjthOjE6e2k6MDtzOjE6IioiO319fXM6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDt9czo5OiJjaGlsZHJlbnMiO086Mzk6IklsbHVtaW5hdGVcRGF0YWJhc2VcRWxvcXVlbnRcQ29sbGVjdGlvbiI6Mjp7czo4OiIAKgBpdGVtcyI7YTowOnt9czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO319czoxMDoiACoAdG91Y2hlcyI7YTowOnt9czoyNzoiACoAcmVsYXRpb25BdXRvbG9hZENhbGxiYWNrIjtOO3M6MjY6IgAqAHJlbGF0aW9uQXV0b2xvYWRDb250ZXh0IjtOO3M6MTA6InRpbWVzdGFtcHMiO2I6MTtzOjEzOiJ1c2VzVW5pcXVlSWRzIjtiOjA7czo5OiIAKgBoaWRkZW4iO2E6MDp7fXM6MTA6IgAqAHZpc2libGUiO2E6MDp7fXM6MTE6IgAqAGZpbGxhYmxlIjthOjk6e2k6MDtzOjQ6InR5cGUiO2k6MTtzOjQ6InNsdWciO2k6MjtzOjM6InVybCI7aTozO3M6NDoidGVzdCI7aTo0O3M6MTA6InNob3dfYWRtaW4iO2k6NTtzOjEwOiJzb3J0X29yZGVyIjtpOjY7czo0OiJpY29uIjtpOjc7czo2OiJzdGF0dXMiO2k6ODtzOjk6InBhcmVudF9pZCI7fXM6MTA6IgAqAGd1YXJkZWQiO2E6MTp7aTowO3M6MToiKiI7fXM6MTk6IgAqAHRyYW5zbGF0aW9uQ2FjaGUiO047fWk6MztPOjE5OiJBcHBcTW9kZWxzXE1lbnVNYWluIjozNDp7czoxMzoiACoAY29ubmVjdGlvbiI7czo1OiJwZ3NxbCI7czo4OiIAKgB0YWJsZSI7czoxMDoibWVudV9tYWlucyI7czoxMzoiACoAcHJpbWFyeUtleSI7czoyOiJpZCI7czoxMDoiACoAa2V5VHlwZSI7czozOiJpbnQiO3M6MTI6ImluY3JlbWVudGluZyI7YjoxO3M6NzoiACoAd2l0aCI7YTowOnt9czoxMjoiACoAd2l0aENvdW50IjthOjA6e31zOjE5OiJwcmV2ZW50c0xhenlMb2FkaW5nIjtiOjA7czoxMDoiACoAcGVyUGFnZSI7aToxNTtzOjY6ImV4aXN0cyI7YjoxO3M6MTg6Indhc1JlY2VudGx5Q3JlYXRlZCI7YjowO3M6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDtzOjEzOiIAKgBhdHRyaWJ1dGVzIjthOjEyOntzOjI6ImlkIjtpOjQ2O3M6NDoidHlwZSI7czo0OiJwYWdlIjtzOjQ6InNsdWciO3M6OToibmV3c3BhcGVyIjtzOjM6InVybCI7TjtzOjQ6InRlc3QiO2I6MDtzOjEwOiJzaG93X2FkbWluIjtiOjE7czoxMDoic29ydF9vcmRlciI7aTo0NjtzOjQ6Imljb24iO047czo2OiJzdGF0dXMiO2I6MTtzOjk6InBhcmVudF9pZCI7aToyNTtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTA1IDA0OjU0OjQ2IjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIyIDE1OjEwOjM5Ijt9czoxMToiACoAb3JpZ2luYWwiO2E6MTI6e3M6MjoiaWQiO2k6NDY7czo0OiJ0eXBlIjtzOjQ6InBhZ2UiO3M6NDoic2x1ZyI7czo5OiJuZXdzcGFwZXIiO3M6MzoidXJsIjtOO3M6NDoidGVzdCI7YjowO3M6MTA6InNob3dfYWRtaW4iO2I6MTtzOjEwOiJzb3J0X29yZGVyIjtpOjQ2O3M6NDoiaWNvbiI7TjtzOjY6InN0YXR1cyI7YjoxO3M6OToicGFyZW50X2lkIjtpOjI1O3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjYtMDEtMDUgMDQ6NTQ6NDYiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDEtMjIgMTU6MTA6MzkiO31zOjEwOiIAKgBjaGFuZ2VzIjthOjA6e31zOjExOiIAKgBwcmV2aW91cyI7YTowOnt9czo4OiIAKgBjYXN0cyI7YTowOnt9czoxNzoiACoAY2xhc3NDYXN0Q2FjaGUiO2E6MDp7fXM6MjE6IgAqAGF0dHJpYnV0ZUNhc3RDYWNoZSI7YTowOnt9czoxMzoiACoAZGF0ZUZvcm1hdCI7TjtzOjEwOiIAKgBhcHBlbmRzIjthOjA6e31zOjE5OiIAKgBkaXNwYXRjaGVzRXZlbnRzIjthOjA6e31zOjE0OiIAKgBvYnNlcnZhYmxlcyI7YTowOnt9czoxMjoiACoAcmVsYXRpb25zIjthOjI6e3M6MTI6InRyYW5zbGF0aW9ucyI7TzozOToiSWxsdW1pbmF0ZVxEYXRhYmFzZVxFbG9xdWVudFxDb2xsZWN0aW9uIjoyOntzOjg6IgAqAGl0ZW1zIjthOjM6e2k6MDtPOjMwOiJBcHBcTW9kZWxzXE1lbnVNYWluVHJhbnNsYXRpb24iOjMzOntzOjEzOiIAKgBjb25uZWN0aW9uIjtzOjU6InBnc3FsIjtzOjg6IgAqAHRhYmxlIjtzOjIyOiJtZW51X21haW5fdHJhbnNsYXRpb25zIjtzOjEzOiIAKgBwcmltYXJ5S2V5IjtzOjI6ImlkIjtzOjEwOiIAKgBrZXlUeXBlIjtzOjM6ImludCI7czoxMjoiaW5jcmVtZW50aW5nIjtiOjE7czo3OiIAKgB3aXRoIjthOjA6e31zOjEyOiIAKgB3aXRoQ291bnQiO2E6MDp7fXM6MTk6InByZXZlbnRzTGF6eUxvYWRpbmciO2I6MDtzOjEwOiIAKgBwZXJQYWdlIjtpOjE1O3M6NjoiZXhpc3RzIjtiOjE7czoxODoid2FzUmVjZW50bHlDcmVhdGVkIjtiOjA7czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO3M6MTM6IgAqAGF0dHJpYnV0ZXMiO2E6Njp7czoyOiJpZCI7aToxMTI7czoxMjoibWVudV9tYWluX2lkIjtpOjQ2O3M6NjoibG9jYWxlIjtzOjI6InV6IjtzOjQ6ImRhdGEiO3M6NTc6InsiaW5mbyI6IG51bGwsICJ0aXRsZSI6ICJHYXpldGFsYXIiLCAiZGVzY3JpcHRpb24iOiBudWxsfSI7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNi0wMS0wNSAwNDo1NDo0NiI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMSAxOTo1ODo1MiI7fXM6MTE6IgAqAG9yaWdpbmFsIjthOjY6e3M6MjoiaWQiO2k6MTEyO3M6MTI6Im1lbnVfbWFpbl9pZCI7aTo0NjtzOjY6ImxvY2FsZSI7czoyOiJ1eiI7czo0OiJkYXRhIjtzOjU3OiJ7ImluZm8iOiBudWxsLCAidGl0bGUiOiAiR2F6ZXRhbGFyIiwgImRlc2NyaXB0aW9uIjogbnVsbH0iO3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjYtMDEtMDUgMDQ6NTQ6NDYiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDEtMjEgMTk6NTg6NTIiO31zOjEwOiIAKgBjaGFuZ2VzIjthOjA6e31zOjExOiIAKgBwcmV2aW91cyI7YTowOnt9czo4OiIAKgBjYXN0cyI7YTowOnt9czoxNzoiACoAY2xhc3NDYXN0Q2FjaGUiO2E6MDp7fXM6MjE6IgAqAGF0dHJpYnV0ZUNhc3RDYWNoZSI7YTowOnt9czoxMzoiACoAZGF0ZUZvcm1hdCI7TjtzOjEwOiIAKgBhcHBlbmRzIjthOjA6e31zOjE5OiIAKgBkaXNwYXRjaGVzRXZlbnRzIjthOjA6e31zOjE0OiIAKgBvYnNlcnZhYmxlcyI7YTowOnt9czoxMjoiACoAcmVsYXRpb25zIjthOjA6e31zOjEwOiIAKgB0b3VjaGVzIjthOjA6e31zOjI3OiIAKgByZWxhdGlvbkF1dG9sb2FkQ2FsbGJhY2siO047czoyNjoiACoAcmVsYXRpb25BdXRvbG9hZENvbnRleHQiO047czoxMDoidGltZXN0YW1wcyI7YjoxO3M6MTM6InVzZXNVbmlxdWVJZHMiO2I6MDtzOjk6IgAqAGhpZGRlbiI7YTowOnt9czoxMDoiACoAdmlzaWJsZSI7YTowOnt9czoxMToiACoAZmlsbGFibGUiO2E6Mzp7aTowO3M6MTI6Im1lbnVfbWFpbl9pZCI7aToxO3M6NjoibG9jYWxlIjtpOjI7czo0OiJkYXRhIjt9czoxMDoiACoAZ3VhcmRlZCI7YToxOntpOjA7czoxOiIqIjt9fWk6MTtPOjMwOiJBcHBcTW9kZWxzXE1lbnVNYWluVHJhbnNsYXRpb24iOjMzOntzOjEzOiIAKgBjb25uZWN0aW9uIjtzOjU6InBnc3FsIjtzOjg6IgAqAHRhYmxlIjtzOjIyOiJtZW51X21haW5fdHJhbnNsYXRpb25zIjtzOjEzOiIAKgBwcmltYXJ5S2V5IjtzOjI6ImlkIjtzOjEwOiIAKgBrZXlUeXBlIjtzOjM6ImludCI7czoxMjoiaW5jcmVtZW50aW5nIjtiOjE7czo3OiIAKgB3aXRoIjthOjA6e31zOjEyOiIAKgB3aXRoQ291bnQiO2E6MDp7fXM6MTk6InByZXZlbnRzTGF6eUxvYWRpbmciO2I6MDtzOjEwOiIAKgBwZXJQYWdlIjtpOjE1O3M6NjoiZXhpc3RzIjtiOjE7czoxODoid2FzUmVjZW50bHlDcmVhdGVkIjtiOjA7czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO3M6MTM6IgAqAGF0dHJpYnV0ZXMiO2E6Njp7czoyOiJpZCI7aToxMTM7czoxMjoibWVudV9tYWluX2lkIjtpOjQ2O3M6NjoibG9jYWxlIjtzOjI6InJ1IjtzOjQ6ImRhdGEiO3M6NjA6InsiaW5mbyI6IG51bGwsICJ0aXRsZSI6ICLQk9Cw0LfQtdGC0YsiLCAiZGVzY3JpcHRpb24iOiBudWxsfSI7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNi0wMS0wNSAwNDo1NDo0NiI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMSAxOTo1ODo1MiI7fXM6MTE6IgAqAG9yaWdpbmFsIjthOjY6e3M6MjoiaWQiO2k6MTEzO3M6MTI6Im1lbnVfbWFpbl9pZCI7aTo0NjtzOjY6ImxvY2FsZSI7czoyOiJydSI7czo0OiJkYXRhIjtzOjYwOiJ7ImluZm8iOiBudWxsLCAidGl0bGUiOiAi0JPQsNC30LXRgtGLIiwgImRlc2NyaXB0aW9uIjogbnVsbH0iO3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjYtMDEtMDUgMDQ6NTQ6NDYiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDEtMjEgMTk6NTg6NTIiO31zOjEwOiIAKgBjaGFuZ2VzIjthOjA6e31zOjExOiIAKgBwcmV2aW91cyI7YTowOnt9czo4OiIAKgBjYXN0cyI7YTowOnt9czoxNzoiACoAY2xhc3NDYXN0Q2FjaGUiO2E6MDp7fXM6MjE6IgAqAGF0dHJpYnV0ZUNhc3RDYWNoZSI7YTowOnt9czoxMzoiACoAZGF0ZUZvcm1hdCI7TjtzOjEwOiIAKgBhcHBlbmRzIjthOjA6e31zOjE5OiIAKgBkaXNwYXRjaGVzRXZlbnRzIjthOjA6e31zOjE0OiIAKgBvYnNlcnZhYmxlcyI7YTowOnt9czoxMjoiACoAcmVsYXRpb25zIjthOjA6e31zOjEwOiIAKgB0b3VjaGVzIjthOjA6e31zOjI3OiIAKgByZWxhdGlvbkF1dG9sb2FkQ2FsbGJhY2siO047czoyNjoiACoAcmVsYXRpb25BdXRvbG9hZENvbnRleHQiO047czoxMDoidGltZXN0YW1wcyI7YjoxO3M6MTM6InVzZXNVbmlxdWVJZHMiO2I6MDtzOjk6IgAqAGhpZGRlbiI7YTowOnt9czoxMDoiACoAdmlzaWJsZSI7YTowOnt9czoxMToiACoAZmlsbGFibGUiO2E6Mzp7aTowO3M6MTI6Im1lbnVfbWFpbl9pZCI7aToxO3M6NjoibG9jYWxlIjtpOjI7czo0OiJkYXRhIjt9czoxMDoiACoAZ3VhcmRlZCI7YToxOntpOjA7czoxOiIqIjt9fWk6MjtPOjMwOiJBcHBcTW9kZWxzXE1lbnVNYWluVHJhbnNsYXRpb24iOjMzOntzOjEzOiIAKgBjb25uZWN0aW9uIjtzOjU6InBnc3FsIjtzOjg6IgAqAHRhYmxlIjtzOjIyOiJtZW51X21haW5fdHJhbnNsYXRpb25zIjtzOjEzOiIAKgBwcmltYXJ5S2V5IjtzOjI6ImlkIjtzOjEwOiIAKgBrZXlUeXBlIjtzOjM6ImludCI7czoxMjoiaW5jcmVtZW50aW5nIjtiOjE7czo3OiIAKgB3aXRoIjthOjA6e31zOjEyOiIAKgB3aXRoQ291bnQiO2E6MDp7fXM6MTk6InByZXZlbnRzTGF6eUxvYWRpbmciO2I6MDtzOjEwOiIAKgBwZXJQYWdlIjtpOjE1O3M6NjoiZXhpc3RzIjtiOjE7czoxODoid2FzUmVjZW50bHlDcmVhdGVkIjtiOjA7czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO3M6MTM6IgAqAGF0dHJpYnV0ZXMiO2E6Njp7czoyOiJpZCI7aToxMTQ7czoxMjoibWVudV9tYWluX2lkIjtpOjQ2O3M6NjoibG9jYWxlIjtzOjI6ImVuIjtzOjQ6ImRhdGEiO3M6NTg6InsiaW5mbyI6IG51bGwsICJ0aXRsZSI6ICJOZXdzcGFwZXJzIiwgImRlc2NyaXB0aW9uIjogbnVsbH0iO3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjYtMDEtMDUgMDQ6NTQ6NDYiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDEtMjEgMTk6NTg6NTIiO31zOjExOiIAKgBvcmlnaW5hbCI7YTo2OntzOjI6ImlkIjtpOjExNDtzOjEyOiJtZW51X21haW5faWQiO2k6NDY7czo2OiJsb2NhbGUiO3M6MjoiZW4iO3M6NDoiZGF0YSI7czo1ODoieyJpbmZvIjogbnVsbCwgInRpdGxlIjogIk5ld3NwYXBlcnMiLCAiZGVzY3JpcHRpb24iOiBudWxsfSI7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNi0wMS0wNSAwNDo1NDo0NiI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMSAxOTo1ODo1MiI7fXM6MTA6IgAqAGNoYW5nZXMiO2E6MDp7fXM6MTE6IgAqAHByZXZpb3VzIjthOjA6e31zOjg6IgAqAGNhc3RzIjthOjA6e31zOjE3OiIAKgBjbGFzc0Nhc3RDYWNoZSI7YTowOnt9czoyMToiACoAYXR0cmlidXRlQ2FzdENhY2hlIjthOjA6e31zOjEzOiIAKgBkYXRlRm9ybWF0IjtOO3M6MTA6IgAqAGFwcGVuZHMiO2E6MDp7fXM6MTk6IgAqAGRpc3BhdGNoZXNFdmVudHMiO2E6MDp7fXM6MTQ6IgAqAG9ic2VydmFibGVzIjthOjA6e31zOjEyOiIAKgByZWxhdGlvbnMiO2E6MDp7fXM6MTA6IgAqAHRvdWNoZXMiO2E6MDp7fXM6Mjc6IgAqAHJlbGF0aW9uQXV0b2xvYWRDYWxsYmFjayI7TjtzOjI2OiIAKgByZWxhdGlvbkF1dG9sb2FkQ29udGV4dCI7TjtzOjEwOiJ0aW1lc3RhbXBzIjtiOjE7czoxMzoidXNlc1VuaXF1ZUlkcyI7YjowO3M6OToiACoAaGlkZGVuIjthOjA6e31zOjEwOiIAKgB2aXNpYmxlIjthOjA6e31zOjExOiIAKgBmaWxsYWJsZSI7YTozOntpOjA7czoxMjoibWVudV9tYWluX2lkIjtpOjE7czo2OiJsb2NhbGUiO2k6MjtzOjQ6ImRhdGEiO31zOjEwOiIAKgBndWFyZGVkIjthOjE6e2k6MDtzOjE6IioiO319fXM6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDt9czo5OiJjaGlsZHJlbnMiO086Mzk6IklsbHVtaW5hdGVcRGF0YWJhc2VcRWxvcXVlbnRcQ29sbGVjdGlvbiI6Mjp7czo4OiIAKgBpdGVtcyI7YTowOnt9czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO319czoxMDoiACoAdG91Y2hlcyI7YTowOnt9czoyNzoiACoAcmVsYXRpb25BdXRvbG9hZENhbGxiYWNrIjtOO3M6MjY6IgAqAHJlbGF0aW9uQXV0b2xvYWRDb250ZXh0IjtOO3M6MTA6InRpbWVzdGFtcHMiO2I6MTtzOjEzOiJ1c2VzVW5pcXVlSWRzIjtiOjA7czo5OiIAKgBoaWRkZW4iO2E6MDp7fXM6MTA6IgAqAHZpc2libGUiO2E6MDp7fXM6MTE6IgAqAGZpbGxhYmxlIjthOjk6e2k6MDtzOjQ6InR5cGUiO2k6MTtzOjQ6InNsdWciO2k6MjtzOjM6InVybCI7aTozO3M6NDoidGVzdCI7aTo0O3M6MTA6InNob3dfYWRtaW4iO2k6NTtzOjEwOiJzb3J0X29yZGVyIjtpOjY7czo0OiJpY29uIjtpOjc7czo2OiJzdGF0dXMiO2k6ODtzOjk6InBhcmVudF9pZCI7fXM6MTA6IgAqAGd1YXJkZWQiO2E6MTp7aTowO3M6MToiKiI7fXM6MTk6IgAqAHRyYW5zbGF0aW9uQ2FjaGUiO047fX1zOjI4OiIAKgBlc2NhcGVXaGVuQ2FzdGluZ1RvU3RyaW5nIjtiOjA7fXM6MTI6InRyYW5zbGF0aW9ucyI7TzozOToiSWxsdW1pbmF0ZVxEYXRhYmFzZVxFbG9xdWVudFxDb2xsZWN0aW9uIjoyOntzOjg6IgAqAGl0ZW1zIjthOjM6e2k6MDtPOjMwOiJBcHBcTW9kZWxzXE1lbnVNYWluVHJhbnNsYXRpb24iOjMzOntzOjEzOiIAKgBjb25uZWN0aW9uIjtzOjU6InBnc3FsIjtzOjg6IgAqAHRhYmxlIjtzOjIyOiJtZW51X21haW5fdHJhbnNsYXRpb25zIjtzOjEzOiIAKgBwcmltYXJ5S2V5IjtzOjI6ImlkIjtzOjEwOiIAKgBrZXlUeXBlIjtzOjM6ImludCI7czoxMjoiaW5jcmVtZW50aW5nIjtiOjE7czo3OiIAKgB3aXRoIjthOjA6e31zOjEyOiIAKgB3aXRoQ291bnQiO2E6MDp7fXM6MTk6InByZXZlbnRzTGF6eUxvYWRpbmciO2I6MDtzOjEwOiIAKgBwZXJQYWdlIjtpOjE1O3M6NjoiZXhpc3RzIjtiOjE7czoxODoid2FzUmVjZW50bHlDcmVhdGVkIjtiOjA7czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO3M6MTM6IgAqAGF0dHJpYnV0ZXMiO2E6Njp7czoyOiJpZCI7aTo0OTtzOjEyOiJtZW51X21haW5faWQiO2k6MjU7czo2OiJsb2NhbGUiO3M6MjoidXoiO3M6NDoiZGF0YSI7czo2NjoieyJpbmZvIjogbnVsbCwgInRpdGxlIjogIkF4Ym9yb3QgeGl6bWF0bGFyaSIsICJkZXNjcmlwdGlvbiI6IG51bGx9IjtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI1LTEyLTIzIDA2OjE4OjI1IjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIxIDE5OjU2OjQ0Ijt9czoxMToiACoAb3JpZ2luYWwiO2E6Njp7czoyOiJpZCI7aTo0OTtzOjEyOiJtZW51X21haW5faWQiO2k6MjU7czo2OiJsb2NhbGUiO3M6MjoidXoiO3M6NDoiZGF0YSI7czo2NjoieyJpbmZvIjogbnVsbCwgInRpdGxlIjogIkF4Ym9yb3QgeGl6bWF0bGFyaSIsICJkZXNjcmlwdGlvbiI6IG51bGx9IjtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI1LTEyLTIzIDA2OjE4OjI1IjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIxIDE5OjU2OjQ0Ijt9czoxMDoiACoAY2hhbmdlcyI7YTowOnt9czoxMToiACoAcHJldmlvdXMiO2E6MDp7fXM6ODoiACoAY2FzdHMiO2E6MDp7fXM6MTc6IgAqAGNsYXNzQ2FzdENhY2hlIjthOjA6e31zOjIxOiIAKgBhdHRyaWJ1dGVDYXN0Q2FjaGUiO2E6MDp7fXM6MTM6IgAqAGRhdGVGb3JtYXQiO047czoxMDoiACoAYXBwZW5kcyI7YTowOnt9czoxOToiACoAZGlzcGF0Y2hlc0V2ZW50cyI7YTowOnt9czoxNDoiACoAb2JzZXJ2YWJsZXMiO2E6MDp7fXM6MTI6IgAqAHJlbGF0aW9ucyI7YTowOnt9czoxMDoiACoAdG91Y2hlcyI7YTowOnt9czoyNzoiACoAcmVsYXRpb25BdXRvbG9hZENhbGxiYWNrIjtOO3M6MjY6IgAqAHJlbGF0aW9uQXV0b2xvYWRDb250ZXh0IjtOO3M6MTA6InRpbWVzdGFtcHMiO2I6MTtzOjEzOiJ1c2VzVW5pcXVlSWRzIjtiOjA7czo5OiIAKgBoaWRkZW4iO2E6MDp7fXM6MTA6IgAqAHZpc2libGUiO2E6MDp7fXM6MTE6IgAqAGZpbGxhYmxlIjthOjM6e2k6MDtzOjEyOiJtZW51X21haW5faWQiO2k6MTtzOjY6ImxvY2FsZSI7aToyO3M6NDoiZGF0YSI7fXM6MTA6IgAqAGd1YXJkZWQiO2E6MTp7aTowO3M6MToiKiI7fX1pOjE7TzozMDoiQXBwXE1vZGVsc1xNZW51TWFpblRyYW5zbGF0aW9uIjozMzp7czoxMzoiACoAY29ubmVjdGlvbiI7czo1OiJwZ3NxbCI7czo4OiIAKgB0YWJsZSI7czoyMjoibWVudV9tYWluX3RyYW5zbGF0aW9ucyI7czoxMzoiACoAcHJpbWFyeUtleSI7czoyOiJpZCI7czoxMDoiACoAa2V5VHlwZSI7czozOiJpbnQiO3M6MTI6ImluY3JlbWVudGluZyI7YjoxO3M6NzoiACoAd2l0aCI7YTowOnt9czoxMjoiACoAd2l0aENvdW50IjthOjA6e31zOjE5OiJwcmV2ZW50c0xhenlMb2FkaW5nIjtiOjA7czoxMDoiACoAcGVyUGFnZSI7aToxNTtzOjY6ImV4aXN0cyI7YjoxO3M6MTg6Indhc1JlY2VudGx5Q3JlYXRlZCI7YjowO3M6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDtzOjEzOiIAKgBhdHRyaWJ1dGVzIjthOjY6e3M6MjoiaWQiO2k6NTA7czoxMjoibWVudV9tYWluX2lkIjtpOjI1O3M6NjoibG9jYWxlIjtzOjI6InJ1IjtzOjQ6ImRhdGEiO3M6ODk6InsiaW5mbyI6IG51bGwsICJ0aXRsZSI6ICLQmNC90YTQvtGA0LzQsNGG0LjQvtC90L3Ri9C1INGD0YHQu9GD0LPQuCIsICJkZXNjcmlwdGlvbiI6IG51bGx9IjtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI1LTEyLTIzIDA2OjE4OjI1IjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIxIDE5OjU2OjQ0Ijt9czoxMToiACoAb3JpZ2luYWwiO2E6Njp7czoyOiJpZCI7aTo1MDtzOjEyOiJtZW51X21haW5faWQiO2k6MjU7czo2OiJsb2NhbGUiO3M6MjoicnUiO3M6NDoiZGF0YSI7czo4OToieyJpbmZvIjogbnVsbCwgInRpdGxlIjogItCY0L3RhNC+0YDQvNCw0YbQuNC+0L3QvdGL0LUg0YPRgdC70YPQs9C4IiwgImRlc2NyaXB0aW9uIjogbnVsbH0iO3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjUtMTItMjMgMDY6MTg6MjUiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDEtMjEgMTk6NTY6NDQiO31zOjEwOiIAKgBjaGFuZ2VzIjthOjA6e31zOjExOiIAKgBwcmV2aW91cyI7YTowOnt9czo4OiIAKgBjYXN0cyI7YTowOnt9czoxNzoiACoAY2xhc3NDYXN0Q2FjaGUiO2E6MDp7fXM6MjE6IgAqAGF0dHJpYnV0ZUNhc3RDYWNoZSI7YTowOnt9czoxMzoiACoAZGF0ZUZvcm1hdCI7TjtzOjEwOiIAKgBhcHBlbmRzIjthOjA6e31zOjE5OiIAKgBkaXNwYXRjaGVzRXZlbnRzIjthOjA6e31zOjE0OiIAKgBvYnNlcnZhYmxlcyI7YTowOnt9czoxMjoiACoAcmVsYXRpb25zIjthOjA6e31zOjEwOiIAKgB0b3VjaGVzIjthOjA6e31zOjI3OiIAKgByZWxhdGlvbkF1dG9sb2FkQ2FsbGJhY2siO047czoyNjoiACoAcmVsYXRpb25BdXRvbG9hZENvbnRleHQiO047czoxMDoidGltZXN0YW1wcyI7YjoxO3M6MTM6InVzZXNVbmlxdWVJZHMiO2I6MDtzOjk6IgAqAGhpZGRlbiI7YTowOnt9czoxMDoiACoAdmlzaWJsZSI7YTowOnt9czoxMToiACoAZmlsbGFibGUiO2E6Mzp7aTowO3M6MTI6Im1lbnVfbWFpbl9pZCI7aToxO3M6NjoibG9jYWxlIjtpOjI7czo0OiJkYXRhIjt9czoxMDoiACoAZ3VhcmRlZCI7YToxOntpOjA7czoxOiIqIjt9fWk6MjtPOjMwOiJBcHBcTW9kZWxzXE1lbnVNYWluVHJhbnNsYXRpb24iOjMzOntzOjEzOiIAKgBjb25uZWN0aW9uIjtzOjU6InBnc3FsIjtzOjg6IgAqAHRhYmxlIjtzOjIyOiJtZW51X21haW5fdHJhbnNsYXRpb25zIjtzOjEzOiIAKgBwcmltYXJ5S2V5IjtzOjI6ImlkIjtzOjEwOiIAKgBrZXlUeXBlIjtzOjM6ImludCI7czoxMjoiaW5jcmVtZW50aW5nIjtiOjE7czo3OiIAKgB3aXRoIjthOjA6e31zOjEyOiIAKgB3aXRoQ291bnQiO2E6MDp7fXM6MTk6InByZXZlbnRzTGF6eUxvYWRpbmciO2I6MDtzOjEwOiIAKgBwZXJQYWdlIjtpOjE1O3M6NjoiZXhpc3RzIjtiOjE7czoxODoid2FzUmVjZW50bHlDcmVhdGVkIjtiOjA7czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO3M6MTM6IgAqAGF0dHJpYnV0ZXMiO2E6Njp7czoyOiJpZCI7aToxNDg7czoxMjoibWVudV9tYWluX2lkIjtpOjI1O3M6NjoibG9jYWxlIjtzOjI6ImVuIjtzOjQ6ImRhdGEiO3M6Njg6InsiaW5mbyI6IG51bGwsICJ0aXRsZSI6ICJJbmZvcm1hdGlvbiBzZXJ2aWNlcyIsICJkZXNjcmlwdGlvbiI6IG51bGx9IjtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIxIDE5OjU2OjQ0IjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIxIDE5OjU2OjQ0Ijt9czoxMToiACoAb3JpZ2luYWwiO2E6Njp7czoyOiJpZCI7aToxNDg7czoxMjoibWVudV9tYWluX2lkIjtpOjI1O3M6NjoibG9jYWxlIjtzOjI6ImVuIjtzOjQ6ImRhdGEiO3M6Njg6InsiaW5mbyI6IG51bGwsICJ0aXRsZSI6ICJJbmZvcm1hdGlvbiBzZXJ2aWNlcyIsICJkZXNjcmlwdGlvbiI6IG51bGx9IjtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIxIDE5OjU2OjQ0IjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIxIDE5OjU2OjQ0Ijt9czoxMDoiACoAY2hhbmdlcyI7YTowOnt9czoxMToiACoAcHJldmlvdXMiO2E6MDp7fXM6ODoiACoAY2FzdHMiO2E6MDp7fXM6MTc6IgAqAGNsYXNzQ2FzdENhY2hlIjthOjA6e31zOjIxOiIAKgBhdHRyaWJ1dGVDYXN0Q2FjaGUiO2E6MDp7fXM6MTM6IgAqAGRhdGVGb3JtYXQiO047czoxMDoiACoAYXBwZW5kcyI7YTowOnt9czoxOToiACoAZGlzcGF0Y2hlc0V2ZW50cyI7YTowOnt9czoxNDoiACoAb2JzZXJ2YWJsZXMiO2E6MDp7fXM6MTI6IgAqAHJlbGF0aW9ucyI7YTowOnt9czoxMDoiACoAdG91Y2hlcyI7YTowOnt9czoyNzoiACoAcmVsYXRpb25BdXRvbG9hZENhbGxiYWNrIjtOO3M6MjY6IgAqAHJlbGF0aW9uQXV0b2xvYWRDb250ZXh0IjtOO3M6MTA6InRpbWVzdGFtcHMiO2I6MTtzOjEzOiJ1c2VzVW5pcXVlSWRzIjtiOjA7czo5OiIAKgBoaWRkZW4iO2E6MDp7fXM6MTA6IgAqAHZpc2libGUiO2E6MDp7fXM6MTE6IgAqAGZpbGxhYmxlIjthOjM6e2k6MDtzOjEyOiJtZW51X21haW5faWQiO2k6MTtzOjY6ImxvY2FsZSI7aToyO3M6NDoiZGF0YSI7fXM6MTA6IgAqAGd1YXJkZWQiO2E6MTp7aTowO3M6MToiKiI7fX19czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO319czoxMDoiACoAdG91Y2hlcyI7YTowOnt9czoyNzoiACoAcmVsYXRpb25BdXRvbG9hZENhbGxiYWNrIjtOO3M6MjY6IgAqAHJlbGF0aW9uQXV0b2xvYWRDb250ZXh0IjtOO3M6MTA6InRpbWVzdGFtcHMiO2I6MTtzOjEzOiJ1c2VzVW5pcXVlSWRzIjtiOjA7czo5OiIAKgBoaWRkZW4iO2E6MDp7fXM6MTA6IgAqAHZpc2libGUiO2E6MDp7fXM6MTE6IgAqAGZpbGxhYmxlIjthOjk6e2k6MDtzOjQ6InR5cGUiO2k6MTtzOjQ6InNsdWciO2k6MjtzOjM6InVybCI7aTozO3M6NDoidGVzdCI7aTo0O3M6MTA6InNob3dfYWRtaW4iO2k6NTtzOjEwOiJzb3J0X29yZGVyIjtpOjY7czo0OiJpY29uIjtpOjc7czo2OiJzdGF0dXMiO2k6ODtzOjk6InBhcmVudF9pZCI7fXM6MTA6IgAqAGd1YXJkZWQiO2E6MTp7aTowO3M6MToiKiI7fXM6MTk6IgAqAHRyYW5zbGF0aW9uQ2FjaGUiO047fWk6NTtPOjE5OiJBcHBcTW9kZWxzXE1lbnVNYWluIjozNDp7czoxMzoiACoAY29ubmVjdGlvbiI7czo1OiJwZ3NxbCI7czo4OiIAKgB0YWJsZSI7czoxMDoibWVudV9tYWlucyI7czoxMzoiACoAcHJpbWFyeUtleSI7czoyOiJpZCI7czoxMDoiACoAa2V5VHlwZSI7czozOiJpbnQiO3M6MTI6ImluY3JlbWVudGluZyI7YjoxO3M6NzoiACoAd2l0aCI7YTowOnt9czoxMjoiACoAd2l0aENvdW50IjthOjA6e31zOjE5OiJwcmV2ZW50c0xhenlMb2FkaW5nIjtiOjA7czoxMDoiACoAcGVyUGFnZSI7aToxNTtzOjY6ImV4aXN0cyI7YjoxO3M6MTg6Indhc1JlY2VudGx5Q3JlYXRlZCI7YjowO3M6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDtzOjEzOiIAKgBhdHRyaWJ1dGVzIjthOjEyOntzOjI6ImlkIjtpOjU0O3M6NDoidHlwZSI7czo0OiJwYWdlIjtzOjQ6InNsdWciO3M6OToidGVzdF9tZW51IjtzOjM6InVybCI7TjtzOjQ6InRlc3QiO2I6MDtzOjEwOiJzaG93X2FkbWluIjtiOjE7czoxMDoic29ydF9vcmRlciI7aTo1NDtzOjQ6Imljb24iO047czo2OiJzdGF0dXMiO2I6MTtzOjk6InBhcmVudF9pZCI7TjtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIyIDE1OjQ4OjQ4IjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIyIDE1OjQ4OjQ4Ijt9czoxMToiACoAb3JpZ2luYWwiO2E6MTI6e3M6MjoiaWQiO2k6NTQ7czo0OiJ0eXBlIjtzOjQ6InBhZ2UiO3M6NDoic2x1ZyI7czo5OiJ0ZXN0X21lbnUiO3M6MzoidXJsIjtOO3M6NDoidGVzdCI7YjowO3M6MTA6InNob3dfYWRtaW4iO2I6MTtzOjEwOiJzb3J0X29yZGVyIjtpOjU0O3M6NDoiaWNvbiI7TjtzOjY6InN0YXR1cyI7YjoxO3M6OToicGFyZW50X2lkIjtOO3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjYtMDEtMjIgMTU6NDg6NDgiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDEtMjIgMTU6NDg6NDgiO31zOjEwOiIAKgBjaGFuZ2VzIjthOjA6e31zOjExOiIAKgBwcmV2aW91cyI7YTowOnt9czo4OiIAKgBjYXN0cyI7YTowOnt9czoxNzoiACoAY2xhc3NDYXN0Q2FjaGUiO2E6MDp7fXM6MjE6IgAqAGF0dHJpYnV0ZUNhc3RDYWNoZSI7YTowOnt9czoxMzoiACoAZGF0ZUZvcm1hdCI7TjtzOjEwOiIAKgBhcHBlbmRzIjthOjA6e31zOjE5OiIAKgBkaXNwYXRjaGVzRXZlbnRzIjthOjA6e31zOjE0OiIAKgBvYnNlcnZhYmxlcyI7YTowOnt9czoxMjoiACoAcmVsYXRpb25zIjthOjI6e3M6OToiY2hpbGRyZW5zIjtPOjM5OiJJbGx1bWluYXRlXERhdGFiYXNlXEVsb3F1ZW50XENvbGxlY3Rpb24iOjI6e3M6ODoiACoAaXRlbXMiO2E6MDp7fXM6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDt9czoxMjoidHJhbnNsYXRpb25zIjtPOjM5OiJJbGx1bWluYXRlXERhdGFiYXNlXEVsb3F1ZW50XENvbGxlY3Rpb24iOjI6e3M6ODoiACoAaXRlbXMiO2E6Mzp7aTowO086MzA6IkFwcFxNb2RlbHNcTWVudU1haW5UcmFuc2xhdGlvbiI6MzM6e3M6MTM6IgAqAGNvbm5lY3Rpb24iO3M6NToicGdzcWwiO3M6ODoiACoAdGFibGUiO3M6MjI6Im1lbnVfbWFpbl90cmFuc2xhdGlvbnMiO3M6MTM6IgAqAHByaW1hcnlLZXkiO3M6MjoiaWQiO3M6MTA6IgAqAGtleVR5cGUiO3M6MzoiaW50IjtzOjEyOiJpbmNyZW1lbnRpbmciO2I6MTtzOjc6IgAqAHdpdGgiO2E6MDp7fXM6MTI6IgAqAHdpdGhDb3VudCI7YTowOnt9czoxOToicHJldmVudHNMYXp5TG9hZGluZyI7YjowO3M6MTA6IgAqAHBlclBhZ2UiO2k6MTU7czo2OiJleGlzdHMiO2I6MTtzOjE4OiJ3YXNSZWNlbnRseUNyZWF0ZWQiO2I6MDtzOjI4OiIAKgBlc2NhcGVXaGVuQ2FzdGluZ1RvU3RyaW5nIjtiOjA7czoxMzoiACoAYXR0cmlidXRlcyI7YTo2OntzOjI6ImlkIjtpOjE1MztzOjEyOiJtZW51X21haW5faWQiO2k6NTQ7czo2OiJsb2NhbGUiO3M6MjoidXoiO3M6NDoiZGF0YSI7czo1NzoieyJpbmZvIjogbnVsbCwgInRpdGxlIjogInRlc3RfbWVudSIsICJkZXNjcmlwdGlvbiI6IG51bGx9IjtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIyIDE1OjQ4OjQ4IjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIyIDE1OjQ4OjQ4Ijt9czoxMToiACoAb3JpZ2luYWwiO2E6Njp7czoyOiJpZCI7aToxNTM7czoxMjoibWVudV9tYWluX2lkIjtpOjU0O3M6NjoibG9jYWxlIjtzOjI6InV6IjtzOjQ6ImRhdGEiO3M6NTc6InsiaW5mbyI6IG51bGwsICJ0aXRsZSI6ICJ0ZXN0X21lbnUiLCAiZGVzY3JpcHRpb24iOiBudWxsfSI7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMiAxNTo0ODo0OCI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMiAxNTo0ODo0OCI7fXM6MTA6IgAqAGNoYW5nZXMiO2E6MDp7fXM6MTE6IgAqAHByZXZpb3VzIjthOjA6e31zOjg6IgAqAGNhc3RzIjthOjA6e31zOjE3OiIAKgBjbGFzc0Nhc3RDYWNoZSI7YTowOnt9czoyMToiACoAYXR0cmlidXRlQ2FzdENhY2hlIjthOjA6e31zOjEzOiIAKgBkYXRlRm9ybWF0IjtOO3M6MTA6IgAqAGFwcGVuZHMiO2E6MDp7fXM6MTk6IgAqAGRpc3BhdGNoZXNFdmVudHMiO2E6MDp7fXM6MTQ6IgAqAG9ic2VydmFibGVzIjthOjA6e31zOjEyOiIAKgByZWxhdGlvbnMiO2E6MDp7fXM6MTA6IgAqAHRvdWNoZXMiO2E6MDp7fXM6Mjc6IgAqAHJlbGF0aW9uQXV0b2xvYWRDYWxsYmFjayI7TjtzOjI2OiIAKgByZWxhdGlvbkF1dG9sb2FkQ29udGV4dCI7TjtzOjEwOiJ0aW1lc3RhbXBzIjtiOjE7czoxMzoidXNlc1VuaXF1ZUlkcyI7YjowO3M6OToiACoAaGlkZGVuIjthOjA6e31zOjEwOiIAKgB2aXNpYmxlIjthOjA6e31zOjExOiIAKgBmaWxsYWJsZSI7YTozOntpOjA7czoxMjoibWVudV9tYWluX2lkIjtpOjE7czo2OiJsb2NhbGUiO2k6MjtzOjQ6ImRhdGEiO31zOjEwOiIAKgBndWFyZGVkIjthOjE6e2k6MDtzOjE6IioiO319aToxO086MzA6IkFwcFxNb2RlbHNcTWVudU1haW5UcmFuc2xhdGlvbiI6MzM6e3M6MTM6IgAqAGNvbm5lY3Rpb24iO3M6NToicGdzcWwiO3M6ODoiACoAdGFibGUiO3M6MjI6Im1lbnVfbWFpbl90cmFuc2xhdGlvbnMiO3M6MTM6IgAqAHByaW1hcnlLZXkiO3M6MjoiaWQiO3M6MTA6IgAqAGtleVR5cGUiO3M6MzoiaW50IjtzOjEyOiJpbmNyZW1lbnRpbmciO2I6MTtzOjc6IgAqAHdpdGgiO2E6MDp7fXM6MTI6IgAqAHdpdGhDb3VudCI7YTowOnt9czoxOToicHJldmVudHNMYXp5TG9hZGluZyI7YjowO3M6MTA6IgAqAHBlclBhZ2UiO2k6MTU7czo2OiJleGlzdHMiO2I6MTtzOjE4OiJ3YXNSZWNlbnRseUNyZWF0ZWQiO2I6MDtzOjI4OiIAKgBlc2NhcGVXaGVuQ2FzdGluZ1RvU3RyaW5nIjtiOjA7czoxMzoiACoAYXR0cmlidXRlcyI7YTo2OntzOjI6ImlkIjtpOjE1NDtzOjEyOiJtZW51X21haW5faWQiO2k6NTQ7czo2OiJsb2NhbGUiO3M6MjoicnUiO3M6NDoiZGF0YSI7czo1NzoieyJpbmZvIjogbnVsbCwgInRpdGxlIjogInRlc3RfbWVudSIsICJkZXNjcmlwdGlvbiI6IG51bGx9IjtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIyIDE1OjQ4OjQ4IjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIyIDE1OjQ4OjQ4Ijt9czoxMToiACoAb3JpZ2luYWwiO2E6Njp7czoyOiJpZCI7aToxNTQ7czoxMjoibWVudV9tYWluX2lkIjtpOjU0O3M6NjoibG9jYWxlIjtzOjI6InJ1IjtzOjQ6ImRhdGEiO3M6NTc6InsiaW5mbyI6IG51bGwsICJ0aXRsZSI6ICJ0ZXN0X21lbnUiLCAiZGVzY3JpcHRpb24iOiBudWxsfSI7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMiAxNTo0ODo0OCI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMiAxNTo0ODo0OCI7fXM6MTA6IgAqAGNoYW5nZXMiO2E6MDp7fXM6MTE6IgAqAHByZXZpb3VzIjthOjA6e31zOjg6IgAqAGNhc3RzIjthOjA6e31zOjE3OiIAKgBjbGFzc0Nhc3RDYWNoZSI7YTowOnt9czoyMToiACoAYXR0cmlidXRlQ2FzdENhY2hlIjthOjA6e31zOjEzOiIAKgBkYXRlRm9ybWF0IjtOO3M6MTA6IgAqAGFwcGVuZHMiO2E6MDp7fXM6MTk6IgAqAGRpc3BhdGNoZXNFdmVudHMiO2E6MDp7fXM6MTQ6IgAqAG9ic2VydmFibGVzIjthOjA6e31zOjEyOiIAKgByZWxhdGlvbnMiO2E6MDp7fXM6MTA6IgAqAHRvdWNoZXMiO2E6MDp7fXM6Mjc6IgAqAHJlbGF0aW9uQXV0b2xvYWRDYWxsYmFjayI7TjtzOjI2OiIAKgByZWxhdGlvbkF1dG9sb2FkQ29udGV4dCI7TjtzOjEwOiJ0aW1lc3RhbXBzIjtiOjE7czoxMzoidXNlc1VuaXF1ZUlkcyI7YjowO3M6OToiACoAaGlkZGVuIjthOjA6e31zOjEwOiIAKgB2aXNpYmxlIjthOjA6e31zOjExOiIAKgBmaWxsYWJsZSI7YTozOntpOjA7czoxMjoibWVudV9tYWluX2lkIjtpOjE7czo2OiJsb2NhbGUiO2k6MjtzOjQ6ImRhdGEiO31zOjEwOiIAKgBndWFyZGVkIjthOjE6e2k6MDtzOjE6IioiO319aToyO086MzA6IkFwcFxNb2RlbHNcTWVudU1haW5UcmFuc2xhdGlvbiI6MzM6e3M6MTM6IgAqAGNvbm5lY3Rpb24iO3M6NToicGdzcWwiO3M6ODoiACoAdGFibGUiO3M6MjI6Im1lbnVfbWFpbl90cmFuc2xhdGlvbnMiO3M6MTM6IgAqAHByaW1hcnlLZXkiO3M6MjoiaWQiO3M6MTA6IgAqAGtleVR5cGUiO3M6MzoiaW50IjtzOjEyOiJpbmNyZW1lbnRpbmciO2I6MTtzOjc6IgAqAHdpdGgiO2E6MDp7fXM6MTI6IgAqAHdpdGhDb3VudCI7YTowOnt9czoxOToicHJldmVudHNMYXp5TG9hZGluZyI7YjowO3M6MTA6IgAqAHBlclBhZ2UiO2k6MTU7czo2OiJleGlzdHMiO2I6MTtzOjE4OiJ3YXNSZWNlbnRseUNyZWF0ZWQiO2I6MDtzOjI4OiIAKgBlc2NhcGVXaGVuQ2FzdGluZ1RvU3RyaW5nIjtiOjA7czoxMzoiACoAYXR0cmlidXRlcyI7YTo2OntzOjI6ImlkIjtpOjE1NTtzOjEyOiJtZW51X21haW5faWQiO2k6NTQ7czo2OiJsb2NhbGUiO3M6MjoiZW4iO3M6NDoiZGF0YSI7czo1NzoieyJpbmZvIjogbnVsbCwgInRpdGxlIjogInRlc3RfbWVudSIsICJkZXNjcmlwdGlvbiI6IG51bGx9IjtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIyIDE1OjQ4OjQ4IjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTAxLTIyIDE1OjQ4OjQ4Ijt9czoxMToiACoAb3JpZ2luYWwiO2E6Njp7czoyOiJpZCI7aToxNTU7czoxMjoibWVudV9tYWluX2lkIjtpOjU0O3M6NjoibG9jYWxlIjtzOjI6ImVuIjtzOjQ6ImRhdGEiO3M6NTc6InsiaW5mbyI6IG51bGwsICJ0aXRsZSI6ICJ0ZXN0X21lbnUiLCAiZGVzY3JpcHRpb24iOiBudWxsfSI7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMiAxNTo0ODo0OCI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wMS0yMiAxNTo0ODo0OCI7fXM6MTA6IgAqAGNoYW5nZXMiO2E6MDp7fXM6MTE6IgAqAHByZXZpb3VzIjthOjA6e31zOjg6IgAqAGNhc3RzIjthOjA6e31zOjE3OiIAKgBjbGFzc0Nhc3RDYWNoZSI7YTowOnt9czoyMToiACoAYXR0cmlidXRlQ2FzdENhY2hlIjthOjA6e31zOjEzOiIAKgBkYXRlRm9ybWF0IjtOO3M6MTA6IgAqAGFwcGVuZHMiO2E6MDp7fXM6MTk6IgAqAGRpc3BhdGNoZXNFdmVudHMiO2E6MDp7fXM6MTQ6IgAqAG9ic2VydmFibGVzIjthOjA6e31zOjEyOiIAKgByZWxhdGlvbnMiO2E6MDp7fXM6MTA6IgAqAHRvdWNoZXMiO2E6MDp7fXM6Mjc6IgAqAHJlbGF0aW9uQXV0b2xvYWRDYWxsYmFjayI7TjtzOjI2OiIAKgByZWxhdGlvbkF1dG9sb2FkQ29udGV4dCI7TjtzOjEwOiJ0aW1lc3RhbXBzIjtiOjE7czoxMzoidXNlc1VuaXF1ZUlkcyI7YjowO3M6OToiACoAaGlkZGVuIjthOjA6e31zOjEwOiIAKgB2aXNpYmxlIjthOjA6e31zOjExOiIAKgBmaWxsYWJsZSI7YTozOntpOjA7czoxMjoibWVudV9tYWluX2lkIjtpOjE7czo2OiJsb2NhbGUiO2k6MjtzOjQ6ImRhdGEiO31zOjEwOiIAKgBndWFyZGVkIjthOjE6e2k6MDtzOjE6IioiO319fXM6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDt9fXM6MTA6IgAqAHRvdWNoZXMiO2E6MDp7fXM6Mjc6IgAqAHJlbGF0aW9uQXV0b2xvYWRDYWxsYmFjayI7TjtzOjI2OiIAKgByZWxhdGlvbkF1dG9sb2FkQ29udGV4dCI7TjtzOjEwOiJ0aW1lc3RhbXBzIjtiOjE7czoxMzoidXNlc1VuaXF1ZUlkcyI7YjowO3M6OToiACoAaGlkZGVuIjthOjA6e31zOjEwOiIAKgB2aXNpYmxlIjthOjA6e31zOjExOiIAKgBmaWxsYWJsZSI7YTo5OntpOjA7czo0OiJ0eXBlIjtpOjE7czo0OiJzbHVnIjtpOjI7czozOiJ1cmwiO2k6MztzOjQ6InRlc3QiO2k6NDtzOjEwOiJzaG93X2FkbWluIjtpOjU7czoxMDoic29ydF9vcmRlciI7aTo2O3M6NDoiaWNvbiI7aTo3O3M6Njoic3RhdHVzIjtpOjg7czo5OiJwYXJlbnRfaWQiO31zOjEwOiIAKgBndWFyZGVkIjthOjE6e2k6MDtzOjE6IioiO31zOjE5OiIAKgB0cmFuc2xhdGlvbkNhY2hlIjtOO319czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO30=	1769097664
laravel-cache-static_value:more:url:uz	s:5:"about";	1769100964
laravel-cache-static_value:more:title:uz	s:8:"Batafsil";	1769100964
laravel-cache-static_value:news:title:uz	s:11:"Yangiliklar";	1769100964
laravel-cache-static_value:all:title:uz	s:8:"Barchasi";	1769100964
laravel-cache-static_value:projects:title:uz	s:13:"Loyihalarimiz";	1769100964
laravel-cache-static_value:newspapers:title:uz	s:9:"Gazetalar";	1769100964
laravel-cache-static_value:statisctic:title:uz	s:10:"Statistika";	1769100964
laravel-cache-static_value:volunteers:title:uz	s:16:"Volontyorlarimiz";	1769100964
laravel-cache-static_value:knowledge:title:uz	s:20:"Ilmni rivojlantirish";	1769100964
laravel-cache-static_value:download :title:uz	N;	1769100964
laravel-cache-static_value:keyboard:title:uz	s:20:"Platformaga o’tish";	1769100964
laravel-cache-static_value:podcasts:title:uz	s:26:"Podkastlarimizga havolalar";	1769100964
laravel-cache-static_value:mutoola:title:uz	s:38:"- eng sara audio va elektron kitoblar!";	1769100964
laravel-cache-static_value:download:title:uz	s:65:"O‘zbek tilidagi eng katta mobil kutubxonani hozir yuklab oling!";	1769100964
laravel-cache-static_value:site:title:uz	s:21:"Mutolaa saytiga otish";	1769100964
laravel-cache-static_value:platform:title:uz	s:38:"Elektron murojaat yuborish platformasi";	1769100964
laravel-cache-static_value:join-us:title:uz	s:76:"Biz barcha sizni qiynayotga muammoga yo’l topaolamiz. Bizga murojat qiling";	1769100964
laravel-cache-static_value:button1:title:uz	s:17:"Murojaat yuborish";	1769100964
laravel-cache-static_value:video_l:url:uz	s:61:"https://www.youtube.com/embed/BHACKCNDMW8?si=AtPPS9WpLIT3_TaW";	1769100964
laravel-cache-static_value:video_l:title:uz	s:17:"Video qo’llanma";	1769100964
laravel-cache-static_value:vatandosh:title:uz	s:29:"Vatandoshlar safida bo‘ling";	1769100964
laravel-cache-static_value:vatandosh1:title:uz	s:69:"“Vatandoshlar” jamoat fondiga a’zo bo‘lish uchun ariza bering";	1769100964
laravel-cache-setting_global_image_main	s:87:"http://vatandoshlar.7z7.uz/storage/settings/a0e3313c-3d27-490e-91bf-6e109a4f36c4157.png";	1769097664
laravel-cache-setting_global_image_secondary	s:87:"http://vatandoshlar.7z7.uz/storage/settings/a0e178d2-8396-456a-b547-a15e69f4ca64127.jpg";	1769097664
laravel-cache-static_value:vatandoshlar:title:uz	s:18:"“Vatandoshlar”";	1769100964
laravel-cache-static_value:vatandoshlar:content:uz	s:12:"Jamoat Fondi";	1769100964
laravel-cache-static_value:search:title:uz	s:28:"Qidiruv so'zingizni kiriting";	1769100964
laravel-cache-static_value:menu:title:uz	s:5:"Menyu";	1769100964
laravel-cache-static_value:agency:title:uz	s:108:"O'zbekiston Respublikasi Prezidenti Administratsiyasi huzuridagi ta'lim sifatini ta'minlash milliy agentligi";	1769100964
laravel-cache-static_value:phonenumber:description:uz	s:18:"+998(55) 502-22-66";	1769100964
laravel-cache-static_value:phonenumber:title:uz	s:13:"Telefon raqam";	1769100964
laravel-cache-static_value:email:description:uz	s:16:"info@example.com";	1769100964
laravel-cache-static_value:email:title:uz	s:15:"Elektron pochta";	1769100964
laravel-cache-static_value:adress_info:content:uz	s:63:"100100, Toshkent sh., Yakkasaroy tumani, Bobur ko'chasi, 30-uy.";	1769100964
laravel-cache-static_value:adress_info:title:uz	s:6:"Manzil";	1769100964
laravel-cache-static_value:safe:title:uz	s:57:"©2025 VATANDOSHLAR FONDI. Barcha huquqlari himoyalangan.";	1769100964
laravel-cache-static_value:develop:title:uz	s:16:"Ishlab chiquvchi";	1769100964
\.


--
-- Data for Name: cache_locks; Type: TABLE DATA; Schema: public; Owner: vatandoshlar_usr
--

COPY public.cache_locks (key, owner, expiration) FROM stdin;
\.


--
-- Data for Name: content_images; Type: TABLE DATA; Schema: public; Owner: vatandoshlar_usr
--

COPY public.content_images (id, content_id, image, compressed, type, size, main, status, created_at, updated_at, category, sort_order) FROM stdin;
6	35	contents/1768287498_Vector (5).png	\N	image/png	2413	f	t	2026-01-13 06:58:19	2026-01-13 06:58:19	\N	\N
7	35	contents/1768287499_Frame 1321315991 (16).png	\N	image/png	1642	f	t	2026-01-13 06:58:19	2026-01-13 06:58:19	\N	\N
8	35	contents/1768287596_Vector (5).png	\N	image/png	2413	f	t	2026-01-13 06:59:56	2026-01-13 06:59:56	\N	\N
9	35	contents/1768287841_Vector (5).png	\N	image/png	2413	f	t	2026-01-13 07:04:01	2026-01-13 07:04:01	\N	\N
10	35	contents/1768287863_Frame 1321315991 (16).png	\N	image/png	1642	f	t	2026-01-13 07:04:23	2026-01-13 07:04:23	\N	\N
\.


--
-- Data for Name: content_settings; Type: TABLE DATA; Schema: public; Owner: vatandoshlar_usr
--

COPY public.content_settings (id, key, label, type, required, is_translatable, options, sort_order, relation, status, created_at, updated_at, category) FROM stdin;
1	title	Title	text	t	t	\N	1	\N	t	\N	2026-01-08 12:17:12	list
2	key	Key	text	t	f	\N	1	\N	t	\N	2026-01-08 12:17:12	list
3	url	Url	text	t	f	\N	1	\N	t	2026-01-20 13:22:31	2026-01-20 13:22:39	\N
4	description	description	text	t	f	\N	1	\N	t	2026-01-21 13:10:14	2026-01-21 13:10:53	\N
5	content	content	text	t	t	\N	1	\N	t	2026-01-21 13:23:52	2026-01-21 13:23:52	\N
6	short_description	Short description	text	t	t	\N	1	\N	t	2026-01-22 11:06:18	2026-01-22 11:06:18	\N
\.


--
-- Data for Name: content_translations; Type: TABLE DATA; Schema: public; Owner: vatandoshlar_usr
--

COPY public.content_translations (id, content_id, locale, data, created_at, updated_at, category) FROM stdin;
25	7	uz	{"title": "Loyihalarimiz"}	2026-01-05 06:08:08	2026-01-08 12:17:27	list
26	7	ru	{"title": "Наши проекты"}	2026-01-05 06:08:08	2026-01-08 12:17:27	list
27	7	en	{"title": "Projects"}	2026-01-05 06:08:08	2026-01-08 12:17:27	list
28	7	\N	{"key": "projects"}	2026-01-05 06:08:08	2026-01-08 12:17:27	list
29	8	uz	{"title": "Gazetalar"}	2026-01-05 06:08:54	2026-01-08 12:17:27	list
30	8	ru	{"title": "Газеты"}	2026-01-05 06:08:54	2026-01-08 12:17:27	list
31	8	en	{"title": "Newspapers"}	2026-01-05 06:08:54	2026-01-08 12:17:27	list
32	8	\N	{"key": "newspapers"}	2026-01-05 06:08:54	2026-01-08 12:17:27	list
33	9	uz	{"title": "Volontyorlarimiz"}	2026-01-05 06:09:45	2026-01-08 12:17:27	list
34	9	ru	{"title": "Наши волонтеры"}	2026-01-05 06:09:45	2026-01-08 12:17:27	list
35	9	en	{"title": "Our volunteers"}	2026-01-05 06:09:45	2026-01-08 12:17:27	list
36	9	\N	{"key": "volunteers"}	2026-01-05 06:09:45	2026-01-08 12:17:27	list
41	11	uz	{"title": "Podkastlarimizga havolalar"}	2026-01-05 06:11:20	2026-01-08 12:17:27	list
42	11	ru	{"title": "Ссылки на наши подкасты"}	2026-01-05 06:11:20	2026-01-08 12:17:27	list
43	11	en	{"title": "Links to our podcasts"}	2026-01-05 06:11:20	2026-01-08 12:17:27	list
44	11	\N	{"key": "podcasts"}	2026-01-05 06:11:20	2026-01-08 12:17:27	list
45	12	uz	{"title": "- eng sara audio va elektron kitoblar!"}	2026-01-05 06:12:41	2026-01-08 12:17:27	list
46	12	ru	{"title": "— Лучшие аудиокниги и электронные книги!"}	2026-01-05 06:12:41	2026-01-08 12:17:27	list
47	12	en	{"title": "— The best audiobooks and e-books!"}	2026-01-05 06:12:41	2026-01-08 12:17:27	list
48	12	\N	{"key": "mutoola"}	2026-01-05 06:12:41	2026-01-08 12:17:27	list
49	13	uz	{"title": "O‘zbek tilidagi eng katta mobil kutubxonani hozir yuklab oling!"}	2026-01-05 06:13:52	2026-01-08 12:17:27	list
50	13	ru	{"title": "Скачайте крупнейшую мобильную библиотеку на узбекском языке прямо сейчас!"}	2026-01-05 06:13:52	2026-01-08 12:17:27	list
51	13	en	{"title": "Download the largest mobile library in the Uzbek language now!"}	2026-01-05 06:13:52	2026-01-08 12:17:27	list
52	13	\N	{"key": "download"}	2026-01-05 06:13:52	2026-01-08 12:17:27	list
53	14	uz	{"title": "Mutolaa saytiga otish"}	2026-01-05 06:15:07	2026-01-08 12:17:27	list
54	14	ru	{"title": "Перейдите на сайт для чтения"}	2026-01-05 06:15:07	2026-01-08 12:17:27	list
55	14	en	{"title": "Go to the reading site"}	2026-01-05 06:15:07	2026-01-08 12:17:27	list
56	14	\N	{"key": "site"}	2026-01-05 06:15:07	2026-01-08 12:17:27	list
167	42	en	{"title": "Working hours:"}	2026-01-13 09:01:18	2026-01-13 09:01:18	\N
168	42	\N	{"key": "work-time"}	2026-01-13 09:01:18	2026-01-13 09:01:18	\N
61	16	uz	{"title": "Biz barcha sizni qiynayotga muammoga yo’l topaolamiz. Bizga murojat qiling"}	2026-01-05 06:17:30	2026-01-08 12:17:27	list
17	5	uz	{"title": "O'zbekiston Respublikasi Prezidenti Administratsiyasi huzuridagi ta'lim sifatini ta'minlash milliy agentligi"}	2025-12-29 11:37:26	2026-01-20 17:18:08	list
18	5	ru	{"title": "Национальное агентство по обеспечению качества образования при Администрации Президента Республики Узбекистан"}	2025-12-29 11:37:26	2026-01-20 17:18:08	list
19	5	en	{"title": "National Agency for Quality Assurance in Education under the Administration of the President of the Republic of Uzbekistan"}	2025-12-29 11:37:26	2026-01-20 17:18:08	list
20	5	\N	{"key": "agency", "url": null}	2025-12-29 11:37:26	2026-01-20 17:18:08	list
21	6	uz	{"title": "Forum va seminarlardan video"}	2025-12-29 13:28:11	2026-01-20 17:18:22	list
22	6	ru	{"title": null}	2025-12-29 13:28:11	2026-01-20 17:18:22	list
23	6	en	{"title": null}	2025-12-29 13:28:11	2026-01-20 17:18:22	list
24	6	\N	{"key": "forum", "url": null}	2025-12-29 13:28:11	2026-01-20 17:18:22	list
3	1	en	{"title": "News", "content": null}	2025-12-29 11:28:37	2026-01-22 06:48:12	list
5	2	uz	{"title": "Telefon raqam", "content": null}	2025-12-29 11:34:12	2026-01-21 13:29:30	list
9	3	uz	{"title": "Elektron pochta"}	2025-12-29 11:34:55	2026-01-21 13:15:13	list
8	2	\N	{"key": "phone", "url": null, "description": "+998 71 234 56 55"}	2025-12-29 11:34:12	2026-01-21 13:29:30	list
10	3	ru	{"title": "Электрон почта"}	2025-12-29 11:34:55	2026-01-21 13:15:13	list
11	3	en	{"title": "Email"}	2025-12-29 11:34:55	2026-01-21 13:15:13	list
12	3	\N	{"key": "email", "url": null, "description": "info@example.com"}	2025-12-29 11:34:55	2026-01-21 13:15:13	list
14	4	ru	{"title": "Адрес", "content": "Узбекистан, город Ташкент, Яккасарайский район, улица Бабура, 45"}	2025-12-29 11:36:08	2026-01-21 13:24:41	list
15	4	en	{"title": "Address", "content": "Uzbekistan, Tashkent city, Yakkasaroy district, Babur street, 45"}	2025-12-29 11:36:08	2026-01-21 13:24:41	list
16	4	\N	{"key": "address", "url": null, "description": null}	2025-12-29 11:36:08	2026-01-21 13:24:41	list
6	2	ru	{"title": "Номер телефона", "content": null}	2025-12-29 11:34:12	2026-01-21 13:29:30	list
170	43	ru	{"title": "Понедельник-пятница:"}	2026-01-13 09:02:14	2026-01-21 13:21:14	\N
13	4	uz	{"title": "Manzil", "content": "O'zbekiston, Toshkent shahri, Yakkasaroy tumani, Bobur ko'chasi, 45-uy"}	2025-12-29 11:36:08	2026-01-21 13:24:41	list
7	2	en	{"title": "Phone number", "content": null}	2025-12-29 11:34:12	2026-01-21 13:29:30	list
4	1	\N	{"key": "news", "url": null, "description": null}	2025-12-29 11:28:37	2026-01-22 06:48:12	list
62	16	ru	{"title": "Мы можем помочь вам с любой проблемой. Свяжитесь с нами."}	2026-01-05 06:17:30	2026-01-08 12:17:27	list
63	16	en	{"title": "We can help you with any problem. Contact us."}	2026-01-05 06:17:30	2026-01-08 12:17:27	list
64	16	\N	{"key": "callus"}	2026-01-05 06:17:30	2026-01-08 12:17:27	list
69	18	uz	{"title": "Video qo'llanma"}	2026-01-05 06:19:15	2026-01-08 12:17:27	list
70	18	ru	{"title": "Видеоинструкция"}	2026-01-05 06:19:15	2026-01-08 12:17:27	list
71	18	en	{"title": "Video instructions"}	2026-01-05 06:19:15	2026-01-08 12:17:27	list
72	18	\N	{"key": "button2"}	2026-01-05 06:19:15	2026-01-08 12:17:27	list
73	19	uz	{"title": "Vatandoshlar safida bo‘ling"}	2026-01-05 06:20:38	2026-01-08 12:17:27	list
74	19	ru	{"title": "Будьте среди своих соотечественников."}	2026-01-05 06:20:38	2026-01-08 12:17:27	list
75	19	en	{"title": "Be among your compatriots"}	2026-01-05 06:20:38	2026-01-08 12:17:27	list
76	19	\N	{"key": "vatandosh"}	2026-01-05 06:20:38	2026-01-08 12:17:27	list
77	20	uz	{"title": "“Vatandoshlar” jamoat fondiga a’zo bo‘lish uchun ariza bering"}	2026-01-05 06:21:27	2026-01-08 12:17:27	list
78	20	ru	{"title": "Подайте заявку на членство в общественном фонде «Ватандошлар»."}	2026-01-05 06:21:27	2026-01-08 12:17:27	list
79	20	en	{"title": "Apply to join the \\"Vatandoshlar\\" Public Foundation"}	2026-01-05 06:21:27	2026-01-08 12:17:27	list
80	20	\N	{"key": "vatandosh1"}	2026-01-05 06:21:27	2026-01-08 12:17:27	list
81	21	uz	{"title": "Siz yuklab olish yoki havola orqali o’tishingiz mumkin"}	2026-01-05 06:43:23	2026-01-08 12:17:27	list
82	21	ru	{"title": "Вы можете скачать файл или перейти по ссылке."}	2026-01-05 06:43:23	2026-01-08 12:17:27	list
83	21	en	{"title": "You can download the yoki files by following the link."}	2026-01-05 06:43:23	2026-01-08 12:17:27	list
84	21	\N	{"key": "the link"}	2026-01-05 06:43:23	2026-01-08 12:17:27	list
85	22	uz	{"title": "O’zbek tilini o’rganish platformasiga marxamat"}	2026-01-05 06:54:59	2026-01-08 12:17:27	list
86	22	ru	{"title": "Добро пожаловать на платформу для изучения узбекского языка!"}	2026-01-05 06:54:59	2026-01-08 12:17:27	list
87	22	en	{"title": "Welcome to the Uzbek language learning platform!"}	2026-01-05 06:54:59	2026-01-08 12:17:27	list
88	22	\N	{"key": "uzbek"}	2026-01-05 06:54:59	2026-01-08 12:17:27	list
89	23	uz	{"title": "Platformaga o’tish"}	2026-01-05 06:57:49	2026-01-08 12:17:27	list
90	23	ru	{"title": "Перейдите на платформу"}	2026-01-05 06:57:49	2026-01-08 12:17:27	list
91	23	en	{"title": "Go to the platform"}	2026-01-05 06:57:49	2026-01-08 12:17:27	list
92	23	\N	{"key": "keyboard"}	2026-01-05 06:57:49	2026-01-08 12:17:27	list
93	24	uz	{"title": "Barchasi"}	2026-01-05 06:58:49	2026-01-08 12:17:27	list
94	24	ru	{"title": "Все"}	2026-01-05 06:58:49	2026-01-08 12:17:27	list
95	24	en	{"title": "All"}	2026-01-05 06:58:49	2026-01-08 12:17:27	list
96	24	\N	{"key": "all"}	2026-01-05 06:58:49	2026-01-08 12:17:27	list
137	35	uz	{"title": "newtext"}	2026-01-13 06:58:18	2026-01-13 06:58:18	\N
138	35	ru	{"title": null}	2026-01-13 06:58:18	2026-01-13 06:58:18	\N
139	35	en	{"title": null}	2026-01-13 06:58:18	2026-01-13 06:58:18	\N
140	35	\N	{"key": "newtext"}	2026-01-13 06:58:18	2026-01-13 06:58:18	\N
153	39	uz	{"title": "Telefon raqamingiz:"}	2026-01-13 08:55:47	2026-01-13 08:55:47	\N
154	39	ru	{"title": "Ваш номер телефона:"}	2026-01-13 08:55:47	2026-01-13 08:55:47	\N
155	39	en	{"title": "Your phone number:"}	2026-01-13 08:55:47	2026-01-13 08:55:47	\N
156	39	\N	{"key": "number"}	2026-01-13 08:55:47	2026-01-13 08:55:47	\N
157	40	uz	{"title": "Xabar matni:"}	2026-01-13 08:58:06	2026-01-13 08:58:06	\N
158	40	ru	{"title": "Текст сообщения:"}	2026-01-13 08:58:06	2026-01-13 08:58:06	\N
159	40	en	{"title": "Message text:"}	2026-01-13 08:58:06	2026-01-13 08:58:06	\N
160	40	\N	{"key": "message"}	2026-01-13 08:58:06	2026-01-13 08:58:06	\N
145	37	uz	{"title": "Biz bilan bog'lanish uchun ariza shakli"}	2026-01-13 08:52:06	2026-01-13 08:52:06	\N
146	37	ru	{"title": "Форма заявки для связи с нами"}	2026-01-13 08:52:06	2026-01-13 08:52:06	\N
147	37	en	{"title": "Application form to contact us"}	2026-01-13 08:52:06	2026-01-13 08:52:06	\N
148	37	\N	{"key": "contactmessage"}	2026-01-13 08:52:06	2026-01-13 08:52:06	\N
149	38	uz	{"title": "To'liq ismingiz:"}	2026-01-13 08:55:00	2026-01-13 08:55:00	\N
150	38	ru	{"title": "Ваше полное имя:"}	2026-01-13 08:55:00	2026-01-13 08:55:00	\N
151	38	en	{"title": "Your full name:"}	2026-01-13 08:55:00	2026-01-13 08:55:00	\N
152	38	\N	{"key": "fullname"}	2026-01-13 08:55:00	2026-01-13 08:55:00	\N
161	41	uz	{"title": "Yuborish"}	2026-01-13 08:58:55	2026-01-13 08:58:55	\N
162	41	ru	{"title": "Отправлять"}	2026-01-13 08:58:55	2026-01-13 08:58:55	\N
163	41	en	{"title": "Send"}	2026-01-13 08:58:55	2026-01-13 08:58:55	\N
164	41	\N	{"key": "request"}	2026-01-13 08:58:55	2026-01-13 08:58:55	\N
165	42	uz	{"title": "Ish vaqti:"}	2026-01-13 09:01:18	2026-01-13 09:01:18	\N
166	42	ru	{"title": "Рабочее время:"}	2026-01-13 09:01:18	2026-01-13 09:01:18	\N
68	17	\N	{"key": "button1"}	2026-01-05 06:18:28	2026-01-20 13:19:48	list
1	1	uz	{"title": "Yangiliklar", "content": "s"}	2025-12-29 11:28:37	2026-01-22 06:48:12	list
65	17	uz	{"title": "Murojaat yuborish"}	2026-01-05 06:18:28	2026-01-20 13:19:48	list
67	17	en	{"title": "Send a request"}	2026-01-05 06:18:28	2026-01-20 13:19:48	list
2	1	ru	{"title": "Новости", "content": null}	2025-12-29 11:28:37	2026-01-22 06:48:12	list
177	45	uz	{"title": "Ma'lumot"}	2026-01-13 09:09:32	2026-01-13 09:09:32	\N
178	45	ru	{"title": "Информация"}	2026-01-13 09:09:32	2026-01-13 09:09:32	\N
179	45	en	{"title": "Information"}	2026-01-13 09:09:32	2026-01-13 09:09:32	\N
180	45	\N	{"key": "info"}	2026-01-13 09:09:32	2026-01-13 09:09:32	\N
181	46	uz	{"title": "Rahmat!"}	2026-01-13 09:11:01	2026-01-13 09:11:01	\N
182	46	ru	{"title": "Спасибо!"}	2026-01-13 09:11:01	2026-01-13 09:11:01	\N
183	46	en	{"title": "Thank you!"}	2026-01-13 09:11:01	2026-01-13 09:11:01	\N
184	46	\N	{"key": "thanks"}	2026-01-13 09:11:01	2026-01-13 09:11:01	\N
185	47	uz	{"title": "Kontakt ma'lumotlari"}	2026-01-13 09:14:35	2026-01-13 09:14:35	\N
186	47	ru	{"title": "Контактная информация"}	2026-01-13 09:14:35	2026-01-13 09:14:35	\N
187	47	en	{"title": "Contact information"}	2026-01-13 09:14:35	2026-01-13 09:14:35	\N
188	47	\N	{"key": "contacts"}	2026-01-13 09:14:35	2026-01-13 09:14:35	\N
189	48	uz	{"title": "Iltimos F.I.SH.ni to'liq kiriting:"}	2026-01-13 09:21:50	2026-01-13 09:21:50	\N
190	48	ru	{"title": "Пожалуйста, введите ваш полный номер F.I.S.:"}	2026-01-13 09:21:50	2026-01-13 09:21:50	\N
191	48	en	{"title": "Please enter your full F.I.S. number:"}	2026-01-13 09:21:50	2026-01-13 09:21:50	\N
192	48	\N	{"key": "pleasure"}	2026-01-13 09:21:50	2026-01-13 09:21:50	\N
193	49	uz	{"title": "Tug'ilgan sana:"}	2026-01-13 09:22:27	2026-01-13 09:22:27	\N
194	49	ru	{"title": "Дата рождения:"}	2026-01-13 09:22:27	2026-01-13 09:22:27	\N
195	49	en	{"title": "Date of birth:"}	2026-01-13 09:22:27	2026-01-13 09:22:27	\N
196	49	\N	{"key": "birthdate"}	2026-01-13 09:22:27	2026-01-13 09:22:27	\N
197	50	uz	{"title": "Mutaxassisligi:"}	2026-01-13 09:23:17	2026-01-13 09:23:17	\N
198	50	ru	{"title": "Специализация:"}	2026-01-13 09:23:17	2026-01-13 09:23:17	\N
199	50	en	{"title": "Specialization:"}	2026-01-13 09:23:17	2026-01-13 09:23:17	\N
200	50	\N	{"key": "Specialization:"}	2026-01-13 09:23:17	2026-01-13 09:23:17	\N
201	51	uz	{"title": "Mutaxassislikni tanlang"}	2026-01-13 09:24:02	2026-01-13 09:24:02	\N
202	51	ru	{"title": "Выберите специализацию"}	2026-01-13 09:24:02	2026-01-13 09:24:02	\N
203	51	en	{"title": "Select a specialization"}	2026-01-13 09:24:02	2026-01-13 09:24:02	\N
204	51	\N	{"key": "select_spec"}	2026-01-13 09:24:02	2026-01-13 09:24:02	\N
205	52	uz	{"title": "Yashash manzili:"}	2026-01-13 09:25:09	2026-01-13 09:25:09	\N
206	52	ru	{"title": "Адрес проживания:"}	2026-01-13 09:25:09	2026-01-13 09:25:09	\N
207	52	en	{"title": "Residential address:"}	2026-01-13 09:25:09	2026-01-13 09:25:09	\N
208	52	\N	{"key": "turar-joy"}	2026-01-13 09:25:09	2026-01-13 09:25:09	\N
209	53	uz	{"title": "Email, telefon yoki boshqa bog‘lanish ma’lumoti:"}	2026-01-13 09:25:54	2026-01-13 09:25:54	\N
210	53	ru	{"title": "Адрес электронной почты, номер телефона или другая контактная информация:"}	2026-01-13 09:25:54	2026-01-13 09:25:54	\N
211	53	en	{"title": "Email address, phone number or other contact information:"}	2026-01-13 09:25:54	2026-01-13 09:25:54	\N
212	53	\N	{"key": "add-info"}	2026-01-13 09:25:54	2026-01-13 09:25:54	\N
213	54	uz	{"title": "Takliflar:"}	2026-01-13 09:26:45	2026-01-13 09:26:45	\N
214	54	ru	{"title": "Предложения:"}	2026-01-13 09:26:45	2026-01-13 09:26:45	\N
215	54	en	{"title": "Offers:"}	2026-01-13 09:26:45	2026-01-13 09:26:45	\N
216	54	\N	{"key": "taklif"}	2026-01-13 09:26:45	2026-01-13 09:26:45	\N
217	55	uz	{"title": "Ma'lumot kiriting"}	2026-01-13 09:37:19	2026-01-13 09:37:19	\N
218	55	ru	{"title": "Введите информацию"}	2026-01-13 09:37:19	2026-01-13 09:37:19	\N
219	55	en	{"title": "Enter the information"}	2026-01-13 09:37:19	2026-01-13 09:37:19	\N
220	55	\N	{"key": "info-add"}	2026-01-13 09:37:19	2026-01-13 09:37:19	\N
221	56	uz	{"title": "Manzilni kiriting"}	2026-01-13 09:40:34	2026-01-13 09:40:34	\N
222	56	ru	{"title": "Введите адрес"}	2026-01-13 09:40:34	2026-01-13 09:40:34	\N
223	56	en	{"title": "Enter the address"}	2026-01-13 09:40:34	2026-01-13 09:40:34	\N
224	56	\N	{"key": "the_address"}	2026-01-13 09:40:34	2026-01-13 09:40:34	\N
225	57	uz	{"title": "Bog‘lanish ma’lumoti"}	2026-01-13 09:43:04	2026-01-13 09:43:04	\N
226	57	ru	{"title": "Контактная информация"}	2026-01-13 09:43:04	2026-01-13 09:43:04	\N
227	57	en	{"title": "Contact information"}	2026-01-13 09:43:04	2026-01-13 09:43:04	\N
228	57	\N	{"key": "contact-info"}	2026-01-13 09:43:04	2026-01-13 09:43:04	\N
229	58	uz	{"title": "Yopish"}	2026-01-13 09:45:06	2026-01-13 09:45:06	\N
230	58	ru	{"title": "Закрывать"}	2026-01-13 09:45:06	2026-01-13 09:45:06	\N
231	58	en	{"title": "Close"}	2026-01-13 09:45:06	2026-01-13 09:45:06	\N
232	58	\N	{"key": "close"}	2026-01-13 09:45:06	2026-01-13 09:45:06	\N
245	62	uz	{"title": "Statistika"}	2026-01-13 09:55:53	2026-01-13 09:55:53	\N
234	59	ru	{"title": "Видеоурок"}	2026-01-13 09:50:35	2026-01-20 13:23:02	\N
235	59	en	{"title": "Video tutorial"}	2026-01-13 09:50:35	2026-01-20 13:23:02	\N
169	43	uz	{"title": "Dushanba-Juma:"}	2026-01-13 09:02:14	2026-01-21 13:21:14	\N
171	43	en	{"title": "Monday-Friday:"}	2026-01-13 09:02:14	2026-01-21 13:21:14	\N
172	43	\N	{"key": "work-days", "url": null, "description": "09:00 – 18:00"}	2026-01-13 09:02:14	2026-01-21 13:21:14	\N
237	60	uz	{"title": "Elektron murojaat yuborish platformasi", "content": "Biz barcha sizni qiynayotga muammoga yo’l topaolamiz. Bizga murojat qiling", "short_description": null}	2026-01-13 09:53:20	2026-01-23 13:22:10	\N
238	60	ru	{"title": "Электронная платформа для подачи заявок", "content": null, "short_description": null}	2026-01-13 09:53:20	2026-01-23 13:22:10	\N
239	60	en	{"title": "Electronic platform for submitting applications", "content": null, "short_description": null}	2026-01-13 09:53:20	2026-01-23 13:22:10	\N
240	60	\N	{"key": "platform", "url": null, "description": null}	2026-01-13 09:53:20	2026-01-23 13:22:10	\N
246	62	ru	{"title": "Статистика"}	2026-01-13 09:55:53	2026-01-13 09:55:53	\N
247	62	en	{"title": "Statistics"}	2026-01-13 09:55:53	2026-01-13 09:55:53	\N
248	62	\N	{"key": "statisctic"}	2026-01-13 09:55:53	2026-01-13 09:55:53	\N
249	63	uz	{"title": "Ishtirok etish uchun ariza yuborish"}	2026-01-13 10:02:23	2026-01-13 10:02:23	\N
250	63	ru	{"title": "Подайте заявку на участие."}	2026-01-13 10:02:23	2026-01-13 10:02:23	\N
251	63	en	{"title": "Submit an application to participate."}	2026-01-13 10:02:23	2026-01-13 10:02:23	\N
252	63	\N	{"key": "Participation"}	2026-01-13 10:02:23	2026-01-13 10:02:23	\N
253	64	uz	{"title": "Jinsi:"}	2026-01-13 10:03:22	2026-01-13 10:03:22	\N
254	64	ru	{"title": "Пол:"}	2026-01-13 10:03:22	2026-01-13 10:03:22	\N
255	64	en	{"title": "Gender:"}	2026-01-13 10:03:22	2026-01-13 10:03:22	\N
256	64	\N	{"key": "gender"}	2026-01-13 10:03:22	2026-01-13 10:03:22	\N
257	65	uz	{"title": "Tanlang"}	2026-01-13 10:04:30	2026-01-13 10:04:30	\N
258	65	ru	{"title": "Выбирать"}	2026-01-13 10:04:30	2026-01-13 10:04:30	\N
259	65	en	{"title": "Choose"}	2026-01-13 10:04:30	2026-01-13 10:04:30	\N
260	65	\N	{"key": "choose"}	2026-01-13 10:04:30	2026-01-13 10:04:30	\N
261	66	uz	{"title": "Istiqomat qilayotgan davlatingiz:"}	2026-01-13 10:05:28	2026-01-13 10:05:28	\N
262	66	ru	{"title": "Ваша страна проживания:"}	2026-01-13 10:05:28	2026-01-13 10:05:28	\N
263	66	en	{"title": "Your country of residence:"}	2026-01-13 10:05:28	2026-01-13 10:05:28	\N
264	66	\N	{"key": "owncity"}	2026-01-13 10:05:28	2026-01-13 10:05:28	\N
265	67	uz	{"title": "Shahar/tuman:"}	2026-01-13 10:06:22	2026-01-13 10:06:22	\N
266	67	ru	{"title": "Город/район:"}	2026-01-13 10:06:22	2026-01-13 10:06:22	\N
267	67	en	{"title": "City/district:"}	2026-01-13 10:06:22	2026-01-13 10:06:22	\N
268	67	\N	{"key": "city"}	2026-01-13 10:06:22	2026-01-13 10:06:22	\N
269	68	uz	{"title": "Ish joyi:"}	2026-01-13 10:06:59	2026-01-13 10:06:59	\N
270	68	ru	{"title": "Рабочее место:"}	2026-01-13 10:06:59	2026-01-13 10:06:59	\N
271	68	en	{"title": "Workplace:"}	2026-01-13 10:06:59	2026-01-13 10:06:59	\N
272	68	\N	{"key": "workplace:"}	2026-01-13 10:06:59	2026-01-13 10:06:59	\N
273	69	uz	{"title": "Lavozimi:"}	2026-01-13 10:07:40	2026-01-13 10:07:40	\N
274	69	ru	{"title": "Позиция:"}	2026-01-13 10:07:40	2026-01-13 10:07:40	\N
275	69	en	{"title": "Position:"}	2026-01-13 10:07:40	2026-01-13 10:07:40	\N
276	69	\N	{"key": "position"}	2026-01-13 10:07:40	2026-01-13 10:07:40	\N
277	70	uz	{"title": "Ma'lumoti:"}	2026-01-13 10:08:38	2026-01-13 10:08:38	\N
278	70	ru	{"title": "Информация:"}	2026-01-13 10:08:38	2026-01-13 10:08:38	\N
279	70	en	{"title": "Information:"}	2026-01-13 10:08:38	2026-01-13 10:08:38	\N
280	70	\N	{"key": "information"}	2026-01-13 10:08:38	2026-01-13 10:08:38	\N
281	71	uz	{"title": "Fayl:"}	2026-01-13 10:14:53	2026-01-13 10:14:53	\N
282	71	ru	{"title": "Файл:"}	2026-01-13 10:14:53	2026-01-13 10:14:53	\N
283	71	en	{"title": "File:"}	2026-01-13 10:14:53	2026-01-13 10:14:53	\N
284	71	\N	{"key": "file"}	2026-01-13 10:14:53	2026-01-13 10:14:53	\N
285	72	uz	{"title": "Faylni yuklang yoki sudrab torting"}	2026-01-13 10:15:43	2026-01-13 10:15:43	\N
286	72	ru	{"title": "Загрузите или перетащите файл."}	2026-01-13 10:15:43	2026-01-13 10:15:43	\N
287	72	en	{"title": "Upload or drag file"}	2026-01-13 10:15:43	2026-01-13 10:15:43	\N
288	72	\N	{"key": "upload"}	2026-01-13 10:15:43	2026-01-13 10:15:43	\N
289	73	uz	{"title": "Video, rasm, hujjat, PDF, docx, excel va boshqalar"}	2026-01-13 10:16:35	2026-01-13 10:16:35	\N
290	73	ru	{"title": "Видео, изображение, документ, PDF, docx, excel и другие"}	2026-01-13 10:16:35	2026-01-13 10:16:35	\N
291	73	en	{"title": "Video, image, document, PDF, docx, excel and others"}	2026-01-13 10:16:35	2026-01-13 10:16:35	\N
292	73	\N	{"key": "video"}	2026-01-13 10:16:35	2026-01-13 10:16:35	\N
293	74	uz	{"title": "Erkak"}	2026-01-13 10:17:58	2026-01-13 10:17:58	\N
294	74	ru	{"title": "Мужской"}	2026-01-13 10:17:58	2026-01-13 10:17:58	\N
295	74	en	{"title": "Male"}	2026-01-13 10:17:58	2026-01-13 10:17:58	\N
296	74	\N	{"key": "erkak"}	2026-01-13 10:17:58	2026-01-13 10:17:58	\N
297	75	uz	{"title": "Ayol"}	2026-01-13 10:18:27	2026-01-13 10:18:27	\N
298	75	ru	{"title": "Женщина"}	2026-01-13 10:18:27	2026-01-13 10:18:27	\N
299	75	en	{"title": "Woman"}	2026-01-13 10:18:27	2026-01-13 10:18:27	\N
300	75	\N	{"key": "ayol"}	2026-01-13 10:18:27	2026-01-13 10:18:27	\N
301	76	uz	{"title": "Ilmni rivojlantirish"}	2026-01-20 06:50:02	2026-01-20 06:50:02	\N
302	76	ru	{"title": "Развитие науки"}	2026-01-20 06:50:02	2026-01-20 06:50:02	\N
303	76	en	{"title": "Development of science"}	2026-01-20 06:50:02	2026-01-20 06:50:02	\N
304	76	\N	{"key": "knowledge"}	2026-01-20 06:50:02	2026-01-20 06:50:02	\N
66	17	ru	{"title": "Отправить запрос"}	2026-01-05 06:18:28	2026-01-20 13:19:48	list
233	59	uz	{"title": "Video qo’llanma"}	2026-01-13 09:50:35	2026-01-20 13:23:02	\N
236	59	\N	{"key": "video_l", "url": "https://www.youtube.com/embed/BHACKCNDMW8?si=AtPPS9WpLIT3_TaW"}	2026-01-13 09:50:35	2026-01-20 13:23:02	\N
313	79	uz	{"title": "Elektron pochta"}	2026-01-21 13:17:04	2026-01-21 13:17:04	\N
314	79	ru	{"title": "Электронная почта"}	2026-01-21 13:17:04	2026-01-21 13:17:04	\N
315	79	en	{"title": "Email"}	2026-01-21 13:17:04	2026-01-21 13:17:04	\N
316	79	\N	{"key": "email_info", "url": null, "description": "info@vatandoshlarfondi.uz"}	2026-01-21 13:17:04	2026-01-21 13:17:04	\N
319	80	en	{"title": "Address", "content": "100100, Tashkent city, Yakkasaroy district, Babur street, house 30."}	2026-01-21 13:19:30	2026-01-21 13:25:42	\N
320	80	\N	{"key": "adress_info", "url": null, "description": null}	2026-01-21 13:19:30	2026-01-21 13:25:42	\N
309	78	uz	{"title": "Telefon raqam", "content": null}	2026-01-21 13:13:37	2026-01-21 13:27:42	\N
310	78	ru	{"title": "Номер телефона", "content": null}	2026-01-21 13:13:37	2026-01-21 13:27:42	\N
311	78	en	{"title": "Contact information", "content": null}	2026-01-21 13:13:37	2026-01-21 13:27:42	\N
312	78	\N	{"key": "phonenumber", "url": null, "description": "+998(55) 502-22-66"}	2026-01-21 13:13:37	2026-01-21 13:27:42	\N
305	77	uz	{"title": "Batafsil", "content": null, "short_description": null}	2026-01-21 09:40:03	2026-01-23 06:04:25	\N
307	77	en	{"title": "More details", "content": null, "short_description": null}	2026-01-21 09:40:03	2026-01-23 06:04:25	\N
308	77	\N	{"key": "more", "url": "about", "description": null}	2026-01-21 09:40:03	2026-01-23 06:04:25	\N
317	80	uz	{"title": "Manzil", "content": "100100, Toshkent sh., Yakkasaroy tumani, Bobur ko'chasi, 30-uy."}	2026-01-21 13:19:30	2026-01-21 13:25:42	\N
318	80	ru	{"title": "Аддресс", "content": "100100, город Ташкент, Яккасарайский район, улица Бабура, дом 30."}	2026-01-21 13:19:30	2026-01-21 13:25:42	\N
321	81	uz	{"title": "“Vatandoshlar”", "content": "Jamoat Fondi"}	2026-01-21 13:59:01	2026-01-21 13:59:01	\N
322	81	ru	{"title": "«Соотечественники»", "content": "Общественный фонд"}	2026-01-21 13:59:01	2026-01-21 13:59:01	\N
323	81	en	{"title": "\\"Compatriots\\"", "content": "Public Foundation"}	2026-01-21 13:59:01	2026-01-21 13:59:01	\N
324	81	\N	{"key": "vatandoshlar", "url": null, "description": null}	2026-01-21 13:59:01	2026-01-21 13:59:01	\N
325	82	uz	{"title": "Qidiruv so'zingizni kiriting", "content": null}	2026-01-21 17:09:08	2026-01-21 17:11:29	\N
326	82	ru	{"title": "Введите поисковый запрос", "content": null}	2026-01-21 17:09:08	2026-01-21 17:11:29	\N
327	82	en	{"title": "Enter your search term", "content": null}	2026-01-21 17:09:08	2026-01-21 17:11:29	\N
328	82	\N	{"key": "search", "url": null, "description": null}	2026-01-21 17:09:08	2026-01-21 17:11:29	\N
333	84	uz	{"title": "Musiqachi", "content": null}	2026-01-21 17:41:32	2026-01-21 17:41:32	\N
334	84	ru	{"title": "Музыкант", "content": null}	2026-01-21 17:41:32	2026-01-21 17:41:32	\N
335	84	en	{"title": "Musician", "content": null}	2026-01-21 17:41:32	2026-01-21 17:41:32	\N
336	84	\N	{"key": null, "url": null, "description": null}	2026-01-21 17:41:32	2026-01-21 17:41:32	\N
337	85	uz	{"title": "Tashkil topgan sanasi", "content": null}	2026-01-22 06:06:49	2026-01-22 06:06:49	\N
338	85	ru	{"title": "Дата основания", "content": null}	2026-01-22 06:06:49	2026-01-22 06:06:49	\N
339	85	en	{"title": "Date of establishment", "content": null}	2026-01-22 06:06:49	2026-01-22 06:06:49	\N
340	85	\N	{"key": "date_at", "url": null, "description": null}	2026-01-22 06:06:49	2026-01-22 06:06:49	\N
341	86	uz	{"title": "Rahbari saylangan sanasi:", "content": null}	2026-01-22 06:08:08	2026-01-22 06:08:08	\N
342	86	ru	{"title": "Дата выборов лидера:", "content": null}	2026-01-22 06:08:08	2026-01-22 06:08:08	\N
343	86	en	{"title": "Date of election of the leader:", "content": null}	2026-01-22 06:08:08	2026-01-22 06:08:08	\N
344	86	\N	{"key": "leader", "url": null, "description": null}	2026-01-22 06:08:08	2026-01-22 06:08:08	\N
345	87	uz	{"title": "Tashkilotning asosiy maqsad va vazifalari:", "content": null}	2026-01-22 06:08:57	2026-01-22 06:08:57	\N
346	87	ru	{"title": "Основные цели и задачи организации:", "content": null}	2026-01-22 06:08:57	2026-01-22 06:08:57	\N
347	87	en	{"title": "The main goals and objectives of the organization are:", "content": null}	2026-01-22 06:08:57	2026-01-22 06:08:57	\N
348	87	\N	{"key": "aim", "url": null, "description": null}	2026-01-22 06:08:57	2026-01-22 06:08:57	\N
349	88	uz	{"title": "Xarita ko'rinishida", "content": null}	2026-01-22 06:10:31	2026-01-22 06:10:31	\N
350	88	ru	{"title": "В режиме карты", "content": null}	2026-01-22 06:10:31	2026-01-22 06:10:31	\N
351	88	en	{"title": "In map view", "content": null}	2026-01-22 06:10:31	2026-01-22 06:10:31	\N
352	88	\N	{"key": "map", "url": null, "description": null}	2026-01-22 06:10:31	2026-01-22 06:10:31	\N
353	89	uz	{"title": "Grid ko'rinishida", "content": null}	2026-01-22 06:11:24	2026-01-22 06:11:24	\N
354	89	ru	{"title": "В табличном представлении", "content": null}	2026-01-22 06:11:24	2026-01-22 06:11:24	\N
355	89	en	{"title": "In grid view", "content": null}	2026-01-22 06:11:24	2026-01-22 06:11:24	\N
356	89	\N	{"key": "grid", "url": null, "description": null}	2026-01-22 06:11:24	2026-01-22 06:11:24	\N
329	83	uz	{"title": "Loyihalar bo'yicha menejer", "content": null}	2026-01-21 17:39:30	2026-01-22 06:47:46	\N
330	83	ru	{"title": "Руководитель проекта", "content": null}	2026-01-21 17:39:30	2026-01-22 06:47:46	\N
331	83	en	{"title": "Project Manager", "content": null}	2026-01-21 17:39:30	2026-01-22 06:47:46	\N
332	83	\N	{"key": null, "url": null, "description": "asdasd"}	2026-01-21 17:39:30	2026-01-22 06:47:46	\N
358	90	ru	{"title": "©2025 Фонд «Граждане». Все права защищены.", "content": null, "short_description": null}	2026-01-22 06:55:01	2026-01-23 13:26:51	\N
359	90	en	{"title": "©2025 CITIZENS FOUNDATION. All rights reserved.", "content": null, "short_description": null}	2026-01-22 06:55:01	2026-01-23 13:26:51	\N
360	90	\N	{"key": "safe", "url": null, "description": null}	2026-01-22 06:55:01	2026-01-23 13:26:51	\N
361	91	uz	{"title": "ta natija topildi", "content": null}	2026-01-22 08:35:26	2026-01-22 08:35:26	\N
362	91	ru	{"title": "найденные результаты", "content": null}	2026-01-22 08:35:26	2026-01-22 08:35:26	\N
363	91	en	{"title": "results found", "content": null}	2026-01-22 08:35:26	2026-01-22 08:35:26	\N
364	91	\N	{"key": "search-found", "url": null, "description": null}	2026-01-22 08:35:26	2026-01-22 08:35:26	\N
365	92	uz	{"title": "Hech qanday natija topilmadi", "content": null}	2026-01-22 08:37:16	2026-01-22 08:37:16	\N
366	92	ru	{"title": "Результаты не найдены.", "content": null}	2026-01-22 08:37:16	2026-01-22 08:37:16	\N
367	92	en	{"title": "No results found.", "content": null}	2026-01-22 08:37:16	2026-01-22 08:37:16	\N
368	92	\N	{"key": "search-not-found", "url": null, "description": null}	2026-01-22 08:37:16	2026-01-22 08:37:16	\N
369	93	uz	{"title": "Barcha viloyatlar", "content": null}	2026-01-22 10:43:48	2026-01-22 10:43:48	\N
370	93	ru	{"title": "Все регионы", "content": null}	2026-01-22 10:43:48	2026-01-22 10:43:48	\N
371	93	en	{"title": "All regions", "content": null}	2026-01-22 10:43:48	2026-01-22 10:43:48	\N
372	93	\N	{"key": "cities", "url": null, "description": null}	2026-01-22 10:43:48	2026-01-22 10:43:48	\N
373	94	uz	{"title": "Batafsil loyiha haqida", "content": null}	2026-01-22 10:49:44	2026-01-22 10:49:44	\N
374	94	ru	{"title": "Подробнее о проекте", "content": null}	2026-01-22 10:49:44	2026-01-22 10:49:44	\N
375	94	en	{"title": "More about the project", "content": null}	2026-01-22 10:49:44	2026-01-22 10:49:44	\N
376	94	\N	{"key": "more-about", "url": null, "description": null}	2026-01-22 10:49:44	2026-01-22 10:49:44	\N
377	95	uz	{"title": "Tanlov shartlari", "content": null}	2026-01-22 10:51:19	2026-01-22 10:51:19	\N
378	95	ru	{"title": "Условия соревнований", "content": null}	2026-01-22 10:51:19	2026-01-22 10:51:19	\N
379	95	en	{"title": "Competition conditions", "content": null}	2026-01-22 10:51:19	2026-01-22 10:51:19	\N
357	90	uz	{"title": "VATANDOSHLAR FONDI. Barcha huquqlari himoyalangan.", "content": null, "short_description": null}	2026-01-22 06:55:01	2026-01-23 13:26:51	\N
380	95	\N	{"key": "requirements", "url": null, "description": null}	2026-01-22 10:51:19	2026-01-22 10:51:19	\N
381	96	uz	{"title": "Ishtirok etish", "content": null}	2026-01-22 10:53:53	2026-01-22 10:53:53	\N
382	96	ru	{"title": "Участие", "content": null}	2026-01-22 10:53:53	2026-01-22 10:53:53	\N
383	96	en	{"title": "Participation", "content": null}	2026-01-22 10:53:53	2026-01-22 10:53:53	\N
384	96	\N	{"key": "Participate", "url": null, "description": null}	2026-01-22 10:53:53	2026-01-22 10:53:53	\N
385	97	uz	{"title": "Video ko’rish", "content": null}	2026-01-22 10:55:53	2026-01-22 10:55:53	\N
386	97	ru	{"title": "Посмотреть  видео", "content": null}	2026-01-22 10:55:53	2026-01-22 10:55:53	\N
387	97	en	{"title": "Watch the video", "content": null}	2026-01-22 10:55:53	2026-01-22 10:55:53	\N
388	97	\N	{"key": "video-play", "url": null, "description": null}	2026-01-22 10:55:53	2026-01-22 10:55:53	\N
419	105	en	{"title": "There is an error.", "content": null, "short_description": null}	2026-01-22 13:11:12	2026-01-22 13:11:12	\N
420	105	\N	{"key": "somethingWentWrong", "url": null, "description": null}	2026-01-22 13:11:12	2026-01-22 13:11:12	\N
421	106	uz	{"title": "Bo’lishish", "content": null, "short_description": null}	2026-01-22 13:29:33	2026-01-22 13:29:33	\N
422	106	ru	{"title": "Поделиться", "content": null, "short_description": null}	2026-01-22 13:29:33	2026-01-22 13:29:33	\N
389	98	uz	{"title": "Hafta", "content": "O‘zgartirish uchun aylantiring", "short_description": "Ochiq/Yopiq"}	2026-01-22 11:03:58	2026-01-22 11:07:07	\N
390	98	ru	{"title": "Неделя", "content": "Поверните, чтобы изменить", "short_description": "Открыто/Закрыто"}	2026-01-22 11:03:58	2026-01-22 11:07:07	\N
391	98	en	{"title": "Week", "content": "Rotate to change", "short_description": "Open/Closed"}	2026-01-22 11:03:58	2026-01-22 11:07:07	\N
392	98	\N	{"key": "week", "url": null, "description": null}	2026-01-22 11:03:58	2026-01-22 11:07:07	\N
393	99	uz	{"title": "Loyihadan lavhalar", "content": null, "short_description": null}	2026-01-22 11:40:09	2026-01-22 11:40:09	\N
394	99	ru	{"title": "Кадры из проекта", "content": null, "short_description": null}	2026-01-22 11:40:09	2026-01-22 11:40:09	\N
395	99	en	{"title": "Photos from project", "content": null, "short_description": null}	2026-01-22 11:40:09	2026-01-22 11:40:09	\N
396	99	\N	{"key": "project", "url": null, "description": null}	2026-01-22 11:40:09	2026-01-22 11:40:09	\N
397	100	uz	{"title": "Bekor Qilish", "content": null, "short_description": null}	2026-01-22 11:47:59	2026-01-22 11:47:59	\N
398	100	ru	{"title": "Отмена", "content": null, "short_description": null}	2026-01-22 11:47:59	2026-01-22 11:47:59	\N
399	100	en	{"title": "Cancel", "content": null, "short_description": null}	2026-01-22 11:47:59	2026-01-22 11:47:59	\N
400	100	\N	{"key": "cancel", "url": null, "description": null}	2026-01-22 11:47:59	2026-01-22 11:47:59	\N
401	101	uz	{"title": "Ishlab chiquvchi", "content": null, "short_description": null}	2026-01-22 12:58:06	2026-01-22 12:58:06	\N
402	101	ru	{"title": "Разработано компанией", "content": null, "short_description": null}	2026-01-22 12:58:06	2026-01-22 12:58:06	\N
403	101	en	{"title": "Developed by", "content": null, "short_description": null}	2026-01-22 12:58:06	2026-01-22 12:58:06	\N
404	101	\N	{"key": "develop", "url": null, "description": null}	2026-01-22 12:58:06	2026-01-22 12:58:06	\N
405	102	uz	{"title": "Menyu", "content": null, "short_description": null}	2026-01-22 13:01:08	2026-01-22 13:01:08	\N
406	102	ru	{"title": "Меню", "content": null, "short_description": null}	2026-01-22 13:01:08	2026-01-22 13:01:08	\N
407	102	en	{"title": "Menu", "content": null, "short_description": null}	2026-01-22 13:01:08	2026-01-22 13:01:08	\N
408	102	\N	{"key": "menu", "url": null, "description": null}	2026-01-22 13:01:08	2026-01-22 13:01:08	\N
409	103	uz	{"title": "Arizangiz muvaffaqiyatli yuborildi. Tez orada siz bilan bog’lanamiz", "content": null, "short_description": null}	2026-01-22 13:04:13	2026-01-22 13:08:08	\N
410	103	ru	{"title": "Ваша заявка успешно отправлена. Мы свяжемся с вами в ближайшее время.", "content": null, "short_description": null}	2026-01-22 13:04:13	2026-01-22 13:08:08	\N
411	103	en	{"title": "Your application has been successfully submitted. We will contact you shortly.", "content": null, "short_description": null}	2026-01-22 13:04:13	2026-01-22 13:08:08	\N
412	103	\N	{"key": "ApplicationSent", "url": null, "description": null}	2026-01-22 13:04:13	2026-01-22 13:08:08	\N
413	104	uz	{"title": "Arizangiz hato yuborildi. Iltimos qayta tekshirib ko'ring", "content": null, "short_description": null}	2026-01-22 13:10:01	2026-01-22 13:10:01	\N
414	104	ru	{"title": "Ваша заявка была отправлена ​​по ошибке. Пожалуйста, проверьте еще раз.", "content": null, "short_description": null}	2026-01-22 13:10:01	2026-01-22 13:10:01	\N
415	104	en	{"title": "Your application was sent in error. Please check again.", "content": null, "short_description": null}	2026-01-22 13:10:01	2026-01-22 13:10:01	\N
416	104	\N	{"key": "ApplicationNotSent", "url": null, "description": null}	2026-01-22 13:10:01	2026-01-22 13:10:01	\N
417	105	uz	{"title": "Hatolik bor.", "content": null, "short_description": null}	2026-01-22 13:11:12	2026-01-22 13:11:12	\N
418	105	ru	{"title": "Произошла ошибка.", "content": null, "short_description": null}	2026-01-22 13:11:12	2026-01-22 13:11:12	\N
423	106	en	{"title": "Share", "content": null, "short_description": null}	2026-01-22 13:29:33	2026-01-22 13:29:33	\N
424	106	\N	{"key": "share", "url": null, "description": null}	2026-01-22 13:29:33	2026-01-22 13:29:33	\N
425	107	uz	{"title": "Havolani nusxalash", "content": null, "short_description": null}	2026-01-22 13:30:11	2026-01-22 13:30:11	\N
426	107	ru	{"title": "Скопировать ссылку", "content": null, "short_description": null}	2026-01-22 13:30:11	2026-01-22 13:30:11	\N
427	107	en	{"title": "Copy link", "content": null, "short_description": null}	2026-01-22 13:30:11	2026-01-22 13:30:11	\N
428	107	\N	{"key": "copy", "url": null, "description": null}	2026-01-22 13:30:11	2026-01-22 13:30:11	\N
306	77	ru	{"title": "Подробнее", "content": null, "short_description": null}	2026-01-21 09:40:03	2026-01-23 06:04:25	\N
429	108	uz	{"title": "Bog'lanish", "content": null, "short_description": null}	2026-01-23 06:09:48	2026-01-23 06:35:48	\N
430	108	ru	{"title": "Контакты", "content": null, "short_description": null}	2026-01-23 06:09:48	2026-01-23 06:35:48	\N
431	108	en	{"title": "Contacts", "content": null, "short_description": null}	2026-01-23 06:09:48	2026-01-23 06:35:48	\N
432	108	\N	{"key": "contacts_header", "url": null, "description": null}	2026-01-23 06:09:48	2026-01-23 06:35:48	\N
433	109	uz	{"title": "asdsd", "content": null, "short_description": null}	2026-01-27 06:44:30	2026-01-27 06:44:30	\N
434	109	ru	{"title": null, "content": null, "short_description": null}	2026-01-27 06:44:30	2026-01-27 06:44:30	\N
435	109	en	{"title": null, "content": null, "short_description": null}	2026-01-27 06:44:30	2026-01-27 06:44:30	\N
436	109	\N	{"key": "sd", "url": null, "description": null}	2026-01-27 06:44:30	2026-01-27 06:44:30	\N
437	110	uz	{"title": "Telegram Contact ChatID", "content": null, "short_description": null}	2026-01-27 07:44:24	2026-01-27 07:44:24	\N
438	110	ru	{"title": null, "content": null, "short_description": null}	2026-01-27 07:44:24	2026-01-27 07:44:24	\N
439	110	en	{"title": null, "content": null, "short_description": null}	2026-01-27 07:44:24	2026-01-27 07:44:24	\N
440	110	\N	{"key": "telegram_contact_chat_id", "url": null, "description": "-1003249220292"}	2026-01-27 07:44:24	2026-01-27 07:44:24	\N
441	111	uz	{"title": "Telegram Murojat ChatID", "content": null, "short_description": null}	2026-01-27 07:45:03	2026-01-27 07:45:03	\N
442	111	ru	{"title": null, "content": null, "short_description": null}	2026-01-27 07:45:03	2026-01-27 07:45:03	\N
443	111	en	{"title": null, "content": null, "short_description": null}	2026-01-27 07:45:03	2026-01-27 07:45:03	\N
444	111	\N	{"key": "telegram_application_chat_id", "url": null, "description": "-1003249220292"}	2026-01-27 07:45:03	2026-01-27 07:45:03	\N
445	112	uz	{"title": "Telegram Ishtirok etish ChatID", "content": null, "short_description": null}	2026-01-27 07:45:19	2026-01-27 07:45:19	\N
446	112	ru	{"title": null, "content": null, "short_description": null}	2026-01-27 07:45:19	2026-01-27 07:45:19	\N
447	112	en	{"title": null, "content": null, "short_description": null}	2026-01-27 07:45:19	2026-01-27 07:45:19	\N
448	112	\N	{"key": "telegram_participation_chat_id", "url": null, "description": "-1003249220292"}	2026-01-27 07:45:19	2026-01-27 07:45:19	\N
\.


--
-- Data for Name: contents; Type: TABLE DATA; Schema: public; Owner: vatandoshlar_usr
--

COPY public.contents (id, type, slug, url, test, show_admin, sort_order, icon, status, parent_id, created_at, updated_at, category) FROM stdin;
7	category	\N	\N	f	t	1	\N	t	\N	2026-01-05 06:08:08	2026-01-08 12:16:36	list
8	category	\N	\N	f	t	1	\N	t	\N	2026-01-05 06:08:54	2026-01-08 12:16:36	list
9	category	\N	\N	f	t	1	\N	t	\N	2026-01-05 06:09:45	2026-01-08 12:16:36	list
11	category	\N	\N	f	t	1	\N	t	\N	2026-01-05 06:11:20	2026-01-08 12:16:36	list
12	category	\N	\N	f	t	1	\N	t	\N	2026-01-05 06:12:41	2026-01-08 12:16:36	list
13	category	\N	\N	f	t	1	\N	t	\N	2026-01-05 06:13:52	2026-01-08 12:16:36	list
14	category	\N	\N	f	t	1	\N	t	\N	2026-01-05 06:15:07	2026-01-08 12:16:36	list
16	category	\N	\N	f	t	1	\N	t	\N	2026-01-05 06:17:30	2026-01-08 12:16:36	list
18	category	\N	\N	f	t	1	\N	t	\N	2026-01-05 06:19:15	2026-01-08 12:16:36	list
19	category	\N	\N	f	t	1	\N	t	\N	2026-01-05 06:20:38	2026-01-08 12:16:36	list
20	category	\N	\N	f	t	1	\N	t	\N	2026-01-05 06:21:27	2026-01-08 12:16:36	list
21	category	\N	\N	f	t	1	\N	t	\N	2026-01-05 06:43:23	2026-01-08 12:16:36	list
22	category	\N	\N	f	t	1	\N	t	\N	2026-01-05 06:54:59	2026-01-08 12:16:36	list
23	category	\N	\N	f	t	1	\N	t	\N	2026-01-05 06:57:49	2026-01-08 12:16:36	list
24	category	\N	\N	f	t	1	\N	t	\N	2026-01-05 06:58:49	2026-01-08 12:16:36	list
35	category	\N	\N	f	t	1	\N	t	\N	2026-01-13 06:58:18	2026-01-13 06:58:18	list
37	category	\N	\N	f	t	1	\N	t	\N	2026-01-13 08:52:06	2026-01-13 08:52:06	list
38	category	\N	\N	f	t	1	\N	t	\N	2026-01-13 08:55:00	2026-01-13 08:55:00	list
39	category	\N	\N	f	t	1	\N	t	\N	2026-01-13 08:55:47	2026-01-13 08:55:47	list
40	category	\N	\N	f	t	1	\N	t	\N	2026-01-13 08:58:06	2026-01-13 08:58:06	list
41	category	\N	\N	f	t	1	\N	t	\N	2026-01-13 08:58:55	2026-01-13 08:58:55	list
42	category	\N	\N	f	t	1	\N	t	\N	2026-01-13 09:01:18	2026-01-13 09:01:18	list
43	category	\N	\N	f	t	1	\N	t	\N	2026-01-13 09:02:14	2026-01-13 09:02:14	list
45	category	\N	\N	f	t	1	\N	t	\N	2026-01-13 09:09:32	2026-01-13 09:09:32	list
46	category	\N	\N	f	t	1	\N	t	\N	2026-01-13 09:11:01	2026-01-13 09:11:01	list
47	category	\N	\N	f	t	1	\N	t	\N	2026-01-13 09:14:35	2026-01-13 09:14:35	list
48	category	\N	\N	f	t	1	\N	t	\N	2026-01-13 09:21:50	2026-01-13 09:21:50	list
49	category	\N	\N	f	t	1	\N	t	\N	2026-01-13 09:22:27	2026-01-13 09:22:27	list
50	category	\N	\N	f	t	1	\N	t	\N	2026-01-13 09:23:17	2026-01-13 09:23:17	list
51	category	\N	\N	f	t	1	\N	t	\N	2026-01-13 09:24:02	2026-01-13 09:24:02	list
52	category	\N	\N	f	t	1	\N	t	\N	2026-01-13 09:25:09	2026-01-13 09:25:09	list
53	category	\N	\N	f	t	1	\N	t	\N	2026-01-13 09:25:54	2026-01-13 09:25:54	list
54	category	\N	\N	f	t	1	\N	t	\N	2026-01-13 09:26:45	2026-01-13 09:26:45	list
55	category	\N	\N	f	t	1	\N	t	\N	2026-01-13 09:37:19	2026-01-13 09:37:19	list
56	category	\N	\N	f	t	1	\N	t	\N	2026-01-13 09:40:34	2026-01-13 09:40:34	list
57	category	\N	\N	f	t	1	\N	t	\N	2026-01-13 09:43:04	2026-01-13 09:43:04	list
58	category	\N	\N	f	t	1	\N	t	\N	2026-01-13 09:45:06	2026-01-13 09:45:06	list
59	category	\N	\N	f	t	1	\N	t	\N	2026-01-13 09:50:35	2026-01-13 09:50:35	list
60	category	\N	\N	f	t	1	\N	t	\N	2026-01-13 09:53:20	2026-01-13 09:53:20	list
62	category	\N	\N	f	t	1	\N	t	\N	2026-01-13 09:55:53	2026-01-13 09:55:53	list
63	category	\N	\N	f	t	1	\N	t	\N	2026-01-13 10:02:23	2026-01-13 10:02:23	list
64	category	\N	\N	f	t	1	\N	t	\N	2026-01-13 10:03:22	2026-01-13 10:03:22	list
65	category	\N	\N	f	t	1	\N	t	\N	2026-01-13 10:04:30	2026-01-13 10:04:30	list
66	category	\N	\N	f	t	1	\N	t	\N	2026-01-13 10:05:28	2026-01-13 10:05:28	list
67	category	\N	\N	f	t	1	\N	t	\N	2026-01-13 10:06:22	2026-01-13 10:06:22	list
68	category	\N	\N	f	t	1	\N	t	\N	2026-01-13 10:06:59	2026-01-13 10:06:59	list
69	category	\N	\N	f	t	1	\N	t	\N	2026-01-13 10:07:40	2026-01-13 10:07:40	list
70	category	\N	\N	f	t	1	\N	t	\N	2026-01-13 10:08:38	2026-01-13 10:08:38	list
71	category	\N	\N	f	t	1	\N	t	\N	2026-01-13 10:14:53	2026-01-13 10:14:53	list
72	category	\N	\N	f	t	1	\N	t	\N	2026-01-13 10:15:43	2026-01-13 10:15:43	list
73	category	\N	\N	f	t	1	\N	t	\N	2026-01-13 10:16:35	2026-01-13 10:16:35	list
74	category	\N	\N	f	t	1	\N	t	\N	2026-01-13 10:17:58	2026-01-13 10:17:58	list
75	category	\N	\N	f	t	1	\N	t	\N	2026-01-13 10:18:27	2026-01-13 10:18:27	list
76	category	\N	\N	f	t	1	\N	t	\N	2026-01-20 06:50:02	2026-01-20 06:50:02	list
17	category	\N	\N	f	f	1	\N	t	\N	2026-01-05 06:18:28	2026-01-20 13:19:48	list
2	category	\N	\N	f	t	1	\N	t	\N	2025-12-29 11:34:12	2026-01-20 14:00:50	list
3	category	\N	\N	f	t	1	\N	t	\N	2025-12-29 11:34:55	2026-01-20 14:00:55	list
4	category	\N	\N	f	t	1	\N	t	\N	2025-12-29 11:36:08	2026-01-20 17:17:28	list
6	category	\N	\N	f	t	1	\N	t	\N	2025-12-29 13:28:11	2026-01-20 17:23:21	list
77	category	\N	\N	f	t	1	\N	t	\N	2026-01-21 09:40:03	2026-01-21 09:40:03	list
78	category	\N	\N	f	t	1	\N	t	\N	2026-01-21 13:13:37	2026-01-21 13:13:37	list
79	category	\N	\N	f	t	1	\N	t	\N	2026-01-21 13:17:04	2026-01-21 13:17:04	list
80	category	\N	\N	f	t	1	\N	t	\N	2026-01-21 13:19:30	2026-01-21 13:19:30	list
81	category	\N	\N	f	t	1	\N	t	\N	2026-01-21 13:59:01	2026-01-21 13:59:01	list
82	category	\N	\N	f	t	1	\N	t	\N	2026-01-21 17:09:08	2026-01-21 17:09:08	list
84	category	\N	\N	f	t	1	\N	t	\N	2026-01-21 17:41:32	2026-01-21 17:41:32	job
85	category	\N	\N	f	t	1	\N	t	\N	2026-01-22 06:06:49	2026-01-22 06:06:49	list
86	category	\N	\N	f	t	1	\N	t	\N	2026-01-22 06:08:08	2026-01-22 06:08:08	list
87	category	\N	\N	f	t	1	\N	t	\N	2026-01-22 06:08:57	2026-01-22 06:08:57	list
88	category	\N	\N	f	t	1	\N	t	\N	2026-01-22 06:10:31	2026-01-22 06:10:31	list
89	category	\N	\N	f	t	1	\N	t	\N	2026-01-22 06:11:24	2026-01-22 06:11:24	list
83	category	\N	\N	f	t	1	\N	t	\N	2026-01-21 17:39:30	2026-01-22 06:47:46	\N
90	category	\N	\N	f	t	1	\N	t	\N	2026-01-22 06:55:01	2026-01-22 06:55:01	list
91	category	\N	\N	f	t	1	\N	t	\N	2026-01-22 08:35:26	2026-01-22 08:35:26	list
92	category	\N	\N	f	t	1	\N	t	\N	2026-01-22 08:37:16	2026-01-22 08:37:16	list
93	category	\N	\N	f	t	1	\N	t	\N	2026-01-22 10:43:48	2026-01-22 10:43:48	list
94	category	\N	\N	f	t	1	\N	t	\N	2026-01-22 10:49:44	2026-01-22 10:49:44	list
95	category	\N	\N	f	t	1	\N	t	\N	2026-01-22 10:51:19	2026-01-22 10:51:19	list
96	category	\N	\N	f	t	1	\N	t	\N	2026-01-22 10:53:53	2026-01-22 10:53:53	list
97	category	\N	\N	f	t	1	\N	t	\N	2026-01-22 10:55:53	2026-01-22 10:55:53	list
98	category	\N	\N	f	t	1	\N	t	\N	2026-01-22 11:03:58	2026-01-22 11:03:58	list
99	category	\N	\N	f	t	1	\N	t	\N	2026-01-22 11:40:09	2026-01-22 11:40:09	list
100	category	\N	\N	f	t	1	\N	t	\N	2026-01-22 11:47:59	2026-01-22 11:47:59	list
5	category	\N	\N	f	t	1	\N	t	\N	2025-12-29 11:37:26	2026-01-23 13:25:57	list
1	category	\N	\N	f	t	1	\N	t	\N	2025-12-29 11:28:37	2026-01-22 12:23:19	list
101	category	\N	\N	f	t	1	\N	t	\N	2026-01-22 12:58:06	2026-01-22 12:58:06	list
102	category	\N	\N	f	t	1	\N	t	\N	2026-01-22 13:01:08	2026-01-22 13:01:08	list
103	category	\N	\N	f	t	1	\N	t	\N	2026-01-22 13:04:13	2026-01-22 13:04:13	list
104	category	\N	\N	f	t	1	\N	t	\N	2026-01-22 13:10:01	2026-01-22 13:10:01	list
105	category	\N	\N	f	t	1	\N	t	\N	2026-01-22 13:11:12	2026-01-22 13:11:12	list
106	category	\N	\N	f	t	1	\N	t	\N	2026-01-22 13:29:33	2026-01-22 13:29:33	list
107	category	\N	\N	f	t	1	\N	t	\N	2026-01-22 13:30:11	2026-01-22 13:30:11	list
108	category	\N	\N	f	t	1	\N	t	\N	2026-01-23 06:09:48	2026-01-23 06:09:48	list
109	category	\N	\N	f	t	1	\N	t	\N	2026-01-27 06:44:30	2026-01-27 06:44:30	list
112	category	\N	\N	f	t	1	\N	f	\N	2026-01-27 07:45:19	2026-01-28 10:07:08	list
111	category	\N	\N	f	t	1	\N	f	\N	2026-01-27 07:45:03	2026-01-28 10:07:08	list
110	category	\N	\N	f	t	1	\N	f	\N	2026-01-27 07:44:24	2026-01-28 10:07:09	list
\.


--
-- Data for Name: countries; Type: TABLE DATA; Schema: public; Owner: vatandoshlar_usr
--

COPY public.countries (id, name, nicename, iso, iso3, numcode, phonecode, phonemask, status, created_at, updated_at) FROM stdin;
217	{"en":"Gabon","ru":"\\u0413\\u0430\\u0431\\u043e\\u043d","oz":"Gabon"}	Gabon	GA	GAB	266	241	0-00-00-00	active	2026-01-15 12:24:33	2026-01-15 12:24:33
218	{"en":"Gambia","ru":"\\u0413\\u0430\\u043c\\u0431\\u0438\\u044f","oz":"Gambiya"}	Gambia	GM	GMB	270	220	000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
219	{"en":"Georgia","ru":"\\u0413\\u0440\\u0443\\u0437\\u0438\\u044f","oz":"Gruziya"}	Georgia	GE	GEO	268	995	000-000-000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
220	{"en":"Germany","ru":"\\u0413\\u0435\\u0440\\u043c\\u0430\\u043d\\u0438\\u044f","oz":"Germaniya"}	Germany	DE	DEU	276	49	000-0000000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
221	{"en":"Ghana","ru":"\\u0413\\u0430\\u043d\\u0430","oz":"Gana"}	Ghana	GH	GHA	288	233	00-000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
222	{"en":"Gibraltar","ru":"\\u0413\\u0438\\u0431\\u0440\\u0430\\u043b\\u0442\\u0430\\u0440","oz":"Gibraltar"}	Gibraltar	GI	GIB	292	350	000-00000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
223	{"en":"Greece","ru":"\\u0413\\u0440\\u0435\\u0446\\u0438\\u044f","oz":"Gretsiya"}	Greece	GR	GRC	300	30	00-0000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
224	{"en":"Greenland","ru":"\\u0413\\u0440\\u0435\\u043d\\u043b\\u0430\\u043d\\u0434\\u0438\\u044f","oz":"Grenlandiya"}	Greenland	GL	GRL	304	299	00-00-00	active	2026-01-15 12:24:33	2026-01-15 12:24:33
225	{"en":"Grenada","ru":"\\u0413\\u0440\\u0435\\u043d\\u0430\\u0434\\u0430","oz":"Grenada"}	Grenada	GD	GRD	308	1473	000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
226	{"en":"Guadeloupe","ru":"\\u0413\\u0432\\u0430\\u0434\\u0435\\u043b\\u0443\\u043f\\u0430","oz":"Gvadelupa"}	Guadeloupe	GP	GLP	312	590	000-00-00-00	active	2026-01-15 12:24:33	2026-01-15 12:24:33
227	{"en":"Guam","ru":"\\u0413\\u0443\\u0430\\u043c","oz":"Guam"}	Guam	GU	GUM	316	1671	000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
228	{"en":"Guatemala","ru":"\\u0413\\u0432\\u0430\\u0442\\u0435\\u043c\\u0430\\u043b\\u0430","oz":"Gvatemala"}	Guatemala	GT	GTM	320	502	0-000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
229	{"en":"Guinea","ru":"\\u0413\\u0432\\u0438\\u043d\\u0435\\u044f","oz":"Gvineya"}	Guinea	GN	GIN	324	224	00-000-000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
230	{"en":"Guinea-Bissau","ru":"\\u0413\\u0432\\u0438\\u043d\\u0435\\u044f-\\u0411\\u0438\\u0441\\u0430\\u0443","oz":"Gvineya-Bisau"}	Guinea-Bissau	GW	GNB	624	245	00-000-000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
231	{"en":"Guyana","ru":"\\u0413\\u0430\\u0439\\u0430\\u043d\\u0430","oz":"Gayana"}	Guyana	GY	GUY	328	592	000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
232	{"en":"Haiti","ru":"\\u0413\\u0430\\u0438\\u0442\\u0438","oz":"Gaiti"}	Haiti	HT	HTI	332	509	00-00-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
233	{"en":"Heard Island and Mcdonald Islands","ru":"\\u041e\\u0441\\u0442\\u0440\\u043e\\u0432\\u0430 \\u0425\\u0435\\u0440\\u0434 \\u0438 \\u041c\\u0430\\u043a\\u0434\\u043e\\u043d\\u0430\\u043b\\u044c\\u0434","oz":"Xerd va Makdonald orollari"}	Heard Island and Mcdonald Islands	HM	HMD	334	0		active	2026-01-15 12:24:33	2026-01-15 12:24:33
234	{"en":"Holy See (Vatican City State)","ru":"\\u0412\\u0430\\u0442\\u0438\\u043a\\u0430\\u043d","oz":"Vatikan"}	Holy See (Vatican City State)	VA	VAT	336	39	00-0000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
235	{"en":"Honduras","ru":"\\u0413\\u043e\\u043d\\u0434\\u0443\\u0440\\u0430\\u0441","oz":"Gonduras"}	Honduras	HN	HND	340	504	0000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
236	{"en":"Hong Kong","ru":"\\u0413\\u043e\\u043d\\u043a\\u043e\\u043d\\u0433","oz":"Gonkong"}	Hong Kong	HK	HKG	344	852	0000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
237	{"en":"Hungary","ru":"\\u0412\\u0435\\u043d\\u0433\\u0440\\u0438\\u044f","oz":"Vengriya"}	Hungary	HU	HUN	348	36	00-000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
238	{"en":"Iceland","ru":"\\u0418\\u0441\\u043b\\u0430\\u043d\\u0434\\u0438\\u044f","oz":"Islandiya"}	Iceland	IS	ISL	352	354	000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
239	{"en":"India","ru":"\\u0418\\u043d\\u0434\\u0438\\u044f","oz":"Hindiston"}	India	IN	IND	356	91	00000-00000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
240	{"en":"Indonesia","ru":"\\u0418\\u043d\\u0434\\u043e\\u043d\\u0435\\u0437\\u0438\\u044f","oz":"Indoneziya"}	Indonesia	ID	IDN	360	62	00-000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
242	{"en":"Iraq","ru":"\\u0418\\u0440\\u0430\\u043a","oz":"Iroq"}	Iraq	IQ	IRQ	368	964	000-000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
243	{"en":"Ireland","ru":"\\u0418\\u0440\\u043b\\u0430\\u043d\\u0434\\u0438\\u044f","oz":"Irlandiya"}	Ireland	IE	IRL	372	353	00-000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
244	{"en":"Israel","ru":"\\u0418\\u0437\\u0440\\u0430\\u0438\\u043b\\u044c","oz":"Isroil"}	Israel	IL	ISR	376	972	0-000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
245	{"en":"Italy","ru":"\\u0418\\u0442\\u0430\\u043b\\u0438\\u044f","oz":"Italiya"}	Italy	IT	ITA	380	39	00-0000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
246	{"en":"Jamaica","ru":"\\u042f\\u043c\\u0430\\u0439\\u043a\\u0430","oz":"Yamayka"}	Jamaica	JM	JAM	388	1876	000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
247	{"en":"Japan","ru":"\\u042f\\u043f\\u043e\\u043d\\u0438\\u044f","oz":"Yaponiya"}	Japan	JP	JPN	392	81	00-0000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
248	{"en":"Jordan","ru":"\\u0418\\u043e\\u0440\\u0434\\u0430\\u043d\\u0438\\u044f","oz":"Iordaniya"}	Jordan	JO	JOR	400	962	0-000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
249	{"en":"Kazakhstan","ru":"\\u041a\\u0430\\u0437\\u0430\\u0445\\u0441\\u0442\\u0430\\u043d","oz":"Qozog'iston"}	Kazakhstan	KZ	KAZ	398	7	(000) 000-00-00	active	2026-01-15 12:24:33	2026-01-15 12:24:33
250	{"en":"Kenya","ru":"\\u041a\\u0435\\u043d\\u0438\\u044f","oz":"Keniya"}	Kenya	KE	KEN	404	254	000-000000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
251	{"en":"Kiribati","ru":"\\u041a\\u0438\\u0440\\u0438\\u0431\\u0430\\u0442\\u0438","oz":"Kiribati"}	Kiribati	KI	KIR	296	686	00-000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
253	{"en":"Kuwait","ru":"\\u041a\\u0443\\u0432\\u0435\\u0439\\u0442","oz":"Quvayt"}	Kuwait	KW	KWT	414	965	0000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
254	{"en":"Kyrgyzstan","ru":"\\u041a\\u044b\\u0440\\u0433\\u044b\\u0437\\u0441\\u0442\\u0430\\u043d","oz":"Qirg'iziston"}	Kyrgyzstan	KG	KGZ	417	996	000-000-000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
255	{"en":"Lao People's Democratic Republic"}	Lao People's Democratic Republic	LA	LAO	418	856	00-000-000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
256	{"en":"Latvia","ru":"\\u041b\\u0430\\u0442\\u0432\\u0438\\u044f","oz":"Latviya"}	Latvia	LV	LVA	428	371	00-000-000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
257	{"en":"Lebanon","ru":"\\u041b\\u0438\\u0432\\u0430\\u043d","oz":"Livan"}	Lebanon	LB	LBN	422	961	0-000-000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
258	{"en":"Lesotho","ru":"\\u041b\\u0435\\u0441\\u043e\\u0442\\u043e","oz":"Lesoto"}	Lesotho	LS	LSO	426	266	0-000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
299	{"en":"Oman","ru":"\\u041e\\u043c\\u0430\\u043d","oz":"Ummon"}	Oman	OM	OMN	512	968	00-000-000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
241	{"en": "Islamic Republic of","ru": "Иран","oz": "Eron"}\n	Iran 	IR	IRN	364	98	000-000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
141	{"en":"Afghanistan","ru":"\\u0410\\u0444\\u0433\\u0430\\u043d\\u0438\\u0441\\u0442\\u0430\\u043d","oz":"Afg'oniston"}	Afghanistan	AF	AFG	004	93	00-000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
142	{"en":"Albania","ru":"\\u0410\\u043b\\u0431\\u0430\\u043d\\u0438\\u044f","oz":"Albaniya"}	Albania	AL	ALB	008	355	00-000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
143	{"en":"Algeria","ru":"\\u0410\\u043b\\u0436\\u0438\\u0440","oz":"Jazoir"}	Algeria	DZ	DZA	012	213	00-000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
144	{"en":"American Samoa","ru":"\\u0410\\u043c\\u0435\\u0440\\u0438\\u043a\\u0430\\u043d\\u0441\\u043a\\u043e\\u0435 \\u0421\\u0430\\u043c\\u043e\\u0430","oz":"Amerika Samoasi"}	American Samoa	AS	ASM	016	1684	000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
145	{"en":"Andorra","ru":"\\u0410\\u043d\\u0434\\u043e\\u0440\\u0440\\u0430","oz":"Andorra"}	Andorra	AD	AND	020	376	000-000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
146	{"en":"Angola","ru":"\\u0410\\u043d\\u0433\\u043e\\u043b\\u0430","oz":"Angola"}	Angola	AO	AGO	024	244	000-000-000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
147	{"en":"Anguilla","ru":"\\u0410\\u043d\\u0433\\u0438\\u043b\\u044c\\u044f","oz":"Angilya"}	Anguilla	AI	AIA	660	1264	000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
148	{"en":"Antarctica","ru":"\\u0410\\u043d\\u0442\\u0430\\u0440\\u043a\\u0442\\u0438\\u0434\\u0430","oz":"Antarktida"}	Antarctica	AQ	ATA	010	0		active	2026-01-15 12:24:33	2026-01-15 12:24:33
149	{"en":"Antigua and Barbuda","ru":"\\u0410\\u043d\\u0442\\u0438\\u0433\\u0443\\u0430 \\u0438 \\u0411\\u0430\\u0440\\u0431\\u0443\\u0434\\u0430","oz":"Antigua va Barbuda"}	Antigua and Barbuda	AG	ATG	028	1268	000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
150	{"en":"Argentina","ru":"\\u0410\\u0440\\u0433\\u0435\\u043d\\u0442\\u0438\\u043d\\u0430","oz":"Argentina"}	Argentina	AR	ARG	032	54	00-0000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
151	{"en":"Armenia","ru":"\\u0410\\u0440\\u043c\\u0435\\u043d\\u0438\\u044f","oz":"Armaniston"}	Armenia	AM	ARM	051	374	00-000-000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
152	{"en":"Aruba","ru":"\\u0410\\u0440\\u0443\\u0431\\u0430","oz":"Aruba"}	Aruba	AW	ABW	533	297	000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
153	{"en":"Australia","ru":"\\u0410\\u0432\\u0441\\u0442\\u0440\\u0430\\u043b\\u0438\\u044f","oz":"Avstraliya"}	Australia	AU	AUS	036	61	0-0000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
154	{"en":"Austria","ru":"\\u0410\\u0432\\u0441\\u0442\\u0440\\u0438\\u044f","oz":"Avstriya"}	Austria	AT	AUT	040	43	000-0000000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
155	{"en":"Azerbaijan","ru":"\\u0410\\u0437\\u0435\\u0440\\u0431\\u0430\\u0439\\u0434\\u0436\\u0430\\u043d","oz":"Ozarbayjon"}	Azerbaijan	AZ	AZE	031	994	00-000-00-00	active	2026-01-15 12:24:33	2026-01-15 12:24:33
156	{"en":"Bahamas","ru":"\\u0411\\u0430\\u0433\\u0430\\u043c\\u0441\\u043a\\u0438\\u0435 \\u043e\\u0441\\u0442\\u0440\\u043e\\u0432\\u0430","oz":"Bagam orollari"}	Bahamas	BS	BHS	044	1242	000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
157	{"en":"Bahrain","ru":"\\u0411\\u0430\\u0445\\u0440\\u0435\\u0439\\u043d","oz":"Bahrayn"}	Bahrain	BH	BHR	048	973	0000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
158	{"en":"Bangladesh","ru":"\\u0411\\u0430\\u043d\\u0433\\u043b\\u0430\\u0434\\u0435\\u0448","oz":"Bangladesh"}	Bangladesh	BD	BGD	050	880	00-000-000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
159	{"en":"Barbados","ru":"\\u0411\\u0430\\u0440\\u0431\\u0430\\u0434\\u043e\\u0441","oz":"Barbados"}	Barbados	BB	BRB	052	1246	000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
160	{"en":"Belarus","ru":"\\u0411\\u0435\\u043b\\u0430\\u0440\\u0443\\u0441\\u044c","oz":"Belarus"}	Belarus	BY	BLR	112	375	00-000-00-00	active	2026-01-15 12:24:33	2026-01-15 12:24:33
161	{"en":"Belgium","ru":"\\u0411\\u0435\\u043b\\u044c\\u0433\\u0438\\u044f","oz":"Belgiya"}	Belgium	BE	BEL	056	32	000-000-000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
162	{"en":"Belize","ru":"\\u0411\\u0435\\u043b\\u0438\\u0437","oz":"Beliz"}	Belize	BZ	BLZ	084	501	000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
163	{"en":"Benin","ru":"\\u0411\\u0435\\u043d\\u0438\\u043d","oz":"Benin"}	Benin	BJ	BEN	204	229	00-00-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
164	{"en":"Bermuda","ru":"\\u0411\\u0435\\u0440\\u043c\\u0443\\u0434\\u0441\\u043a\\u0438\\u0435 \\u043e\\u0441\\u0442\\u0440\\u043e\\u0432\\u0430","oz":"Bermuda orollari"}	Bermuda	BM	BMU	060	1441	000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
165	{"en":"Bhutan","ru":"\\u0411\\u0443\\u0442\\u0430\\u043d","oz":"Butan"}	Bhutan	BT	BTN	064	975	0-000-000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
166	{"en":"Bolivia","ru":"\\u0411\\u043e\\u043b\\u0438\\u0432\\u0438\\u044f","oz":"Boliviya"}	Bolivia	BO	BOL	068	591	0-000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
167	{"en":"Bosnia and Herzegovina","ru":"\\u0411\\u043e\\u0441\\u043d\\u0438\\u044f \\u0438 \\u0413\\u0435\\u0440\\u0446\\u0435\\u0433\\u043e\\u0432\\u0438\\u043d\\u0430","oz":"Bosniya va Gertsegovina"}	Bosnia and Herzegovina	BA	BIH	070	387	00-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
168	{"en":"Botswana","ru":"\\u0411\\u043e\\u0442\\u0441\\u0432\\u0430\\u043d\\u0430","oz":"Botsvana"}	Botswana	BW	BWA	072	267	00-000-000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
169	{"en":"Bouvet Island","ru":"\\u041e\\u0441\\u0442\\u0440\\u043e\\u0432 \\u0411\\u0443\\u0432\\u0435","oz":"Buve oroli"}	Bouvet Island	BV	BVT	074	0		active	2026-01-15 12:24:33	2026-01-15 12:24:33
170	{"en":"Brazil","ru":"\\u0411\\u0440\\u0430\\u0437\\u0438\\u043b\\u0438\\u044f","oz":"Braziliya"}	Brazil	BR	BRA	076	55	00-00000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
171	{"en":"British Indian Ocean Territory"}	British Indian Ocean Territory	IO	IOT	086	246	000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
172	{"en":"Brunei Darussalam","ru":"\\u0411\\u0440\\u0443\\u043d\\u0435\\u0439","oz":"Bruney"}	Brunei Darussalam	BN	BRN	096	673	000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
173	{"en":"Bulgaria","ru":"\\u0411\\u043e\\u043b\\u0433\\u0430\\u0440\\u0438\\u044f","oz":"Bolgariya"}	Bulgaria	BG	BGR	100	359	00-000-000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
174	{"en":"Burkina Faso","ru":"\\u0411\\u0443\\u0440\\u043a\\u0438\\u043d\\u0430-\\u0424\\u0430\\u0441\\u043e","oz":"Burkina Faso"}	Burkina Faso	BF	BFA	854	226	00-00-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
175	{"en":"Burundi","ru":"\\u0411\\u0443\\u0440\\u0443\\u043d\\u0434\\u0438","oz":"Burundi"}	Burundi	BI	BDI	108	257	00-00-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
176	{"en":"Cambodia","ru":"\\u041a\\u0430\\u043c\\u0431\\u043e\\u0434\\u0436\\u0430","oz":"Kambodja"}	Cambodia	KH	KHM	116	855	00-000-000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
177	{"en":"Cameroon","ru":"\\u041a\\u0430\\u043c\\u0435\\u0440\\u0443\\u043d","oz":"Kamerun"}	Cameroon	CM	CMR	120	237	0-000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
178	{"en":"Canada","ru":"\\u041a\\u0430\\u043d\\u0430\\u0434\\u0430","oz":"Kanada"}	Canada	CA	CAN	124	1	(000) 000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
179	{"en":"Cape Verde","ru":"\\u041a\\u0430\\u0431\\u043e-\\u0412\\u0435\\u0440\\u0434\\u0435","oz":"Kabo-Verde"}	Cape Verde	CV	CPV	132	238	000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
180	{"en":"Cayman Islands","ru":"\\u041a\\u0430\\u0439\\u043c\\u0430\\ufffd\\ufffd\\u043e\\u0432\\u044b \\u043e\\u0441\\u0442\\u0440\\u043e\\u0432\\u0430","oz":"Kayman orollari"}	Cayman Islands	KY	CYM	136	1345	000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
259	{"en":"Liberia","ru":"\\u041b\\u0438\\u0431\\u0435\\u0440\\u0438\\u044f","oz":"Liberiya"}	Liberia	LR	LBR	430	231	00-000-000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
181	{"en":"Central African Republic","ru":"\\u0426\\u0435\\u043d\\u0442\\u0440\\u0430\\u043b\\u044c\\u043d\\u043e\\u0430\\u0444\\u0440\\u0438\\u043a\\u0430\\u043d\\u0441\\u043a\\u0430\\u044f \\u0420\\u0435\\u0441\\u043f\\u0443\\u0431\\u043b\\u0438\\u043a\\u0430","oz":"Markaziy Afrika Respublikasi"}	Central African Republic	CF	CAF	140	236	00-00-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
182	{"en":"Chad","ru":"\\u0427\\u0430\\u0434","oz":"Chad"}	Chad	TD	TCD	148	235	00-00-00-00	active	2026-01-15 12:24:33	2026-01-15 12:24:33
183	{"en":"Chile","ru":"\\u0427\\u0438\\u043b\\u0438","oz":"Chili"}	Chile	CL	CHL	152	56	0-0000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
184	{"en":"China","ru":"\\u041a\\u0438\\u0442\\u0430\\u0439","oz":"Xitoy"}	China	CN	CHN	156	86	000-0000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
185	{"en":"Christmas Island","ru":"\\u041e\\u0441\\u0442\\u0440\\u043e\\u0432 \\u0420\\u043e\\u0436\\u0434\\u0435\\u0441\\u0442\\u0432\\u0430","oz":"Rojdestvo oroli"}	Christmas Island	CX	CXR	162	61	0-0000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
186	{"en":"Cocos (Keeling) Islands","ru":"\\u041a\\u043e\\u043a\\u043e\\u0441\\u043e\\u0432\\u044b\\u0435 \\u043e\\u0441\\u0442\\u0440\\u043e\\u0432\\u0430","oz":"Kokos orollari"}	Cocos (Keeling) Islands	CC	CCK	166	672	0-0000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
187	{"en":"Colombia","ru":"\\u041a\\u043e\\u043b\\u0443\\u043c\\u0431\\u0438\\u044f","oz":"Kolumbiya"}	Colombia	CO	COL	170	57	000-000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
188	{"en":"Comoros","ru":"\\u041a\\u043e\\u043c\\u043e\\u0440\\u0441\\u043a\\u0438\\u0435 \\u043e\\u0441\\u0442\\u0440\\u043e\\u0432\\u0430","oz":"Komor orollari"}	Comoros	KM	COM	174	269	00-00000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
189	{"en":"Congo","ru":"\\u041a\\u043e\\u043d\\u0433\\u043e","oz":"Kongo"}	Congo	CG	COG	178	242	00-000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
191	{"en":"Cook Islands","ru":"\\u041e\\u0441\\u0442\\u0440\\u043e\\u0432\\u0430 \\u041a\\u0443\\u043a\\u0430","oz":"Kuk orollari"}	Cook Islands	CK	COK	184	682	00-000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
192	{"en":"Costa Rica","ru":"\\u041a\\u043e\\u0441\\u0442\\u0430-\\u0420\\u0438\\u043a\\u0430","oz":"Kosta-Rika"}	Costa Rica	CR	CRI	188	506	0000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
194	{"en":"Croatia","ru":"\\u0425\\u043e\\u0440\\u0432\\u0430\\u0442\\u0438\\u044f","oz":"Xorvatiya"}	Croatia	HR	HRV	191	385	00-000-000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
195	{"en":"Cuba","ru":"\\u041a\\u0443\\u0431\\u0430","oz":"Kuba"}	Cuba	CU	CUB	192	53	0-000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
196	{"en":"Cyprus","ru":"\\u041a\\u0438\\u043f\\u0440","oz":"Kipr"}	Cyprus	CY	CYP	196	357	00-000-000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
197	{"en":"Czech Republic","ru":"\\u0427\\u0435\\u0448\\u0441\\u043a\\u0430\\u044f \\u0420\\u0435\\u0441\\u043f\\u0443\\u0431\\u043b\\u0438\\u043a\\u0430","oz":"Chexiya Respublikasi"}	Czech Republic	CZ	CZE	203	420	000-000-000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
198	{"en":"Denmark","ru":"\\u0414\\u0430\\u043d\\u0438\\u044f","oz":"Daniya"}	Denmark	DK	DNK	208	45	00-00-00-00	active	2026-01-15 12:24:33	2026-01-15 12:24:33
199	{"en":"Djibouti","ru":"\\u0414\\u0436\\u0438\\u0431\\u0443\\u0442\\u0438","oz":"Jibuti"}	Djibouti	DJ	DJI	262	253	00-00-00-00	active	2026-01-15 12:24:33	2026-01-15 12:24:33
200	{"en":"Dominica","ru":"\\u0414\\u043e\\u043c\\u0438\\u043d\\u0438\\u043a\\u0430","oz":"Dominika"}	Dominica	DM	DMA	212	1767	000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
201	{"en":"Dominican Republic","ru":"\\u0414\\u043e\\u043c\\u0438\\u043d\\u0438\\u043a\\u0430\\u043d\\u0441\\u043a\\u0430\\u044f \\u0420\\u0435\\u0441\\u043f\\u0443\\u0431\\u043b\\u0438\\u043a\\u0430","oz":"Dominikan Respublikasi"}	Dominican Republic	DO	DOM	214	1809	000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
202	{"en":"Ecuador","ru":"\\u042d\\u043a\\u0432\\u0430\\u0434\\u043e\\u0440","oz":"Ekvador"}	Ecuador	EC	ECU	218	593	0-000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
203	{"en":"Egypt","ru":"\\u0415\\u0433\\u0438\\u043f\\u0435\\u0442","oz":"Misr"}	Egypt	EG	EGY	818	20	00-0000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
204	{"en":"El Salvador","ru":"\\u0421\\u0430\\u043b\\u044c\\u0432\\u0430\\u0434\\u043e\\u0440","oz":"Salvador"}	El Salvador	SV	SLV	222	503	0000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
205	{"en":"Equatorial Guinea","ru":"\\u042d\\u043a\\u0432\\u0430\\u0442\\u043e\\u0440\\u0438\\u0430\\u043b\\u044c\\u043d\\u0430\\u044f \\u0413\\u0432\\u0438\\u043d\\u0435\\u044f","oz":"Ekvatorial Gvineya"}	Equatorial Guinea	GQ	GNQ	226	240	00-000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
206	{"en":"Eritrea","ru":"\\u042d\\u0440\\u0438\\u0442\\u0440\\u0435\\u044f","oz":"Eritreya"}	Eritrea	ER	ERI	232	291	0-000-000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
207	{"en":"Estonia","ru":"\\u042d\\u0441\\u0442\\u043e\\u043d\\u0438\\u044f","oz":"Estoniya"}	Estonia	EE	EST	233	372	0000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
208	{"en":"Ethiopia","ru":"\\u042d\\u0444\\u0438\\u043e\\u043f\\u0438\\u044f","oz":"Efiopiya"}	Ethiopia	ET	ETH	231	251	00-000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
209	{"en":"Falkland Islands (Malvinas)","ru":"\\u0424\\u043e\\u043b\\u043a\\u043b\\u0435\\u043d\\u0434\\u0441\\u043a\\u0438\\u0435 \\u043e\\u0441\\u0442\\u0440\\u043e\\u0432\\u0430","oz":"Folklend orollari"}	Falkland Islands (Malvinas)	FK	FLK	238	500	00000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
210	{"en":"Faroe Islands","ru":"\\u0424\\u0430\\u0440\\u0435\\u0440\\u0441\\u043a\\u0438\\u0435 \\u043e\\u0441\\u0442\\u0440\\u043e\\u0432\\u0430","oz":"Farer orollari"}	Faroe Islands	FO	FRO	234	298	000-000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
211	{"en":"Fiji","ru":"\\u0424\\u0438\\u0434\\u0436\\u0438","oz":"Fiji"}	Fiji	FJ	FJI	242	679	000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
212	{"en":"Finland","ru":"\\u0424\\u0438\\u043d\\u043b\\u044f\\u043d\\u0434\\u0438\\u044f","oz":"Finlyandiya"}	Finland	FI	FIN	246	358	00-000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
213	{"en":"France","ru":"\\u0424\\u0440\\u0430\\u043d\\u0446\\u0438\\u044f","oz":"Fransiya"}	France	FR	FRA	250	33	0-00-00-00-00	active	2026-01-15 12:24:33	2026-01-15 12:24:33
214	{"en":"French Guiana","ru":"\\u0424\\u0440\\u0430\\u043d\\u0446\\u0443\\u0437\\u0441\\u043a\\u0430\\u044f \\u0413\\u0432\\u0438\\u0430\\u043d\\u0430","oz":"Fransuz Gvianasi"}	French Guiana	GF	GUF	254	594	000-00-00-00	active	2026-01-15 12:24:33	2026-01-15 12:24:33
215	{"en":"French Polynesia","ru":"\\u0424\\u0440\\u0430\\u043d\\u0446\\u0443\\u0437\\u0441\\u043a\\u0430\\u044f \\u041f\\u043e\\u043b\\u0438\\u043d\\u0435\\u0437\\u0438\\u044f","oz":"Fransuz Polineziyasi"}	French Polynesia	PF	PYF	258	689	00-00-00	active	2026-01-15 12:24:33	2026-01-15 12:24:33
216	{"en":"French Southern Territories","ru":"\\u0424\\u0440\\u0430\\u043d\\u0446\\u0443\\u0437\\u0441\\u043a\\u0438\\u0435 \\u042e\\u0436\\u043d\\u044b\\u0435 \\u0422\\u0435\\u0440\\u0440\\u0438\\u0442\\u043e\\u0440\\u0438\\u0438","oz":"Fransuz Janubiy hududlari"}	French Southern Territories	TF	ATF	260	0		active	2026-01-15 12:24:33	2026-01-15 12:24:33
193	{"en": "Cote D'Ivoire","ru": "Cote D'Ivoire","oz": "Cote D'Ivoire"}\n	Cote D'Ivoire	CI	CIV	384	225	00-000-000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
260	{"en":"Libyan Arab Jamahiriya","ru":"\\u041b\\u0438\\u0432\\u0438\\u044f","oz":"Liviya"}	Libyan Arab Jamahiriya	LY	LBY	434	218	00-000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
261	{"en":"Liechtenstein","ru":"\\u041b\\u0438\\u0445\\u0442\\u0435\\u043d\\u0448\\u0442\\u0435\\u0439\\u043d","oz":"Lixtenshteyn"}	Liechtenstein	LI	LIE	438	423	000-000-000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
262	{"en":"Lithuania","ru":"\\u041b\\u0438\\u0442\\u0432\\u0430","oz":"Litva"}	Lithuania	LT	LTU	440	370	000-00-000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
263	{"en":"Luxembourg","ru":"\\u041b\\u044e\\u043a\\u0441\\u0435\\u043c\\u0431\\u0443\\u0440\\u0433","oz":"Lyuksemburg"}	Luxembourg	LU	LUX	442	352	000-000-000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
264	{"en":"Macao","ru":"\\u041c\\u0430\\u043a\\u0430\\u043e","oz":"Makao"}	Macao	MO	MAC	446	853	0000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
266	{"en":"Madagascar","ru":"\\u041c\\u0430\\u0434\\u0430\\u0433\\u0430\\u0441\\u043a\\u0430\\u0440","oz":"Madagaskar"}	Madagascar	MG	MDG	450	261	00-00-00000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
267	{"en":"Malawi","ru":"\\u041c\\u0430\\u043b\\u0430\\u0432\\u0438","oz":"Malavi"}	Malawi	MW	MWI	454	265	0-000-000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
268	{"en":"Malaysia","ru":"\\u041c\\u0430\\u043b\\u0430\\u0439\\u0437\\u0438\\u044f","oz":"Malayziya"}	Malaysia	MY	MYS	458	60	00-000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
269	{"en":"Maldives","ru":"\\u041c\\u0430\\u043b\\u044c\\u0434\\u0438\\u0432\\u044b","oz":"Maldiv orollari"}	Maldives	MV	MDV	462	960	000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
270	{"en":"Mali","ru":"\\u041c\\u0430\\u043b\\u0438","oz":"Mali"}	Mali	ML	MLI	466	223	00-00-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
271	{"en":"Malta","ru":"\\u041c\\u0430\\u043b\\u044c\\u0442\\u0430","oz":"Malta"}	Malta	MT	MLT	470	356	0000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
272	{"en":"Marshall Islands","ru":"\\u041c\\u0430\\u0440\\u0448\\u0430\\u043b\\u043b\\u043e\\u0432\\u044b \\u041e\\u0441\\u0442\\u0440\\u043e\\u0432\\u0430","oz":"Marshal orollari"}	Marshall Islands	MH	MHL	584	692	000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
273	{"en":"Martinique","ru":"\\u041c\\u0430\\u0440\\u0442\\u0438\\u043d\\u0438\\u043a\\u0430","oz":"Martinika"}	Martinique	MQ	MTQ	474	596	000-00-00-00	active	2026-01-15 12:24:33	2026-01-15 12:24:33
274	{"en":"Mauritania","ru":"\\u041c\\u0430\\u0432\\u0440\\u0438\\u0442\\u0430\\u043d\\u0438\\u044f","oz":"Mavritaniya"}	Mauritania	MR	MRT	478	222	00-00-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
275	{"en":"Mauritius","ru":"\\u041c\\u0430\\u0432\\u0440\\u0438\\u043a\\u0438\\u0439","oz":"Mavrikiy"}	Mauritius	MU	MUS	480	230	000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
276	{"en":"Mayotte","ru":"\\u041c\\u0430\\u0439\\u043e\\u0442\\u0442\\u0430","oz":"Mayotta"}	Mayotte	YT	MYT	175	269	00-00000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
277	{"en":"Mexico","ru":"\\u041c\\u0435\\u043a\\u0441\\u0438\\u043a\\u0430","oz":"Meksika"}	Mexico	MX	MEX	484	52	00-0000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
280	{"en":"Monaco","ru":"\\u041c\\u043e\\u043d\\u0430\\u043a\\u043e","oz":"Monako"}	Monaco	MC	MCO	492	377	00-00-00-00-00	active	2026-01-15 12:24:33	2026-01-15 12:24:33
281	{"en":"Mongolia","ru":"\\u041c\\u043e\\u043d\\u0433\\u043e\\u043b\\u0438\\u044f","oz":"Mo'g'uliston"}	Mongolia	MN	MNG	496	976	00-00-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
282	{"en":"Montserrat","ru":"\\u041c\\u043e\\u043d\\u0442\\u0441\\u0435\\u0440\\u0440\\u0430\\u0442","oz":"Montserrat"}	Montserrat	MS	MSR	500	1664	000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
283	{"en":"Morocco","ru":"\\u041c\\u0430\\u0440\\u043e\\u043a\\u043a\\u043e","oz":"Marokash"}	Morocco	MA	MAR	504	212	00-0000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
284	{"en":"Mozambique","ru":"\\u041c\\u043e\\u0437\\u0430\\u043c\\u0431\\u0438\\u043a","oz":"Mozambik"}	Mozambique	MZ	MOZ	508	258	00-000-000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
285	{"en":"Myanmar","ru":"\\u041c\\u044c\\u044f\\u043d\\u043c\\u0430","oz":"Myanma"}	Myanmar	MM	MMR	104	95	0-000-000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
286	{"en":"Namibia","ru":"\\u041d\\u0430\\u043c\\u0438\\u0431\\u0438\\u044f","oz":"Namibiya"}	Namibia	NA	NAM	516	264	00-000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
287	{"en":"Nauru","ru":"\\u041d\\u0430\\u0443\\u0440\\u0443","oz":"Nauru"}	Nauru	NR	NRU	520	674	000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
288	{"en":"Nepal","ru":"\\u041d\\u0435\\u043f\\u0430\\u043b","oz":"Nepal"}	Nepal	NP	NPL	524	977	00-000-000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
289	{"en":"Netherlands Antilles","ru":"\\u041d\\u0438\\u0434\\u0435\\u0440\\u043b\\u0430\\u043d\\u0434\\u0441\\u043a\\u0438\\u0435 \\u0410\\u043d\\u0442\\u0438\\u043b\\u044c\\u0441\\u043a\\u0438\\u0435 \\u043e\\u0441\\u0442\\u0440\\u043e\\u0432\\u0430","oz":"Niderlandiya Antil orollari"}	Netherlands Antilles	NL	ANT	530	599	000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
290	{"en":"New Caledonia","ru":"\\u041d\\u043e\\u0432\\u0430\\u044f \\u041a\\u0430\\u043b\\u0435\\u0434\\u043e\\u043d\\u0438\\u044f","oz":"Yangi Kaledoniya"}	New Caledonia	NC	NCL	540	687	00-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
291	{"en":"New Zealand","ru":"\\u041d\\u043e\\u0432\\u0430\\u044f \\u0417\\u0435\\u043b\\u0430\\u043d\\u0434\\u0438\\u044f","oz":"Yangi Zelandiya"}	New Zealand	NZ	NZL	554	64	00-000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
292	{"en":"Nicaragua","ru":"\\u041d\\u0438\\u043a\\u0430\\u0440\\u0430\\u0433\\u0443\\u0430","oz":"Nikaragua"}	Nicaragua	NI	NIC	558	505	0000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
293	{"en":"Niger","ru":"\\u041d\\u0438\\u0433\\u0435\\u0440","oz":"Niger"}	Niger	NE	NER	562	227	00-00-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
294	{"en":"Nigeria","ru":"\\u041d\\u0438\\u0433\\u0435\\u0440\\u0438\\u044f","oz":"Nigeriya"}	Nigeria	NG	NGA	566	234	00-0000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
295	{"en":"Niue","ru":"\\u041d\\u0438\\u0443\\u044d","oz":"Niue"}	Niue	NU	NIU	570	683	0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
296	{"en":"Norfolk Island","ru":"\\u041e\\u0441\\u0442\\u0440\\u043e\\u0432 \\u041d\\u043e\\u0440\\u0444\\u043e\\u043b\\u043a","oz":"Norfolk oroli"}	Norfolk Island	NF	NFK	574	672	0-0000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
297	{"en":"Northern Mariana Islands","ru":"\\u0421\\u0435\\u0432\\u0435\\u0440\\u043d\\u044b\\u0435 \\u041c\\u0430\\u0440\\u0438\\u0430\\u043d\\u0441\\u043a\\u0438\\u0435 \\u043e\\u0441\\u0442\\u0440\\u043e\\u0432\\u0430","oz":"Shimoliy Mariana orollari"}	Northern Mariana Islands	MP	MNP	580	1670	000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
298	{"en":"Norway","ru":"\\u041d\\u043e\\u0440\\u0432\\u0435\\u0433\\u0438\\u044f","oz":"Norvegiya"}	Norway	NO	NOR	578	47	000-00-000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
265	{ "en":"the Former Yugoslav Republic of", "ru":"Македония","oz": "Makedoniya"}\n	Macedonia 	MK	MKD	807	389	00-000-000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
278	{ "en":"Micronesia, Federated States of", "ru":"Микронезия","oz":"Mikroneziya"}	Micronesia	FM	FSM	583	691	000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
300	{"en":"Pakistan","ru":"\\u041f\\u0430\\u043a\\u0438\\u0441\\u0442\\u0430\\u043d","oz":"Pokiston"}	Pakistan	PK	PAK	586	92	000-0000000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
301	{"en":"Palau","ru":"\\u041f\\u0430\\u043b\\u0430\\u0443","oz":"Palau"}	Palau	PW	PLW	585	680	000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
303	{"en":"Panama","ru":"\\u041f\\u0430\\u043d\\u0430\\u043c\\u0430","oz":"Panama"}	Panama	PA	PAN	591	507	000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
304	{"en":"Papua New Guinea","ru":"\\u041f\\u0430\\u043f\\u0443\\u0430 \\u2014 \\u041d\\u043e\\u0432\\u0430\\u044f \\u0413\\u0432\\u0438\\u043d\\u0435\\u044f","oz":"Papua Yangi Gvineya"}	Papua New Guinea	PG	PNG	598	675	000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
305	{"en":"Paraguay","ru":"\\u041f\\u0430\\u0440\\u0430\\u0433\\u0432\\u0430\\u0439","oz":"Paragvay"}	Paraguay	PY	PRY	600	595	00-000-000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
306	{"en":"Peru","ru":"\\u041f\\u0435\\u0440\\u0443","oz":"Peru"}	Peru	PE	PER	604	51	00-000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
307	{"en":"Philippines","ru":"\\u0424\\u0438\\u043b\\u0438\\u043f\\u043f\\u0438\\u043d\\u044b","oz":"Filippin"}	Philippines	PH	PHL	608	63	000-000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
308	{"en":"Pitcairn","ru":"\\u041f\\u0438\\u0442\\u043a\\u044d\\u0440\\u043d","oz":"Pitkern"}	Pitcairn	PN	PCN	612	0		active	2026-01-15 12:24:33	2026-01-15 12:24:33
309	{"en":"Poland","ru":"\\u041f\\u043e\\u043b\\u044c\\u0448\\u0430","oz":"Polsha"}	Poland	PL	POL	616	48	00-000-00-00	active	2026-01-15 12:24:33	2026-01-15 12:24:33
310	{"en":"Portugal","ru":"\\u041f\\u043e\\u0440\\u0442\\u0443\\u0433\\u0430\\u043b\\u0438\\u044f","oz":"Portugaliya"}	Portugal	PT	PRT	620	351	00-000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
311	{"en":"Puerto Rico","ru":"\\u041f\\u0443\\u044d\\u0440\\u0442\\u043e-\\u0420\\u0438\\u043a\\u043e","oz":"Puerto-Riko"}	Puerto Rico	PR	PRI	630	1787	000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
312	{"en":"Qatar","ru":"\\u041a\\u0430\\u0442\\u0430\\u0440","oz":"Qatar"}	Qatar	QA	QAT	634	974	0000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
313	{"en":"Reunion","ru":"\\u0420\\u0435\\u044e\\u043d\\u044c\\u043e\\u043d","oz":"Reyunion"}	Reunion	RE	REU	638	262	000-00-00-00	active	2026-01-15 12:24:33	2026-01-15 12:24:33
314	{"en":"Romania","ru":"\\u0420\\u0443\\u043c\\u044b\\u043d\\u0438\\u044f","oz":"Ruminiya"}	Romania	RO	ROM	642	40	00-000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
315	{"en":"Russian Federation","ru":"\\u0420\\u043e\\u0441\\u0441\\u0438\\u0439\\u0441\\u043a\\u0430\\u044f \\u0424\\u0435\\u0434\\u0435\\u0440\\u0430\\u0446\\u0438\\u044f","oz":"Rossiya Federatsiyasi"}	Russian Federation	RU	RUS	643	70	(000) 000-00-00	active	2026-01-15 12:24:33	2026-01-15 12:24:33
316	{"en":"Rwanda","ru":"\\u0420\\u0443\\u0430\\u043d\\u0434\\u0430","oz":"Ruanda"}	Rwanda	RW	RWA	646	250	000-000-000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
317	{"en":"Saint Helena","ru":"\\u041e\\u0441\\u0442\\u0440\\u043e\\u0432 \\u0421\\u0432\\u044f\\u0442\\u043e\\u0439 \\u0415\\u043b\\u0435\\u043d\\u044b","oz":"Avliyo Yelena oroli"}	Saint Helena	SH	SHN	654	290	0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
318	{"en":"Saint Kitts and Nevis","ru":"\\u0421\\u0435\\u043d\\u0442-\\u041a\\u0438\\u0442\\u0441 \\u0438 \\u041d\\u0435\\u0432\\u0438\\u0441","oz":"Sent-Kits va Nevis"}	Saint Kitts and Nevis	KN	KNA	659	1869	000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
319	{"en":"Saint Lucia","ru":"\\u0421\\u0435\\u043d\\u0442-\\u041b\\u044e\\u0441\\u0438\\u044f","oz":"Sent-Lyusiya"}	Saint Lucia	LC	LCA	662	1758	000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
320	{"en":"Saint Pierre and Miquelon","ru":"\\u0421\\u0435\\u043d-\\u041f\\u044c\\u0435\\u0440 \\u0438 \\u041c\\u0438\\u043a\\u0435\\u043b\\u043e\\u043d","oz":"Sen-Pyer va Mikelon"}	Saint Pierre and Miquelon	PM	SPM	666	508	00-00-00	active	2026-01-15 12:24:33	2026-01-15 12:24:33
321	{"en":"Saint Vincent and the Grenadines","ru":"\\u0421\\u0435\\u043d\\u0442-\\u0412\\u0438\\u043d\\u0441\\u0435\\u043d\\u0442 \\u0438 \\u0413\\u0440\\u0435\\u043d\\u0430\\u0434\\u0438\\u043d\\u044b","oz":"Sent-Vinsent va Grenadinlar"}	Saint Vincent and the Grenadines	VC	VCT	670	1784	000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
322	{"en":"Samoa","ru":"\\u0421\\u0430\\u043c\\u043e\\u0430","oz":"Samoa"}	Samoa	WS	WSM	882	684	000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
323	{"en":"San Marino","ru":"\\u0421\\u0430\\u043d-\\u041c\\u0430\\u0440\\u0438\\u043d\\u043e","oz":"San-Marino"}	San Marino	SM	SMR	674	378	0000-000000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
324	{"en":"Sao Tome and Principe","ru":"\\u0421\\u0430\\u043d-\\u0422\\u043e\\u043c\\u0435 \\u0438 \\u041f\\u0440\\u0438\\u043d\\u0441\\u0438\\u043f\\u0438","oz":"San-Tome va Prinsipi"}	Sao Tome and Principe	ST	STP	678	239	00-00000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
325	{"en":"Saudi Arabia","ru":"\\u0421\\u0430\\u0443\\u0434\\u043e\\u0432\\u0441\\u043a\\u0430\\u044f \\u0410\\u0440\\u0430\\u0432\\u0438\\u044f","oz":"Saudiya Arabistoni"}	Saudi Arabia	SA	SAU	682	966	0-000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
326	{"en":"Senegal","ru":"\\u0421\\u0435\\u043d\\u0435\\u0433\\u0430\\u043b","oz":"Senegal"}	Senegal	SN	SEN	686	221	00-000-00-00	active	2026-01-15 12:24:33	2026-01-15 12:24:33
327	{"en":"Serbia and Montenegro","ru":"\\u0421\\u0435\\u0440\\u0431\\u0438\\u044f \\u0438 \\u0427\\u0435\\u0440\\u043d\\u043e\\u0433\\u043e\\u0440\\u0438\\u044f","oz":"Serbiya va Chernogoriya"}	Serbia and Montenegro	RS	SRB	688	381	00-000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
328	{"en":"Seychelles","ru":"\\u0421\\u0435\\u0439\\u0448\\u0435\\u043b\\u044c\\u0441\\u043a\\u0438\\u0435 \\u041e\\u0441\\u0442\\u0440\\u043e\\u0432\\u0430","oz":"Seyshel orollari"}	Seychelles	SC	SYC	690	248	0-000-000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
329	{"en":"Sierra Leone","ru":"\\u0421\\u044c\\u0435\\u0440\\u0440\\u0430-\\u041b\\u0435\\u043e\\u043d\\u0435","oz":"Syerra-Leone"}	Sierra Leone	SL	SLE	694	232	00-000000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
330	{"en":"Singapore","ru":"\\u0421\\u0438\\u043d\\u0433\\u0430\\u043f\\u0443\\u0440","oz":"Singapur"}	Singapore	SG	SGP	702	65	0000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
331	{"en":"Slovakia","ru":"\\u0421\\u043b\\u043e\\u0432\\u0430\\u043a\\u0438\\u044f","oz":"Slovakiya"}	Slovakia	SK	SVK	703	421	000-000-000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
332	{"en":"Slovenia","ru":"\\u0421\\u043b\\u043e\\u0432\\u0435\\u043d\\u0438\\u044f","oz":"Sloveniya"}	Slovenia	SI	SVN	705	386	00-000-000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
333	{"en":"Solomon Islands","ru":"\\u0421\\u043e\\u043b\\u043e\\u043c\\u043e\\u043d\\u043e\\u0432\\u044b \\u041e\\u0441\\u0442\\u0440\\u043e\\u0432\\u0430","oz":"Solomon orollari"}	Solomon Islands	SB	SLB	090	677	00-00000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
334	{"en":"Somalia","ru":"\\u0421\\u043e\\u043c\\u0430\\u043b\\u0438","oz":"Somali"}	Somalia	SO	SOM	706	252	0-000-000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
335	{"en":"South Africa","ru":"\\u042e\\u0436\\u043d\\u0430\\u044f \\u0410\\u0444\\u0440\\u0438\\u043a\\u0430","oz":"Janubiy Afrika"}	South Africa	ZA	ZAF	710	27	00-000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
372	{"en":"Wallis and Futuna","ru":"\\u0423\\u043e\\u043b\\u043b\\u0438\\u0441 \\u0438 \\u0424\\u0443\\u0442\\u0443\\u043d\\u0430","oz":"Uollis va Futuna"}	Wallis and Futuna	WF	WLF	876	681	00-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
337	{"en":"Spain","ru":"\\u0418\\u0441\\u043f\\u0430\\u043d\\u0438\\u044f","oz":"Ispaniya"}	Spain	ES	ESP	724	34	000-000-000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
338	{"en":"Sri Lanka","ru":"\\u0428\\u0440\\u0438-\\u041b\\u0430\\u043d\\u043a\\u0430","oz":"Shri-Lanka"}	Sri Lanka	LK	LKA	144	94	00-000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
339	{"en":"Sudan","ru":"\\u0421\\u0443\\u0434\\u0430\\u043d","oz":"Sudan"}	Sudan	SD	SDN	736	249	00-000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
340	{"en":"Suriname","ru":"\\u0421\\u0443\\u0440\\u0438\\u043d\\u0430\\u043c","oz":"Surinam"}	Suriname	SR	SUR	740	597	000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
341	{"en":"Svalbard and Jan Mayen","ru":"\\u0428\\u043f\\u0438\\u0446\\u0431\\u0435\\u0440\\u0433\\u0435\\u043d \\u0438 \\u042f\\u043d-\\u041c\\u0430\\u0439\\u0435\\u043d","oz":"Shpitsbergen va Yan-Mayen"}	Svalbard and Jan Mayen	SJ	SJM	744	47	000-00-000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
342	{"en":"Swaziland","ru":"\\u0421\\u0432\\u0430\\u0437\\u0438\\u043b\\u0435\\u043d\\u0434","oz":"Svaziland"}	Swaziland	SZ	SWZ	748	268	00-00-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
343	{"en":"Sweden","ru":"\\u0428\\u0432\\u0435\\u0446\\u0438\\u044f","oz":"Shvetsiya"}	Sweden	SE	SWE	752	46	00-000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
344	{"en":"Switzerland","ru":"\\u0428\\u0432\\u0435\\u0439\\u0446\\u0430\\u0440\\u0438\\u044f","oz":"Shveytsariya"}	Switzerland	CH	CHE	756	41	00-000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
345	{"en":"Syrian Arab Republic","ru":"\\u0421\\u0438\\u0440\\u0438\\u044f","oz":"Suriya"}	Syrian Arab Republic	SY	SYR	760	963	00-0000-000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
347	{"en":"Tajikistan","ru":"\\u0422\\u0430\\u0434\\u0436\\u0438\\u043a\\u0438\\u0441\\u0442\\u0430\\u043d","oz":"Tojikiston"}	Tajikistan	TJ	TJK	762	992	00-000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
349	{"en":"Thailand","ru":"\\u0422\\u0430\\u0438\\u043b\\u0430\\u043d\\u0434","oz":"Tailand"}	Thailand	TH	THA	764	66	00-000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
350	{"en":"Timor-Leste","ru":"\\u0412\\u043e\\u0441\\u0442\\u043e\\u0447\\u043d\\u044b\\u0439 \\u0422\\u0438\\u043c\\u043e\\u0440","oz":"Sharqiy Timor"}	Timor-Leste	TL	TLS	626	670	000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
351	{"en":"Togo","ru":"\\u0422\\u043e\\u0433\\u043e","oz":"Togo"}	Togo	TG	TGO	768	228	00-000-000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
352	{"en":"Tokelau","ru":"\\u0422\\u043e\\u043a\\u0435\\u043b\\u0430\\u0443","oz":"Tokelau"}	Tokelau	TK	TKL	772	690	0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
353	{"en":"Tonga","ru":"\\u0422\\u043e\\u043d\\u0433\\u0430","oz":"Tonga"}	Tonga	TO	TON	776	676	00000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
354	{"en":"Trinidad and Tobago","ru":"\\u0422\\u0440\\u0438\\u043d\\u0438\\u0434\\u0430\\u0434 \\u0438 \\u0422\\u043e\\u0431\\u0430\\u0433\\u043e","oz":"Trinidad va Tobago"}	Trinidad and Tobago	TT	TTO	780	1868	000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
355	{"en":"Tunisia","ru":"\\u0422\\u0443\\u043d\\u0438\\u0441","oz":"Tunis"}	Tunisia	TN	TUN	788	216	00-000-000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
356	{"en":"Turkey","ru":"\\u0422\\u0443\\u0440\\u0446\\u0438\\u044f","oz":"Turkiya"}	Turkey	TR	TUR	792	90	000-000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
357	{"en":"Turkmenistan","ru":"\\u0422\\u0443\\u0440\\u043a\\u043c\\u0435\\u043d\\u0438\\u0441\\u0442\\u0430\\u043d","oz":"Turkmaniston"}	Turkmenistan	TM	TKM	795	7370	0-000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
358	{"en":"Turks and Caicos Islands","ru":"\\u0422\\u0435\\u0440\\u043a\\u0441 \\u0438 \\u041a\\u0430\\u0439\\u043a\\u043e\\u0441","oz":"Terks va Kaykos orollari"}	Turks and Caicos Islands	TC	TCA	796	1649	000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
359	{"en":"Tuvalu","ru":"\\u0422\\u0443\\u0432\\u0430\\u043b\\u0443","oz":"Tuvalu"}	Tuvalu	TV	TUV	798	688	00000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
360	{"en":"Uganda","ru":"\\u0423\\u0433\\u0430\\u043d\\u0434\\u0430","oz":"Uganda"}	Uganda	UG	UGA	800	256	00-000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
361	{"en":"Ukraine","ru":"\\u0423\\u043a\\u0440\\u0430\\u0438\\u043d\\u0430","oz":"Ukraina"}	Ukraine	UA	UKR	804	380	00-000-00-00	active	2026-01-15 12:24:33	2026-01-15 12:24:33
362	{"en":"United Arab Emirates","ru":"\\u041e\\u0431\\u044a\\u0435\\u0434\\u0438\\u043d\\u0451\\u043d\\u043d\\u044b\\u0435 \\u0410\\u0440\\u0430\\u0431\\u0441\\u043a\\u0438\\u0435 \\u042d\\u043c\\u0438\\u0440\\u0430\\u0442\\u044b","oz":"Birlashgan Arab Amirliklari"}	United Arab Emirates	AE	ARE	784	971	0-000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
363	{"en":"United Kingdom","ru":"\\u0412\\u0435\\u043b\\u0438\\u043a\\u043e\\u0431\\u0440\\u0438\\u0442\\u0430\\u043d\\u0438\\u044f","oz":"Buyuk Britaniya"}	United Kingdom	GB	GBR	826	44	00-0000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
364	{"en":"United States","ru":"\\u0421\\u043e\\u0435\\u0434\\u0438\\u043d\\u0451\\u043d\\u043d\\u044b\\u0435 \\u0428\\u0442\\u0430\\u0442\\u044b","oz":"Amerika Qo'shma Shtatlari"}	United States	US	USA	840	1	(000) 000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
365	{"en":"United States Minor Outlying Islands","ru":"\\u0412\\u043d\\u0435\\u0448\\u043d\\u0438\\u0435 \\u043c\\u0430\\u043b\\u044b\\u0435 \\u043e\\u0441\\u0442\\u0440\\u043e\\u0432\\u0430 \\u0421\\u0428\\u0410","oz":"AQSh tashqi kichik orollari"}	United States Minor Outlying Islands	UM	UMI	581	1	(000) 000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
366	{"en":"Uruguay","ru":"\\u0423\\u0440\\u0443\\u0433\\u0432\\u0430\\u0439","oz":"Urugvay"}	Uruguay	UY	URY	858	598	0-000-00-00	active	2026-01-15 12:24:33	2026-01-15 12:24:33
367	{"en":"Uzbekistan","ru":"\\u0423\\u0437\\u0431\\u0435\\u043a\\u0438\\u0441\\u0442\\u0430\\u043d","oz":"O'zbekiston"}	Uzbekistan	UZ	UZB	860	998	00-000-00-00	active	2026-01-15 12:24:33	2026-01-15 12:24:33
368	{"en":"Vanuatu","ru":"\\u0412\\u0430\\u043d\\u0443\\u0430\\u0442\\u0443","oz":"Vanuatu"}	Vanuatu	VU	VUT	548	678	00-00000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
369	{"en":"Venezuela","ru":"\\u0412\\u0435\\u043d\\u0435\\u0441\\u0443\\u044d\\u043b\\u0430","oz":"Venesuela"}	Venezuela	VE	VEN	862	58	000-000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
370	{"en":"Viet Nam","ru":"\\u0412\\u044c\\u0435\\u0442\\u043d\\u0430\\u043c","oz":"Vyetnam"}	Viet Nam	VN	VNM	704	84	00-0000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
348	{"en": "Tanzania, United Republic of","ru": "Танзания","oz": "Tanzaniya"}\n	Tanzania 	TZ	TZA	834	255	00-000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
346	{"en": "Taiwan, Province of China","ru": "Тайвань","oz": "Tayvan"}\n	Taiwan 	TW	TWN	158	886	0-0000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
336	{"en":"South Georgia and the South Sandwich Islands","ru":"\\u042e\\u0436\\u043d\\u0430\\u044f \\u0413\\u0435\\u043e\\u0440\\u0433\\u0438\\u044f \\u0438 \\u042e\\u0436\\u043d\\u044b\\u0435 \\u0421\\u0430\\u043d\\u0434\\u0432\\u0438\\u0447\\u0435\\u0432\\u044b \\u041e\\u0441\\u0442\\u0440\\u043e\\u0432\\u0430","oz":"Janubiy Georgiya va Janubiy Sendvich orollari"}	South Georgia and the South Sandwich Islands	GS	SGS	239	500\n	0000\n	active	2026-01-15 12:24:33	2026-01-15 12:24:33
373	{"en":"Western Sahara","ru":"\\u0417\\u0430\\u043f\\u0430\\u0434\\u043d\\u0430\\u044f \\u0421\\u0430\\u0445\\u0430\\u0440\\u0430","oz":"G'arbiy Sahro"}	Western Sahara	EH	ESH	732	212	00-0000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
374	{"en":"Yemen","ru":"\\u0419\\u0435\\u043c\\u0435\\u043d","oz":"Yaman"}	Yemen	YE	YEM	887	967	0-000-000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
375	{"en":"Zambia","ru":"\\u0417\\u0430\\u043c\\u0431\\u0438\\u044f","oz":"Zambiya"}	Zambia	ZM	ZMB	894	260	00-000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
376	{"en":"Zimbabwe","ru":"\\u0417\\u0438\\u043c\\u0431\\u0430\\u0431\\u0432\\u0435","oz":"Zimbabve"}	Zimbabwe	ZW	ZWE	716	263	0-000000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
371	{"en": "Virgin Islands, U.s.","ru": "Виргинские Острова (США)","oz": "Virgin orollari (AQSH)"}\n	Virgin Islands, U.s.	VI	VIR	850	1340	000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
302	{"en": "Palestinian Territory, Occupied","ru": "Палестина","oz": "Falastin"}\n	Palestinian Territory, Occupied	PS	PSE	275	970	00-000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
279	{"en": "Moldova, Republic of","ru":"Молдова","oz":"Moldova"}	Moldova 	MD	MDA	498	373	00-000-000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
252	{"en": "Republic of","ru": "Республика Корея","oz": "Janubiy Koreya"}\n	Korea 	KR	KOR	410	82	00-0000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
190	{"en": "the Democratic Republic of the","ru": "Демократическая Республика Конго","oz": "Kongo Demokratik Respublikasi"}\n	Congo	CD	COD	180	242	00-000-0000	active	2026-01-15 12:24:33	2026-01-15 12:24:33
\.


--
-- Data for Name: failed_jobs; Type: TABLE DATA; Schema: public; Owner: vatandoshlar_usr
--

COPY public.failed_jobs (id, uuid, connection, queue, payload, exception, failed_at) FROM stdin;
\.


--
-- Data for Name: form_images; Type: TABLE DATA; Schema: public; Owner: vatandoshlar_usr
--

COPY public.form_images (id, support_id, type, size, image, created_at, updated_at) FROM stdin;
1	108	participation	2413	supports/e8b576c4-62f8-4282-bb31-61decd15e290.png	2026-01-12 12:29:43	2026-01-12 12:29:43
2	108	participation	1642	supports/1d6b0aee-447b-4b36-bdb5-3899994849dc.png	2026-01-12 12:29:43	2026-01-12 12:29:43
3	109	participation	2413	supports/f417b5cd-c8e2-43a3-b8d8-2d320148a1d0.png	2026-01-12 12:30:04	2026-01-12 12:30:04
4	109	participation	1642	supports/676f55d7-0357-4bcf-8275-0508bb1d5b5d.png	2026-01-12 12:30:04	2026-01-12 12:30:04
5	111	participation	1252	supports/a9664b71-7afd-4651-a47b-f3cdc4799e2b.png	2026-01-12 13:06:21	2026-01-12 13:06:21
6	111	participation	1194	supports/38b73994-a18c-40bb-8794-bf1561bbf261.png	2026-01-12 13:06:21	2026-01-12 13:06:21
7	13	participation	751123	supports/d048ec04-749d-4941-aa0a-023e759dc72f.png	2026-01-19 12:00:13	2026-01-19 12:00:13
8	158	participation	95384	supports/c79358a4-7e20-4cbf-9194-48ad49fe0526.pdf	2026-01-28 10:30:51	2026-01-28 10:30:51
9	159	participation	152907	supports/56f1135f-ed61-48f6-bbf0-9304202e8c92.jpg	2026-01-28 10:38:36	2026-01-28 10:38:36
10	160	participation	95384	supports/6f67ef40-7d33-445d-b6d7-93587587b941.pdf	2026-01-28 11:50:07	2026-01-28 11:50:07
11	161	participation	95384	supports/bab4dabf-cd7b-4aa3-ac8f-34eacb50a28c.pdf	2026-01-28 11:54:23	2026-01-28 11:54:23
12	162	participation	95384	supports/fd809824-2965-41a9-bb7f-99ecaed5d165.pdf	2026-01-28 11:56:26	2026-01-28 11:56:26
\.


--
-- Data for Name: job_batches; Type: TABLE DATA; Schema: public; Owner: vatandoshlar_usr
--

COPY public.job_batches (id, name, total_jobs, pending_jobs, failed_jobs, failed_job_ids, options, cancelled_at, created_at, finished_at) FROM stdin;
\.


--
-- Data for Name: jobs; Type: TABLE DATA; Schema: public; Owner: vatandoshlar_usr
--

COPY public.jobs (id, queue, payload, attempts, reserved_at, available_at, created_at) FROM stdin;
\.


--
-- Data for Name: lang_images; Type: TABLE DATA; Schema: public; Owner: vatandoshlar_usr
--

COPY public.lang_images (id, image, compressed, type, size, main, status, created_at, updated_at, lang_id, sort_order) FROM stdin;
8	langs/a0db849a-19a4-4ca7-9e07-f2f5ec1085d4487.png	\N	image/png	9976	t	t	2026-01-17 10:47:09	2026-01-17 10:47:22	2	\N
9	langs/a0db84b5-a253-441e-a7ec-2e0f238547f1375.png	\N	image/png	1743	t	t	2026-01-17 10:47:27	2026-01-17 10:47:32	3	\N
10	langs/a0db84c5-509b-41cf-be5e-f9c8a8e221f2138.png	\N	image/png	18142	t	t	2026-01-17 10:47:38	2026-01-17 10:47:42	1	\N
11	langs/a0f3cbec-554e-47d9-adec-5baaa2c2e23b430.png	\N	image/png	22646	t	t	2026-01-29 12:26:27	2026-01-29 12:26:27	4	\N
\.


--
-- Data for Name: langs; Type: TABLE DATA; Schema: public; Owner: vatandoshlar_usr
--

COPY public.langs (id, code, name, is_default, status, locale, flag_icon, sort_order, created_at, updated_at, short_name) FROM stdin;
1	en	English	t	t	en_US	flags/en.svg	3	2025-12-23 04:21:31	2026-01-22 07:58:50	Eng
4	tr	Turkcha	f	f	\N	\N	0	2026-01-29 12:26:27	2026-01-29 13:48:23	\N
2	uz	O'zbek	t	t	uz_UZ	flags/uz.svg	1	2025-12-23 04:21:31	2026-02-02 09:57:43	O'zb
3	ru	Русский	t	t	ru_RU	flags/ru.svg	2	2025-12-23 04:21:31	2026-02-02 09:58:02	Рус
\.


--
-- Data for Name: menu_main_images; Type: TABLE DATA; Schema: public; Owner: vatandoshlar_usr
--

COPY public.menu_main_images (id, menu_main_id, image, compressed, type, size, main, status, created_at, updated_at, sort_order) FROM stdin;
1	49	menu_images/1768286270_Group 35.png	\N	image/png	1252	f	t	2026-01-13 06:37:50	2026-01-13 06:37:50	\N
\.


--
-- Data for Name: menu_main_settings; Type: TABLE DATA; Schema: public; Owner: vatandoshlar_usr
--

COPY public.menu_main_settings (id, key, label, type, required, is_translatable, options, sort_order, relation, status, created_at, updated_at) FROM stdin;
1	title	Title	text	t	t	\N	1	\N	t	\N	\N
2	description	Description	text	t	t	\N	1	\N	t	\N	\N
3	info	Info	textarea-editor	t	t	\N	1	\N	t	2025-12-30 06:09:52	2025-12-30 06:09:52
\.


--
-- Data for Name: menu_main_translations; Type: TABLE DATA; Schema: public; Owner: vatandoshlar_usr
--

COPY public.menu_main_translations (id, menu_main_id, locale, data, created_at, updated_at) FROM stdin;
5	3	uz	{"title": "Statistika", "description": null}	2025-12-23 04:25:08	2025-12-23 04:25:08
6	3	ru	{"title": null, "description": null}	2025-12-23 04:25:08	2025-12-23 04:25:08
43	22	uz	{"title": "Sarlavha", "description": null}	2025-12-23 05:38:42	2025-12-23 05:38:42
44	22	ru	{"title": null, "description": null}	2025-12-23 05:38:42	2025-12-23 05:38:42
62	30	uz	{"title": "Url", "description": null}	2025-12-25 13:30:47	2025-12-25 13:30:47
63	30	ru	{"title": null, "description": null}	2025-12-25 13:30:47	2025-12-25 13:30:47
64	30	en	{"title": null, "description": null}	2025-12-25 13:30:47	2025-12-25 13:30:47
45	23	uz	{"title": "davlatlar", "description": null}	2025-12-23 05:39:07	2025-12-23 05:46:49
46	23	ru	{"title": null, "description": null}	2025-12-23 05:39:07	2025-12-23 05:46:49
65	31	uz	{"title": "Form", "description": null}	2025-12-25 13:31:05	2025-12-26 11:05:40
66	31	ru	{"title": null, "description": null}	2025-12-25 13:31:05	2025-12-26 11:05:40
67	31	en	{"title": null, "description": null}	2025-12-25 13:31:05	2025-12-26 11:05:40
69	32	uz	{"title": "Forms", "description": null}	2025-12-26 13:13:22	2025-12-26 13:13:22
70	32	ru	{"title": null, "description": null}	2025-12-26 13:13:22	2025-12-26 13:13:22
71	32	en	{"title": null, "description": null}	2025-12-26 13:13:22	2025-12-26 13:13:22
28	14	ru	{"info": null, "title": "Лидерство", "description": null}	2025-12-23 05:13:48	2026-01-22 06:28:16
106	44	uz	{"info": null, "title": "Bog'lanish", "description": null}	2025-12-30 23:27:51	2026-01-23 13:32:20
12	6	ru	{"info": null, "title": "Главная страница", "description": null}	2025-12-23 04:52:03	2026-01-22 06:23:53
20	10	ru	{"info": null, "title": "Места расположения", "description": null}	2025-12-23 04:56:55	2026-01-22 06:27:45
2	1	ru	{"info": null, "title": null, "description": null}	2025-12-23 04:24:05	2026-01-21 11:56:39
99	1	en	{"info": null, "title": null, "description": null}	2025-12-30 06:13:41	2026-01-21 11:56:39
107	44	ru	{"info": null, "title": "Связь", "description": null}	2025-12-30 23:27:51	2026-01-23 13:32:20
108	44	en	{"info": null, "title": "Contact", "description": null}	2025-12-30 23:27:51	2026-01-23 13:32:20
55	5	en	{"info": null, "title": "Uzbekistan", "description": null}	2025-12-25 12:13:52	2026-02-02 09:59:06
47	24	uz	{"info": null, "title": "Biz haqimizda", "description": null}	2025-12-23 05:42:34	2026-01-22 06:24:46
13	7	uz	{"info": null, "title": "Qadriyatlar", "description": null}	2025-12-23 04:52:36	2026-01-21 19:47:09
14	7	ru	{"info": null, "title": "Ценности", "description": null}	2025-12-23 04:52:36	2026-01-21 19:47:09
68	8	en	{"info": null, "title": "3D Travel", "description": null}	2025-12-26 05:32:09	2026-01-21 19:48:35
72	33	uz	{"info": null, "title": "Locations", "description": null}	2025-12-26 13:17:17	2026-01-22 06:27:32
25	13	uz	{"info": null, "title": "Biz haqimizda", "description": null}	2025-12-23 05:13:24	2026-01-21 19:50:28
26	13	ru	{"info": null, "title": "О  нас", "description": null}	2025-12-23 05:13:24	2026-01-21 19:50:28
48	24	ru	{"info": null, "title": "О  нас", "description": null}	2025-12-23 05:42:34	2026-01-22 06:24:46
18	9	ru	{"info": null, "title": "Прошлое и настоящее", "description": null}	2025-12-23 04:55:51	2026-01-22 06:25:40
78	35	uz	{"info": null, "title": "Hero(Главный)", "description": null}	2025-12-27 18:31:23	2026-01-23 06:32:03
79	35	ru	{"info": null, "title": null, "description": null}	2025-12-27 18:31:23	2026-01-23 06:32:03
31	16	uz	{"info": null, "title": "FAQ", "description": null}	2025-12-23 05:14:52	2026-01-21 19:54:08
32	16	ru	{"info": null, "title": "FAQ", "description": null}	2025-12-23 05:14:52	2026-01-21 19:54:08
40	20	ru	{"info": null, "title": "Ассоциации", "description": null}	2025-12-23 05:36:31	2026-01-29 13:49:24
10	5	ru	{"info": null, "title": "Узбекистан", "description": null}	2025-12-23 04:51:35	2026-02-02 09:59:06
41	21	uz	{"info": null, "title": "Jamoat birlashmalari", "description": null}	2025-12-23 05:36:49	2026-01-21 19:55:14
42	21	ru	{"info": null, "title": "Общественные объединения", "description": null}	2025-12-23 05:36:49	2026-01-21 19:55:14
84	37	uz	{"info": null, "title": "Loyihalar", "description": null}	2025-12-29 11:46:30	2026-01-21 19:55:48
85	37	ru	{"info": null, "title": "Проекты", "description": null}	2025-12-29 11:46:30	2026-01-21 19:55:48
86	37	en	{"info": null, "title": "Projects", "description": null}	2025-12-29 11:46:30	2026-01-21 19:55:48
87	38	uz	{"info": null, "title": "Barcha Loyihalar", "description": null}	2025-12-29 11:47:01	2026-01-21 19:56:17
89	38	en	{"info": null, "title": "All Projects", "description": null}	2025-12-29 11:47:01	2026-01-21 19:56:17
49	25	uz	{"info": null, "title": "Axborot xizmatlari", "description": null}	2025-12-23 06:18:25	2026-01-21 19:56:44
50	25	ru	{"info": null, "title": "Информационные услуги", "description": null}	2025-12-23 06:18:25	2026-01-21 19:56:44
51	26	uz	{"info": null, "title": "Yangiliklar", "description": null}	2025-12-23 06:18:44	2026-01-21 19:57:16
52	26	ru	{"info": null, "title": "Новости", "description": null}	2025-12-23 06:18:44	2026-01-21 19:57:16
53	27	uz	{"info": null, "title": "Mediateka", "description": null}	2025-12-23 06:19:02	2026-01-21 19:57:31
54	27	ru	{"info": null, "title": "Mediateka", "description": null}	2025-12-23 06:19:02	2026-01-21 19:57:31
73	33	ru	{"info": null, "title": null, "description": null}	2025-12-26 13:17:17	2026-01-22 06:27:32
74	33	en	{"info": null, "title": null, "description": null}	2025-12-26 13:17:17	2026-01-22 06:27:32
19	10	uz	{"info": null, "title": "Manzilgohlar", "description": null}	2025-12-23 04:56:55	2026-01-22 06:27:45
80	35	en	{"info": null, "title": null, "description": null}	2025-12-27 18:31:23	2026-01-23 06:32:03
3	2	uz	{"info": null, "title": "Vatandoshlar Jamoat Fondi", "description": null}	2025-12-23 04:24:42	2026-01-23 06:35:09
4	2	ru	{"info": null, "title": null, "description": null}	2025-12-23 04:24:42	2026-01-23 06:35:09
7	4	uz	{"info": null, "title": "Prezident", "description": null}	2025-12-23 04:25:44	2026-01-23 06:35:57
8	4	ru	{"info": null, "title": null, "description": null}	2025-12-23 04:25:44	2026-01-23 06:35:57
39	20	uz	{"info": null, "title": "Birlashmalar", "description": null}	2025-12-23 05:36:31	2026-01-29 13:49:24
129	7	en	{"info": null, "title": "Values", "description": null}	2026-01-14 10:33:53	2026-01-21 19:47:09
15	8	uz	{"info": null, "title": "3D  Sayohat", "description": null}	2025-12-23 04:53:12	2026-01-21 19:48:35
115	47	uz	{"info": null, "title": "Ilovalar", "description": null}	2026-01-06 10:33:30	2026-01-19 12:57:37
116	47	ru	{"info": null, "title": null, "description": null}	2026-01-06 10:33:30	2026-01-19 12:57:37
117	47	en	{"info": null, "title": null, "description": null}	2026-01-06 10:33:30	2026-01-19 12:57:37
16	8	ru	{"info": null, "title": "3D Путешествия", "description": null}	2025-12-23 04:53:12	2026-01-21 19:48:35
136	50	uz	{"info": null, "title": "Kitoblar", "description": null}	2026-01-19 16:37:07	2026-01-23 07:16:13
150	53	uz	{"info": null, "title": "Vatandoshlar safida bo‘ling", "description": null}	2026-01-22 10:19:03	2026-01-23 13:24:56
111	45	en	{"info": null, "title": "Our volunteers", "description": null}	2026-01-05 04:54:22	2026-02-02 10:33:59
109	45	uz	{"info": null, "title": "Volontorlarimiz", "description": null}	2026-01-05 04:54:22	2026-02-02 10:33:59
112	46	uz	{"info": null, "title": "Gazetalar", "description": null}	2026-01-05 04:54:46	2026-01-21 19:58:52
1	1	uz	{"info": "<p>hjjkhjkhkjhkjhjkl</p><p><br></p><p><iframe width=\\"560\\" height=\\"315\\" src=\\"https://www.youtube.com/embed/FzvmmnAyKH4?si=zdJtHSL8TNpSXyhn\\" title=\\"YouTube video player\\" frameborder=\\"0\\" allow=\\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\\" referrerpolicy=\\"strict-origin-when-cross-origin\\" allowfullscreen=\\"\\"></iframe></p>", "title": "Asosiy sahifa", "description": null}	2025-12-23 04:24:05	2026-01-21 11:56:39
142	52	uz	{"info": null, "title": "Podcastlar", "description": null}	2026-01-21 18:32:15	2026-01-21 18:32:15
143	52	ru	{"info": null, "title": null, "description": null}	2026-01-21 18:32:15	2026-01-21 18:32:15
144	52	en	{"info": null, "title": null, "description": null}	2026-01-21 18:32:15	2026-01-21 18:32:15
145	13	en	{"info": null, "title": "About us", "description": null}	2026-01-21 19:50:28	2026-01-21 19:50:28
110	45	ru	{"info": null, "title": "Наши волонтеры", "description": null}	2026-01-05 04:54:22	2026-02-02 10:33:59
17	9	uz	{"info": null, "title": "Moziy va bugun", "description": null}	2025-12-23 04:55:51	2026-01-22 06:25:40
130	9	en	{"info": null, "title": "Past and present", "description": null}	2026-01-14 10:35:37	2026-01-22 06:25:40
153	2	en	{"info": null, "title": null, "description": null}	2026-01-23 06:35:09	2026-01-23 06:35:09
154	4	en	{"info": null, "title": null, "description": null}	2026-01-23 06:35:57	2026-01-23 06:35:57
146	16	en	{"info": null, "title": "FAQ", "description": null}	2026-01-21 19:54:08	2026-01-21 19:54:08
135	21	en	{"info": null, "title": "Public associations", "description": null}	2026-01-14 10:38:39	2026-01-21 19:55:14
88	38	ru	{"info": null, "title": "Все проекты", "description": null}	2025-12-29 11:47:01	2026-01-21 19:56:17
148	25	en	{"info": null, "title": "Information services", "description": null}	2026-01-21 19:56:44	2026-01-21 19:56:44
127	26	en	{"info": null, "title": "News", "description": null}	2026-01-14 08:28:20	2026-01-21 19:57:16
149	27	en	{"info": null, "title": "Mediateka", "description": null}	2026-01-21 19:57:31	2026-01-21 19:57:31
113	46	ru	{"info": null, "title": "Газеты", "description": null}	2026-01-05 04:54:46	2026-01-21 19:58:52
114	46	en	{"info": null, "title": "Newspapers", "description": null}	2026-01-05 04:54:46	2026-01-21 19:58:52
122	49	ru	{"info": null, "title": "Применять", "description": null}	2026-01-12 12:37:19	2026-01-23 13:32:33
123	49	en	{"info": null, "title": "Apply", "description": null}	2026-01-12 12:37:19	2026-01-23 13:32:33
11	6	uz	{"info": null, "title": "Bosh sahifa", "description": null}	2025-12-23 04:52:03	2026-01-22 06:23:53
128	6	en	{"info": null, "title": "Main Page", "description": null}	2026-01-14 10:33:16	2026-01-22 06:23:53
132	24	en	{"info": null, "title": "About us", "description": null}	2026-01-14 10:36:35	2026-01-22 06:24:46
140	51	ru	{"info": null, "title": null, "description": null}	2026-01-21 11:49:19	2026-01-23 07:15:31
131	10	en	{"info": null, "title": "Locations", "description": null}	2026-01-14 10:36:09	2026-01-22 06:27:45
27	14	uz	{"info": null, "title": "Rahbariyat", "description": null}	2025-12-23 05:13:48	2026-01-22 06:28:16
133	14	en	{"info": null, "title": "Leadership", "description": null}	2026-01-14 10:37:04	2026-01-22 06:28:16
29	15	uz	{"info": null, "title": "Fondning asosiy yo’nalishlari", "description": null}	2025-12-23 05:14:18	2026-01-22 06:28:39
30	15	ru	{"info": null, "title": "Основные направления деятельности фонда", "description": null}	2025-12-23 05:14:18	2026-01-22 06:28:39
134	15	en	{"info": null, "title": "Main directions of the fund", "description": null}	2026-01-14 10:37:53	2026-01-22 06:28:39
137	50	ru	{"info": null, "title": null, "description": null}	2026-01-19 16:37:07	2026-01-23 07:16:13
156	54	ru	{"info": null, "title": null, "description": null}	2026-01-23 07:14:57	2026-01-23 07:16:37
151	53	ru	{"info": null, "title": null, "description": null}	2026-01-22 10:19:03	2026-01-23 13:24:56
139	51	uz	{"info": null, "title": "Mutolaa", "description": null}	2026-01-21 11:49:19	2026-01-23 07:15:31
141	51	en	{"info": null, "title": null, "description": null}	2026-01-21 11:49:19	2026-01-23 07:15:31
138	50	en	{"info": null, "title": null, "description": null}	2026-01-19 16:37:07	2026-01-23 07:16:13
155	54	uz	{"info": null, "title": "Mutolaa", "description": null}	2026-01-23 07:14:57	2026-01-23 07:16:37
157	54	en	{"info": null, "title": null, "description": null}	2026-01-23 07:14:57	2026-01-23 07:16:37
152	53	en	{"info": null, "title": null, "description": null}	2026-01-22 10:19:03	2026-01-23 13:24:56
121	49	uz	{"info": "<p><br></p>", "title": "Murojat qilish", "description": null}	2026-01-12 12:37:19	2026-01-23 13:32:33
147	20	en	{"info": null, "title": "Associations", "description": null}	2026-01-21 19:54:38	2026-01-29 13:49:24
9	5	uz	{"info": null, "title": "O'zbekiston", "description": null}	2025-12-23 04:51:35	2026-02-02 09:59:06
\.


--
-- Data for Name: menu_mains; Type: TABLE DATA; Schema: public; Owner: vatandoshlar_usr
--

COPY public.menu_mains (id, type, slug, url, test, show_admin, sort_order, icon, status, parent_id, created_at, updated_at) FROM stdin;
50	section	asosiy-rasmlar	\N	f	t	7	\N	t	54	2026-01-19 16:37:07	2026-02-02 10:43:32
6	page	uzbekistan	\N	f	t	1	\N	t	5	2025-12-23 04:52:02	2026-01-22 06:23:53
16	page	faq	\N	f	t	16	\N	t	13	2025-12-23 05:14:52	2025-12-23 05:14:52
22	section	sarlavha	\N	f	t	22	\N	t	21	2025-12-23 05:38:42	2025-12-23 05:38:42
23	section	tanlov	\N	f	t	23	\N	t	21	2025-12-23 05:39:07	2025-12-23 05:39:07
32	section	forms	\N	f	t	32	\N	t	10	2025-12-26 13:13:22	2025-12-26 13:13:22
27	page	mediateka	\N	f	t	27	\N	t	25	2025-12-23 06:19:02	2025-12-23 06:19:02
30	section	url	\N	f	t	30	\N	t	6	2025-12-25 13:30:47	2025-12-25 13:30:47
31	section	sarlavhass	\N	f	t	31	\N	t	6	2025-12-25 13:31:05	2025-12-25 13:34:53
24	page	about	\N	f	t	14	\N	t	13	2025-12-23 05:42:34	2026-01-22 06:24:46
9	page	pastandpresent	\N	f	t	4	\N	t	5	2025-12-23 04:55:51	2026-01-22 06:25:40
33	section	locations1	\N	f	t	33	\N	t	10	2025-12-26 13:17:17	2026-01-22 06:27:32
10	page	locations	\N	f	t	5	\N	t	5	2025-12-23 04:56:55	2026-01-22 06:27:45
14	page	leadership	\N	f	t	14	\N	t	13	2025-12-23 05:13:48	2026-01-22 06:28:16
15	page	directions	\N	f	t	15	\N	t	13	2025-12-23 05:14:17	2026-01-22 06:28:39
26	page	news	\N	f	t	26	\N	t	25	2025-12-23 06:18:44	2026-01-14 10:25:12
44	section	contacts	\N	f	t	55	\N	t	1	2025-12-30 23:27:51	2026-01-23 13:32:55
49	page	application	\N	f	f	56	\N	t	1	2026-01-12 12:37:19	2026-01-23 13:33:16
35	section	video	\N	f	t	1	\N	t	1	2025-12-27 18:31:23	2026-01-23 06:32:18
21	page	associations	\N	f	t	21	\N	t	20	2025-12-23 05:36:49	2026-01-14 10:38:38
38	page	projects	\N	f	t	38	\N	t	37	2025-12-29 11:47:01	2026-01-14 10:38:59
2	section	vatandoshlar	\N	f	t	2	\N	t	1	2025-12-23 04:24:41	2026-01-23 06:32:18
1	category	asosiy_sahifa	\N	f	t	1	\N	f	\N	2025-12-23 04:24:05	2026-02-02 09:59:00
5	category	ozbekiston	\N	f	t	2	\N	t	\N	2025-12-23 04:51:35	2026-02-02 09:59:00
13	category	biz-haqimizda	\N	f	t	3	\N	t	\N	2025-12-23 05:13:24	2026-02-02 09:59:00
20	category	birlashmalar	\N	f	t	4	\N	t	\N	2025-12-23 05:36:31	2026-02-02 09:59:00
37	category	loyihalar	\N	f	t	5	\N	t	\N	2025-12-29 11:46:30	2026-02-02 09:59:00
25	category	axborot-xizmatlari	\N	f	t	6	\N	t	\N	2025-12-23 06:18:25	2026-02-02 09:59:00
4	section	jamoat-fondi	\N	f	t	4	\N	t	1	2025-12-23 04:25:44	2026-02-02 10:31:17
46	page	newspaper	\N	f	t	46	\N	t	25	2026-01-05 04:54:46	2026-01-22 15:10:39
45	page	volunteers	\N	f	t	45	\N	t	1	2026-01-05 04:54:22	2026-02-02 10:36:56
53	section	ariza-yuborish	\N	f	t	10	\N	t	1	2026-01-22 10:19:03	2026-02-02 10:43:09
3	section	statistika	\N	f	t	3	\N	t	1	2025-12-23 04:25:08	2026-01-23 06:32:18
47	section	cc	\N	f	t	6	\N	t	1	2026-01-06 10:33:30	2026-01-23 06:32:18
52	section	podcastlar	\N	f	t	9	\N	t	1	2026-01-21 18:32:15	2026-01-23 06:32:18
54	category	mutolaa	\N	f	t	54	\N	t	1	2026-01-23 07:14:57	2026-01-23 07:14:57
51	section	mutoola	\N	f	t	8	\N	t	54	2026-01-21 11:49:19	2026-01-23 07:15:31
7	page	traditions	\N	f	t	2	\N	t	5	2025-12-23 04:52:36	2026-01-21 19:46:25
8	url	3d-sayohat	https://uzbekistan360.uz/ru	f	f	3	\N	t	5	2025-12-23 04:53:12	2026-01-21 19:46:25
\.


--
-- Data for Name: menus; Type: TABLE DATA; Schema: public; Owner: vatandoshlar_usr
--

COPY public.menus (id, title, status, sort_order, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: vatandoshlar_usr
--

COPY public.migrations (id, migration, batch) FROM stdin;
1	0001_01_01_000000_create_users_table	1
2	0001_01_01_000001_create_cache_table	1
3	0001_01_01_000002_create_jobs_table	1
4	2025_12_03_094858_create_menus_table	1
5	2025_12_03_133507_create_roles_table	1
6	2025_12_04_093815_create_permissions_table	1
7	2025_12_04_094905_create_menu_mains_table	1
8	2025_12_04_104850_create_langs_table	1
9	2025_12_05_053253_create_menu_main_settings_table	1
10	2025_12_08_045829_create_menu_main_translations_table	1
11	2025_12_08_050435_create_menu_main_images_table	1
12	2025_12_08_100657_create_page_sections_table	1
13	2025_12_08_100708_create_page_section_settings_table	1
14	2025_12_08_100721_create_page_section_translations_table	1
15	2025_12_09_063323_create_role_menu_permissions_table	1
16	2025_12_09_123317_create_page_section_images_table	1
17	2025_12_16_103643_create_settings_table	1
18	2025_12_16_120031_create_socials_table	1
19	2025_12_16_173056_create_contents_table	1
20	2025_12_16_174028_create_content_translations_table	1
21	2025_12_16_174335_create_content_settings_table	1
22	2025_12_16_175011_create_content_images_table	1
23	2025_12_30_094546_create_supports_table	2
24	2026_01_06_075146_create_view_counts_table	3
25	2026_01_09_093839_create_form_images_table	4
26	2026_01_12_075744_create_order_settings_table	5
\.


--
-- Data for Name: order_settings; Type: TABLE DATA; Schema: public; Owner: vatandoshlar_usr
--

COPY public.order_settings (id, menu_main_id, "order", status, created_at, updated_at) FROM stdin;
2	38	sort_order_asc	t	2026-01-13 12:20:20	2026-01-13 12:22:26
1	26	time_desc	t	2026-01-12 08:02:58	2026-01-29 12:19:33
3	14	sort_order_asc	t	2026-01-23 11:32:47	2026-01-23 11:32:58
\.


--
-- Data for Name: page_section_images; Type: TABLE DATA; Schema: public; Owner: vatandoshlar_usr
--

COPY public.page_section_images (id, page_section_id, page_section_parent_id, category, category_slug, image, compressed, type, size, main, status, created_at, updated_at, sort_order) FROM stdin;
1	1	\N	\N	\N	page_section_images/1766464991_logo.png	\N	image/png	98609	t	t	2025-12-23 04:43:12	2025-12-23 04:43:12	\N
2	2	\N	\N	\N	page_section_images/1766465101_stats-img-1.svg	\N	image/svg+xml	1022	t	t	2025-12-23 04:45:01	2025-12-23 04:45:01	\N
3	5	\N	\N	\N	page_section_images/1766466384_b8b65328e2c66f9e5b6a1abea44d4fbda4ff74d9.png	\N	image/png	1255572	t	t	2025-12-23 05:06:24	2025-12-23 05:06:24	\N
4	5	\N	\N	\N	page_section_images/1766466384_71596a3c79e6ea29869f23118068e52cdaa097e0.png	\N	image/png	1051197	f	t	2025-12-23 05:06:24	2025-12-23 05:06:24	\N
5	5	\N	\N	\N	page_section_images/1766466384_9f44c2e308de8a752650fc50f9a730e071877078.png	\N	image/png	1672804	f	t	2025-12-23 05:06:24	2025-12-23 05:06:24	\N
6	6	\N	\N	\N	page_section_images/1766466468_56fe38f6ec843c64677b251a9d627181f820bf50.png	\N	image/png	1739467	t	t	2025-12-23 05:07:49	2025-12-23 05:07:49	\N
7	7	\N	\N	\N	page_section_images/1766466507_about-video.jpg	\N	image/jpeg	469151	t	t	2025-12-23 05:08:27	2025-12-23 05:08:27	\N
8	8	\N	\N	\N	page_section_images/1766466629_c1a4917b58c218386f15744094c20059373d611d-min.png	\N	image/png	895781	t	t	2025-12-23 05:10:29	2025-12-23 05:10:29	\N
9	9	\N	\N	\N	page_section_images/1766466695_c1a4917b58c218386f15744094c20059373d611d-min.png	\N	image/png	895781	t	t	2025-12-23 05:11:36	2025-12-23 05:11:36	\N
10	12	\N	\N	\N	page_section_images/1766467747_logo.png	\N	image/png	98609	t	t	2025-12-23 05:29:07	2025-12-23 05:29:07	\N
11	12	\N	\N	\N	page_section_images/1766467747_56fe38f6ec843c64677b251a9d627181f820bf50.png	\N	image/png	1739467	f	t	2025-12-23 05:29:07	2025-12-23 05:29:07	\N
12	13	\N	\N	\N	page_section_images/1766467806_c1a4917b58c218386f15744094c20059373d611d-min.png	\N	image/png	895781	t	t	2025-12-23 05:30:06	2025-12-23 05:30:06	\N
15	16	\N	\N	\N	page_section_images/1766468047_financial-1.svg	\N	image/svg+xml	2954	t	t	2025-12-23 05:34:07	2025-12-23 05:34:07	\N
16	17	\N	\N	\N	page_section_images/1766468067_financial-2.svg	\N	image/svg+xml	2234	t	t	2025-12-23 05:34:27	2025-12-23 05:34:27	\N
17	19	\N	\N	\N	page_section_images/1766468859_flag-uz.png	\N	image/png	9976	t	t	2025-12-23 05:47:39	2025-12-23 05:47:39	\N
18	20	\N	\N	\N	page_section_images/1766468880_flag-en.png	\N	image/png	18142	t	t	2025-12-23 05:48:00	2025-12-23 05:48:00	\N
291	164	\N	\N	\N	page_section_images/1767601213_c1a4917b58c218386f15744094c20059373d611d-min.png	\N	image/png	895781	t	t	2026-01-05 08:20:13	2026-01-05 08:20:13	\N
295	169	\N	\N	\N	page_section_images/1767601337_volunteer-6.png	\N	image/png	105042	t	t	2026-01-05 08:22:17	2026-01-05 08:22:17	\N
24	27	20	tashkilot	tashkilot-1	page_section_images/1766469748_association-3.png	\N	image/png	11024	t	t	2025-12-23 06:02:28	2025-12-23 06:02:28	\N
25	30	20	tashkilot	tashkilot-1	page_section_images/1766469975_association-4.png	\N	image/png	5583	t	t	2025-12-23 06:06:15	2025-12-23 06:06:15	\N
27	31	30	Nomi	nomi-3	page_section_images/1766470044_association-3.png	\N	image/png	11024	t	t	2025-12-23 06:07:24	2025-12-23 06:07:24	\N
28	32	30	Rahbar	rahbar-3	page_section_images/1766470115_flag-ru.png	\N	image/png	1743	t	t	2025-12-23 06:08:35	2025-12-23 06:08:35	\N
30	34	\N	\N	\N	page_section_images/1766470959_news-img-2.png	\N	image/png	23441	t	t	2025-12-23 06:22:39	2025-12-23 06:22:39	\N
31	39	\N	\N	\N	page_section_images/1766652621_c1a4917b58c218386f15744094c20059373d611d-min.png	\N	image/png	895781	f	t	2025-12-25 08:50:21	2025-12-25 08:50:21	\N
33	39	\N	\N	\N	page_section_images/1766652621_Taqu.jpg	\N	image/jpeg	62105	f	t	2025-12-25 08:50:21	2025-12-25 08:50:21	\N
34	39	\N	\N	\N	page_section_images/1766652621_news-img-1.png	\N	image/png	1264559	f	t	2025-12-25 08:50:21	2025-12-25 08:50:21	\N
35	40	\N	\N	\N	page_section_images/1766655727_financial-3.svg	\N	image/svg+xml	2146	t	t	2025-12-25 09:42:07	2025-12-25 09:42:36	\N
48	37	\N	\N	\N	page_section_images/1766656863_logo.png	\N	image/png	98609	t	t	2025-12-25 10:01:03	2025-12-25 10:01:03	\N
64	51	\N	\N	\N	page_section_images/1766669091_c1a4917b58c218386f15744094c20059373d611d-min.png	\N	image/png	895781	f	t	2025-12-25 13:24:51	2025-12-25 13:24:51	\N
65	51	\N	\N	\N	page_section_images/1766669091_form.jpg	\N	image/jpeg	192942	f	t	2025-12-25 13:24:51	2025-12-25 13:24:51	\N
66	51	\N	\N	\N	page_section_images/1766669091_oila1.jpg	\N	image/jpeg	1739467	f	t	2025-12-25 13:24:51	2025-12-25 13:24:51	\N
67	54	\N	\N	\N	page_section_images/1766669782_c1a4917b58c218386f15744094c20059373d611d-min.png	\N	image/png	895781	f	t	2025-12-25 13:36:22	2025-12-25 13:36:22	\N
68	54	\N	\N	\N	page_section_images/1766669782_form.jpg	\N	image/jpeg	192942	f	t	2025-12-25 13:36:22	2025-12-25 13:36:22	\N
69	54	\N	\N	\N	page_section_images/1766669782_oila1.jpg	\N	image/jpeg	1739467	f	t	2025-12-25 13:36:22	2025-12-25 13:36:22	\N
73	14	\N	\N	\N	page_section_images/1766726046_f87cf5263832720cdbe41c7eb7faa98cae5c58a2.png	\N	image/png	786846	t	t	2025-12-26 05:14:06	2025-12-26 05:14:06	\N
74	15	\N	\N	\N	page_section_images/1766726080_7f1beefe896a37c2a8669f8c96ad0b81629aa952.png	\N	image/png	751123	t	t	2025-12-26 05:14:40	2025-12-26 05:14:40	\N
76	56	\N	\N	\N	page_section_images/1766733524_b8b65328e2c66f9e5b6a1abea44d4fbda4ff74d9.png	\N	image/png	1255572	t	t	2025-12-26 07:18:44	2025-12-26 07:18:44	\N
77	53	\N	\N	\N	page_section_images/1766741574_c1a4917b58c218386f15744094c20059373d611d-min.png	\N	image/png	895781	f	t	2025-12-26 09:32:54	2025-12-26 09:32:54	\N
78	53	\N	\N	\N	page_section_images/1766741574_form.jpg	\N	image/jpeg	192942	f	t	2025-12-26 09:32:54	2025-12-26 09:32:54	\N
79	53	\N	\N	\N	page_section_images/1766741574_oila1.jpg	\N	image/jpeg	1739467	f	t	2025-12-26 09:32:55	2025-12-26 09:32:55	\N
329	33	\N	\N	\N	page_section_images/1767613038_Taqu.jpg	\N	image/jpeg	62105	f	t	2026-01-05 11:37:18	2026-01-05 11:37:18	\N
89	60	\N	\N	\N	page_section_images/1766756303_c1a4917b58c218386f15744094c20059373d611d-min.png	\N	image/png	895781	f	t	2025-12-26 13:38:23	2025-12-26 13:38:23	\N
90	60	\N	\N	\N	page_section_images/1766756303_form.jpg	\N	image/jpeg	192942	f	t	2025-12-26 13:38:23	2025-12-26 13:38:23	\N
91	60	\N	\N	\N	page_section_images/1766756303_oila1.jpg	\N	image/jpeg	1739467	f	t	2025-12-26 13:38:23	2025-12-26 13:38:23	\N
92	61	\N	\N	\N	page_section_images/1766756347_c1a4917b58c218386f15744094c20059373d611d-min.png	\N	image/png	895781	f	t	2025-12-26 13:39:07	2025-12-26 13:39:07	\N
93	61	\N	\N	\N	page_section_images/1766756347_form.jpg	\N	image/jpeg	192942	f	t	2025-12-26 13:39:07	2025-12-26 13:39:07	\N
94	61	\N	\N	\N	page_section_images/1766756347_oila1.jpg	\N	image/jpeg	1739467	f	t	2025-12-26 13:39:07	2025-12-26 13:39:07	\N
95	62	\N	\N	\N	page_section_images/1766756680_c1a4917b58c218386f15744094c20059373d611d-min.png	\N	image/png	895781	f	t	2025-12-26 13:44:40	2025-12-26 13:44:40	\N
96	62	\N	\N	\N	page_section_images/1766756680_form.jpg	\N	image/jpeg	192942	f	t	2025-12-26 13:44:40	2025-12-26 13:44:40	\N
97	62	\N	\N	\N	page_section_images/1766756680_oila1.jpg	\N	image/jpeg	1739467	f	t	2025-12-26 13:44:40	2025-12-26 13:44:40	\N
98	63	\N	\N	\N	page_section_images/1766756734_c1a4917b58c218386f15744094c20059373d611d-min.png	\N	image/png	895781	f	t	2025-12-26 13:45:34	2025-12-26 13:45:34	\N
99	63	\N	\N	\N	page_section_images/1766756734_form.jpg	\N	image/jpeg	192942	f	t	2025-12-26 13:45:34	2025-12-26 13:45:34	\N
100	63	\N	\N	\N	page_section_images/1766756734_oila1.jpg	\N	image/jpeg	1739467	f	t	2025-12-26 13:45:34	2025-12-26 13:45:34	\N
101	64	\N	\N	\N	page_section_images/1766756794_c1a4917b58c218386f15744094c20059373d611d-min.png	\N	image/png	895781	f	t	2025-12-26 13:46:35	2025-12-26 13:46:35	\N
102	64	\N	\N	\N	page_section_images/1766756795_form.jpg	\N	image/jpeg	192942	f	t	2025-12-26 13:46:35	2025-12-26 13:46:35	\N
103	64	\N	\N	\N	page_section_images/1766756795_oila1.jpg	\N	image/jpeg	1739467	f	t	2025-12-26 13:46:35	2025-12-26 13:46:35	\N
107	66	\N	\N	\N	page_section_images/1766756853_c1a4917b58c218386f15744094c20059373d611d-min.png	\N	image/png	895781	f	t	2025-12-26 13:47:33	2025-12-26 13:47:33	\N
108	66	\N	\N	\N	page_section_images/1766756853_form.jpg	\N	image/jpeg	192942	f	t	2025-12-26 13:47:33	2025-12-26 13:47:33	\N
109	66	\N	\N	\N	page_section_images/1766756853_oila1.jpg	\N	image/jpeg	1739467	f	t	2025-12-26 13:47:33	2025-12-26 13:47:33	\N
110	67	\N	\N	\N	page_section_images/1766756912_c1a4917b58c218386f15744094c20059373d611d-min.png	\N	image/png	895781	f	t	2025-12-26 13:48:32	2025-12-26 13:48:32	\N
111	67	\N	\N	\N	page_section_images/1766756912_form.jpg	\N	image/jpeg	192942	f	t	2025-12-26 13:48:32	2025-12-26 13:48:32	\N
112	67	\N	\N	\N	page_section_images/1766756912_oila1.jpg	\N	image/jpeg	1739467	f	t	2025-12-26 13:48:32	2025-12-26 13:48:32	\N
113	68	\N	\N	\N	page_section_images/1766756969_c1a4917b58c218386f15744094c20059373d611d-min.png	\N	image/png	895781	f	t	2025-12-26 13:49:30	2025-12-26 13:49:30	\N
114	68	\N	\N	\N	page_section_images/1766756970_form.jpg	\N	image/jpeg	192942	f	t	2025-12-26 13:49:30	2025-12-26 13:49:30	\N
115	68	\N	\N	\N	page_section_images/1766756970_oila1.jpg	\N	image/jpeg	1739467	f	t	2025-12-26 13:49:30	2025-12-26 13:49:30	\N
116	69	\N	\N	\N	page_section_images/1766757029_c1a4917b58c218386f15744094c20059373d611d-min.png	\N	image/png	895781	f	t	2025-12-26 13:50:29	2025-12-26 13:50:29	\N
117	69	\N	\N	\N	page_section_images/1766757029_form.jpg	\N	image/jpeg	192942	f	t	2025-12-26 13:50:29	2025-12-26 13:50:29	\N
118	69	\N	\N	\N	page_section_images/1766757029_oila1.jpg	\N	image/jpeg	1739467	f	t	2025-12-26 13:50:29	2025-12-26 13:50:29	\N
119	70	\N	\N	\N	page_section_images/1766757069_c1a4917b58c218386f15744094c20059373d611d-min.png	\N	image/png	895781	f	t	2025-12-26 13:51:10	2025-12-26 13:51:10	\N
120	70	\N	\N	\N	page_section_images/1766757070_form.jpg	\N	image/jpeg	192942	f	t	2025-12-26 13:51:10	2025-12-26 13:51:10	\N
121	70	\N	\N	\N	page_section_images/1766757070_oila1.jpg	\N	image/jpeg	1739467	f	t	2025-12-26 13:51:10	2025-12-26 13:51:10	\N
122	71	\N	\N	\N	page_section_images/1766757113_c1a4917b58c218386f15744094c20059373d611d-min.png	\N	image/png	895781	f	t	2025-12-26 13:51:53	2025-12-26 13:51:53	\N
123	71	\N	\N	\N	page_section_images/1766757113_form.jpg	\N	image/jpeg	192942	f	t	2025-12-26 13:51:53	2025-12-26 13:51:53	\N
124	71	\N	\N	\N	page_section_images/1766757113_oila1.jpg	\N	image/jpeg	1739467	f	t	2025-12-26 13:51:53	2025-12-26 13:51:53	\N
125	72	\N	\N	\N	page_section_images/1766757172_c1a4917b58c218386f15744094c20059373d611d-min.png	\N	image/png	895781	f	t	2025-12-26 13:52:52	2025-12-26 13:52:52	\N
126	72	\N	\N	\N	page_section_images/1766757172_form.jpg	\N	image/jpeg	192942	f	t	2025-12-26 13:52:53	2025-12-26 13:52:53	\N
127	72	\N	\N	\N	page_section_images/1766757173_oila1.jpg	\N	image/jpeg	1739467	f	t	2025-12-26 13:52:53	2025-12-26 13:52:53	\N
128	73	\N	\N	\N	page_section_images/1766757215_c1a4917b58c218386f15744094c20059373d611d-min.png	\N	image/png	895781	f	t	2025-12-26 13:53:35	2025-12-26 13:53:35	\N
129	73	\N	\N	\N	page_section_images/1766757215_form.jpg	\N	image/jpeg	192942	f	t	2025-12-26 13:53:35	2025-12-26 13:53:35	\N
130	73	\N	\N	\N	page_section_images/1766757215_oila1.jpg	\N	image/jpeg	1739467	f	t	2025-12-26 13:53:35	2025-12-26 13:53:35	\N
131	74	60	video	video	page_section_images/1766757358_c1a4917b58c218386f15744094c20059373d611d-min.png	\N	image/png	895781	t	t	2025-12-26 13:55:58	2025-12-26 13:55:58	\N
132	75	60	video	video	page_section_images/1766757376_form.jpg	\N	image/jpeg	192942	t	t	2025-12-26 13:56:17	2025-12-26 13:56:17	\N
133	76	60	video	video	page_section_images/1766757395_oila1.jpg	\N	image/jpeg	1739467	t	t	2025-12-26 13:56:36	2025-12-26 13:56:36	\N
134	77	61	video	video-1	page_section_images/1766757456_c1a4917b58c218386f15744094c20059373d611d-min.png	\N	image/png	895781	t	t	2025-12-26 13:57:36	2025-12-26 13:57:36	\N
135	78	61	video	video-1	page_section_images/1766757473_form.jpg	\N	image/jpeg	192942	t	t	2025-12-26 13:57:53	2025-12-26 13:57:53	\N
136	79	61	video	video-1	page_section_images/1766757491_oila1.jpg	\N	image/jpeg	1739467	t	t	2025-12-26 13:58:11	2025-12-26 13:58:11	\N
137	80	62	video	video-2	page_section_images/1766758654_c1a4917b58c218386f15744094c20059373d611d-min.png	\N	image/png	895781	t	t	2025-12-26 14:17:34	2025-12-26 14:17:34	\N
87	57	52	Url	url	page_section_images/1766747422_oila1.jpg	\N	image/jpeg	1739467	t	t	2025-12-26 11:10:22	2025-12-29 13:33:55	\N
88	58	52	Url	url	page_section_images/1766747439_form.jpg	\N	image/jpeg	192942	t	t	2025-12-26 11:10:39	2025-12-29 13:34:24	\N
279	173	\N	\N	\N	page_section_images/1767597755_form.jpg	\N	image/jpeg	192942	t	t	2026-01-05 07:22:35	2026-01-05 07:22:35	\N
138	81	62	video	video-2	page_section_images/1766758671_oila1.jpg	\N	image/jpeg	1739467	t	t	2025-12-26 14:17:51	2025-12-26 14:17:51	\N
139	82	62	video	video-2	page_section_images/1766758689_form.jpg	\N	image/jpeg	192942	t	t	2025-12-26 14:18:09	2025-12-26 14:18:09	\N
140	83	63	video	video-3	page_section_images/1766758736_form.jpg	\N	image/jpeg	192942	t	t	2025-12-26 14:18:56	2025-12-26 14:18:56	\N
141	84	63	video	video-3	page_section_images/1766758753_c1a4917b58c218386f15744094c20059373d611d-min.png	\N	image/png	895781	t	t	2025-12-26 14:19:13	2025-12-26 14:19:13	\N
142	85	63	video	video-3	page_section_images/1766758770_oila1.jpg	\N	image/jpeg	1739467	t	t	2025-12-26 14:19:30	2025-12-26 14:19:30	\N
143	86	64	video	video-4	page_section_images/1766758810_c1a4917b58c218386f15744094c20059373d611d-min.png	\N	image/png	895781	t	t	2025-12-26 14:20:11	2025-12-26 14:20:11	\N
144	87	64	video	video-4	page_section_images/1766758828_form.jpg	\N	image/jpeg	192942	t	t	2025-12-26 14:20:28	2025-12-26 14:20:28	\N
145	88	64	video	video-4	page_section_images/1766758846_oila1.jpg	\N	image/jpeg	1739467	t	t	2025-12-26 14:20:46	2025-12-26 14:20:46	\N
146	90	89	video	video-6	page_section_images/1766759177_c1a4917b58c218386f15744094c20059373d611d-min.png	\N	image/png	895781	t	t	2025-12-26 14:26:17	2025-12-26 14:26:17	\N
147	91	89	video	video-6	page_section_images/1766759192_form.jpg	\N	image/jpeg	192942	t	t	2025-12-26 14:26:32	2025-12-26 14:26:32	\N
148	92	89	video	video-6	page_section_images/1766759208_oila1.jpg	\N	image/jpeg	1739467	t	t	2025-12-26 14:26:48	2025-12-26 14:26:48	\N
215	139	\N	\N	\N	page_section_images/1767090592_association-3.png	\N	image/png	11024	f	t	2025-12-30 10:29:52	2025-12-30 10:29:52	\N
149	93	66	video	video-7	page_section_images/1766759249_c1a4917b58c218386f15744094c20059373d611d-min.png	\N	image/png	895781	t	t	2025-12-26 14:27:29	2025-12-26 14:27:29	\N
150	94	66	video	video-7	page_section_images/1766759270_form.jpg	\N	image/jpeg	192942	t	t	2025-12-26 14:27:50	2025-12-26 14:27:50	\N
151	95	66	video	video-7	page_section_images/1766759285_oila1.jpg	\N	image/jpeg	1739467	t	t	2025-12-26 14:28:05	2025-12-26 14:28:05	\N
152	96	67	video	video-8	page_section_images/1766759319_c1a4917b58c218386f15744094c20059373d611d-min.png	\N	image/png	895781	t	t	2025-12-26 14:28:39	2025-12-26 14:28:39	\N
153	97	67	video	video-8	page_section_images/1766759333_form.jpg	\N	image/jpeg	192942	t	t	2025-12-26 14:28:53	2025-12-26 14:28:53	\N
154	98	67	video	video-8	page_section_images/1766759346_oila1.jpg	\N	image/jpeg	1739467	t	t	2025-12-26 14:29:06	2025-12-26 14:29:06	\N
155	99	68	video	video-9	page_section_images/1766759391_c1a4917b58c218386f15744094c20059373d611d-min.png	\N	image/png	895781	t	t	2025-12-26 14:29:51	2025-12-26 14:29:51	\N
156	100	68	video	video-9	page_section_images/1766759405_form.jpg	\N	image/jpeg	192942	t	t	2025-12-26 14:30:05	2025-12-26 14:30:05	\N
157	101	68	video	video-9	page_section_images/1766759418_oila1.jpg	\N	image/jpeg	1739467	t	t	2025-12-26 14:30:19	2025-12-26 14:30:19	\N
158	102	69	video	video-10	page_section_images/1766759452_oila1.jpg	\N	image/jpeg	1739467	t	t	2025-12-26 14:30:52	2025-12-26 14:30:52	\N
159	103	69	video	video-10	page_section_images/1766759469_form.jpg	\N	image/jpeg	192942	t	t	2025-12-26 14:31:09	2025-12-26 14:31:09	\N
160	104	69	video	video-10	page_section_images/1766759484_c1a4917b58c218386f15744094c20059373d611d-min.png	\N	image/png	895781	t	t	2025-12-26 14:31:24	2025-12-26 14:31:24	\N
161	105	70	video	video-11	page_section_images/1766759533_c1a4917b58c218386f15744094c20059373d611d-min.png	\N	image/png	895781	t	t	2025-12-26 14:32:14	2025-12-26 14:32:14	\N
162	106	70	video	video-11	page_section_images/1766759550_form.jpg	\N	image/jpeg	192942	t	t	2025-12-26 14:32:30	2025-12-26 14:32:30	\N
163	107	70	video	video-11	page_section_images/1766759563_oila1.jpg	\N	image/jpeg	1739467	f	t	2025-12-26 14:32:43	2025-12-26 14:32:43	\N
164	108	71	video	video-12	page_section_images/1766759597_c1a4917b58c218386f15744094c20059373d611d-min.png	\N	image/png	895781	t	t	2025-12-26 14:33:17	2025-12-26 14:33:17	\N
165	109	71	video	video-12	page_section_images/1766759615_form.jpg	\N	image/jpeg	192942	t	t	2025-12-26 14:33:35	2025-12-26 14:33:35	\N
166	110	71	video	video-12	page_section_images/1766759628_oila1.jpg	\N	image/jpeg	1739467	t	t	2025-12-26 14:33:49	2025-12-26 14:33:49	\N
167	111	72	video	video-13	page_section_images/1766759691_c1a4917b58c218386f15744094c20059373d611d-min.png	\N	image/png	895781	t	t	2025-12-26 14:34:51	2025-12-26 14:34:51	\N
168	112	72	video	video-13	page_section_images/1766759710_form.jpg	\N	image/jpeg	192942	t	t	2025-12-26 14:35:10	2025-12-26 14:35:10	\N
169	113	72	video	video-13	page_section_images/1766759723_oila1.jpg	\N	image/jpeg	1739467	t	t	2025-12-26 14:35:24	2025-12-26 14:35:24	\N
170	114	73	video	video-14	page_section_images/1766759756_c1a4917b58c218386f15744094c20059373d611d-min.png	\N	image/png	895781	t	t	2025-12-26 14:35:56	2025-12-26 14:35:56	\N
171	115	73	video	video-14	page_section_images/1766759771_form.jpg	\N	image/jpeg	192942	t	t	2025-12-26 14:36:11	2025-12-26 14:36:11	\N
172	116	73	video	video-14	page_section_images/1766759787_oila1.jpg	\N	image/jpeg	1739467	t	t	2025-12-26 14:36:27	2025-12-26 14:36:27	\N
292	165	\N	\N	\N	page_section_images/1767601245_volunteer-2.png	\N	image/png	51409	t	t	2026-01-05 08:20:45	2026-01-05 08:20:45	\N
296	170	\N	\N	\N	page_section_images/1767601368_volunteer-7.png	\N	image/png	55422	t	t	2026-01-05 08:22:48	2026-01-05 08:22:48	\N
180	4	\N	\N	\N	page_section_images/1766864471_prezident.png	\N	image/png	58403	t	t	2025-12-27 19:41:11	2025-12-27 19:41:11	\N
187	124	19	tashkilot	tashkilot	page_section_images/1766995973_association-1.png	\N	image/png	80956	t	t	2025-12-29 08:12:53	2025-12-29 08:12:53	\N
188	125	19	tashkilot	tashkilot	page_section_images/1766996015_association-3.png	\N	image/png	11024	t	t	2025-12-29 08:13:35	2025-12-29 08:13:35	\N
189	126	124	Nomi	nomi-5	page_section_images/1766996150_association-1.png	\N	image/png	80956	t	t	2025-12-29 08:15:50	2025-12-29 08:15:50	\N
190	128	124	Rahbar	rahbar-5	page_section_images/1766996525_2302d0d79c36d32933b02c7f1b9e6140350fad23.png	\N	image/png	565477	t	t	2025-12-29 08:22:05	2025-12-29 08:22:05	\N
191	129	\N	\N	\N	page_section_images/1766998645_association-2.png	\N	image/png	8354	t	t	2025-12-29 08:57:25	2025-12-29 08:57:25	\N
192	29	\N	\N	\N	page_section_images/1767000379_2302d0d79c36d32933b02c7f1b9e6140350fad23.png	\N	image/png	565477	f	t	2025-12-29 09:26:19	2025-12-29 09:26:19	\N
193	29	\N	\N	\N	page_section_images/1767000379_2302d0d79c36d32933b02c7f1b9e6140350fad23.png	\N	image/png	565477	t	t	2025-12-29 09:26:19	2025-12-29 09:26:19	\N
293	166	\N	\N	\N	page_section_images/1767601269_volunteer-3.png	\N	image/png	56798	t	t	2026-01-05 08:21:09	2026-01-05 08:21:09	\N
297	171	\N	\N	\N	page_section_images/1767601399_volunteer-8.png	\N	image/png	52654	t	t	2026-01-05 08:23:19	2026-01-05 08:23:19	\N
196	132	\N	\N	\N	page_section_images/1767011429_0a9de2d13f6d63a28051589157af258de5c64e37.jpg	\N	image/jpeg	478813	t	t	2025-12-29 12:30:29	2025-12-29 12:30:29	\N
197	133	\N	\N	\N	page_section_images/1767011476_71596a3c79e6ea29869f23118068e52cdaa097e0.png	\N	image/png	1051197	t	t	2025-12-29 12:31:16	2025-12-29 12:31:16	\N
198	134	\N	\N	\N	page_section_images/1767011517_662b4243d213d533c2a32dc5abe015394d50cc47.png	\N	image/png	3427681	t	t	2025-12-29 12:31:57	2025-12-29 12:31:57	\N
207	131	\N	\N	\N	page_section_images/1767013363_prezident.png	\N	image/png	58403	f	t	2025-12-29 13:02:43	2025-12-29 13:02:43	\N
208	131	\N	\N	\N	page_section_images/1767013363_video-3.png	\N	image/png	1739467	t	t	2025-12-29 13:02:43	2025-12-29 13:02:43	\N
209	135	\N	\N	\N	page_section_images/1767090564_video-3.png	\N	image/png	1739467	f	t	2025-12-30 10:29:25	2025-12-30 10:29:25	\N
210	135	\N	\N	\N	page_section_images/1767090565_9f44c2e308de8a752650fc50f9a730e071877078.png	\N	image/png	1672804	f	t	2025-12-30 10:29:25	2025-12-30 10:29:25	\N
211	135	\N	\N	\N	page_section_images/1767090565_71596a3c79e6ea29869f23118068e52cdaa097e0.png	\N	image/png	1051197	f	t	2025-12-30 10:29:25	2025-12-30 10:29:25	\N
212	135	\N	\N	\N	page_section_images/1767090565_association-2.png	\N	image/png	8354	f	t	2025-12-30 10:29:25	2025-12-30 10:29:25	\N
213	139	\N	\N	\N	page_section_images/1767090592_2302d0d79c36d32933b02c7f1b9e6140350fad23.png	\N	image/png	565477	f	t	2025-12-30 10:29:52	2025-12-30 10:29:52	\N
214	139	\N	\N	\N	page_section_images/1767090592_association-4.png	\N	image/png	5583	f	t	2025-12-30 10:29:52	2025-12-30 10:29:52	\N
466	214	\N	\N	\N	news/a0e71977-2263-4253-8e49-82f199ea0ed0231.jpg	\N	image/jpeg	202670	f	t	2026-01-23 04:57:31	2026-01-23 04:57:31	\N
216	139	\N	\N	\N	page_section_images/1767090592_association-2.png	\N	image/png	8354	f	t	2025-12-30 10:29:52	2025-12-30 10:29:52	\N
217	139	\N	\N	\N	page_section_images/1767090592_association-1.png	\N	image/png	80956	f	t	2025-12-30 10:29:52	2025-12-30 10:29:52	\N
218	139	\N	\N	\N	page_section_images/1767090592_flag-en.png	\N	image/png	18142	f	t	2025-12-30 10:29:52	2025-12-30 10:29:52	\N
219	139	\N	\N	\N	page_section_images/1767090592_flag-ru.png	\N	image/png	1743	f	t	2025-12-30 10:29:52	2025-12-30 10:29:52	\N
220	139	\N	\N	\N	page_section_images/1767090592_flag-uz.png	\N	image/png	9976	f	t	2025-12-30 10:29:52	2025-12-30 10:29:52	\N
244	150	\N	\N	\N	page_section_images/1767124750_71596a3c79e6ea29869f23118068e52cdaa097e0.png	\N	image/png	1051197	f	t	2025-12-30 19:59:11	2025-12-30 19:59:11	\N
245	150	\N	\N	\N	page_section_images/1767124751_9f44c2e308de8a752650fc50f9a730e071877078.png	\N	image/png	1672804	f	t	2025-12-30 19:59:11	2025-12-30 19:59:11	\N
246	150	\N	\N	\N	page_section_images/1767124751_f87cf5263832720cdbe41c7eb7faa98cae5c58a2.png	\N	image/png	786846	f	t	2025-12-30 19:59:11	2025-12-30 19:59:11	\N
247	150	\N	\N	\N	page_section_images/1767124751_7f1beefe896a37c2a8669f8c96ad0b81629aa952.png	\N	image/png	751123	f	t	2025-12-30 19:59:11	2025-12-30 19:59:11	\N
248	151	\N	\N	\N	page_section_images/1767124785_7f1beefe896a37c2a8669f8c96ad0b81629aa952.png	\N	image/png	751123	f	t	2025-12-30 19:59:45	2025-12-30 19:59:45	\N
249	151	\N	\N	\N	page_section_images/1767124785_flag-uz.png	\N	image/png	9976	f	t	2025-12-30 19:59:45	2025-12-30 19:59:45	\N
250	151	\N	\N	\N	page_section_images/1767124785_2302d0d79c36d32933b02c7f1b9e6140350fad23.png	\N	image/png	565477	f	t	2025-12-30 19:59:45	2025-12-30 19:59:45	\N
251	151	\N	\N	\N	page_section_images/1767124785_association-3.png	\N	image/png	11024	f	t	2025-12-30 19:59:45	2025-12-30 19:59:45	\N
252	152	\N	\N	\N	page_section_images/1767142699_7f1beefe896a37c2a8669f8c96ad0b81629aa952.png	\N	image/png	751123	f	t	2025-12-31 00:58:19	2025-12-31 00:58:19	\N
253	152	\N	\N	\N	page_section_images/1767142699_f87cf5263832720cdbe41c7eb7faa98cae5c58a2.png	\N	image/png	786846	f	t	2025-12-31 00:58:19	2025-12-31 00:58:19	\N
254	152	\N	\N	\N	page_section_images/1767142699_news-img-2.png	\N	image/png	23441	f	t	2025-12-31 00:58:19	2025-12-31 00:58:19	\N
255	152	\N	\N	\N	page_section_images/1767142699_news-img-1.png	\N	image/png	1264559	f	t	2025-12-31 00:58:19	2025-12-31 00:58:19	\N
256	152	\N	\N	\N	page_section_images/1767142699_662b4243d213d533c2a32dc5abe015394d50cc47.png	\N	image/png	3427681	f	t	2025-12-31 00:58:19	2025-12-31 00:58:19	\N
257	153	\N	\N	\N	page_section_images/1767142745_form.jpg	\N	image/jpeg	192942	f	t	2025-12-31 00:59:05	2025-12-31 00:59:05	\N
258	153	\N	\N	\N	page_section_images/1767142745_oila1.jpg	\N	image/jpeg	1739467	f	t	2025-12-31 00:59:05	2025-12-31 00:59:05	\N
259	153	\N	\N	\N	page_section_images/1767142745_Salah.jpg	\N	image/jpeg	108682	f	t	2025-12-31 00:59:05	2025-12-31 00:59:05	\N
260	153	\N	\N	\N	page_section_images/1767142745_Taqu.jpg	\N	image/jpeg	62105	f	t	2025-12-31 00:59:05	2025-12-31 00:59:05	\N
267	160	\N	\N	\N	page_section_images/1767589153_oila1.jpg	\N	image/jpeg	1739467	t	t	2026-01-05 04:59:13	2026-01-05 04:59:13	\N
268	161	\N	\N	\N	page_section_images/1767589184_9f44c2e308de8a752650fc50f9a730e071877078.png	\N	image/png	1672804	t	t	2026-01-05 04:59:44	2026-01-05 04:59:44	\N
269	162	\N	\N	\N	page_section_images/1767589218_logooo.png	\N	image/png	2159430	t	t	2026-01-05 05:00:18	2026-01-05 05:00:18	\N
270	163	\N	\N	\N	page_section_images/1767589257_Salah.jpg	\N	image/jpeg	108682	t	t	2026-01-05 05:00:57	2026-01-05 05:00:57	\N
274	168	\N	\N	\N	page_section_images/1767597019_oila1.jpg	\N	image/jpeg	1739467	t	t	2026-01-05 07:10:19	2026-01-05 07:10:19	\N
294	167	\N	\N	\N	page_section_images/1767601294_volunteer-4.png	\N	image/png	34293	t	t	2026-01-05 08:21:34	2026-01-05 08:21:34	\N
281	33	\N	\N	\N	page_section_images/1767599574_news-1.png	\N	image/png	69957	t	t	2026-01-05 07:52:54	2026-01-05 07:52:54	\N
298	172	\N	\N	\N	page_section_images/1767601425_volunteer-9.png	\N	image/png	44925	t	t	2026-01-05 08:23:46	2026-01-05 08:23:46	\N
283	119	\N	\N	\N	page_section_images/1767599907_news-4.jpg	\N	image/jpeg	89775	t	t	2026-01-05 07:58:27	2026-01-05 07:58:27	\N
286	149	\N	\N	\N	page_section_images/1767600110_projects-1.png	\N	image/png	78356	t	t	2026-01-05 08:01:50	2026-01-05 08:01:50	\N
465	118	\N	\N	\N	news/a0e5d3b2-85f2-4c9e-a036-7e405a07293c414.jpg	\N	image/jpeg	44141	t	t	2026-01-22 13:46:36	2026-01-22 13:46:46	\N
357	20	\N	\N	\N	page_section_images/1768279294_Vector (5).png	\N	image/png	2413	f	t	2026-01-13 04:41:34	2026-01-13 04:41:34	\N
358	20	\N	\N	\N	page_section_images/1768279294_Frame 1321315991 (16).png	\N	image/png	1642	f	t	2026-01-13 04:41:34	2026-01-13 04:41:34	\N
13	120	\N	\N	\N	video/a0db86bc-e5c3-406c-8c84-f9577abccec253.mp4	\N	video/mp4	12734611	t	t	2026-01-17 10:53:08	2026-01-17 10:53:39	\N
411	148	\N	\N	\N	projects/a0df2711-3900-44fc-bb74-5341f5194b02380.jpg	\N	image/jpeg	162139	t	t	2026-01-19 06:08:55	2026-01-19 06:08:58	\N
415	191	\N	\N	\N	asosiy_rasmlar/a0e020e9-9c2a-4080-a44e-64f95954426c76.png	\N	image/png	704035	t	t	2026-01-19 17:47:32	2026-01-19 17:47:41	\N
416	192	\N	\N	\N	page_section_images/a0e02116-ba1a-4cc9-8cb6-c217ff9e20db15.png	\N	image/png	550254	t	t	2026-01-19 17:48:02	2026-01-19 17:48:02	\N
417	193	\N	\N	\N	page_section_images/a0e02135-9552-49e8-9800-7a9b9853c6cf450.png	\N	image/png	600965	t	t	2026-01-19 17:48:22	2026-01-19 17:48:22	\N
420	157	\N	\N	\N	projects/a0e10fa0-0af5-4c51-ae49-eae8921d51a5111.jpg	\N	image/jpeg	149642	t	t	2026-01-20 04:55:02	2026-01-20 04:55:09	\N
421	156	\N	\N	\N	projects/a0e10fce-2482-4376-b1b2-29c7651f67ad452.jpg	\N	image/jpeg	84421	t	t	2026-01-20 04:55:32	2026-01-20 04:55:37	\N
422	158	\N	\N	\N	projects/a0e10fe6-27a6-4e2b-af3d-400d8dc62213241.jpg	\N	image/jpeg	89775	t	t	2026-01-20 04:55:48	2026-01-20 04:55:56	\N
423	148	\N	\N	\N	projects/a0e12d63-9948-49cf-8fad-ee828dea3227232.png	\N	image/png	584803	f	t	2026-01-20 06:18:15	2026-01-20 06:18:15	\N
424	194	\N	\N	\N	cc/a0e13774-e674-4db5-a887-676337687214172.png	\N	image/png	44699	t	t	2026-01-20 06:46:24	2026-01-20 06:46:28	\N
419	190	\N	\N	\N	cc/a0e0262f-c73d-45e1-9b55-5f5025d5162d276.jpg	\N	image/jpeg	268394	t	t	2026-01-19 18:02:17	2026-01-20 06:46:49	\N
425	195	\N	\N	\N	page_section_images/a0e33595-2a32-4177-8bdc-6473fb97d58c38.svg	\N	image/svg+xml	1682	t	t	2026-01-21 06:32:49	2026-01-21 06:32:49	\N
426	196	\N	\N	\N	page_section_images/a0e335ba-2f3d-407b-b332-09fef4d0c7b7325.svg	\N	image/svg+xml	1898	t	t	2026-01-21 06:33:14	2026-01-21 06:33:14	\N
427	197	\N	\N	\N	page_section_images/a0e335e4-1915-48f8-bc66-67adff5d8f86299.svg	\N	image/svg+xml	3074	t	t	2026-01-21 06:33:41	2026-01-21 06:33:41	\N
428	198	\N	\N	\N	page_section_images/a0e33612-843c-489a-871a-3b4324f9a033432.svg	\N	image/svg+xml	1558	t	t	2026-01-21 06:34:12	2026-01-21 06:34:12	\N
429	199	\N	\N	\N	page_section_images/a0e3364a-7ec8-43f0-9a52-488c7e29bf17100.svg	\N	image/svg+xml	2922	t	t	2026-01-21 06:34:48	2026-01-21 06:34:48	\N
430	200	\N	\N	\N	page_section_images/a0e3367e-9b9f-42ad-a178-959da1932c51251.svg	\N	image/svg+xml	1798	t	t	2026-01-21 06:35:22	2026-01-21 06:35:22	\N
431	201	\N	\N	\N	page_section_images/a0e336a3-8c93-4850-95e0-1d8b498c58ae60.svg	\N	image/svg+xml	2078	t	t	2026-01-21 06:35:47	2026-01-21 06:35:47	\N
432	202	\N	\N	\N	page_section_images/a0e336c6-2e7c-4a16-82a8-3ea68d861193244.svg	\N	image/svg+xml	1706	t	t	2026-01-21 06:36:09	2026-01-21 06:36:09	\N
433	203	\N	\N	\N	page_section_images/a0e336e8-8d8f-4f7c-9420-d30b67a8f75c313.svg	\N	image/svg+xml	1762	t	t	2026-01-21 06:36:32	2026-01-21 06:36:32	\N
435	205	\N	\N	\N	mutoola/a0e3ae4b-61d3-49cc-8c4c-4a6b51a9ef76323.png	\N	image/png	22697	f	t	2026-01-21 12:10:21	2026-01-21 12:10:21	\N
438	206	\N	\N	\N	page_section_images/a0e437fe-b452-46a7-94f5-c946457867e6186.png	\N	image/png	276545	f	t	2026-01-21 18:35:24	2026-01-21 18:35:24	\N
439	206	\N	\N	\N	page_section_images/a0e437fe-b697-430f-bc53-2feae6fb3ceb102.png	\N	image/png	357584	f	t	2026-01-21 18:35:24	2026-01-21 18:35:24	\N
440	206	\N	\N	\N	page_section_images/a0e437fe-b7dc-4265-acde-ea079724b2f2402.png	\N	image/png	684760	f	t	2026-01-21 18:35:24	2026-01-21 18:35:24	\N
441	207	\N	\N	\N	page_section_images/a0e43839-478f-458a-938a-d05703bbac8172.png	\N	image/png	704035	f	t	2026-01-21 18:36:02	2026-01-21 18:36:02	\N
442	207	\N	\N	\N	page_section_images/a0e43839-4987-4aaa-8f83-c6f7f3dd2de7178.png	\N	image/png	550254	f	t	2026-01-21 18:36:02	2026-01-21 18:36:02	\N
443	207	\N	\N	\N	page_section_images/a0e43839-4abc-40c0-9f48-7664fe32fc91294.png	\N	image/png	600965	f	t	2026-01-21 18:36:02	2026-01-21 18:36:02	\N
444	208	\N	\N	\N	page_section_images/a0e438a0-dfa1-4b55-a3b6-06b4cb81c41b65.jpg	\N	image/jpeg	84421	f	t	2026-01-21 18:37:10	2026-01-21 18:37:10	\N
445	208	\N	\N	\N	page_section_images/a0e438a0-e149-4970-92dc-9c11fa869b69241.jpg	\N	image/jpeg	149642	f	t	2026-01-21 18:37:10	2026-01-21 18:37:10	\N
446	208	\N	\N	\N	page_section_images/a0e438a0-e221-4a23-8d0a-cc0cc097fc9776.jpg	\N	image/jpeg	89775	f	t	2026-01-21 18:37:10	2026-01-21 18:37:10	\N
447	209	\N	\N	\N	page_section_images/a0e43900-9599-45df-8ec3-955725b4659a37.jpg	\N	image/jpeg	149642	f	t	2026-01-21 18:38:13	2026-01-21 18:38:13	\N
448	209	\N	\N	\N	podcastlar/a0e43de0-a8b2-42d3-9130-0abb3ceac28c271.png	\N	image/png	44699	f	t	2026-01-21 18:51:51	2026-01-21 18:51:51	\N
449	209	\N	\N	\N	podcastlar/a0e43de0-aac7-41d8-9e46-aa16c8291276211.jpg	\N	image/jpeg	268394	f	t	2026-01-21 18:51:51	2026-01-21 18:51:51	\N
452	211	\N	\N	\N	page_section_images/a0e521d6-f2ed-4145-b81a-fa63b8d422de177.jpg	\N	image/jpeg	202670	f	t	2026-01-22 05:29:16	2026-01-22 05:29:16	\N
453	211	\N	\N	\N	page_section_images/a0e521d6-f506-4b82-9380-eb3a6b35badc347.jpg	\N	image/jpeg	239502	f	t	2026-01-22 05:29:16	2026-01-22 05:29:16	\N
454	211	\N	\N	\N	page_section_images/a0e521d6-f5f4-4443-9728-d454a29ba231257.jpg	\N	image/jpeg	55392	t	t	2026-01-22 05:29:16	2026-01-22 05:29:16	\N
436	205	\N	\N	\N	mutoola/a0e3ae54-6a06-405b-b813-cf02125d0745234.png	\N	image/png	13393	f	t	2026-01-21 12:10:27	2026-01-22 05:51:20	\N
437	205	\N	\N	\N	mutoola/a0e3ae5f-9456-4415-946b-dc78671dcf52119.png	\N	image/png	22382	t	t	2026-01-21 12:10:35	2026-01-22 05:51:20	\N
455	187	\N	\N	\N	mediateka/a0e575a9-e908-47fc-9707-0cf6d1837732371.jpg	\N	image/jpeg	202670	t	t	2026-01-22 09:23:40	2026-01-22 09:23:43	\N
457	212	\N	\N	\N	ariza_yuborish/a0e58a6b-c247-4b3d-9e33-c7c25354b7b9133.png	\N	image/png	51409	f	t	2026-01-22 10:21:42	2026-01-22 10:21:42	\N
458	212	\N	\N	\N	ariza_yuborish/a0e58a6b-c473-4657-8e3c-5b069839a247309.png	\N	image/png	56798	f	t	2026-01-22 10:21:42	2026-01-22 10:21:42	\N
459	212	\N	\N	\N	ariza_yuborish/a0e58a6b-c552-4eed-bfab-dfffcd031668327.png	\N	image/png	34293	f	t	2026-01-22 10:21:42	2026-01-22 10:21:42	\N
460	212	\N	\N	\N	ariza_yuborish/a0e58a83-5b6d-48f5-b0cb-3de30e862885497.png	\N	image/png	146615	f	t	2026-01-22 10:21:58	2026-01-22 10:21:58	\N
461	213	\N	\N	\N	page_section_images/a0e58ae0-76eb-4de2-9651-f1e049f5eaad385.png	\N	image/png	160666	f	t	2026-01-22 10:22:59	2026-01-22 10:22:59	\N
462	213	\N	\N	\N	page_section_images/a0e58ae0-78be-4e76-b215-f8af82128c93208.png	\N	image/png	105042	f	t	2026-01-22 10:22:59	2026-01-22 10:22:59	\N
463	213	\N	\N	\N	page_section_images/a0e58ae0-79dc-4654-a458-c10ed795c02c383.png	\N	image/png	55422	f	t	2026-01-22 10:22:59	2026-01-22 10:22:59	\N
464	213	\N	\N	\N	page_section_images/a0e58ae0-7acf-44b6-9195-4be29a139c26162.png	\N	image/png	52654	f	t	2026-01-22 10:22:59	2026-01-22 10:22:59	\N
\.


--
-- Data for Name: page_section_settings; Type: TABLE DATA; Schema: public; Owner: vatandoshlar_usr
--

COPY public.page_section_settings (id, menu_main_id, page_section_parent_id, category, category_slug, key, label, type, required, is_translatable, options, sort_order, relation, status, created_at, updated_at) FROM stdin;
1	2	\N	\N	\N	title	Title	text	t	t	\N	1	\N	t	2025-12-23 04:42:26	2025-12-23 04:42:26
2	2	\N	\N	\N	description	Description	text	t	t	\N	1	\N	t	2025-12-23 04:42:26	2025-12-23 04:42:26
3	3	\N	\N	\N	title	Title	text	t	t	\N	1	\N	t	2025-12-23 04:44:11	2025-12-23 04:44:11
4	3	\N	\N	\N	number	Number	text	t	f	\N	1	\N	t	2025-12-23 04:44:12	2025-12-23 04:44:12
5	4	\N	\N	\N	title	Title	text	t	t	\N	1	\N	t	2025-12-23 04:49:23	2025-12-23 04:49:23
6	4	\N	\N	\N	content	Content	text	t	t	\N	1	\N	t	2025-12-23 04:49:24	2025-12-23 04:49:24
7	4	\N	\N	\N	description	Description	text	t	t	\N	1	\N	t	2025-12-23 04:49:24	2025-12-23 04:49:24
8	4	\N	\N	\N	content1	Content1	text	t	t	\N	1	\N	t	2025-12-23 04:49:24	2025-12-23 04:49:24
9	11	\N	\N	\N	title	Title	text	t	t	\N	1	\N	t	2025-12-23 05:05:21	2025-12-23 05:05:21
10	11	\N	\N	\N	description	Description	text	t	t	\N	1	\N	t	2025-12-23 05:05:21	2025-12-23 05:05:21
11	12	\N	\N	\N	title	Title	text	t	t	\N	1	\N	t	2025-12-23 05:06:52	2025-12-23 05:06:52
12	7	\N	\N	\N	title	Title	text	t	t	\N	1	\N	t	2025-12-23 05:09:20	2025-12-23 05:09:20
13	7	\N	\N	\N	description	Description	text	t	t	\N	1	\N	t	2025-12-23 05:09:20	2025-12-23 05:09:20
14	9	\N	\N	\N	title	Title	text	t	t	\N	1	\N	t	2025-12-23 05:11:02	2025-12-23 05:11:02
15	9	\N	\N	\N	description	Description	text	t	t	\N	1	\N	t	2025-12-23 05:11:02	2025-12-23 05:11:02
16	10	\N	\N	\N	title	Title	text	t	t	\N	1	\N	t	2025-12-23 05:12:17	2025-12-23 05:12:17
17	10	\N	\N	\N	description	Description	text	t	t	\N	1	\N	t	2025-12-23 05:12:17	2025-12-23 05:12:17
151	36	\N	\N	\N	title	Title	text	t	t	\N	1	\N	t	2025-12-29 09:58:52	2025-12-29 09:58:52
63	16	\N	\N	\N	title	Title	text	t	t	\N	1	\N	t	2025-12-25 09:46:24	2025-12-25 09:46:24
20	18	\N	\N	\N	description	Description	textarea	t	t	\N	1	\N	t	2025-12-23 05:26:22	2025-12-23 05:26:44
21	18	\N	\N	\N	content	Content	textarea	t	t	\N	1	\N	t	2025-12-23 05:27:46	2025-12-23 05:27:46
22	19	\N	\N	\N	title	Title	text	t	t	\N	1	\N	t	2025-12-23 05:29:40	2025-12-23 05:29:40
23	14	\N	\N	\N	title	Title	text	t	t	\N	1	\N	t	2025-12-23 05:31:09	2025-12-23 05:31:09
24	14	\N	\N	\N	phone	Phone	text	t	f	\N	1	\N	t	2025-12-23 05:31:09	2025-12-23 05:31:09
25	14	\N	\N	\N	email	Email	text	t	f	\N	1	\N	t	2025-12-23 05:31:09	2025-12-23 05:31:09
26	15	\N	\N	\N	title	Title	text	t	t	\N	1	\N	t	2025-12-23 05:33:37	2025-12-23 05:33:37
27	23	\N	\N	\N	title	Title	text	t	t	\N	1	\N	t	2025-12-23 05:45:15	2025-12-23 05:45:15
28	22	\N	\N	\N	title	Title	textarea	t	t	\N	1	\N	t	2025-12-23 05:45:51	2025-12-23 05:45:51
154	41	\N	\N	\N	title	Title	text	t	t	\N	1	\N	t	2025-12-29 12:33:13	2025-12-29 12:33:13
29	23	19	tashkilot	tashkilot	title	Title	text	t	f	\N	1	\N	t	2025-12-23 05:53:34	2025-12-23 05:53:34
30	23	21	Nomi	nomi	title	Title	text	t	t	\N	1	\N	t	2025-12-23 05:54:40	2025-12-23 05:54:40
31	23	21	Nomi	nomi	date_at	Date_at	text	t	f	\N	1	\N	t	2025-12-23 05:54:40	2025-12-23 05:54:58
33	23	21	Rahbar	rahbar	title	Title	text	t	t	\N	1	\N	t	2025-12-23 05:56:49	2025-12-23 05:56:49
34	23	21	Rahbar	rahbar	phone	Phone	text	t	f	\N	1	\N	t	2025-12-23 05:56:49	2025-12-23 05:56:49
35	23	21	Rahbar	rahbar	email	Email	text	t	f	\N	1	\N	t	2025-12-23 05:56:49	2025-12-23 05:56:49
36	23	24	Nomi	nomi-1	title	Title	text	t	t	\N	1	\N	t	2025-12-23 05:58:58	2025-12-23 05:58:58
37	23	24	Nomi	nomi-1	date_at	Date_at	text	t	t	\N	1	\N	t	2025-12-23 05:58:58	2025-12-23 05:58:58
38	23	24	Nomi	nomi-1	first_boss	Boss	text	t	t	\N	1	\N	t	2025-12-23 05:58:58	2025-12-23 05:58:58
39	23	24	Rahbar	rahbar-1	title	Title	text	t	t	\N	1	\N	t	2025-12-23 06:00:15	2025-12-23 06:00:15
40	23	24	Rahbar	rahbar-1	phone	Phone	text	t	f	\N	1	\N	t	2025-12-23 06:00:15	2025-12-23 06:00:15
41	23	24	Rahbar	rahbar-1	email	Email	text	t	f	\N	1	\N	t	2025-12-23 06:00:15	2025-12-23 06:00:15
42	23	20	tashkilot	tashkilot-1	title	Title	text	t	t	\N	1	\N	t	2025-12-23 06:02:00	2025-12-23 06:02:00
43	23	27	Nomi	nomi-2	title	Title	text	t	t	\N	1	\N	t	2025-12-23 06:03:21	2025-12-23 06:03:21
44	23	27	Nomi	nomi-2	date_at	Date_at	text	t	f	\N	1	\N	t	2025-12-23 06:03:21	2025-12-23 06:03:21
46	23	27	Rahbar	rahbar-2	title	Title	text	t	t	\N	1	\N	t	2025-12-23 06:04:49	2025-12-23 06:04:49
48	23	27	Rahbar	rahbar-2	email	Email	text	t	f	\N	1	\N	t	2025-12-23 06:04:49	2025-12-23 06:04:49
49	23	30	Nomi	nomi-3	title	Title	text	t	t	\N	1	\N	t	2025-12-23 06:06:54	2025-12-23 06:06:54
50	23	30	Nomi	nomi-3	date_at	Date_at	text	t	f	\N	1	\N	t	2025-12-23 06:06:54	2025-12-23 06:06:54
51	23	30	Nomi	nomi-3	first_boss	Boss	text	t	f	\N	1	\N	t	2025-12-23 06:06:54	2025-12-23 06:06:54
52	23	30	Rahbar	rahbar-3	title	Title	text	t	t	\N	1	\N	t	2025-12-23 06:08:04	2025-12-23 06:08:04
53	23	30	Rahbar	rahbar-3	phone	Phone	text	t	f	\N	1	\N	t	2025-12-23 06:08:04	2025-12-23 06:08:04
54	23	30	Rahbar	rahbar-3	email	Email	text	t	f	\N	1	\N	t	2025-12-23 06:08:04	2025-12-23 06:08:04
55	26	\N	\N	\N	title	Title	text	t	t	\N	1	\N	t	2025-12-23 06:20:02	2025-12-23 06:20:02
58	27	\N	\N	\N	title	Title	text	t	t	\N	1	\N	t	2025-12-23 06:21:59	2025-12-23 06:21:59
18	17	\N	\N	\N	description	Description	text	t	t	\N	1	\N	t	2025-12-23 05:18:57	2025-12-25 08:28:51
19	18	\N	\N	\N	title	Title	text	t	t	\N	1	\N	t	2025-12-23 05:26:22	2025-12-25 08:30:29
59	24	\N	\N	\N	title	Title	text	t	t	\N	1	\N	t	2025-12-25 08:46:46	2025-12-25 08:46:46
60	24	\N	\N	\N	description	Description	text	t	t	\N	1	\N	t	2025-12-25 08:46:46	2025-12-25 08:46:46
61	24	\N	\N	\N	content	Content	text	t	t	\N	1	\N	t	2025-12-25 08:46:46	2025-12-25 08:46:46
65	6	\N	\N	\N	title	Title	text	t	t	\N	1	\N	t	2025-12-25 09:55:32	2025-12-25 09:55:32
66	6	\N	\N	\N	description	Description	text	t	t	\N	1	\N	t	2025-12-25 09:55:32	2025-12-25 09:55:32
67	6	\N	\N	\N	url	Url	text	t	t	\N	1	\N	t	2025-12-25 13:17:35	2025-12-25 13:17:35
68	28	\N	\N	\N	title	Title	text	t	t	\N	1	\N	t	2025-12-25 13:21:49	2025-12-25 13:21:49
69	28	\N	\N	\N	url	Url	text	t	t	\N	1	\N	t	2025-12-25 13:21:49	2025-12-25 13:21:49
70	29	\N	\N	\N	title	Title	text	t	t	\N	1	\N	t	2025-12-25 13:23:00	2025-12-25 13:23:00
71	29	\N	\N	\N	description	Description	text	t	t	\N	1	\N	t	2025-12-25 13:23:00	2025-12-25 13:23:00
72	30	\N	\N	\N	title	Title	text	t	t	\N	1	\N	t	2025-12-25 13:31:28	2025-12-25 13:31:28
32	23	21	Nomi	nomi	boss_at	Boss_at	text	t	f	\N	1	\N	t	2025-12-23 05:54:40	2025-12-29 08:09:23
45	23	27	Nomi	nomi-2	boss_at	Boss_at	text	t	f	\N	1	\N	t	2025-12-23 06:03:21	2025-12-29 09:23:20
74	31	\N	\N	\N	title	Title	text	t	t	\N	1	\N	t	2025-12-25 13:35:17	2025-12-25 13:35:17
75	31	\N	\N	\N	description	Description	text	t	t	\N	1	\N	t	2025-12-25 13:35:17	2025-12-25 13:35:17
62	24	\N	\N	\N	url	Url	text	t	f	\N	1	\N	t	2025-12-25 08:46:46	2026-01-22 12:02:43
64	16	\N	\N	\N	description	Description	textarea-editor	t	t	\N	1	\N	t	2025-12-25 09:46:24	2026-01-23 14:05:54
47	23	27	Rahbar	rahbar-2	phone	Phone	text	t	f	\N	1	\N	t	2025-12-23 06:04:49	2025-12-29 09:25:27
76	27	\N	\N	\N	url	Url	text	t	f	\N	1	\N	t	2025-12-26 05:11:06	2025-12-26 05:12:04
77	14	\N	\N	\N	description	Description	text	t	t	\N	1	\N	t	2025-12-26 05:16:30	2025-12-26 05:16:30
78	7	\N	\N	\N	url	Url	text	t	f	\N	1	\N	t	2025-12-26 05:18:39	2025-12-26 05:21:46
80	9	\N	\N	\N	url	Url	text	t	f	\N	1	\N	t	2025-12-26 05:27:34	2025-12-26 05:29:14
73	30	\N	\N	\N	url	Url	text	t	f	\N	1	\N	t	2025-12-25 13:31:28	2025-12-26 09:35:27
83	30	52	Url	url	url	Url	text	t	f	\N	1	\N	t	2025-12-26 11:09:36	2025-12-26 11:09:49
85	32	\N	\N	\N	title	Title	text	t	t	\N	1	\N	t	2025-12-26 13:16:02	2025-12-26 13:16:02
86	32	\N	\N	\N	description	Description	text	t	t	\N	1	\N	t	2025-12-26 13:16:02	2025-12-26 13:16:02
88	33	\N	\N	\N	path	Path	text	t	f	\N	1	\N	t	2025-12-26 13:18:29	2025-12-26 13:21:25
89	33	\N	\N	\N	description	Description	text	t	t	\N	1	\N	t	2025-12-26 13:37:38	2025-12-26 13:40:01
87	33	\N	\N	\N	title	Title	text	t	t	\N	1	\N	t	2025-12-26 13:18:29	2025-12-26 13:42:31
90	33	60	video	video	url	Url	text	t	f	\N	1	\N	t	2025-12-26 13:55:22	2025-12-26 13:55:22
91	33	61	video	video-1	url	Url	text	t	f	\N	1	\N	t	2025-12-26 13:57:14	2025-12-26 13:57:14
92	33	62	video	video-2	url	Url	text	t	f	\N	1	\N	t	2025-12-26 14:17:16	2025-12-26 14:17:16
93	33	63	video	video-3	url	Url	text	t	f	\N	1	\N	t	2025-12-26 14:18:35	2025-12-26 14:18:35
94	33	64	video	video-4	url	Url	text	t	f	\N	1	\N	t	2025-12-26 14:19:53	2025-12-26 14:19:53
95	33	65	video	video-5	url	Url	text	t	t	\N	1	\N	t	2025-12-26 14:21:29	2025-12-26 14:21:29
96	33	65	video	video-5	url	Url	text	t	f	\N	1	\N	t	2025-12-26 14:22:03	2025-12-26 14:22:03
97	33	65	video	video-5	url	Url	text	t	f	\N	1	\N	t	2025-12-26 14:23:15	2025-12-26 14:23:15
98	33	89	video	video-6	url	Url	text	t	f	\N	1	\N	t	2025-12-26 14:25:38	2025-12-26 14:25:38
99	33	66	video	video-7	url	Url	text	t	f	\N	1	\N	t	2025-12-26 14:27:12	2025-12-26 14:27:12
100	33	67	video	video-8	url	Url	text	t	f	\N	1	\N	t	2025-12-26 14:28:24	2025-12-26 14:28:24
101	33	68	video	video-9	url	Url	text	t	f	\N	1	\N	t	2025-12-26 14:29:34	2025-12-26 14:29:34
102	33	69	video	video-10	url	Url	text	t	f	\N	1	\N	t	2025-12-26 14:30:36	2025-12-26 14:30:36
103	33	70	video	video-11	url	Url	text	t	f	\N	1	\N	t	2025-12-26 14:31:52	2025-12-26 14:31:52
104	33	71	video	video-12	url	Url	text	t	f	\N	1	\N	t	2025-12-26 14:33:03	2025-12-26 14:33:03
105	33	72	video	video-13	url	Url	text	t	f	\N	1	\N	t	2025-12-26 14:34:36	2025-12-26 14:34:36
106	33	73	video	video-14	url	Url	text	t	f	\N	1	\N	t	2025-12-26 14:35:42	2025-12-26 14:35:42
107	33	\N	\N	\N	code	Code	text	t	f	\N	1	\N	t	2025-12-27 07:01:08	2025-12-27 07:01:39
108	33	\N	\N	\N	offset	Offset	text	t	f	\N	1	\N	t	2025-12-27 07:28:52	2025-12-27 07:28:52
109	33	66	video	video-7	title	title	text	t	t	\N	1	\N	t	2025-12-27 14:22:41	2025-12-27 14:22:41
110	35	\N	\N	\N	title	Title	text	t	t	\N	1	\N	t	2025-12-27 18:32:28	2025-12-27 18:33:36
111	33	60	video	video	title	Title	text	t	t	\N	1	\N	t	2025-12-28 06:09:32	2025-12-28 06:09:56
112	33	61	video	video-1	title	Title	text	t	t	\N	1	\N	t	2025-12-28 06:11:24	2025-12-28 06:11:24
113	33	62	video	video-2	title	Title	text	t	t	\N	1	\N	t	2025-12-28 06:13:42	2025-12-28 06:13:42
114	33	63	video	video-3	title	Title	text	t	t	\N	1	\N	t	2025-12-28 06:16:04	2025-12-28 06:16:04
115	33	64	video	video-4	title	Title	text	t	t	\N	1	\N	t	2025-12-28 06:21:38	2025-12-28 06:21:38
116	33	89	video	video-6	title	Title	text	t	t	\N	1	\N	t	2025-12-28 06:23:04	2025-12-28 06:23:04
117	33	67	video	video-8	title	Title	text	t	t	\N	1	\N	t	2025-12-28 06:25:02	2025-12-28 06:25:02
118	33	68	video	video-9	title	Title	text	t	t	\N	1	\N	t	2025-12-28 06:26:49	2025-12-28 06:26:49
119	33	69	video	video-10	title	Title	text	t	t	\N	1	\N	t	2025-12-28 06:28:30	2025-12-28 06:28:30
120	33	70	video	video-11	title	Title	text	t	t	\N	1	\N	t	2025-12-28 06:30:21	2025-12-28 06:30:21
121	33	71	video	video-12	title	Title	text	t	t	\N	1	\N	t	2025-12-28 06:31:38	2025-12-28 06:31:38
122	23	121	Nomi	nomi-4	title	Title	text	t	t	\N	1	\N	t	2025-12-29 08:02:16	2025-12-29 08:02:16
123	23	121	Nomi	nomi-4	date_at	Date_at	text	t	f	\N	1	\N	t	2025-12-29 08:02:16	2025-12-29 08:02:16
124	23	121	Nomi	nomi-4	boss_at	Boss_at	text	t	f	\N	1	\N	t	2025-12-29 08:02:16	2025-12-29 08:02:16
125	23	121	Nomi	nomi-4	content	Content	text	t	t	\N	1	\N	t	2025-12-29 08:02:16	2025-12-29 08:02:16
126	23	121	Rahbar	rahbar-4	title	Title	text	t	t	\N	1	\N	t	2025-12-29 08:05:03	2025-12-29 08:05:03
127	23	121	Rahbar	rahbar-4	description	Description	text	t	t	\N	1	\N	t	2025-12-29 08:05:03	2025-12-29 08:05:04
128	23	121	Rahbar	rahbar-4	phone	Phone	text	t	f	\N	1	\N	t	2025-12-29 08:05:04	2025-12-29 08:05:04
129	23	121	Rahbar	rahbar-4	email	Email	text	t	t	\N	1	\N	t	2025-12-29 08:05:04	2025-12-29 08:05:04
130	23	21	Rahbar	rahbar	description	Description	text	t	t	\N	1	\N	t	2025-12-29 08:10:55	2025-12-29 08:10:55
131	23	124	Nomi	nomi-5	title	Title	text	t	t	\N	1	\N	t	2025-12-29 08:14:48	2025-12-29 08:14:48
132	23	124	Nomi	nomi-5	date_at	Date_at	text	t	f	\N	1	\N	t	2025-12-29 08:14:48	2025-12-29 08:14:48
133	23	124	Nomi	nomi-5	boss_at	Boss_at	text	t	f	\N	1	\N	t	2025-12-29 08:14:48	2025-12-29 08:14:48
134	23	124	Nomi	nomi-5	description	Description	text	t	t	\N	1	\N	t	2025-12-29 08:14:48	2025-12-29 08:14:48
135	23	125	Nomi	nomi-6	title	Title	text	t	t	\N	1	\N	t	2025-12-29 08:18:18	2025-12-29 08:18:18
136	23	125	Nomi	nomi-6	description	Description	text	t	t	\N	1	\N	t	2025-12-29 08:18:18	2025-12-29 08:18:18
137	23	125	Nomi	nomi-6	date_at	Date_at	text	t	f	\N	1	\N	t	2025-12-29 08:18:18	2025-12-29 08:18:18
138	23	125	Nomi	nomi-6	boss_at	Boss_at	text	t	f	\N	1	\N	t	2025-12-29 08:18:18	2025-12-29 08:18:18
139	23	124	Rahbar	rahbar-5	title	Title	text	t	t	\N	1	\N	t	2025-12-29 08:20:39	2025-12-29 08:20:39
140	23	124	Rahbar	rahbar-5	phone	Phone	text	t	f	\N	1	\N	t	2025-12-29 08:20:39	2025-12-29 08:20:39
148	23	27	Rahbar	rahbar-2	description	Description	text	t	t	\N	1	\N	t	2025-12-29 09:25:27	2025-12-29 09:25:27
141	23	124	Rahbar	rahbar-5	email	Email	text	t	f	\N	1	\N	t	2025-12-29 08:20:39	2025-12-29 08:20:39
84	30	52	Url	url	title	Title	text	t	t	\N	1	\N	t	2025-12-26 11:29:17	2026-01-22 09:34:40
142	23	124	Rahbar	rahbar-5	description	Description	text	t	t	\N	1	\N	t	2025-12-29 08:20:39	2025-12-29 08:20:39
149	23	30	Nomi	nomi-3	description	Description	text	t	t	\N	1	\N	t	2025-12-29 09:27:19	2025-12-29 09:27:19
143	23	125	Rahbar	rahbar-6	title	Title	text	t	t	\N	1	\N	t	2025-12-29 08:21:37	2025-12-29 08:21:37
144	23	125	Rahbar	rahbar-6	description	Description	text	t	t	\N	1	\N	t	2025-12-29 08:21:37	2025-12-29 08:21:37
145	23	125	Rahbar	rahbar-6	email	Email	text	t	f	\N	1	\N	t	2025-12-29 08:21:37	2025-12-29 08:21:37
150	23	30	Rahbar	rahbar-3	description	Description	text	t	t	\N	1	\N	t	2025-12-29 09:28:27	2025-12-29 09:28:48
146	23	125	Rahbar	rahbar-6	phone	Phone	text	t	f	\N	1	\N	t	2025-12-29 08:21:37	2025-12-29 08:21:37
152	40	\N	\N	\N	title	Title	text	t	t	\N	1	\N	t	2025-12-29 12:26:42	2025-12-29 12:26:42
147	23	27	Nomi	nomi-2	description	Description	text	t	t	\N	1	\N	t	2025-12-29 09:23:20	2025-12-29 09:23:20
153	40	\N	\N	\N	url	Url	text	t	f	\N	1	\N	t	2025-12-29 12:26:42	2025-12-29 12:26:42
155	41	\N	\N	\N	year	Year	text	t	f	\N	1	\N	t	2025-12-29 12:33:13	2025-12-29 12:33:13
156	41	135	Bu mavsumga tegishli rasmlar	bu-mavsumga-tegishli-rasmlar	title	Title	text	t	t	\N	1	\N	t	2025-12-29 12:42:03	2025-12-29 12:42:03
157	41	139	2024-rasmlar	2024-rasmlar	title	Title	text	t	t	\N	1	\N	t	2025-12-29 12:44:58	2025-12-29 12:44:58
158	42	\N	\N	\N	title	Title	textarea-editor	t	t	\N	1	\N	t	2025-12-30 06:18:45	2025-12-30 06:18:45
160	38	\N	\N	\N	description	Description	text	t	t	\N	1	\N	t	2025-12-30 15:59:51	2025-12-30 15:59:51
162	38	144	Yillar	yillar	title	Title	text	t	t	\N	1	\N	t	2025-12-30 16:03:09	2025-12-30 16:03:09
163	38	148	Yillar	yillar-1	title	Title	text	t	t	\N	1	\N	t	2025-12-30 16:46:43	2025-12-30 16:46:43
164	38	149	Yillar	yillar-2	title	Title	text	t	t	\N	1	\N	t	2025-12-30 16:49:30	2025-12-30 16:49:30
165	43	\N	\N	\N	name	Name	text	t	t	\N	1	\N	t	2025-12-30 20:07:06	2025-12-30 20:07:06
166	43	\N	\N	\N	description	Description	textarea	t	t	\N	1	\N	t	2025-12-30 20:07:06	2025-12-30 20:07:06
167	43	\N	\N	\N	email	Email	text	t	f	\N	1	\N	t	2025-12-30 20:07:06	2025-12-30 20:07:06
168	43	\N	\N	\N	phone	Phone	text	t	f	\N	1	\N	t	2025-12-30 20:07:07	2025-12-30 20:07:07
170	46	\N	\N	\N	title	Title	text	t	t	\N	1	\N	t	2026-01-05 04:58:31	2026-01-05 04:58:31
171	46	\N	\N	\N	description	Description	text	t	t	\N	1	\N	t	2026-01-05 04:58:31	2026-01-05 04:58:31
172	45	\N	\N	\N	title	Title	text	t	t	\N	1	\N	t	2026-01-05 05:37:20	2026-01-05 05:37:20
173	45	\N	\N	\N	phone	Phone	text	t	f	\N	1	\N	t	2026-01-05 05:37:20	2026-01-05 05:37:20
174	45	\N	\N	\N	email	Email	text	t	f	\N	1	\N	t	2026-01-05 05:37:20	2026-01-05 05:37:20
175	45	\N	\N	\N	age	Age	number	t	f	\N	1	\N	t	2026-01-05 05:37:20	2026-01-05 05:37:20
176	47	\N	\N	\N	title	Title	text	t	t	\N	1	\N	t	2026-01-06 10:37:26	2026-01-06 10:37:26
159	38	\N	\N	\N	title	Title	text	t	t	\N	1	\N	t	2025-12-30 15:59:51	2026-01-09 06:22:03
56	26	\N	\N	\N	description	Description	textarea-editor	t	t	\N	1	\N	t	2025-12-23 06:20:02	2026-01-09 11:46:18
178	23	\N	\N	\N	code	Code	text	t	f	\N	1	\N	t	2026-01-12 09:39:59	2026-01-12 09:39:59
169	44	\N	\N	\N	title	Title	text	t	t	\N	1	\N	t	2025-12-30 23:32:12	2026-01-15 14:32:34
179	44	\N	\N	\N	map	Map	textarea	t	f	\N	1	\N	t	2026-01-15 14:29:06	2026-01-15 14:32:35
180	47	\N	\N	\N	description	Description	text	t	t	\N	1	\N	t	2026-01-19 16:38:11	2026-01-19 16:38:11
181	38	\N	\N	\N	video	Video	text	t	f	\N	1	\N	t	2026-01-19 17:22:24	2026-01-19 17:22:24
182	50	\N	\N	\N	title	Title	text	t	t	\N	1	\N	t	2026-01-19 17:42:53	2026-01-19 17:46:39
161	38	\N	\N	\N	content	Content	text	t	f	\N	1	\N	t	2025-12-30 15:59:51	2026-01-20 05:37:35
183	38	\N	\N	\N	description1	Description1	textarea-editor	t	t	\N	1	\N	t	2026-01-20 05:37:35	2026-01-20 05:38:09
185	51	\N	\N	\N	title	Title	text	t	t	\N	1	\N	t	2026-01-21 11:57:48	2026-01-21 11:57:48
186	52	\N	\N	\N	title	Title	text	t	t	\N	1	\N	t	2026-01-21 18:32:51	2026-01-21 18:32:51
187	52	\N	\N	\N	description	Description	text	t	t	\N	1	\N	t	2026-01-21 18:32:51	2026-01-21 18:32:51
188	53	\N	\N	\N	title	Title	text	t	t	\N	1	\N	t	2026-01-22 10:19:27	2026-01-22 10:19:27
189	47	\N	\N	\N	link1	Link 1	text	t	f	\N	1	\N	t	2026-01-23 06:56:29	2026-01-23 06:56:29
190	47	\N	\N	\N	link2	Link2	text	t	f	\N	1	\N	t	2026-01-23 06:56:29	2026-01-23 07:02:00
191	51	\N	\N	\N	description	Description	text	t	t	\N	1	\N	t	2026-01-23 07:07:32	2026-01-23 07:07:32
192	51	\N	\N	\N	url	Url	text	t	f	\N	1	\N	t	2026-01-23 07:07:32	2026-01-23 07:07:32
193	51	\N	\N	\N	url_title	Url Title	text	t	t	\N	1	\N	t	2026-01-23 07:07:32	2026-01-23 07:07:32
177	38	\N	\N	\N	last_date	Date	datetime-local	t	f	\N	1	\N	t	2026-01-07 11:46:02	2026-01-23 11:46:39
194	52	\N	\N	\N	url	Ссылка	text	t	f	\N	2	\N	t	2026-01-23 12:48:08	2026-01-23 12:48:08
195	30	52	Url	url	date	Дата	datetime-local	t	f	\N	1	\N	t	2026-01-23 13:38:36	2026-01-23 13:38:47
196	30	\N	\N	\N	date	Date	datetime-local	t	f	\N	1	\N	t	2026-01-23 13:51:05	2026-01-23 13:51:05
\.


--
-- Data for Name: page_section_translations; Type: TABLE DATA; Schema: public; Owner: vatandoshlar_usr
--

COPY public.page_section_translations (id, page_section_id, page_section_parent_id, category, category_slug, locale, data, created_at, updated_at) FROM stdin;
11	5	\N	\N	\N	uz	{"title": "O‘zbekiston – sirli o‘tmish va yorqin kelajak maskani!", "description": "O‘zbekiston – tarix va zamonaviylik uyg‘unligi! Bu yerda har bir qadam o‘ziga xos kashfiyot. So‘nggi yillarda mamlakat turizm, iqtisodiyot va xizmat ko‘rsatish sohalarida yangi bosqichga ko‘tarilib, sayyohlar uchun yanada qulay va qiziqarli makonga aylandi. Samarqand, Buxoro, Xiva kabi shaharlar o‘zining qadimiy ruhi bilan, Toshkent esa zamonaviy tarovati bilan mehmonlarni o‘ziga jalb qiladi. Bu yerda qadimiylik va yangilik birlashadi, mehmondo‘stlik esa har yurakni zabt etadi. O‘zbekiston – bu nafaqat sayohat, balki ilhom, kashfiyot va unutilmas taassurotlar manzili. Bu mo‘jizaviy diyorga qadam qo‘ying va yuragingizni bu yerga abadiy bog‘lang!"}	2025-12-23 05:06:24	2025-12-23 05:06:24
12	5	\N	\N	\N	ru	{"title": null, "description": null}	2025-12-23 05:06:24	2025-12-23 05:06:24
13	6	\N	\N	\N	uz	{"title": "Forum va seminarlardan video"}	2025-12-23 05:07:48	2025-12-23 05:07:48
14	6	\N	\N	\N	ru	{"title": null}	2025-12-23 05:07:48	2025-12-23 05:07:48
15	7	\N	\N	\N	uz	{"title": "Fotogalareya"}	2025-12-23 05:08:27	2025-12-23 05:08:27
16	7	\N	\N	\N	ru	{"title": null}	2025-12-23 05:08:27	2025-12-23 05:08:27
18	8	\N	\N	\N	ru	{"title": null, "url_title": null, "description": null}	2025-12-23 05:10:29	2026-01-05 13:18:53
26	12	\N	\N	\N	ru	{"title": null, "content": null, "description": null}	2025-12-23 05:29:07	2025-12-25 08:31:46
332	88	\N	\N	\N	uz	{"title": "Juventus"}	2025-12-28 06:22:17	2025-12-28 06:22:17
94	39	\N	\N	\N	en	{"url": null, "title": null, "content": null, "description": null}	2025-12-25 08:50:21	2025-12-26 07:23:47
305	78	\N	\N	\N	uz	{"title": "Eng Sara joylar"}	2025-12-28 06:12:16	2025-12-28 06:12:16
306	78	\N	\N	\N	ru	{"title": null}	2025-12-28 06:12:16	2025-12-28 06:12:16
307	78	\N	\N	\N	en	{"title": null}	2025-12-28 06:12:16	2025-12-28 06:12:16
333	88	\N	\N	\N	ru	{"title": null}	2025-12-28 06:22:17	2025-12-28 06:22:17
334	88	\N	\N	\N	en	{"title": null}	2025-12-28 06:22:17	2025-12-28 06:22:17
356	99	\N	\N	\N	uz	{"title": "Atetico Madrid"}	2025-12-28 06:27:11	2025-12-28 06:27:11
357	99	\N	\N	\N	ru	{"title": null}	2025-12-28 06:27:11	2025-12-28 06:27:11
358	99	\N	\N	\N	en	{"title": null}	2025-12-28 06:27:11	2025-12-28 06:27:11
380	107	\N	\N	\N	uz	{"title": "Swansea"}	2025-12-28 06:31:08	2025-12-28 06:31:08
381	107	\N	\N	\N	ru	{"title": null}	2025-12-28 06:31:08	2025-12-28 06:31:08
382	107	\N	\N	\N	en	{"title": null}	2025-12-28 06:31:08	2025-12-28 06:31:08
440	134	\N	\N	\N	uz	{"title": "Maktab loyihasi"}	2025-12-29 12:31:57	2025-12-29 12:31:57
441	134	\N	\N	\N	ru	{"title": null}	2025-12-29 12:31:57	2025-12-29 12:31:57
404	125	19	tashkilot	tashkilot	\N	{"title": "Harvard University"}	2025-12-29 08:13:35	2025-12-29 08:13:35
442	134	\N	\N	\N	en	{"title": null}	2025-12-29 12:31:57	2025-12-29 12:31:57
423	29	\N	\N	\N	en	{"title": null, "description": null}	2025-12-29 09:26:19	2025-12-29 09:26:19
443	134	\N	\N	\N	\N	{"url": null}	2025-12-29 12:31:57	2025-12-29 12:31:57
498	151	148	Yillar	yillar-1	uz	{"title": "2023mavsum"}	2025-12-30 16:47:54	2025-12-30 19:59:45
499	151	148	Yillar	yillar-1	ru	{"title": null}	2025-12-30 16:47:54	2025-12-30 19:59:45
500	151	148	Yillar	yillar-1	en	{"title": null}	2025-12-30 16:47:54	2025-12-30 19:59:45
6	3	\N	\N	\N	uz	{"title": "Qatnashgan vatandoshlar soni"}	2025-12-23 04:45:52	2026-01-05 08:15:05
7	3	\N	\N	\N	ru	{"title": null}	2025-12-23 04:45:52	2026-01-05 08:15:05
8	3	\N	\N	\N	\N	{"number": "120"}	2025-12-23 04:45:52	2026-01-05 08:15:05
27	13	\N	\N	\N	uz	{"title": "Oliy maqsadimiz-xorijdagi vatandoshlarni Vatan atrofida birlashtirish, ularning qalbi va ongida yurtdan faxrlanish tuyg'usini yuksaltirish, milliy o'zlikni asrashdir!"}	2025-12-23 05:30:06	2025-12-23 05:30:06
28	13	\N	\N	\N	ru	{"title": null}	2025-12-23 05:30:06	2025-12-23 05:30:06
35	16	\N	\N	\N	uz	{"title": "Jamoat birlashmalari bilan hamkorlik aloqalarini yo‘lga qo‘yish va rivojlantirish"}	2025-12-23 05:34:07	2025-12-23 05:34:07
36	16	\N	\N	\N	ru	{"title": null}	2025-12-23 05:34:07	2025-12-23 05:34:07
37	17	\N	\N	\N	uz	{"title": "Vatandoshlarning huquq va erkinliklarini himoya qilishga ko‘maklashish"}	2025-12-23 05:34:27	2025-12-23 05:34:27
38	17	\N	\N	\N	ru	{"title": null}	2025-12-23 05:34:27	2025-12-23 05:34:27
2	1	\N	\N	\N	ru	{"title": "<span>Vatandoshlar </span> Jamoat Fondi", "description": "\\"Vatandoshlar\\" jamoat fondi — bu xorijdagi o‘zbekistonlik vatandoshlar bilan aloqalarni mustahkamlash, ularning huquq va manfaatlarini qo‘llab-quvvatlash, shuningdek, ularni O‘zbekiston taraqqiyotiga jalb etish maqsadida tashkil etilgan notijorat tashkilotdir."}	2025-12-23 04:43:11	2026-01-23 06:34:18
524	158	\N	\N	\N	ru	{"title": null, "description": null, "description1": null}	2025-12-31 01:05:11	2026-01-20 05:42:35
20	9	\N	\N	\N	ru	{"title": null, "description": null}	2025-12-23 05:11:35	2026-01-22 09:36:27
4	2	\N	\N	\N	ru	{"title": null}	2025-12-23 04:45:01	2026-01-22 15:13:26
88	37	\N	\N	\N	en	{"url": null, "title": null, "content": null, "description": null}	2025-12-25 08:48:11	2026-01-22 11:56:50
10	4	\N	\N	\N	ru	{"title": "Vatandoshlar jamoat fondi ru", "content": null, "content1": null, "description": null}	2025-12-23 04:50:44	2026-01-23 12:34:28
3	2	\N	\N	\N	uz	{"title": "Qatnashgan vatandoshlar soni"}	2025-12-23 04:45:01	2026-01-22 15:13:26
5	2	\N	\N	\N	\N	{"number": "25565"}	2025-12-23 04:45:01	2026-01-22 15:13:26
9	4	\N	\N	\N	uz	{"title": "Vatandoshlar jamoat fondi", "content": "“Xorijda istiqomat qilayotgan yurtdoshlarni birlashtirish maqsadida 'Vatandoshlar' jamoat fondi tashkil etildi... Bu fonddan asosiy maqsad - tarixiy Vatanimiz atrofida ularni yanada jipslashtirish, ularning qalbi va ongida yurt bilan faxrlanish tuyg'usini yuksaltirish, milliy oʻzlikni saqlab qolish”", "content1": "O’zbekiston Respublikasi Prezidenti", "description": "Shavkat Miromonovich Mirziyoyev"}	2025-12-23 04:50:44	2026-01-23 12:34:28
30	14	\N	\N	\N	ru	{"title": null, "description": null}	2025-12-23 05:32:28	2026-01-07 11:43:52
31	14	\N	\N	\N	\N	{"email": "sattarov@vatandoshlarfondi.uz", "phone": "+998(55) 502-22-99"}	2025-12-23 05:32:28	2026-01-07 11:43:52
29	14	\N	\N	\N	uz	{"title": "Sattarov Odiljon Berdimuratovich", "description": "“Vatandoshlar” jamoat fondi Boshqaruv raisi"}	2025-12-23 05:32:28	2026-01-07 11:43:52
58	27	20	tashkilot	tashkilot-1	uz	{"title": "“Mahalla-USA” o‘zbek diasporal tashkiloti"}	2025-12-23 06:02:28	2025-12-23 06:02:28
59	27	20	tashkilot	tashkilot-1	ru	{"title": null}	2025-12-23 06:02:28	2025-12-23 06:02:28
66	30	20	tashkilot	tashkilot-1	uz	{"title": "“Yurtdosh” Uzbek-Amerika Assotsiatsiyasi"}	2025-12-23 06:06:15	2025-12-23 06:06:15
67	30	20	tashkilot	tashkilot-1	ru	{"title": null}	2025-12-23 06:06:15	2025-12-23 06:06:15
71	32	30	Rahbar	rahbar-3	uz	{"title": "Sadikov Baxodir Talibjonovich  Pittsburgdagi uzbeklar jamiyati rahbari"}	2025-12-23 06:08:35	2025-12-23 06:08:35
72	32	30	Rahbar	rahbar-3	ru	{"title": null}	2025-12-23 06:08:35	2025-12-23 06:08:35
73	32	30	Rahbar	rahbar-3	\N	{"email": "sanayev@vatandoshlarfondi.uz", "phone": "+998(55) 502-22-99"}	2025-12-23 06:08:35	2025-12-23 06:08:35
95	40	\N	\N	\N	uz	{"title": "O‘zbek tili, madaniyati va an’analarini saqlab qolish va rivojlantirish"}	2025-12-25 09:42:07	2025-12-25 09:42:36
96	40	\N	\N	\N	ru	{"title": null}	2025-12-25 09:42:07	2025-12-25 09:42:36
97	40	\N	\N	\N	en	{"title": null}	2025-12-25 09:42:07	2025-12-25 09:42:36
32	15	\N	\N	\N	uz	{"title": "Sanayev Bolidin Elamonovich", "description": "“Vatandoshlar” jamoat fondi Boshqaruv raisi o‘rinbosari"}	2025-12-23 05:33:13	2025-12-26 05:17:23
33	15	\N	\N	\N	ru	{"title": null, "description": null}	2025-12-23 05:33:13	2025-12-26 05:17:23
34	15	\N	\N	\N	\N	{"email": "sanayev@vatandoshlarfondi.uz", "phone": "+998(55) 502-22-99"}	2025-12-23 05:33:13	2025-12-26 05:17:23
308	79	\N	\N	\N	uz	{"title": "Korishga arziydigan joylar"}	2025-12-28 06:13:10	2025-12-28 06:13:10
309	79	\N	\N	\N	ru	{"title": null}	2025-12-28 06:13:10	2025-12-28 06:13:10
61	28	27	Nomi	nomi-2	ru	{"title": null, "description": null}	2025-12-23 06:03:58	2025-12-29 09:24:21
62	28	27	Nomi	nomi-2	\N	{"boss_at": "12/12/2022", "date_at": "12/20/2017"}	2025-12-23 06:03:58	2025-12-29 09:24:21
64	29	27	Rahbar	rahbar-2	ru	{"title": null, "description": null}	2025-12-23 06:05:38	2025-12-29 09:26:19
63	29	27	Rahbar	rahbar-2	uz	{"title": "Sadikov Baxodir Talibjonovich  Pittsburgdagi uzbeklar jamiyati rahbari", "description": "New-york-university Rahbari"}	2025-12-23 06:05:38	2025-12-29 09:26:19
60	28	27	Nomi	nomi-2	uz	{"title": "“Mahalla-USA” o‘zbek diasporal tashkiloti", "description": "АQShdagi vatandoshlarni birlashtirish, ular oʼrtasida hamjixatlikni mustahkamlash, oʼzbek urf-odatlari, qadriyatlari va ona-tilini asrab qolish"}	2025-12-23 06:03:58	2025-12-29 09:24:21
70	31	30	Nomi	nomi-3	\N	{"date_at": "12/20/2018", "first_boss": "12/20/2019"}	2025-12-23 06:07:24	2025-12-29 09:27:50
65	29	27	Rahbar	rahbar-2	\N	{"email": "sanayev@vatandoshlarfondi.uz", "phone": "+998(55) 502-22-50"}	2025-12-23 06:05:38	2025-12-29 09:26:19
68	31	30	Nomi	nomi-3	uz	{"title": "“Yurtdosh” Uzbek-Amerika Assotsiatsiyasi Batafsil", "description": "new-york-university new-york-university new-york-university new-york-university"}	2025-12-23 06:07:24	2025-12-29 09:27:50
69	31	30	Nomi	nomi-3	ru	{"title": null, "description": null}	2025-12-23 06:07:24	2025-12-29 09:27:50
79	35	\N	\N	\N	uz	{"description": "“Vatandoshlar” jamoat fondi 2021 yil 11 avgustda tashkil etilgan. Bizning asosiy maqsadimiz- xorijda istiqomat qilayotgan vatandoshlarni tarixiy Vatani atrofida yanada jipslashtirish, ularning qalbi va ongida yurt bilan faxrlanish tuyg‘usini yuksaltirish, milliy o‘zlikni saqlab qolish, vatandoshlar va ular tomonidan tuzilgan jamoat birlashmalarini qo‘llab-quvvatlash, turli sohalarda faoliyat yuritayotgan vatandoshlarimizning salohiyatini mamlakatimiz taraqqiyotiga samarali yo‘naltirishdir!"}	2025-12-25 08:29:18	2025-12-25 08:29:18
80	35	\N	\N	\N	ru	{"description": null}	2025-12-25 08:29:18	2025-12-25 08:29:18
81	35	\N	\N	\N	en	{"description": null}	2025-12-25 08:29:18	2025-12-25 08:29:18
25	12	\N	\N	\N	uz	{"title": "Fondning ramzi", "content": "<p><span>\\"Vatandoshlar\\" jamoat fondining ramzida asosan milliy qadriyatlarimizni anglatuvchi minoralar hamda tarixiy obidalarimizning naqshlarida aks etgan ko‘k rangdan foydalanilgan. Ko‘k rang – bu tinchlik va hotirjamlik ramzi bo‘lib, u yaxshilikni, donishmandlikni, halollikni va sadoqatni bildiradi. Markazda O‘zbekiston Respublikasining 30 yilligi munosabati bilan “Yangi O‘zbekiston” bog‘ida bunyod etilgan muhtasham obida “Mustaqillik monumenti” joy olgan. Obidaning eng yuqori qismida O‘zbekiston gerbidan ham o‘rin olgan “Humo qushi” tasvirlangan. Obidaning orqa tomonida globus tasviri tushirilgan bo‘lib, bu xorijda istiqomat qilayotgan vatandoshlar bilan ishlashni nazarda tutadi. Shuningdek, ramzda ochiq kaftlar keltirilgan bo‘lib, bu Fondning ochiqlik va qabul qilishlikni, halollik va samimiylikni, vatandoshlarni “Yangi O‘zbekiston” atrofida yanada jipslashishiga, ularga doimiy ravishda g‘amxo‘rlik qilishga ham tayyor ekanligini anglatadi.</span></p>", "description": "<div class=\\"content__text\\">\\r\\n<p>\\"Vatandoshlar\\" jamoat fondining ramzida asosan milliy qadriyatlarimizni anglatuvchi minoralar hamda tarixiy obidalarimizning naqshlarida aks etgan ko‘k rangdan foydalanilgan. Ko‘k rang – bu tinchlik va hotirjamlik ramzi bo‘lib, u yaxshilikni, donishmandlikni, halollikni va sadoqatni bildiradi. Markazda O‘zbekiston Respublikasining 30 yilligi munosabati bilan “Yangi O‘zbekiston” bog‘ida bunyod etilgan muhtasham obida “Mustaqillik monumenti” joy olgan. Obidaning eng yuqori qismida O‘zbekiston gerbidan ham o‘rin olgan “Humo qushi” tasvirlangan. Obidaning orqa tomonida globus tasviri tushirilgan bo‘lib, bu xorijda istiqomat qilayotgan vatandoshlar bilan ishlashni nazarda tutadi. Shuningdek, ramzda ochiq kaftlar keltirilgan bo‘lib, bu Fondning ochiqlik va qabul qilishlikni, halollik va samimiylikni, vatandoshlarni “Yangi O‘zbekiston” atrofida yanada jipslashishiga, ularga doimiy ravishda g‘amxo‘rlik qilishga ham tayyor ekanligini anglatadi.</p>\\r\\n</div>\\r\\n<div class=\\"about__page\\">\\r\\n<div class=\\"about__page--img\\"></div>\\r\\n</div>"}	2025-12-23 05:29:07	2025-12-25 08:31:46
82	12	\N	\N	\N	en	{"title": null, "content": null, "description": null}	2025-12-25 08:31:46	2025-12-25 08:31:46
320	83	\N	\N	\N	uz	{"title": "Futbol"}	2025-12-28 06:17:03	2025-12-28 06:17:03
44	20	\N	\N	\N	ru	{"title": null}	2025-12-23 05:48:00	2026-01-12 09:40:36
41	19	\N	\N	\N	uz	{"title": "Ozbekiston"}	2025-12-23 05:47:39	2026-01-12 09:40:45
42	19	\N	\N	\N	ru	{"title": null}	2025-12-23 05:47:39	2026-01-12 09:40:45
457	139	\N	\N	\N	uz	{"title": "2024 yil"}	2025-12-29 12:44:36	2025-12-30 10:29:52
78	34	\N	\N	\N	ru	{"title": null}	2025-12-23 06:22:39	2026-01-14 11:30:41
132	52	\N	\N	\N	uz	{"title": "Forum va seminarlardan video"}	2025-12-25 13:32:21	2025-12-26 12:18:15
40	18	\N	\N	\N	ru	{"title": null}	2025-12-23 05:46:01	2026-01-20 06:39:23
74	33	\N	\N	\N	uz	{"title": "\\"Vatandoshlar\\" jamoat fondi tomonidan Xorijdagi vatandoshlar uchun yangi loyiha amalga oshirilmoqda", "description": null}	2025-12-23 06:21:44	2026-01-21 08:03:05
75	33	\N	\N	\N	ru	{"title": null, "description": null}	2025-12-23 06:21:44	2026-01-21 08:03:05
93	39	\N	\N	\N	ru	{"url": null, "title": null, "content": null, "description": null}	2025-12-25 08:50:21	2025-12-26 07:23:47
98	41	\N	\N	\N	uz	{"title": "Vatandosh kim?", "description": "O‘zbekiston hududidan tashqarida doimo istiqomat qiladigan yoki ta’lim olish, mehnat faoliyati bilan shug‘ullanish, oilaviy sabablar va boshqa sharoitlardan kelib chiqib, vaqtinchalik chet elda yurgan O‘zbekiston Respublikasi fuqarosi Xorijga chiqqan va chet el fuqaroligini olgan, Vataniga ma’naviy va madaniy nuqtai nazardan mansublikni his qilgan hamda O‘zbekiston Respublikasi bilan madaniy-gumanitar, ijtimoiy-iqtisodiy va boshqa aloqalarni rivojlantirishga harakat qilayotgan O‘zbekistondan chiqib ketgan shaxs va uning avlodi Etnik, til va madaniy-tarixiy nuqtai nazardan o‘zini o‘zbeklar yoki qoraqalpoqlar sifatida identifikatsiya qilgan hamda O‘zbekiston bilan har tomonlama aloqada bo‘lish xohishida bo‘lgan   xorijda istiqomat qilayotgan chet el fuqarolari va fuqaroligi bo‘lmagan shaxslar xorijda istiqomat  qilayotganlar."}	2025-12-25 09:49:29	2025-12-25 09:49:29
99	41	\N	\N	\N	ru	{"title": null, "description": null}	2025-12-25 09:49:29	2025-12-25 09:49:29
100	41	\N	\N	\N	en	{"title": null, "description": null}	2025-12-25 09:49:29	2025-12-25 09:49:29
101	42	\N	\N	\N	uz	{"title": "“Vatandoshlar” jamoat fondi qanday tashkilot ?", "description": "Lorem ipsum dolor sit amet consectetur adipisicing elit. Unde, impedit?"}	2025-12-25 09:50:10	2025-12-25 09:50:10
102	42	\N	\N	\N	ru	{"title": null, "description": null}	2025-12-25 09:50:10	2025-12-25 09:50:10
103	42	\N	\N	\N	en	{"title": null, "description": null}	2025-12-25 09:50:10	2025-12-25 09:50:10
120	48	\N	\N	\N	uz	{"url": "https://www.youtube.com/", "title": "Forum va seminarlardan video"}	2025-12-25 13:22:39	2025-12-25 13:22:39
121	48	\N	\N	\N	ru	{"url": null, "title": null}	2025-12-25 13:22:39	2025-12-25 13:22:39
138	54	\N	\N	\N	uz	{"title": "Fotogalareya", "description": null}	2025-12-25 13:36:22	2025-12-25 13:36:22
139	54	\N	\N	\N	ru	{"title": null, "description": null}	2025-12-25 13:36:22	2025-12-25 13:36:22
140	54	\N	\N	\N	en	{"title": null, "description": null}	2025-12-25 13:36:22	2025-12-25 13:36:22
92	39	\N	\N	\N	uz	{"url": null, "title": "Oliy maqsadimiz-xorijdagi vatandoshlarni Vatan atrofida birlashtirish, ularning qalbi va ongida yurtdan faxrlanish tuyg'usini yuksaltirish, milliy o'zlikni asrashdir!", "content": null, "description": null}	2025-12-25 08:50:21	2025-12-26 07:23:47
122	48	\N	\N	\N	en	{"url": null, "title": null}	2025-12-25 13:22:39	2025-12-25 13:22:39
126	50	\N	\N	\N	uz	{"title": "O‘zbekiston – sirli o‘tmish va yorqin kelajak maskani!", "description": "O‘zbekiston – tarix va zamonaviylik uyg‘unligi! Bu yerda har bir qadam o‘ziga xos kashfiyot. So‘nggi yillarda mamlakat turizm, iqtisodiyot va xizmat ko‘rsatish sohalarida yangi bosqichga ko‘tarilib, sayyohlar uchun yanada qulay va qiziqarli makonga aylandi. Samarqand, Buxoro, Xiva kabi shaharlar o‘zining qadimiy ruhi bilan, Toshkent esa zamonaviy tarovati bilan mehmonlarni o‘ziga jalb qiladi. Bu yerda qadimiylik va yangilik birlashadi, mehmondo‘stlik esa har yurakni zabt etadi. O‘zbekiston – bu nafaqat sayohat, balki ilhom, kashfiyot va unutilmas taassurotlar manzili. Bu mo‘jizaviy diyorga qadam qo‘ying va yuragingizni bu yerga abadiy bog‘lang!"}	2025-12-25 13:23:52	2025-12-25 13:23:52
127	50	\N	\N	\N	ru	{"title": null, "description": null}	2025-12-25 13:23:52	2025-12-25 13:23:52
128	50	\N	\N	\N	en	{"title": null, "description": null}	2025-12-25 13:23:52	2025-12-25 13:23:52
129	51	\N	\N	\N	uz	{"title": "Fotogalareya", "description": null}	2025-12-25 13:24:51	2025-12-25 13:24:51
130	51	\N	\N	\N	ru	{"title": null, "description": null}	2025-12-25 13:24:51	2025-12-25 13:24:51
131	51	\N	\N	\N	en	{"title": null, "description": null}	2025-12-25 13:24:51	2025-12-25 13:24:51
136	53	\N	\N	\N	ru	{"title": null, "description": null}	2025-12-25 13:35:56	2025-12-26 09:33:37
137	53	\N	\N	\N	en	{"title": null, "description": null}	2025-12-25 13:35:56	2025-12-26 09:33:37
238	89	\N	\N	\N	ru	{"title": null, "description": null}	2025-12-26 14:25:11	2025-12-27 07:31:11
310	79	\N	\N	\N	en	{"title": null}	2025-12-28 06:13:10	2025-12-28 06:13:10
335	87	\N	\N	\N	uz	{"title": "Barcelona"}	2025-12-28 06:22:33	2025-12-28 06:22:33
237	89	\N	\N	\N	uz	{"title": "Namangan", "description": "Viloyatning eng qadimiy shahri va markazi bo‘lgan Termizda va uning atrofida zardushtiylar, nestorianlar, buddistlar kabi turli xalqlarning shaharlari va qalʼalarining xarobalari, meʼmorchilik va arxeologiya obidalari, shuningdek islom meʼmorchiligi yodgorliklari saqlanib qolgan. Termizdan uncha uzoq bo‘lmagan joyda esa, fil suyagidan yasalgan shaxmat donalari topilgan,"}	2025-12-26 14:25:11	2025-12-27 07:31:11
239	89	\N	\N	\N	en	{"title": null, "description": null}	2025-12-26 14:25:11	2025-12-27 07:31:11
90	38	\N	\N	\N	ru	{"url": null, "title": null, "content": null, "description": null}	2025-12-25 08:48:32	2026-01-19 12:36:37
91	38	\N	\N	\N	en	{"url": null, "title": null, "content": null, "description": null}	2025-12-25 08:48:32	2026-01-19 12:36:37
84	36	\N	\N	\N	ru	{"url": null, "title": null, "content": null, "description": null}	2025-12-25 08:47:03	2026-01-19 12:36:50
85	36	\N	\N	\N	en	{"url": null, "title": null, "content": null, "description": null}	2025-12-25 08:47:03	2026-01-19 12:36:50
104	43	\N	\N	\N	uz	{"title": "“Vatandoshlar” jamoat fondi pul mablag‘ini kimdan oladi?", "description": "Lorem ipsum dolor sit amet consectetur adipisicing elit. Unde,<b> impedit?</b>"}	2025-12-25 09:50:30	2026-01-23 14:06:13
105	43	\N	\N	\N	ru	{"title": null, "description": null}	2025-12-25 09:50:30	2026-01-23 14:06:13
106	43	\N	\N	\N	en	{"title": null, "description": null}	2025-12-25 09:50:30	2026-01-23 14:06:13
133	52	\N	\N	\N	ru	{"title": null}	2025-12-25 13:32:21	2025-12-26 12:18:15
134	52	\N	\N	\N	en	{"title": null}	2025-12-25 13:32:21	2025-12-26 12:18:15
336	87	\N	\N	\N	ru	{"title": null}	2025-12-28 06:22:33	2025-12-28 06:22:33
337	87	\N	\N	\N	en	{"title": null}	2025-12-28 06:22:33	2025-12-28 06:22:33
359	100	\N	\N	\N	uz	{"title": "Betis"}	2025-12-28 06:27:26	2025-12-28 06:27:26
360	100	\N	\N	\N	ru	{"title": null}	2025-12-28 06:27:26	2025-12-28 06:27:26
361	100	\N	\N	\N	en	{"title": null}	2025-12-28 06:27:26	2025-12-28 06:27:26
383	108	\N	\N	\N	uz	{"title": "Futbolchi"}	2025-12-28 06:32:15	2025-12-28 06:32:15
384	108	\N	\N	\N	ru	{"title": null}	2025-12-28 06:32:15	2025-12-28 06:32:15
385	108	\N	\N	\N	en	{"title": null}	2025-12-28 06:32:15	2025-12-28 06:32:15
147	15	\N	\N	\N	en	{"title": null, "description": null}	2025-12-26 05:14:40	2025-12-26 05:17:23
135	53	\N	\N	\N	uz	{"title": "O‘zbekiston – sirli o‘tmish va yorqin kelajak maskani!", "description": "O‘zbekiston – tarix va zamonaviylik uyg‘unligi! Bu yerda har bir qadam o‘ziga xos kashfiyot. So‘nggi yillarda mamlakat turizm, iqtisodiyot va xizmat ko‘rsatish sohalarida yangi bosqichga ko‘tarilib, sayyohlar uchun yanada qulay va qiziqarli makonga aylandi. Samarqand, Buxoro, Xiva kabi shaharlar o‘zining qadimiy ruhi bilan, Toshkent esa zamonaviy tarovati bilan mehmonlarni o‘ziga jalb qiladi. Bu yerda qadimiylik va yangilik birlashadi, mehmondo‘stlik esa har yurakni zabt etadi. O‘zbekiston – bu nafaqat sayohat, balki ilhom, kashfiyot va unutilmas taassurotlar manzili. Bu mo‘jizaviy diyorga qadam qo‘ying va yuragingizni bu yerga abadiy bog‘lang!"}	2025-12-25 13:35:56	2025-12-26 09:33:37
148	8	\N	\N	\N	\N	{"url": "https://www.youtube.com/embed/BHACKCNDMW8?si=AtPPS9WpLIT3_TaW"}	2025-12-26 05:24:48	2026-01-05 13:18:53
154	52	\N	\N	\N	\N	{"url": null}	2025-12-26 11:06:46	2025-12-26 12:18:15
163	59	\N	\N	\N	uz	{"title": "Har bir manzil – yangi bir orzu!", "description": "Har bir manzil – yangi bir orzu! O‘zbekistonning eng go‘zal va sirli joylariga sayohat qilish, unutilmas xotiralar bilan qaytish uchun sizni kutmoqda! Bu yerda sizni ajoyib tabiat manzaralari, qadimiy shaharlarning tarixiy obidalari va madaniyatning eng boy meroslari kutib oladi. Har bir manzil o‘ziga xos hikoya va hissiyotlarni uyg‘otadi. Har bir manzil – bu nafaqat tabiatning go‘zalligi, balki yurtimizning yuragidan chiqib, har bir sayyohni o‘ziga jalb qiladigan sehrdir. O‘zbekistonni kashf eting, uning har bir burchagidan ilhom oling va qaytganingizda qalbingizda unutilmas xotiralar qoladi!"}	2025-12-26 13:16:46	2025-12-26 13:16:46
164	59	\N	\N	\N	ru	{"title": null, "description": null}	2025-12-26 13:16:46	2025-12-26 13:16:46
165	59	\N	\N	\N	en	{"title": null, "description": null}	2025-12-26 13:16:46	2025-12-26 13:16:46
146	14	\N	\N	\N	en	{"title": null, "description": null}	2025-12-26 05:14:06	2026-01-07 11:43:52
311	80	\N	\N	\N	uz	{"title": "Chiroyli manzilgohlar"}	2025-12-28 06:14:41	2025-12-28 06:14:41
312	80	\N	\N	\N	ru	{"title": null}	2025-12-28 06:14:41	2025-12-28 06:14:41
313	80	\N	\N	\N	en	{"title": null}	2025-12-28 06:14:41	2025-12-28 06:14:41
338	90	\N	\N	\N	uz	{"title": "Roma"}	2025-12-28 06:23:24	2025-12-28 06:23:24
183	61	\N	\N	\N	uz	{"title": "Andijon", "description": "Viloyatning eng qadimiy shahri va markazi bo‘lgan Termizda va uning atrofida zardushtiylar, nestorianlar, buddistlar kabi turli xalqlarning shaharlari va qalʼalarining xarobalari, meʼmorchilik va arxeologiya obidalari, shuningdek islom meʼmorchiligi yodgorliklari saqlanib qolgan. Termizdan uncha uzoq bo‘lmagan joyda esa, fil suyagidan yasalgan shaxmat donalari topilgan,"}	2025-12-26 13:39:07	2025-12-27 07:29:40
321	83	\N	\N	\N	ru	{"title": null}	2025-12-28 06:17:03	2025-12-28 06:17:03
322	83	\N	\N	\N	en	{"title": null}	2025-12-28 06:17:03	2025-12-28 06:17:03
344	92	\N	\N	\N	uz	{"title": "Inter"}	2025-12-28 06:24:26	2025-12-28 06:24:26
184	61	\N	\N	\N	ru	{"title": null, "description": null}	2025-12-26 13:39:07	2025-12-27 07:29:40
185	61	\N	\N	\N	en	{"title": null, "description": null}	2025-12-26 13:39:07	2025-12-27 07:29:40
433	132	\N	\N	\N	ru	{"title": null}	2025-12-29 12:30:29	2025-12-29 12:30:29
434	132	\N	\N	\N	en	{"title": null}	2025-12-29 12:30:29	2025-12-29 12:30:29
435	132	\N	\N	\N	\N	{"url": null}	2025-12-29 12:30:29	2025-12-29 12:30:29
458	139	\N	\N	\N	ru	{"title": null}	2025-12-29 12:44:36	2025-12-30 10:29:52
459	139	\N	\N	\N	en	{"title": null}	2025-12-29 12:44:36	2025-12-30 10:29:52
460	139	\N	\N	\N	\N	{"year": "2024mavsum"}	2025-12-29 12:44:36	2025-12-30 10:29:52
495	150	148	Yillar	yillar-1	uz	{"title": "2022 mavsum"}	2025-12-30 16:47:11	2025-12-30 19:59:10
151	56	\N	\N	\N	uz	{"url": "https://www.youtube.com/embed/BHACKCNDMW8?si=AtPPS9WpLIT3_TaW", "title": "Video", "content": null, "description": null}	2025-12-26 06:41:10	2026-01-19 12:36:30
152	56	\N	\N	\N	ru	{"url": null, "title": null, "content": null, "description": null}	2025-12-26 06:41:10	2026-01-19 12:36:30
153	56	\N	\N	\N	en	{"url": null, "title": null, "content": null, "description": null}	2025-12-26 06:41:10	2026-01-19 12:36:30
281	118	\N	\N	\N	uz	{"title": "Xorijdagi Vatandoshlar uchun Anor damolish oromgohi ochildi", "description": null}	2025-12-27 16:59:20	2026-01-21 08:03:13
284	118	\N	\N	\N	\N	{"url": "https://www.youtube.com/watch?v=mlDyGFq2q-A"}	2025-12-27 16:59:20	2026-01-21 08:03:13
160	58	\N	\N	\N	uz	{"title": "Sahifa haqida"}	2025-12-26 11:30:11	2026-01-23 13:54:19
161	58	\N	\N	\N	ru	{"title": null}	2025-12-26 11:30:11	2026-01-23 13:54:19
162	58	\N	\N	\N	en	{"title": null}	2025-12-26 11:30:11	2026-01-23 13:54:19
156	58	52	Url	url	\N	{"url": "https://www.youtube.com/embed/BHACKCNDMW8?si=AtPPS9WpLIT3_TaW", "date": "2025-06-10T13:30"}	2025-12-26 11:10:39	2026-01-23 13:54:19
149	9	\N	\N	\N	en	{"title": null, "description": null}	2025-12-26 05:28:45	2026-01-22 09:36:27
158	57	\N	\N	\N	ru	{"title": null}	2025-12-26 11:29:45	2026-01-23 13:51:21
159	57	\N	\N	\N	en	{"title": null}	2025-12-26 11:29:45	2026-01-23 13:51:21
168	62	\N	\N	\N	\N	{"code": "UZ-BU", "path": "m387.311 352.308-3.466 3.299-3.08 2.04-.524.101-4.046 4.329-.322.946.138.791.653 1.102.763.809.754 1.075.212.469-.258.561-16.659 6.102-5.158 5.725-1.959-2.114-.377-.027-1.084.275-1.931 1.112-.92.239-.965.018-1.269-.165-.781-.386-2.713-2.233-2.638-1.838-6.243-4.797-1.673-1.075-4.303-3.162-1.205-1.185-1.057-1.277-.266-.579-.377-.34-.718-1.131-3.282-3.179-1.857-1.976-3.65-2.582-4.027-2.408-4.091-2.895-3.899-2.555-9.433-6.708-6.399-4.384-13.175-9.677-1.085-1.011-.836-1.185-.148-.487-.183-.827.055-.506-.267-.643-.119-1.608-1.297-1.902.019-.598.634-1.093.074-2.417-.35-.928-.129-1.131-.542-1.874-.055-1.048-.212-.708.037-.551.331-.836-.027-.929-.69-1.231-1.066-.965-.662-.974-.056-.469.46-1.415.267-1.351-.037-.285-1.214-.478-1.213-.771-1.214-1.333-1.168-.524-1.213-.799-.368-.515 5.774-6.993 4.22-4.715.726-3.492.028-1.415-.625-1.057-5.434-6.139-2.979-3.06 10.058-4.65-12.669-17.626.515-.257 3.374-.846 12.458-2.95.965-.073 3.071 6.157 1.278 1.893 1.977 2.132 2.197 1.425 3.255 1.746 1.443 1.452 1.913 3.997 1.287 4.733.524 1.277.809-.082.414-.34 1.875-.046 2.906.836 4.946 2.123 7.797 4.227 9.037 5.238 1.95 1.535.514.965.313 1.369-.441 2.049 3.126-.082 2.427-.212.506-.174 4.946-11.203.956-1.001 2.014-1.075.809.137 1.535 1.774.092 6.993 14.885 1.737.175-.45.754-4.126.524-.175 4.615-.533 3.485-.055 2.087-.349 1.039-2.463.662-1.93.414-.175.891.203.727 2.6 1.967 9.3 1.048 1.011.736.386.947.313 7.934 1.093 5.452.579 7.328 1.048-1.287 8.51-3.669 2.582-.156.947-1.333 3.795-3.08 3.804-.588.561-.865.349-3.539-.211-2.667-.496-1.848-.91-.754-.726-1.838-1.195-1.894-.11-1.021.441-.331.57.331 3.051-.414 4.007-1.186 5.247-2.326 4.393-1.958 2.269-4.045 2.454-.819.303-1.305 2.5 3.926 5.321 1.094 1.057 6.491 2.453.993.056 2.942-.717 4.514 3.391 4.036 8.629.331 1.057z"}	2025-12-26 13:26:58	2025-12-27 07:03:12
170	64	\N	\N	\N	\N	{"code": "UZ-JI", "path": "m533.83 344.342-.441.23-.193 1.415-.294.937-.754.671-.993-.349-1.058.239-2.721-.432-1.71.744-.359-.11-.726-.699-.469-.22-1.305-.294-1.628-.193-1.158.129-.855.238-.681-.119-.937-.542-.681.092-2.05-.147-.892-.441-.68-.175-1.002.083-.552-.138-1.011-.781-.837-.34-1.26-.074-.845.092-1.72-.772-.882-.809-1.269-.073-2.234-1.516-.644.358-1.112.294-1.775-.763-.368-.009-.809.937-1.002.35-.588.413-.864 1.406-.534.147-1.314.028-3.66 1.369-.11.625.184 1.48-.377.468-2.041-.505-.423.101-.322.735-.018 1.204.294.469-4.165-3.511-.947-.965-.598-.882-.193-.873-.018-3.823.092-.34 2.96-4.815.699-.837.635-.496 1.985-.947 1.416-.349 1.196-.138-.074-.937-.984-5.477-.193-.221-10.913-2.325-4.423-.367-1.949-.735-5.36-3.612-.322-3.409.092-.322 1.14-.267.221-.147.414-1.231.064-.744-1.324-2.583-1.71-1.525-.772-3.768-.092-3.612.129-.707.763-1.682-.009-1.011-.883-2.003-4.239-.092-7.162-.846.671-1.645 4.073-7.894 2.869-4.889.257-.68-1.443-6.304-.212-.487-.229-.211-3.926-.965-.874-.533-.662-1.167-1.039-9.778 6.17-.202.266-2.693.203.037.478-4.375 15.997 1.204 4.266.478 2.501.009.782.515.799.119 1.15-.376 1.167-.184 14.168.432 1.297 1.185.8.212 1.884 2.288 3.053 2.83 1.351-1.194.773 1.093 2.804-1.819 1.269 1.185.542-.239.726.432-2.271.487-1.296 1.36 1.278 3.171-1.361 1.351.074 4.797-3.742.138-.671 2.095 1.324 1.838 2.243.625 5.305 3.124 3.301 3.704 3.484 1.231.405.349-.157 2.61-.312.561-1.71-.092-1.931.496-.441 4.494.147.248 1.94-.937.303-.092.147.184-.138.707-.708 1.838-4.551 10.146-.184 1.397.138.882.313.827.607.891.294.046 6.022.285 4.202-.156 3.696-.754 2.096-.726 6.555-1.507.285.625-.928 5.891-1.425.257-.083.129-2.657.772-.221.551.791.735 2.409 1.416 1.131-.028 1.976-.414 1.205-.514 2.638-.745 1.131-.505 3.154-.818 1.544-.193 2.897-.101.772.597.377 1.177.414 2.187-.295.606-.689.055-1.407-.33-.827-.01-.69.028-1.397.322-1.076.808-.193.956-.138.11-.423-.239-.276-1.185-.671-1.011-.598-.092-.533.184-.221.257-.027.487.322.524.864.864.046.579-.377 1.241.027.275 1.38 1.287 2.399 2.977.497 1.011.037.689-.184.635-.653.661-.745.092-.57-.285-.552-.864-.064-1.635-1.241-2.95-.662-.809-.368-.064-.432.202-.11.367.073 1.011.956 1.82.745 1.764.028.634-.331.736-.331.248-.846.193-.276.358-.248 1.314-.221.202-.423.102-.515-.386-.285-1.168-.717-.817-.423-.12-1.351 1.13-.469-.275-1.103-.138-.083 1.057.276 1.534-.294 1.204-.451.781-.23.846-.276.515-.588.248-.579.036-.386.469.248.588 1.728 2.463-.248 1.581-2.179 2.463z", "offset": "-15,-35"}	2025-12-26 13:28:53	2025-12-27 07:30:47
424	31	\N	\N	\N	en	{"title": null, "description": null}	2025-12-29 09:27:38	2025-12-29 09:27:50
447	135	\N	\N	\N	\N	{"year": "2023 mavzum"}	2025-12-29 12:34:27	2025-12-30 10:29:24
314	81	\N	\N	\N	uz	{"title": "Eng chiroyli joy"}	2025-12-28 06:14:55	2025-12-28 06:14:55
315	81	\N	\N	\N	ru	{"title": null}	2025-12-28 06:14:55	2025-12-28 06:14:55
316	81	\N	\N	\N	en	{"title": null}	2025-12-28 06:14:55	2025-12-28 06:14:55
339	90	\N	\N	\N	ru	{"title": null}	2025-12-28 06:23:24	2025-12-28 06:23:24
340	90	\N	\N	\N	en	{"title": null}	2025-12-28 06:23:24	2025-12-28 06:23:24
362	101	\N	\N	\N	uz	{"title": "Sevila"}	2025-12-28 06:27:43	2025-12-28 06:27:43
363	101	\N	\N	\N	ru	{"title": null}	2025-12-28 06:27:43	2025-12-28 06:27:43
364	101	\N	\N	\N	en	{"title": null}	2025-12-28 06:27:43	2025-12-28 06:27:43
386	109	\N	\N	\N	uz	{"title": "Championship"}	2025-12-28 06:35:07	2025-12-28 06:35:07
387	109	\N	\N	\N	ru	{"title": null}	2025-12-28 06:35:07	2025-12-28 06:35:07
388	109	\N	\N	\N	en	{"title": null}	2025-12-28 06:35:07	2025-12-28 06:35:07
405	126	124	Nomi	nomi-5	uz	{"title": "Pittsburgdagi uzbeklar jamiyati", "description": "Tashkilotning asosiy maqsad va vazifalari:  АQShdagi vatandoshlarni birlashtirish, ular oʼrtasida hamjixatlikni mustahkamlash, oʼzbek urf-odatlari, qadriyatlari va ona-tilini asrab qolish"}	2025-12-29 08:15:50	2025-12-29 08:15:50
406	126	124	Nomi	nomi-5	ru	{"title": null, "description": null}	2025-12-29 08:15:50	2025-12-29 08:15:50
407	126	124	Nomi	nomi-5	en	{"title": null, "description": null}	2025-12-29 08:15:50	2025-12-29 08:15:50
408	126	124	Nomi	nomi-5	\N	{"boss_at": "12/12/2022", "date_at": "12/20/2018"}	2025-12-29 08:15:50	2025-12-29 08:15:50
503	152	149	Yillar	yillar-2	en	{"title": null}	2025-12-30 16:54:48	2025-12-31 00:58:19
444	135	\N	\N	\N	uz	{"title": "2023 yil"}	2025-12-29 12:34:27	2025-12-30 10:29:24
445	135	\N	\N	\N	ru	{"title": null}	2025-12-29 12:34:27	2025-12-30 10:29:24
446	135	\N	\N	\N	en	{"title": null}	2025-12-29 12:34:27	2025-12-30 10:29:24
501	152	149	Yillar	yillar-2	uz	{"title": "2022 mavsum"}	2025-12-30 16:54:48	2025-12-31 00:58:19
502	152	149	Yillar	yillar-2	ru	{"title": null}	2025-12-30 16:54:48	2025-12-31 00:58:19
556	167	\N	\N	\N	ru	{"title": null}	2026-01-05 07:09:42	2026-01-05 08:21:34
557	167	\N	\N	\N	en	{"title": null}	2026-01-05 07:09:42	2026-01-05 08:21:34
558	167	\N	\N	\N	\N	{"age": null, "email": null, "phone": null}	2026-01-05 07:09:42	2026-01-05 08:21:34
540	163	\N	\N	\N	uz	{"title": "Yangi O’zbekiston tili va Adabiyoti fani o’qituvchilari", "description": "WORLD CUP 2026"}	2026-01-05 05:00:57	2026-01-05 08:08:36
541	163	\N	\N	\N	ru	{"title": null, "description": null}	2026-01-05 05:00:57	2026-01-05 08:08:36
542	163	\N	\N	\N	en	{"title": null, "description": null}	2026-01-05 05:00:57	2026-01-05 08:08:36
555	167	\N	\N	\N	uz	{"title": "Jahongir"}	2026-01-05 07:09:42	2026-01-05 08:21:34
571	171	\N	\N	\N	uz	{"title": "Forum va seminarlardan video"}	2026-01-05 07:13:02	2026-01-05 08:23:19
572	171	\N	\N	\N	ru	{"title": null}	2026-01-05 07:13:02	2026-01-05 08:23:19
570	170	\N	\N	\N	\N	{"age": null, "email": null, "phone": "941844444"}	2026-01-05 07:12:24	2026-01-05 08:22:48
421	28	\N	\N	\N	en	{"title": null, "description": null}	2025-12-29 09:24:21	2025-12-29 09:24:21
432	132	\N	\N	\N	uz	{"title": "Chinor"}	2025-12-29 12:30:29	2025-12-29 12:30:29
173	67	\N	\N	\N	\N	{"code": "UZ-QA", "path": "m387.311 352.308 1.075-.744.736-.35 1.278-.34 2.39-.367.488-.193.367-.395.635.147 16.135.487 1.37-.166 1.205-.505 1.314-.983.175-.249.037-.303 3.963.809 3.034 3.501 2.546 4.273.083 1.37.202.193.662.229 2.832.717 1.407-.037 2.032-1.268 3.006-1.534 6.942-1.719.579.147 1.076.689 1.517 1.324 1.507 1.057.635.303.276-.009 3.346-1.434.754-.882 1.011-1.636.764-.873.744-.257 1.094-.055 7.88 1.406.579.615.45 1.213-.101 1.158-.423 1.562.056.533.303.442.855.487 1.738.138 3.567-.221.754-.193.386-.441.101-.322-.064-1.636.395-.441.809-.046 4.101 1.167 2.353 1.002 3.531 1.094 1.517.294.919-.212.35 1.452 1.278 2.215.671.689.882.487 1.619.34.57.377.781.267.736.018.947-.202.993.175.937.432.598 1.534.524.212 1.462.073.257.267-.009.523-.322.469-.193 2.298.405 1.157.119 1.884.359.515-.736.754-.901.533-3.668.211-.791.239-.469.23-.616.523-.413.772-.056.368.497 2.886.938 1.929.349.423.138.478.12 3.86-1.232 3.951-.497-.165-1.296-1.314-.92-.294-1.314-.065-1.049.304-.413.312-.543.588-.744 1.195-1.095 2.04-8.173 8.161-.662 3.078-.147 1.397-.34 1.287-.414.799-2.225 2.233-1.683 1.176-3.254 1.701-10.647 11.119-.395 1.149-.956 3.924.248.827-2.198-2.564-.965-.616-1.361-.56-2.933-.322-2.418.754-.524.055-1.158-.303-1.131-.984-2.565-1.507-1.683-1.902-1.186-2.141-.432-.276-1.747-.101-3.218-.947-.579-.367-.459-.892-1.076-.367-.8-.12-.699-.735-.432-.156-1.259.064-.764-.248-.827-.551-1.756-1.802-.828-.22-.983.009-.892.248-.671 1.287-.515-.065-.129.092-.147.589-.34.156h-.487l-4.303-.882-9.13-3.603-1.793-1.029-5.893-3.796-1.701-1.369-2.482-2.316-6.997-6.984-.533-.358-2.51-1.149-3.218-1.222-2.703-1.259-1.591-1.158-.561-.607-8.256-5.1-2.501-1.746-5.093-4.714-1.094-1.204 5.157-5.725 16.66-6.102.258-.561-.212-.469-.754-1.075-.763-.809-.653-1.102-.138-.791.322-.946 4.046-4.329.524-.101 3.08-2.04z", "offset": "5,0"}	2025-12-26 13:30:35	2025-12-27 07:31:36
175	69	\N	\N	\N	\N	{"code": "UZ-SI", "path": "m548.082 310.43-1.48.891-1.186.304-2.197-.616-.902.404-5.001 1.599.929-5.89-.285-.625-6.556 1.507-2.096.726-3.696.753-4.202.157-6.022-.285-.294-.046-.607-.892-.312-.827-.138-.882.184-1.397 4.551-10.145.708-1.838.137-.708-.147-.184-.303.092-1.94.938-.147-.249.441-4.493 1.931-.497 1.71.092.313-.56.156-2.61 3.356 2.858 1.737-.46 1.756 1.443-.496 1.048 4.478 1.314.744-1.029 2.207.165 3.962-1.59-.772-1.92-2.216-1.186-1.039-3.023-3.015-4.163.8-6.847-.92-2.325.791-.827-.809-1.277-3.328-.212-.01-1.194 4.524.285.294.551 2.17-1.351-.019.221.286.082.183 1.103.616.23.736-.34.864.193.34.349-.128.303-1.324.506-.175.321-.028.515.497.974.368-.303 4.468 5.073 3.19 3.189 4.524 4.08 4.33 3.593.57.074 2.786 3.887-.46 4.319-.79 4.889-.929 4.558.018.974.129.57.46.965-.23 4.347-1.021-.322-2.362-.018-3.09.321z", "offset": "0,-20"}	2025-12-26 13:31:46	2025-12-27 07:32:20
573	171	\N	\N	\N	en	{"title": null}	2026-01-05 07:13:02	2026-01-05 08:23:19
531	160	\N	\N	\N	uz	{"title": "Yangi O’zbekiston tili va Adabiyoti fani o’qituvchilari", "description": "Eski Ozbekiston"}	2026-01-05 04:59:13	2026-01-05 08:07:49
172	66	\N	\N	\N	\N	{"code": "UZ-NW", "path": "m458.232 252.709-.478 4.375-.202-.037-.267 2.692-6.169.203 1.039 9.778.662 1.167.874.533 3.925.965.23.211.212.487 1.443 6.304-.257.68-2.869 4.889-4.073 7.894-.671 1.645-1.158-3.189-1.71-2.444-.892-1.029-.534-.249-1.939 1.765-2.161 1.185-1.269.101-1.682-.229-.957-.726-.947-1.425-1.094-.082-1.02.174-.837.993-1.977 4.301-.542 4.512.23.321.496.184.341.662-.157 2.086-.809 5.624-.791 1.231-2.114 5.579.184.9.735.092 1.315-.845.754.064.165.414-.128 1.029-.396.57-3.208 3.023-1.499.698-8.192 1.774-1.122-.184-4.946-2.113-1.922-1.048-.422-.956-.92-1.424-5.038-1.902-.929-.157-.478.258-.322.523-.147.644.046.891-.386 5.33-1.682 5.091-.653 1.186-.478.276-.543.009-2.62-.809-.919-.45-7.953 2.683-.46.322-.074.34.304.707 1.361 1.406.891.745.865 1.332 1.241 4.797-.156.892-.469 1.342-1.076 2.15-.037.579.156.744.745 1.664 1.949 3.492-.367.395-.488.193-2.39.367-1.278.34-.736.35-1.075.744-.267-3.106-.331-1.057-4.036-8.629-4.515-3.391-2.942.717-.993-.055-6.491-2.454-1.094-1.057-3.925-5.321 1.305-2.499.818-.304 4.046-2.453 1.958-2.27 2.326-4.393 1.186-5.247.414-4.007-.331-3.051.331-.57 1.02-.441 1.894.11 1.839 1.195.754.726 1.848.91 2.666.496 3.54.211.864-.349.589-.56 3.08-3.805 1.333-3.795.156-.947 3.669-2.582 1.287-8.51-7.328-1.048-5.452-.579-7.934-1.093-.947-.313-.736-.386-1.048-1.01-1.968-9.301-.726-2.6-.892-.202-.413.174-.662 1.93-1.039 2.463-2.087.349-3.485.055-4.615.533-.524.175-.754 4.126-.175.45-14.885-1.736-.092-6.994-1.535-1.773-.81-.138-2.013 1.075-.956 1.002-4.947 11.202-.505.174-2.428.212-3.125.083.441-2.05-.313-1.369-.515-.965-1.949-1.535-9.038-5.238-7.796-4.227-4.946-2.123-2.906-.836-1.875.046-.414.34-.809.082-.524-1.277-1.287-4.733-1.913-3.997-1.443-1.452-3.255-1.746-2.197-1.425-1.977-2.132-1.278-1.893-3.071-6.157-.965.074-12.458 2.949-3.374.846-.515.257-19.234-26.347 11.814-6.525-6.197-11.165 1.159-14.492 25.431-47.98-14.196-3.842-5.378-9.64 38.945-7.581 18.802-3.318 3.2.625 2.767.331 8.918.965 5.453.349 2.206.386 13.037 1.002 12.541.615.184-.137.781-.037 9.672-4.751 6.436-2.812 4.027-2.013 1.894-.469.993-.101 1.536.065.763.294.698.533.911 1.047 5.268 11.598 1.857 1.755 3.31 3.437 10.003 8.896 1.379 5.578 6.105 19.657 11.557-5.44.322 28.764-.046 6.625-.534-.165-2.225-1.13h-.229l-.092 6.065-.837 1.011-.276 15.292.065 1.975 22.194 2.684 3.199 36.483z"}	2025-12-26 13:29:58	2025-12-27 07:05:08
389	110	\N	\N	\N	uz	{"title": "B seria"}	2025-12-28 06:35:30	2025-12-28 06:35:30
390	110	\N	\N	\N	ru	{"title": null}	2025-12-28 06:35:30	2025-12-28 06:35:30
317	82	\N	\N	\N	uz	{"title": "Golsdo"}	2025-12-28 06:15:23	2025-12-28 06:15:23
318	82	\N	\N	\N	ru	{"title": null}	2025-12-28 06:15:23	2025-12-28 06:15:23
319	82	\N	\N	\N	en	{"title": null}	2025-12-28 06:15:23	2025-12-28 06:15:23
341	91	\N	\N	\N	uz	{"title": "Latsio"}	2025-12-28 06:23:42	2025-12-28 06:23:42
342	91	\N	\N	\N	ru	{"title": null}	2025-12-28 06:23:42	2025-12-28 06:23:42
343	91	\N	\N	\N	en	{"title": null}	2025-12-28 06:23:42	2025-12-28 06:23:42
365	102	\N	\N	\N	uz	{"title": "Atalanta"}	2025-12-28 06:28:55	2025-12-28 06:28:55
366	102	\N	\N	\N	ru	{"title": null}	2025-12-28 06:28:55	2025-12-28 06:28:55
367	102	\N	\N	\N	en	{"title": null}	2025-12-28 06:28:55	2025-12-28 06:28:55
391	110	\N	\N	\N	en	{"title": null}	2025-12-28 06:35:30	2025-12-28 06:35:30
574	171	\N	\N	\N	\N	{"age": null, "email": null, "phone": "941844444"}	2026-01-05 07:13:02	2026-01-05 08:23:19
409	127	125	Nomi	nomi-6	uz	{"title": "Pittsburgdagi uzbeklar jamiyati", "description": "Tashkilotning asosiy maqsad va vazifalari:  АQShdagi vatandoshlarni birlashtirish, ular oʼrtasida hamjixatlikni mustahkamlash, oʼzbek urf-odatlari"}	2025-12-29 08:19:13	2025-12-29 08:19:13
410	127	125	Nomi	nomi-6	ru	{"title": null, "description": null}	2025-12-29 08:19:13	2025-12-29 08:19:13
411	127	125	Nomi	nomi-6	en	{"title": null, "description": null}	2025-12-29 08:19:13	2025-12-29 08:19:13
412	127	125	Nomi	nomi-6	\N	{"boss_at": "12/12/2022", "date_at": "12/20/2018"}	2025-12-29 08:19:13	2025-12-29 08:19:13
504	153	149	Yillar	yillar-2	uz	{"title": "2023mavsum"}	2025-12-30 16:58:03	2025-12-31 00:59:05
505	153	149	Yillar	yillar-2	ru	{"title": null}	2025-12-30 16:58:03	2025-12-31 00:59:05
506	153	149	Yillar	yillar-2	en	{"title": null}	2025-12-30 16:58:03	2025-12-31 00:59:05
559	168	\N	\N	\N	uz	{"title": "Murod"}	2026-01-05 07:10:19	2026-01-05 07:10:19
560	168	\N	\N	\N	ru	{"title": null}	2026-01-05 07:10:19	2026-01-05 07:10:19
561	168	\N	\N	\N	en	{"title": null}	2026-01-05 07:10:19	2026-01-05 07:10:19
562	168	\N	\N	\N	\N	{"age": null, "email": null, "phone": null}	2026-01-05 07:10:19	2026-01-05 07:10:19
532	160	\N	\N	\N	ru	{"title": null, "description": null}	2026-01-05 04:59:13	2026-01-05 08:07:49
533	160	\N	\N	\N	en	{"title": null, "description": null}	2026-01-05 04:59:13	2026-01-05 08:07:49
544	164	\N	\N	\N	ru	{"title": null}	2026-01-05 05:37:55	2026-01-05 08:20:20
545	164	\N	\N	\N	en	{"title": null}	2026-01-05 05:37:55	2026-01-05 08:20:20
546	164	\N	\N	\N	\N	{"age": "18", "email": "sanayev@vatandoshlarfondi.uz", "phone": "+998(55) 502-22-50"}	2026-01-05 05:37:55	2026-01-05 08:20:20
543	164	\N	\N	\N	uz	{"title": "tt"}	2026-01-05 05:37:55	2026-01-05 08:20:20
563	169	\N	\N	\N	uz	{"title": "Mustafo"}	2026-01-05 07:10:54	2026-01-05 08:22:17
564	169	\N	\N	\N	ru	{"title": null}	2026-01-05 07:10:54	2026-01-05 08:22:17
565	169	\N	\N	\N	en	{"title": null}	2026-01-05 07:10:54	2026-01-05 08:22:17
295	74	\N	\N	\N	en	{"title": null}	2025-12-28 06:10:13	2025-12-28 06:10:13
345	92	\N	\N	\N	ru	{"title": null}	2025-12-28 06:24:26	2025-12-28 06:24:26
176	70	\N	\N	\N	\N	{"code": "UZ-SU", "path": "m527.068 422.243-.947 3.244-.129 1.131-2.114 2.224-1.508 2.848.064 1.443-.432 1.02.083.726-.322.818-2.298 1.075-3.724.644-.745 1.323-2.905 6.203-1.057 1.526-1.26.9-2.105 2.729-.966 2.234-1.167 2.233-1.462 1.406-1.094 3.565-.046 2.353.239 3.685-.515 6.12-.653 2.234-.625.404-.543-1.02-1.379-1.103-.68-.202-1.269.138-.386-.055-.791-.699-.919-.542-.561.083-1.26.505-.616.496-.358.46-.644.083-.386-.598-.386-1.259-.68-.661-.754-.368-.616.129-.524.349-1.72 1.581-1.241.422-1.057.625-1.159.101-1.691.432-.883.947-1.379.579-.497-.184-.79-.708-.156-1.406-.258-.45-.708-.34-.34-.8-.248-.248-.892-.349-.414-.312-.643.137-.423-.11-1.398-.781-.423-.652.331-1.406-.294-.772-1.591-.791-1.25-1.295-.395-.239-1.775-.662-1.728.119-3.292 1.462-1.452-.175-.754.064-2.051.699-1.792-.451-.874.01-1.011.34-1.471-.34-1.333.211-1.076-.11-1.646.064-1.204.496-.368-1.847.156-.606.396-.57.79-.579 1.039-.533 2.795-.836.276-.671.009-.69-.395-1.01-4.193-5.092-.239-1.369.515-5.164-.266-1.407v-.551l.413-2.858.681-1.645.671-1.029.708-.699.496-1.167.515-.671 2.096-1.222.396-.367.22-.763-.027-.818-.497-.965-.248-.827.956-3.924.396-1.149 10.646-11.119 3.255-1.701 1.683-1.176 2.225-2.233.413-.799.34-1.287.148-1.397.662-3.078 8.173-8.161 1.094-2.04.745-1.195.542-.588.414-.312 1.048-.304 1.315.065.919.294 1.297 1.314.496.165 1.232-3.951-.119-3.86-.138-.478-.35-.423-.937-1.929-.497-2.886.055-.368.414-.772.616-.523.469-.23.791-.239 3.668-.211.901-.533.736-.754.358.487.625.267.837-.294.57.22.956-.662 1.885-.174 1.241.753 1.352.129.965-1.241 1.885-.064.956-.505.414.009 1.02 1.066.938.23 1.692-.91 1.149.128 1.14.754.8 1.691.285.946 2.473 1.93.083.735-.129 1.14-.322.202.276 1.985-1.158.598-.543.827-.947.294-2.298.367-.322.515 2.326 3.382-.331.615-1.462.175-1.167 1.121.386 1.36.8 1.783-.009.414-.433.514-.303 4.88 2.225 2.95.919.744-.34 1.03-.855 1.332-.23.928.414.009 1.361-.597.423.009 1.535.864 1.296 2.206.194.726.073 1.25.202.211 1.232.441 1.333.653.92.634 1.811 2.325.018.349.662 1.213 1.003 1.369-.01.726z", "offset": "5,10"}	2025-12-26 13:32:12	2025-12-27 07:32:41
346	92	\N	\N	\N	en	{"title": null}	2025-12-28 06:24:26	2025-12-28 06:24:26
368	103	\N	\N	\N	uz	{"title": "Spezia"}	2025-12-28 06:29:11	2025-12-28 06:29:11
369	103	\N	\N	\N	ru	{"title": null}	2025-12-28 06:29:11	2025-12-28 06:29:11
370	103	\N	\N	\N	en	{"title": null}	2025-12-28 06:29:11	2025-12-28 06:29:11
566	169	\N	\N	\N	\N	{"age": null, "email": null, "phone": null}	2026-01-05 07:10:54	2026-01-05 08:22:17
575	172	\N	\N	\N	uz	{"title": "MAN"}	2026-01-05 07:14:23	2026-01-05 08:23:45
576	172	\N	\N	\N	ru	{"title": null}	2026-01-05 07:14:23	2026-01-05 08:23:45
577	172	\N	\N	\N	en	{"title": null}	2026-01-05 07:14:23	2026-01-05 08:23:45
413	128	124	Rahbar	rahbar-5	uz	{"title": "Sadikov Baxodir Talibjonovich", "description": "Sadikov Baxodir Talibjonovich"}	2025-12-29 08:22:05	2025-12-29 08:56:13
414	128	124	Rahbar	rahbar-5	ru	{"title": null, "description": null}	2025-12-29 08:22:05	2025-12-29 08:56:13
415	128	124	Rahbar	rahbar-5	en	{"title": null, "description": null}	2025-12-29 08:22:05	2025-12-29 08:56:13
416	128	124	Rahbar	rahbar-5	\N	{"email": "sattarov@vatandoshlarfondi.uz", "phone": "+998(55) 502-22-55"}	2025-12-29 08:22:05	2025-12-29 08:56:13
578	172	\N	\N	\N	\N	{"age": null, "email": null, "phone": "M"}	2026-01-05 07:14:23	2026-01-05 08:23:45
428	131	\N	\N	\N	uz	{"title": "Anor Tanlovi"}	2025-12-29 12:29:53	2025-12-29 13:02:43
534	161	\N	\N	\N	uz	{"title": "Yangi O’zbekiston tili va Adabiyoti fani o’qituvchilari", "description": "Yangsi"}	2026-01-05 04:59:44	2026-01-05 08:08:03
535	161	\N	\N	\N	ru	{"title": null, "description": null}	2026-01-05 04:59:44	2026-01-05 08:08:03
536	161	\N	\N	\N	en	{"title": null, "description": null}	2026-01-05 04:59:44	2026-01-05 08:08:03
547	165	\N	\N	\N	uz	{"title": "Transfor"}	2026-01-05 05:39:04	2026-01-05 08:20:45
548	165	\N	\N	\N	ru	{"title": null}	2026-01-05 05:39:04	2026-01-05 08:20:45
549	165	\N	\N	\N	en	{"title": null}	2026-01-05 05:39:04	2026-01-05 08:20:45
550	165	\N	\N	\N	\N	{"age": "43", "email": "sattarov@vatandoshlarfondi.uz", "phone": "+998(55) 502-22-55"}	2026-01-05 05:39:04	2026-01-05 08:20:45
186	62	\N	\N	\N	uz	{"title": "Buxoro", "description": "Viloyatning eng qadimiy shahri va markazi bo‘lgan Termizda va uning atrofida zardushtiylar, nestorianlar, buddistlar kabi turli xalqlarning shaharlari va qalʼalarining xarobalari, meʼmorchilik va arxeologiya obidalari, shuningdek islom meʼmorchiligi yodgorliklari saqlanib qolgan. Termizdan uncha uzoq bo‘lmagan joyda esa, fil suyagidan yasalgan shaxmat donalari topilgan,"}	2025-12-26 13:44:40	2025-12-27 07:03:12
193	64	\N	\N	\N	ru	{"title": null, "description": null}	2025-12-26 13:46:34	2025-12-27 07:30:47
187	62	\N	\N	\N	ru	{"title": null, "description": null}	2025-12-26 13:44:40	2025-12-27 07:03:12
188	62	\N	\N	\N	en	{"title": null, "description": null}	2025-12-26 13:44:40	2025-12-27 07:03:12
194	64	\N	\N	\N	en	{"title": null, "description": null}	2025-12-26 13:46:34	2025-12-27 07:30:47
296	75	\N	\N	\N	uz	{"title": "Togri Yol"}	2025-12-28 06:10:28	2025-12-28 06:10:28
297	75	\N	\N	\N	ru	{"title": null}	2025-12-28 06:10:28	2025-12-28 06:10:28
298	75	\N	\N	\N	en	{"title": null}	2025-12-28 06:10:28	2025-12-28 06:10:28
167	61	\N	\N	\N	\N	{"code": "UZ-AN", "path": "m689.854 294.45-.101-3.317-.285-.772-3.687-1.176-2.068-.414-.221.156h-.303l-8.505-1.443-2.059-3.179-.57-.598-2.777-1.433-3.825-.552-.183 1.333-2.786-4.117 1.747-1.112-2.023-2.454 1.866-1.746 1.094-.735 7.898-2.012 3.383.027.525.239.671.515 3.061.68 1.343.138 4.486-.405.488-.248.367-.413 1.159-5.395.22.138.616-.009 2.621-1.241.699-.165 1.121-.846 1.039-1.139.635-.065.137.166 1.214.321.892.625.818.046.726.368.791-.083.717.156.607.295.239 1.075-.092.597-.754 1.397.009.202.166.202.138-.018.423-.662.211-.046.221-.027.432.22.386.359 1.214 2.077.533.634.184 1.838.708.505 1.103.322 1.223.597 1.443.533.506-.184 1.673.267.865-.368.846-.174.625.193 2.032-.515.662.018.754.414 1.397 1.534.349.965.157.138.606.147.469-.036.598-.23.175-.276.588-.303.368-.441.533-.019.322-.193-.138-.496-.533-.367-.322-.451.395-1.305.212-.211.395.009.929 1.342.827.184 1.039.698.874-.478 1.379.064.395.35.211.891-.395 1.599-.395.561-.414.285-2.648 1.112-1.526.22-.579.8-1.067.735-1.287.717-.745.156-.046.211-.8.184-1.232.68-.919.882-1.416.46-1.039-.138-.726.101-.285.331-.046.294.129.404.349.423.028.312-.681.561-.092.386.166 2.518-.065.983-.597.193-.478-.275-.883-.901-1.379-.312-.294.34-.046.698-.8.579-.129.22-.193 1.287-.533.983-.616.147-.386-.036-1.278-1.03-1.352-.064-.634-.349-.837-.8-.469-.165-.625.266-.193-.036-1.26-1.535-.505-.919-1.278-1.075-.368-.175-.901.395-1.011.01-.368.496.138.257 1.03.349.294.285.423.947.965.294.377.514-.037.506-.322.367-.947.092-.248.175-.156.469.129.413.993-.101.239.34.211 1.351.451.487.22.689-1.048 2.454.258.763-.065.588-.156.147-.276.055-1.361-.349-.413-.248-1.425-1.471-.598-.422-.267-.092-.735.275-.294-.193-.46-.652-.267-.193-.827.009-.248-.101-.166-.368.303-1.038-.055-.23-.413-.248z", "offset": "5,-20"}	2025-12-26 13:25:28	2025-12-27 07:29:40
496	150	148	Yillar	yillar-1	ru	{"title": null}	2025-12-30 16:47:11	2025-12-30 19:59:10
497	150	148	Yillar	yillar-1	en	{"title": null}	2025-12-30 16:47:11	2025-12-30 19:59:10
181	60	\N	\N	\N	ru	{"title": null, "description": null}	2025-12-26 13:38:23	2026-01-17 11:43:43
182	60	\N	\N	\N	en	{"title": null, "description": null}	2025-12-26 13:38:23	2026-01-17 11:43:43
177	71	\N	\N	\N	\N	{"code": "UZ-TO", "path": "m648.862 198.618-.138-.35-.597-.468-.727-.349-3.061-2.757-.864-.497-1.609-.193-1.122-.643-.423-.018-.791.193-1.048.459-1.149 1.066-.625.028-.865-.313-.386.037-1.627 2.059-.938.634-.882.395-1.085.818-.644.018-.974-.928-.479.147-.533.515-.616.671-.772 1.268-.754.606-.506.827-.901.717-.689 1.002-.138 1.158-.837 1.654-1.011 2.748.046.183-.203.442-.68.238-.386-.018-1.131-1.038-.689-.193-.138-.579.101-1.48-.506-.836-2.335-1.278-2.473-2.177-.34-.148-.635.129-.34.423-.276 1.948-.202.34-.892.8-.276.634-1.453.882-.285.459.12 1.076.313 1.277-.074.993-.956.68-.883.284-.45.506-.497-.019-1.066.506-.819 1.195-.983.827-.405.698-.68 1.847-.543.928-2.932 1.471-1.233.882-.671 1.967-.294.275-.303.111-.331-.111-.147-.266.046-.515-.35-.616-.358-.064-.626.184-.239.285-1.517 3.667-2.693 1.102-1.104-.955-.68-.304h-.46l-1.535.965-1.876.303-.23-.119-.772.119-.285.184-.184.405-.487.487-.625.303-2.519.597-.479.212-1.121 1.047-.267.469-.873.652-1.196 1.278-.367.496-.46 1.434-.211.257-.681.349-1.121.322-.35-.055-.303.11-1.545 1.314-.616 1.011.019.478.303.496 1.076.699-.313.928-.377.193-2.032-.322-.487.211-.763.037-1.205.322-.432-.019-.919-.533-.515-.128-1.011.119-.331-.11-1.379.294-1.058.634-.588 1.746-.405.46-2.05 1.158-1.048 2.609-.607.423-.469-.055-.542-.533-.267-.11-.469.147-1.82 2.821-.175 2.491-.211.34-1.278 1.075-.276 1.654-.193.129-.782-.138-.625.422-.597.791-1.297 1.259-1.407 1.856-.68 1.057-.441 1.011-1.526 1.92-.662 1.535-.138 1.388-.157.321-1.222 1.112-1.683.662-.956.79 4.468 5.073 3.191 3.189 4.523 4.08 4.33 3.593.57.074 2.786 3.887-.459 4.319-.791 4.889-.929 4.559.009.974.129.569.46.975-.23 4.346 2.344.203.589-.046.965.34 1.002-.083.708-.23 1.196.285 1.802.037 1.029.57.442-.368-.773-1.948-.377-.386-1.268-.248-.377-.386.22-.781-.321-.533.165-.57 1.609.22.763-.055 1.039-.983.009-.836.304-.506-.019-1.112-.956-.763-.386-.459.009-.763-.267-.744-.367-.322.22-.781-.432-.175-.561-1.902-.386-.459.009-.763.322-.377.037-.698-.607-.524-1.232-1.7-.064-.303.248-.589 1.434-.965 1.674-.22.8.156.275-.073.239-.249-.027-.165.368-.689.441-.212.239-1.167-.515-1.13-.313-1.038.194-3.226.055-.294.303-.359.184-.873 1.692-2.38 1.508-.183.606.303 2.326.643 1.113.138.689.68.782 1.571.23 1.094.505.717 1.159.827.671.809.634.101.368.193.46 1.194.276.377.607.138 1.489-.101.855-.542 1.287-2.776.414-.367.653-.193 1.314.377.276-.028.865-.928 1.02-.607.395-.009 1.462.901.193.009 1.085-1.029.699-.451 1.866-.266.763-.331.975-.827 1.315-.515 2.188-2.132.285-.404.257-.8.451-.542.542-.101.947.377 1.048.165 1.343-.864.809-.358.662-.937 1.508-.91 1.103-.028.625-.211.34-.331.469-.928.009-.331-.266-.854.138-.662.625-.754.028-.698.275-.487-.257-1.177.101-.422.349-.258.368-.863.506-.552 1.195-.478.947.23-.184-.386.138-.809-.028-1.608-.22-2.141-.607-1.231-1.756-2.408-.616-6.709 2.731-3.777.625-1.773-.451-.928-.441-.515-.782-.515-1.112-1.332-1.076-.111-.459-.477-.58-1.351-.367-.248-1.205-.515-.984-.165-.891.055-.479.257-.753.092-.865-.221-1.149.083-.579-.34-.147-.34-.157-1.14.074-1.81.257-.68.377-.533 1.168-.496.634-.11 1.177.101 1.526-1.416 1.196.046.781-.367 1.389-1.342.533-.827.276-.211 1.903-1.039.496-.147 1.526-1.038.616-1.232.083-2.031.221-.45.57-.542 1.14-.515 1.995-1.397.303-1.112 1.03-.735.34-.386.681-1.406.965-.992 1.094-.524.598-.046.809.294.377-.009.156-.175.156-.753.203-.184.625.423.956.33.809.01.395-.138.819-.827.276-.469.147-1.673-.837-1.452.313-.827.597-.606.111-.671.156-.267.551-.266h.736l1.719.956.745.184h.708l.965-.478 1.186-1.011.626-.276 1.618-1.663.744-.285 2.464-2.353.993-.377.754-.027 1.168.285.368-.57.643-.496.414-.166.184-.257.092-1.443zm-79.271 47.263-.331.422.083.607-.359-.046-.147.101-.266.625-.046.441.128.313-.312.229-.441.69.524.689.156.505v.818l-.138.506-.873 1.047-.304.212-.588.082-.331-.229-.396-.855.148-.377-.662-.211-.993-.083-.993.8-.019.441-.524.064-.634-.129-.156-.229-.331.211-.148-.046-.303-.772-.441-.23-.304.166-.266-.193-.855-.212-.083-.312.11-1.342.129-.799.414-1.149.092-.772 1.103-1.213h.129l.092.165.947.193.763-.34.239-.312.193-.018 1.471.771.524-.101.506.249.331-.607.652.064.644-.689.552-.101.349-.57.414-.101.036.653.469.422z", "offset": "10,0"}	2025-12-26 13:32:47	2026-01-19 05:15:20
141	33	\N	\N	\N	en	{"title": null, "description": null}	2025-12-26 04:37:40	2026-01-21 08:03:05
490	148	\N	\N	\N	\N	{"video": "https://www.youtube.com/watch?v=UqvRkpzTMJU", "content": "Anor Loyihasi boshlandi", "last_date": "2025-06-12T13:30"}	2025-12-30 16:43:36	2026-01-23 14:11:13
492	149	\N	\N	\N	ru	{"title": null, "description": null, "description1": null}	2025-12-30 16:44:29	2026-01-20 05:41:31
493	149	\N	\N	\N	en	{"title": null, "description": null, "description1": null}	2025-12-30 16:44:29	2026-01-20 05:41:31
487	148	\N	\N	\N	uz	{"title": "Anor Loyihasi", "description": "Anor ijtimoiy va ixtososlashgan milliy loyihaga hush kelibsiz", "description1": "<p><span data-metadata=\\"&lt;!--(figmeta)eyJmaWxlS2V5IjoicExEZG1NWFkxRENDdU1FbDRZb1dWYyIsInBhc3RlSUQiOjIxMDc3OTE5MDUsImRhdGFUeXBlIjoic2NlbmUifQo=(/figmeta)--&gt;\\"></span><span data-buffer=\\"&lt;!--(figma)ZmlnLWtpd2llAAAAEGwAALW9CZxkS1XgHffeXKq6ut++A499B30bi7u5VVV25/byZlW/98axzMrM6ko6KzPNm9Wvm9kQEREREREREZFBRAYZZBAREREZRAYRERURGURkGIZhGIZhGIbB739OxL15s7oe+v2+3/d+r+tGnIg4ceLEiRPnnIh782cy9UEUdc8NOpemA2NuOt2sNnbCTqHdMfzXaJYrO6XNQmOjEpL1tsJKO5X3tXalUSYdhNWNRqFGKhN27q1VSGQ1sRNWBFdO6yrmnfBMtbXTrtSaBWmZbzQ71fV7d8LN5latvLPV2mgXytJ+xSV3ys2G5FfjfLuy3q6Em4BOhKVKo7IDuLW5c/dWpX0vwLU0sF1p1QR4slxdX+d5qlSrVhqdnWKb3kuFUGi7IkXb6eZWm3FUhLIrw067UqjbEvJXubwd8dXVRqfSLpQ61W0GWatCmGUNZde0K6Vmo1EpMdgUMTGF1x5fHNN6ndJDLzvVRqldqUNvoUapa0ON63VmoKuzFS56vcGNrU3TSluHcGPh4jBipu4hbQS3V+j1mHFADKW802xoj0YzZ9vVjuDxGpP+oLXfjQZUg4BCR3FRqd7c1qR3djjuD8fn2ocjqdNoNu6rtJsUmGZZywWDFanvorACyJSbpS0ZCkmvVGhsF0JS/ka7udUiEay3C3Wplyk2m7VKobHTbMHdTrXZAJjdZtzNNqkcg5ZnvlZVtCuVWq3aCiW5Coc6sEKF70S7srFVK7R3Ws3avRuKZI2uYEwZ/izqnexU7hGSTjGDJQFcEd5bLzZFkK+sNuisoVCmvlo6I6y6OtwstCo7Z6udzR3X9ho3MUrgtSWZmmKtWTpD7rqz1fKGLoDrwVWXkd5Qr5SrBRI3blY3Nmv8k+KbQhDYwd7skjswu10rSKe3nC2Em9WdDj2Te9B2oV0tFJX+B3dc4iGa2CnBD3K3xlXc8nsow9NF9bBCGFZDJnQHzM0tKXv45YJcqanUUfiIBJFQ06YQ4CPrzfKW9vooW3+DAnKPtrl28yyZx7BGW81GqFiViMcqa0rNOmCL/XHCwZ1WoSOL+fFanGL6ExRQqxbbBV02T9T8elV7fpJmGERFuP7kYntLNcK31AuNwgbDY61WGxtAvrXTLjTC9Wa7Tua2Uj3caVdLydzdzqITARckd5wOZZ3cWakXK2URlFa72Wl27lWm38U6YL2uV4ta9ymp0dnFqEN86tlKsUX/JJ92pnJvLNRPj9M7EKOC8W2FRrWu4k0vFRqnB/7tOjYlg9x3FKsNGEDXOvDvDPe708HZ4Xy/M7g4t4vs1vDurUK7Qqlh/t168BCzelN1lQ8zVOJRr2SDJFtunhWRyxy3NLKtQrtQq6GnUU91uGYlNbcMrlXWBZqvNDZ2ygWEsKCdr0gefbclmVXJOPJPaLpZQ0ORW4Mfrcp9TRWfk3CiXFlnYSvrS5VQVMQpJL9Sk/IrYhWyEzK1iu3KBFTfqnWqLQVehQxsoTGrjZYK+NWblXsKVgdcU9qsbLc1eW2LZg58XZNh26SsU6HshlZtS7q/sdBGnuNh3mRzMS9uDrfqdWjZOb3VYP0ogltUDTwobFUqiFlxq8jiAfBgXWVsLUhms21F5CHF0WDcr6MrhRxW5k5nk5nYEEFm823XdUP1yoX2mYqg9t0gZTEEogDRb0X2K7KZUrPWTHJZVSvaJheiwTWlKpMW5SYqifyKbRJnV2WBs55Ingib6x0WHjjIrW0W2qgLl9ONlN3FSuqpyj0l+GRHfsWmzvaVIdtSorqv0l5IXF3bglXNsNqRLq5pdYdjJ710h94AaJCocpVpoTchFYiXgOSp/GDPICkgJFV0PLAggVHJCX2GBaYjy7Jvna6SyG2jnmSbyqNyZDZIrjSaVZXY1eoBdlDY644GdkYwZNqVTkknY70qY/eQYaWgY2U5qOztDXpuFKtVNoE2ZkyBRUWhKbebrUXWQwNVZLdjWy/WtoRov4guWAYFVh2RyrAP1SsdVXxZRlcVYnMxsfmNGuJCYkWUQEm36lwTsURVCIVmq8X2ydOrNc9qApo7lugQsartlAotaZ9Z5FiV7ZJqnKwgLQ96k1l3PpyMaRNv4pCKkDA5pD34Uz1TWYisv9wsnF8S6yBIZrfchOmS8s4WtmVcfm3QFTOiMxsekIs7gZidzYqTN69xeLA7mG2Nh/MIZO2CMNO0qvdUaiEJj2FiQklNvzQZR/PZQq7yyBtwI+XKA69eEAXvQ7ib2CAsYeyRyKyDsbxjW2RdRmvnwvlscn5QGA3PjWmQIDMobMSJhMc+6pK+rVzqTlkH8Xjgjwqkl2hp36oRYaQMIrDZyt1b1ZrsRTqFGSfJojitPZqF34g8ajsB5dI2RH5hJezcTn4llb+D/Goqfyf5E6n8XeTXUvmnkD+Zyj+V/KlStV1K936FHe3pyVA4U8d6bAM1xcp2RUbgxQP3i5PJaNAdN6cDKxqMbqth9QNspJmYPKS9cKvIjqBp/x5VG4EIlTJ/czIbPnMynndHNHf6ODW3CL9ywT+9hbG2XlUKF623B7P5kMUtsGaLolTTIoLZrJPy65PDaFA6nEWTGfxgMyqgcSkwpXYzZC1X26S9yr0VWdyIHjkf81u7arFGcSy2SqwJ8hn2Fx5ZHqVqjVSuLnpcmuSZYlwpUivJ/Gl2VVa1KKgT2+iVyaw+nM2EkmT96fTz9DSBAkQxs6Gq/eSXu9G+VV1+CSMAkFlIuqfqzS6MbEstI3O6VZGnF27Lw2+VxUMK6q27eGQqF6eT2fzomgqwddlY2ILdwjExAEtXyfBiQLKE/Vr30uRwvjEb9i2SjF1mqRlY0OnbVRcs2rS68/lgNqaIWtWWrhh2CtUpns7v4XzSHkTDZ4I64ZSSowxK6PCSlGqqzuxw3HPi6JeroVi5gtPgPrGnk/BUhYUDN3amsh02nYLt4Any8EpIm5Wd9TYLmMkWzRZ0Kli5zm7NxGhg5nyQcDLRi2h33btIevGehSLp9s7b2czEY9pEw98Hd5UCj+0ap0TTbImKKtBWKu80u4zLlrV+EeET1UPaNihNDiFs5trlHqgd7HeTFBS2OiKmmRSqrKI6fRjNh3uXyD4gllahhHG7XbGuZ2DzxUrnrDVTMjLnpf3hqO/oybjOjMXoJRhjUdGOQzv9qrkB4qyG1fuwt5uoK+XsEgBpRTqq9RZeHzkpoY5lemsSDUUq2JgAxZ0XiszXlvWPtdrZmSh5Ni385kILsHFPW5zmqZt3asfYjg7ao8qYJU+3VjrW4jlHp2CoYDaKl0He22rrjBexHXgGpVpTLYKM+BCxs0Y+u9XCHK/sqLe5095qdKrqiuRYnuWqGGcqOfl0sx38Oqmz0iyeRiGzehBHqQqM6IviS2A7glDmHoOWAqqcqDLMWTc1iquohipSSk1hnZFoK/ZL8l69SUAJK520b9O2IKDVplijpDO2ABtKqmVtTp2YHLVwGNQKIoak3FopY1nzXKUMlytudoLsdtP692ukLU82VS5OJnmWPflTtotYxq6wWSIS29L6ys6sO7biYUd4C1YAHlNHHDvsAWEM1QzqBHHRJt46MSuevnWO19vNxGkKUqB4+8qkYHajyqYgyU6Va+HvWphDll9AYlwrC5BFtboAJJhOSFDHwhymtQUkxnRyAbKYYFMMSDBdYQllEqkUI7tyCRjju2oJalFevQRLsF6jPTmoQ3ptGhbjvC4NtCivT4MSjDegY6slhF3n50YsYAJ/Vq4FcBMeUxObeAG5udKN0AZ2xq8gNlfaKlZLFBhBHWc8vJtU1pe1YZ0TWshyTYoyUm8JkrVtl2A5u7Uk+XzYciGNlQ3Ek+WaAFZd1QRwwqZ0gbDA7epYWwZ2zooqOnkEuIm3CPhU2JtNRqPycGa1EkS7NfZNdiE4rLuDbYtKm4s2GPRRiPMB5ZV7WmzIVj+XwCCWnua8jS32L8+PCE3SGem88UYTzDVN+qXJCDPIy8zMqvHO8cff5U/Q5U/GWko0vkjOu8Qfvw2I2gvA/fwJ9vmTUUzhfDKlQU/Spm+8qdP4VLBdSYXt7sz4QU+yUkcTAntfzvipBkG9O58NLxovd3DbbeS9g9tu5+Ef3HYHj+DgdgFmDm4XYPbgdgHmWt0Z20F13B/Qzj93OOyb3RQVa8a3Tg+FF7qjwwFtvEN1gG41/jpsbXQPBsYL9roHw9El6nuRWBgkhLJ51JsNp3NygdSF5mGXJocHg9mwtz48dzhjLrCTXHjBIKcIAAmPqIzG7ElrN8tNw2m3xypYakuYBjNHtJ7mPeI/ziM/BsG6SIMMMI0BzUvgRdNYgci/CkS6dak7jZD+RRMWrLrhHo+dOOO3Kni4QnoAYCfJiaNBnF+SWUAMdoNkLoW/FfM9TRaOCH/xR7D5SCg9oTKZyUlqVVkEuja9cHAAqmHv7GB4bn++VIlosgwpqVLFgxn2lqos8JSw+MIxI96f0J8uG3QD+4qtGDZw1DdRZHYYXlN2Vj+G7hChtU5TrVZnY2VRE6SzWySS3x80d5/B0rB6LEOoMomfGsmoqcGSZDaBeA22ebRnXMW3+pBC0IquABbUJrGRCu+seoD7/PVElbnYhjtk8HH/dNdcH3TnKoR/57Xw9SkypTtadvh2pvxSKxR4IDPGUyeRZ9YdM+QIAIqvkm+2y0LrSmG9LeWr5YZq+BONrbrQvIZrJaH2kxghwq9TZfu8QnwunlcSy5DnVYWCunlXl+zzGvxceV4b2vx17W0NFl0v2o7nDeFZjTbfWArPyvMmBFjgN5dKGuO/JbR28oM2ibXzfLAzMB/SbDeEvltlwnk+FKNBZONh5Y5GMx6+XivIOB5R32jLzD4yZD3yfBR+o/T/6HXcGp6P2bTPx27afh/XsfnH322fT2jZ5xPFF+b5pNp6UfJPbrb0+S3tjj6/tWXb39Y60xA+3V5DJ/O8g6fQeWe7U5P8XTwl/5RCsb3N86mF4rbkn8ZT6H76tsXzbdsQxPPbi7WzMj/fwVPqfSdPqfddhTObMo7vLp1WH/97SuuqLL631NJ8obTVlnpF7CfJl9gx5Flet/grBIeFnnWed/Dc4Hknz026lf6qPAX/6U07HnrbEHpqm83TIjd4EGr0NapYZzybp1tPezrP1unW0wXP3adb33Ybz/bp1m138Qxrp+vSrsNxjtTfwlSQedkWi5HnWZ5Cxz31M3WB39uoqa17X2PrTIfnP2GlCF3fxzPk+U+3YTjP72+FHYHv8BT4D7TPtCXfbbc25bnb3irKvPdCPBSe/Y6lY9BpqNe5xzTJ/J3bJtTKc3/blg+37bifsX1G5eX8drvT5jnieQfPgzBkdzJmzFPyE5538pzyvIvnD/J8Cs8Zz6fyjHg+jeecp/DpkOe38bwQhuxrxtzPU/Bd5Cn4LvEUfM/kKfj+GU/B9895Cr5/wVPw/Uuegu9f8RR8z/LC8A5B+ENeaVspfLYkBOUPS0JwPkcSgvRHJCFYnysJQfujkhC8z5OEIP4xSQjm55NQUn9cEoL5BZIQzD8hCcH8QkkI5p+UhGB+kSQE809JQjC/WBKC+aclIZhfQkJp/hlJCOaXSkIw/6wkBPPLJCGYf04SgvnlkhDMPy8JwfwKSQjmX5CEYH4liTsF8y9KQjC/ShKC+ZckIZhfLQnB/K8lIZhfIwnB/MuSEMyvlYRg/hVJCObXkbhLMP+qJATz6yUhmP+NJATzGyQhmH9NEoL5jZIQzP9WEoL5TZIQzL8uCcH8ZhJPEcz/ThKC+S2SEMy/IQnB/FZJCObflIRgfpskBPNvSUIwv10Sgvm3JSGY30HiqYL5dyQhmN8pCcH8u5IQzO+ShGD+PUkI5ndLQjD/viQE83skIZj/vSQE83tJPE0w/4EkBPP7JCGY/1ASgvn9khDM/0ESgvkDkhDMfyQJwfxBSQjmP5aEYP4QiacL5j+RhGD+sCQE859KQjB/RBKC+c8kIZj/XBKC+S8kIZg/KgnB/JeSEMwfI6Eq6q8kIZg/LgnB/NeSEMyfkIRg/o+SEMyflIRg/htJCOZPSUIw/60kBPOnvaMRP8zPOdu1earxYjPUF0O93p1OxRD0/L3Z5EBM1/mEv35xNCHt7V6aDyITeDbiaPxgn7ik5MditWKj9rvzrtbNm2B72B9MjO/HdaI7t2YjqdTqRvNBODmc9UDhRzMsV4wvMXVnvYZYHHQIiIBDSSzzQv8ZhxEUr8yFcOzlaL/bn9wfkfT3MckIw+xjP2OR9wfz7nBEKjNgvJEYIljmFwjTDIgzks7NBwcaqLZF+QvDXZx+yFjFoRa+2G7dxRnjn/j/t8selucMZpBe3Z0JzjE9kzuhxBj/0TpJVxnrouCr+BOx1Ofi+QQXhtFwF8Z5JsPDHTZeYbIRHk5knuHlwD2O9iazAzM2+aHO2Es8s6Kpzj5uyFhIB7TaHQPEm6tKkUCushBMZyx7pjZvriafPkO7xpywkP3J4ahfEvrq3TEA6LlhNsG+pTFkrkXShMTJPeWt1nRT+nLPnJrKSNe1CH1prhgcTJ4xFIO2xdEDPM57V15QQXqpZ67hmODccIzrKD2fHfbn+1B27RJ001rpeXNdT3rCERC37vqhlLnMQ5VDkhl5N86FEZvdaL/ISRuKZs3clICQ2psjlVMRy6q4crdEMgGskFXzoKmNXocOsmce7SAd5LkjM/dqzzz4gjudKCA04wOcQ9S5ecg+RNsTjyX4rUPp5GHd0VzC2BDz8PFkGFlkr/LMI/oDCVHJ9D9SCzQ0umce1ZCM1sJr5Vyj2nEmO8dMTZf2yltxkiW4TCinb0QFOXlwLl4qEkCQXY/Y1bpJYgJL0BjdYigECjhr71CGoSe+BwnPRuHU36qzbMroCuNnzw8uGVb3HtDacBzPHwtNIOXhuQGCEuAQk7Ne2rMQeMk5fyzLmR45pnNoZc4PuheHUad7DiHwJNkQCUbvxJpOT45s79f29rviug5mETW8JKc9Vcsifn4k6SbTSPB60Omy1sxrIGgEsZF5XtY7OdLzjG1wSPd5s7LXHY12CRQLXZGZeycOhnGgOBne1baVm8DMLtJnMb7Z87LnRpem+xH7rJfrD+JD14hd1svvjvDLfvBwIor4bZ531R54E26+1vNW95nPGajOFycXqfNGz1ubJ8ch+J0zF53ImlMOPugnVF0xmpwTYdUqnUkp5kdzby8azNkdzKp3pcwwuCz+N3neNX1CABcG/ZrS//ysd23ZAhZ8djxyo/WWRusvRos6XRotim1ptNmjo81dPtq8GxU4lka74uCp0a7+I0Z74uho1/p2cDWln9Ge3EzRYPzcLscD/cjsE9ix+52LAgW9A6Rydm4wN29AaCe4zNVxY3A/ImU8sxgJ7l2W4HjSLWtkgTKaJ0MieIbWj9PBEI02oiNWx4Fte4aVlTfZomO28VfYoWw8hDm4X9Un60zK7iWhEp3wJiO5QtQDFbk8C3syG9RSh/rsX3vDWTRPuCZ9QVA6n9uQqTX+am9ycNBlCEVrGywCYnvGri8GzRhkelVG6P9y5N3+Bbdz5i7fJfIKqoqaD+Hwa1mGqV1otZwIFibHjEgJ3PTgZty1WDhO0lAgF5zOLrJHwHQF17szJtjNQ5poG6VUiZSWkmkM5vdPqO5GC+sOmJtnEi7lTzLmy3WKLBh06X4oswyhaDWrslCPs/u7M5ldtdOkkvE9kazI7HpeeOlgdzJyNESagTjkyqbjniLpxSfeCLqDkAEO1uEulgWzH6NF7NUE9H2ECQxTYNjlxi9buS/OBt3zU2G77c6bpJHr9dCNwVgsHphtqwTLVQ6jwTrCtSGWKCy5NNbt08N6HO7tNcejS23m8kJ3pLUD12314OBwLoxSg8Ti9ZfxknEa2D8dXbRVjlDnkD1QcSGKBvNqHxZQhOTPhhR8yEsKKoAu0W9XsrK82DM0Xe1j9Bu/IOn2gAn2z9tS0CtNqAEtpKKfl2kT1nYFItU/TNsIYYUnk8NptY+/YAKVEdIfZUXbaSTzMQ/rUrY6OEH24yiOOBsq9k96nCakUfmx/lnuLnTYH6g47vAByrddp0jZP1CjCQuEw9X+P1QzZADlB6qE0XlId/0HKm8Poim7BrMbguYBq3X2BwffhGhRKbUhFvrsUrX/zSphsX4TYqRGaXIAQQMOAx64Wnd8oRvJiqlSJ4jrRDHvmezLxUIVfrs7FktbShfbARJrt4PKxd7oUFgBEFpGo+6uKr8LA1EwzSnjpymuBpJJmpY9FBtaVjPHtbBGos+JKPYfRpwpV2qVToUEYe0jtUOWzXQ66Den7cOxXGYVO8q3+pwxfMkz3uxwXBuMz6FY6G5qj0z6EUVeMBvssl/1m2PItKDMP9xDbdJjl5wLkV8W9MqdL8I9TVkXpTioMkKYCY/aA4QygoEm6LHl0H1RPNvquHi4t8dmQ9OMI6QtGASQvYwM7Z5ddWgHtTQO615DTDCLEWQ09c2IyTpi0BY5132KD3kHagsaQbiyRFFrhDoVsuD1/hAXZ3apOY2EO9L+KyixZajw7KsQ6qDC0/G5kiXAsQHt29uX3qLOpADDx33ztWPnYzBi20OYmIQx0ixCvDccjPoyvZEWpsgOejBqXpivz+iMUWfmoNiGBYKAcWYXS7lDiSoqVRHU9vOY0med5WL7EM0ttj0V0CHr4NRNFj8viIE19hln2ADOJGBx0Wex+0ZJollb3Vn33Kw73U8V5sbsO8xMfn3UnboFkW1xmswiMPGFbm+9UKq07BVSn4OfjYbcYCYTyI38raLAMyFm2kAVUWs2wVX3V+aSiVkgu4ajI1RV9kkEeR5zQibzo6wTPBxATIX63Yd4HJdCx2kDT4dRcTLrO3f7mArZ6HBXDhN3sdKlc6eSclGPXDcmJY/hF7ndfNBnwg7KgwhTEAQri1Esb5fP8zFH0mUVCmTTnEue4XyGtaJpO/rn+Ow2mHliCYjeg5IBCwk7z1/dQ8uesRtppIUoqF0m25KnLjpHoaI3W93EcomIEOI5yIJGgrMjq87FvOlMQjdqqgmAaLCX68WK2vaUPxzvjcSflVtCaZQrw2grLlIerlqyS3H7epe4VmwI9mKoxepND3dHw2gfZNKxkNuZdAbdg9qCPOnEP9oJ+h4lDzvifTScy7AXNpWgau6F90OpaJNIK4vBhlJfImHZWjoe7/Yd/yjMIzm/D1MzEjdxqOl3hsDINrjOFFasBECQzSMEnwPL0WqshESKXux7XnF0OEu2nsWJanzyyQkmOa89mHLo6GpxBmwvZhhOUezBqrfF8borTu4Wm3alxoFnGkNTlgt11pvts4W2LGYqEe4ItY69Dl4gmsBavgeIfeXqnh1O+XYk6dsaxn/CXPq6zngT9SKx9tkC+sNDietlFjG7LI8kZpeLpljVfWrko/3J/cgV0cbiAGnpN6QGy83i2MYhQRfhT7GsXeaEbexyaxdd4uQllzilmztr+YqZDrQj9L3MN1d2ZTSv9M1VhzGHXu6bqyfKh1f45prdBf9f6ptrmf/ZvBkP6jqoTzIP1rK2ksggrlfyJFwZDXqTcR/5LjnITWOJVKmG3jM3RANkPG8e0hsNpyxOefuFsd64iHLdrNWVhFd55pZF9PNBs8GeeIaogaTbW6PpoHc46s4K43PweJVAnwNUZVdzKB+2y347UgpWzcN7+yg1NrJeYRcJJoHWWzWPALuoSnJltkeVe0JuQF2faYSPWoAtKY7vj457V3Ic8DExMMHgCh57DCWu6HHRlPCJyzx+0dtRFE/ozFzAF7EasjnOlHES23NvHpjUmwdeeKZylqd/WSuJe0vDV/spIfYXootuswKVWRaobCxQubRA5ROBWonOD+6/B46tSuJeEie0b40EVMd7clgwl1b3Ga9/aFlAJZ99Yj6RgvLgwrBnpWFxZ0nOX/XGglfiRFzvCPgKI3gpVxrI40NKw3YcDxBtYhuXSmd39MzFO9IJRpRkzOvgQSSyAgdYZvCiinTOLZ/Ye2hlcb7eN5kmWpCZarngRkcQYKVBiQZATafZiq+5eZJOSnzJxZfdgmJTbrPFNTMum1TOOkBcP2ffiSKVdwQUiT2ew2UQd4AdyUoLvSSjloulO82GvcApl+jcOw7eZQjsGJKWnK1Xyzvxez+XVy+wVWA7yXrx/d0ErFjeDCsXoFgh+I0upyXKQ61lso3CdnXD3s4zTRRwTV9c8sKzep/El2dyLzVwF/r06m1yrx3MTOceWwrA+DUyKpiwvaF3f8rVsAXandadO9t3AfBL9XvlcD+wGEIMQzZq9qOTEZbw8CIz7Q0ltKQk3mV8tFo0l/jFnCNmE0QXzsm23xALEeOLbLXMahqYd7AqyDUP5yNsULHYKMfiYFoIW0msg3yeGusTThlCfecCM+J8BHiFOElhN5qMDucDF3jC5uilR/c235z4QUw7dAALZY0GxWHvcHfYC7sH0xES6pmTbkjbG44kvLj1nUal4i7rFWpnC/eGJLyahmjlirbxT81loE83Gj83/tLqHx8ehFY3RoZApdMQnHpFFhrKciFGd+4QI2bmcnmlm/lemYptMxubbzerKUxOhZ2w2FxuLbKlgsOBTi6wOsipDcw/xE2j/pAaqywUxzlKsE6CFoYMFe5nO2Va9c3mFYM1shSTxJcW87pMMggl2REWyOU0K/ryagwPL+y0m2cE4rv3TIPK+jqHJ6QylXvkyhyprLu1nyvODqP9JiYNRz0yFJodb2BoRdtl6ja+CUv6Ohspr3xp3D1galVIwkREg73Z4AcPMZhFBIjqnmOzIeVHB5MJZrZo0IBQn3LtSNPsOSz3pUbd8TnZnE4PpTqAhX7DeIlgelKSBdlg3tvnsYTTm6QG+16mg2lSX0a9ttZEloyfmToVCSJCIi7I7GM/umQQDc5JFLvaFxHDMMDO1klpL7wDO2HWto3jbM4liB0KqcBygmJZnvAqEohrErEsWjEdtJEVZYvgl9xyxQBDNyG1AFTNyDJBDu6plHfOblZQn5vVWnmnub5ji6uNjR19FZhaiAmq9V5XIg39wqyXUIG1BLsKYhgwWqxeEcw46w/HeFzWliAbWEO7xtEAbQ9nQyj0+kM1ChqicdbgnM2qgoH+1uiQE1HX21QziCPNiKoeaoPzdqAtLWsPRl3ORvZtg8xUgbbBwcAehdPErReSwTAq40piuqMPMvXD0XwovQ9m6+KQb9upYILUTkBaCDClo01+acIAJe5c78o5uVzqc4vMvUQhuyMP322Bgd3xSGXiTS+bbIc5abOzOK8ElK/Y915XUm92rCadVsb9qRPDgUuKkQ1pu7hpsUCw3x9Y6j7lswzgkEQ7WoviTIKQBItg1BJMjHq6qGPVJ6ioYuvKDIWkpJygZrVcrumLK2xoqjjMAmSPS4mvuabNvb0C6HhEUJW6lVlkl+TpFSs1fR91ubf60I4RSYgASsef9dNaklQK7+cYbdIemRuEsmTorlIrNs/aPQP9VHDzgNHVth+OSPVqtVhiluhFYNYFKa8wHjuNwh7Ggdf8kq39cKdeBbdVr95ZHHbRgX7ybldQrzZ2YnBGMklRtl64JynCIrpnUZS3KJPSlVKzLa/zioe4JStzNVHgJ0SlMxf2ovSa5jSKsyxfJ9dJ7awX6lW9/XpKs+4e6BWaORt3fiVaobKg5SqipojtjrwkhLoAcjUzjw22AFxjAa1C2b2qdq0FuBd4rrM5pcqZNdc3pbHeJr0h/QmGG5WUeDQ3yZYkH3DY2VBD6mbNY8pt1RsOdIuCpEqpuaUoHqQQVykGPliBUq3QKMGYnWqjXBGf+CFa4GofKbtVy6QRQ20AeKgCXGUHe9jl4mF8by4S8iVkdlFaIh51jqhlS01yZrzBoEFgCiX5tkC1WK1ZhrAoNrEn1Vz15cUEy5qgzM5ba7YcBzPL96Ozl3dUUvPFrNxbqdlFZprtgv02i9e28t+qNtSGpDdmmVSmWNuSCtlORcUmt9G2r4Tlj8F/SBT2gDXa046+ymh7CippHpOMkOtAjpODyxvTbNhX7WXZ8RUMNtvafI3lfFkDCbD4cRQNhewN54ODyHzd9/xFXdRj3CV4dTKk3ZeppHBCRRDTsxjltGTXZBat64OuXIaSPVyUaygmmslYtW4Sde45Be/Haj1FawoDkcCh4Pf2cJEFHWl/PnEpDCAL1U6eHRBQnmD/2iyBFt1NrXZrOzWO2sth68bg9eFFtjKMVIsz1HNGNRoJdq1gX1nLfc2sumhdfXJh4BzWyah/RvdS4v8YGuuJEeGn6m4SRBAmwWaaHLlShCEi+dKRaB1+6GAkbFei9b7BeeZkbJvR396iqxFlzhQIJL2lFw8ymFznBtg4aH92YZ9zaG1Ll5X+kGMjGUBmPmSPn+MvVKPJ05962+00lBPaGRUFM4OSyoN+QTz+oEeoKc5kpCBW9yvlinwnijk0ZzernUqxaW1cT1/9EjXrs+Z25I3qpn6uKQipJfBMqSkfBCKVZQ/Ah08+MJFbr27UC7ob5DHjztuegkKttSlXoeUVLVGvpDy0SLWBypGMOyt0tWPNEKJN2Vjjdy31llSc80M2LmQuRPSwuRaNiltYeDw90ausarvSl2pbNmYjzZiXBkRH4dnWtA+ftsbDi52Yv3BMLVzOrqQ13A0SPmdYuRfCBEW2ePjMZ+JLz+QYvC3mPUdn2g+HQDYnrTyXGcy2YkR+DLJTFIB2OLg/rhCZNY8Jn7OhrxmOaubyzOmZJONo26Zm18sf0z8qI+4vMi/nsDxdp4FkOfJNEplhf8bBqWqUySu0iNvGlgJSsFEJKb17qyJfLAIYHI/OjjroHc6w+ucWZl4Jk+/vRi0Z3OQwGl2y7VjDnvG7mhayL+CYwAa3+Ezew7DpDyoHnHlYtJlDXSdy73RLU37Mm0DvAMr9yCpW4MC5FRmhq6QnYsZ/eca5l3oLw143e8p0v8tJXs74mrDAp067QntVTmbN1ASprK3wtLlI6gn0Fk8LevrYruasPC3o24ZRy54hiHZipG/0lqXpnf5ooXF0gM8NzLPSwJgTzwu8n3MewO+q21MQCRDx+KBn/t76VZjDeXO7S1oKBsNofTgahQKj/1/whpHz/hzkl4A02VYIIeixgmjNuOyrFm2HIZr3+OZfe5otL43gd2M3jvS/USW0Trx3fG47gf5kcMRre5c/eQYhxPAQRcmyxCWVOVI/xHzEN39JBPpCfTIZEyKpDUeXyuLhAP845yzhZG/u3JhQaIHINzGAxmRsF69j8697cPwYZxIsb0gXLTzTD/vm17zheH8wG7K1OIbBz13zyhic4psWvDouSFim4F+JwS6IkxS8LinQU4dFwa/GBRLHWYBfH4NT9BBysmRQ/ltepMA+QKnCEaP5gJ0xhdmKcckfpUqEYIF9MAWzRAn0j1NQoUhgH0oFBltd9iYWtOf9nncshcWkKlS+m+kRFWDvQzA3fwPZcbZlbRSC4bi4TYk5R+ZZWe8L8RypE72YpOf75plgU+jyuvpnpJIG6QPAf54uWMjkv7TgZP9OycgLfPMyd3K5LOkv8g7jUz6wpzt5jVz16rFzHF/86fggETaJgvhzZz3U7Co/o4v6xwNXSef+LyTSZUmzxR+FjaU7GOlfxsgGidO+Zj4mERz8/9Jyo68vsAiny4O9yHwo4z3fXwLD38i8P+P9uD2Qt8CQI4/IPDvr/a27mqa8eZdnfnCRtRpGZg3zzLFY4HKe+C/GAziKzmaymbr2QAJRlbFMl2j858cHlv3B2DbUYf/kMsGoOA6uxZpEy2W8FxDN5/S5MBsUD3cdol9PjjFDOQs1L/S9ryYXxBSEzfsi3/uaavzYPpzEGTuEadygJvabyZrf8w8W5shLAvMNUT2jiQSC/5hAiiTxnJlpgfy39BXI6+O0xVxl47C3EmTvoPqqueEIyFY8nUDj6wur5sajMFv1zJzlW5Br25vMur2Qbp5gHnYM2DboJCXbLDa5I2meZB5+GdBW3hJ4iY3Q3GAeEadt0bZkU5cybzKPXIbYamexZuOrGzPzuEXOFn+fcKjBFmnm5vFx2hb9U0UnEvR6zzwhztiy73di1nFQFLn5T3rffNtKbYlQ12Rck3MJXBCJu/+rpVKm6+L8sEtMblHjWSzcpEp5yGofyDhYlOlaP5SuZfdj4Ve6yrPTVVBk8moD4B9Og0NsTFbtfYPZhKLnpIsah/aNbPs2+AXzI8cUOhkwF81zjyldj0+Mnml+NF1c6k4j88/N89KwZCv+l+bHPPZSNF+MfGZ+2dZMVMv7qdFlPPYC8YPNu32xpci3iD7CT0XkmT+JwTX4Q/5PicRdrDH1ct7wH7FwH+h6EArf934pDnOxYsVYxJz+JFZACqS20csC87f+HARbmBk1PfqICc2b/+BJCZvuaMh589HSFwTziQTM5XJWZ30ASkgyL/C8P/Ligr295ZIPesn1bvN6BuGJIhJsb8piSCiXZAgCitjcvecoacVhf7jo9mcV1pnBK61ovptDV8zMzW6/3al1KINXr/EHR+9B/2gQ2es4zqLdRHSYjOelXiDKuaRdHt8+mvSwnIHnbcqCv0Mydawr83zPvDlYnMWvuKSt9p3gSS42rCYZW/hdEeqMgOiaPC3oezhHs+fPZmxOJhlb+L19iEW5IlZjs+qdSmVthcIBfiGUXiVPCyrHZxZN3cfo7XWBlFajpj2Go/o1SwDbbl1gqqVfHJjfSRkpTTs8RnrtZUDbdAOtRZAhCdlfl87bKpuRmlDupZVVc0s6b6s0LEgVqXmEeUgqayvcbSGsQ/Moc2uSsYXtJB/CW1bff+ecQSD6DbfHmIcucrZBuIeltTDAHrPI2vL7bAMLkhqPTQNsnX8yUFMvMq/yvSe6tC3ZWbAqDmHdcQRkK+5JvxuDycFALgm92/fuTANsnXO25xgote5aBtl6+3NWwWIPWQeRpVbI//lguTQ8P5xWWY+eeYWWbLGFygodsHojls7M/ILCFy06+8PeedRQRNkvHilTPWRuMa8KEhFG7PWeQMSq9P4gkLcO0Gusssm0NthjG1nICALxU166QlvE4kiNFy9qFCdzonvHYPnpo3WOQ/SSRaVFyVBMCLnjiWaCJz9ztE5ngmFF6aLKSzUuiF/C8CM2RWYEZqvi+FmPIy5iT4UI22/eFg6Zr+XMr0jE47Iz7Wf7uxOx/Bj2plpxwH7RwewgEvCrHFhGngB/yQF1qAn01Q6KPOJpsVpl3b/WAenKrjy48SsOZrtKwK9zYOkqAf6qA2pXCfT1DhqqSFowu0yaV//G35/EllTCqrl5mHnwcXArza1IvjaGFA1M2bAVuowtfIbmZVxslNBwPp23VUYKanX7suVS5SCdt1XoEFCJmUClqqYxm+aiAk8f2s+9nTaXNG9L182HPM1uJmQ7hHTwJ7aILUuNwEXBh20B8Uhs5ob5U5u1lhz5j9h8C6sAcwn1Ja0a5u+WwNp/lQhqBEmfsUVpwm3RuvlPrkg+M+eabswm8pmgz9oSR5ZOIdD/vAS1QgD4cxasaBR/OBjtwZzPW3hs99DEtMxP4OYCJOSEvA3uk6m/yKT/pAXr5+Ta5vdtztHsZoqe3uMfDMcMeiAr5N+LrRNn3rvUQqlARtRV6Ji/8CUUMmBzvQAepZN+hz0Mjqz30uAcPkhbXll+Rcb8O82hcw8PMC8AvEUBFG9A2ar5Dc3acgt5q0KoUOBYGOW9a35TIbZOAnybAqnGaMRE+S3N20oO9PYUKGJg0GpelTEfUzAtU7C/UpiOZNuJkI7Z1MzHF0WbieDFhX8tbtSYVb7RPUCr2NekPuqzlLASZZIkJKQ+4Y+LxrLXvEIUlMaKtOAFi4IiHD+32KTYt37CW6BS2/G1vvm5FKxDK3OfeXkKVF5cX/t5j4MMRqi1vs+8IlWLACbG54VBqNcNIPo38Fk5rVBbVetvm7emQPJ9wDXzmwtaOSNgws0bfPM2D7URX/XqUGTuMb+d6kqi0JNDkfd3pGvWu2T4p0r7dzwycUlqBO+UQOMcN0TyGE0X2Ca7cnHpXakOQn2vIWS5zQv67rio2z9ekFpdoI7MS7Lep7yJfrHIVo6hrw+SBjpB8E2PL8xrsuZ/e/ZignpsH/e9D7i8nI9gE9vbC5/wvb+KOSZhK3CYT/vmSwtYhVASkP+xgNQYv92+v+CbLy/g2hp7CmPrfy6gtLewryxgJeSRKVRSI/MZ3/u/i7Li4JnDweU1/iMnfa5GB0MiOaX/vG/+ftG4AyPMF33zPwmzONA2KgZ24Qr9TKabnJbh+gTef/cPkDV8DvEuIvOcwHtWsKhSYk44qpNDvG/45t8HhK2OfGz+pPnvnkK3EEunnVfN/yJcFEK8s/zKuIj4zszuizN9mz7m3bz3eeYbiM0DFMdj+KRPsHTMInTvGACTYvNez3zRe4Z7Se/9nvkvgUN12sE+4JnPY94KUhue+q+wsz8oiotSw2g5xP0xX82YH4ZvDtyRVw7M1zLm1/WIjLUnJyOK7a1Z81JfB+68K1jkmZfHXmOJuROGJqbFz/v6SYIWq2AXbWG+GrAEoeZgqujekjW/FrelG2xJ1Rqvz3OIPSWqJ7ZhKL0RRBuOdfWYd+bNzwX363mdvBBJCIxJG5hnZ8xP+QtwyX6+OG9e7IBly5bwcHfOKaUrflbG/LQrL3V7hAnQ1yxgSl4QmJe4kup4ejhPbjh9PmN+wRWInTcfTuHpKx1kc3KB/UoXyDcC86+JX51VeIiKPi9TAEt+Gf6JAoBHjoyoKS/qUE2bU+WzDl19MO/2hU9fyJjnOljlgjDYfC7j/aiDtDAt2QQu1QfjQ7u1fyXj/ZgrVOJFbBvMrorul2FU8IzoojQj1pgx/zlQ6WCHibfqyLyMnc9XMKqd/Wip5DdsCQ2s5EfmjRnzVgu01c+K+aLg37Tg+gAbt18ajEYor4x5eYblgRgz8eh08bmRnL2hXg0Vkv6Hf7S8hYIhwsBOaeNQVPqyT+DXvV/0bB9XdBjpiVV/gDXjVCPM/Ix16sPpgH1v1uAkj7M98yPUFrdmikhIMRVfzlEWgs8u9xnP/B8/EnBHINrh1/Lm/6ZgRJqZEs6NLGhwIOIqYX+3yn7MFhAn2mVKv543v50GhIMpQUaRszXzvqA/lHjjQatLvJ2zJTbZ/8JpskRS2hOin7vmcy4bzwKtPu+7VjUtkZuaHRnvezKoZlfkEKqJ9d6M+W8x3DZpdQ8jlNP7MmhNDsxQA+WhLFYRwK9b/hNOq4wPD9bRrqwK8/WM+T9eXCBMiQu+kTE/5Hf1A9Rj9BYIrljkrPlclOVvjYVKEo++8jKgrVwa6CEOMqHapGkv/159OdRWrxwMoak25IESvpmHy9ni+hzx7yBM59kjqfCgdN5WabLuEK+0Y4HD8ejLobb6vZaSkCAeKCLzdt978jLI1kMiiPYqJyIxVL/TfMsyxFbbHemEbGC3RZxNet+aytsavT2mDZmLzhMuVUbBj+gyoK2MflPck3X44Rk2uSRrK1zYRXEtfYn+ceZRR2G26j3EF/ssX/0EOwMzt5knHQHZij/QYxblHP2EJizwuyPsgiq78SyEixKov2kZYqvVuu6+50d98/scbMrerfm3e+a2RdZW7ltAQue22yDz5lc1zkDMaz+kkznmm3lTYKelyGRbOYtZBWPul+MIlMG7fO/5HnOrYi1SRdkLvUgtzcWnX7/f/CLGhrj34QGrcp+RM55XuXouELJnXuvZHjuQUojC7Q1JgPDfuoqIEpLUwxuBSLatHzBvBm0CY6JA8u+8Pblno0b8bDCO1+WaeYvDkuxGf+7DJMpQk6mjoJrKT8yZrHmPN6Y6cXOyqiXeilWj5zWjI+9gvNHHonAFYi2K/o0rQNgfxGULhlaFcRAvFd7kY81cVqOAkkXbsbOyp5g/1AqItirKXfNnOvwuhuWMo2lhnTs6FzOqMMa1EJ6LlfFx60+WwEmXsEqmoGH+eoFADrcFwwMg+IR3fnCJgPq5czDzdVnzSe/CBKegIjtqa3/GiQss/ltPKBUbQCSpONibzLA+iNfLAHe9/+IOKWsYRpH5mO/9V2/ODEv8XThvnpM1/40JgdD9JkeYCDmEYs5N0KIcRpCGkB/xR9TH7XN+7fMIRbNxKYI3ZzlN42hhvz5AXSvoZTnO0pAD5llmGfKc8LAJ/owfDdl7CD/Eh36t7njALkuszu/2GImGqzc79Zqsn6/nmGKJn7dZ7eYbOfNvNVeYz2fDXSJNkXlx3vxdqmFNLrDBljexR8QhvAuDqgTN6eJzyYvDSuj7cubN9jgTSAmleXgAD8R3YrPEuU7KJDhTvBRi4VDygox5R1IiMAo5Gs15b0tD2ZY/6ZnfSkDtAbExpF7F9hU5dHBcIqTo0XZkPpAzv53AO8jDuIHKZDifSKBhbzKl5ody3t/I+/UUI1yX0/47ajXD/Hn3onlRBr9EL7GFeqTM0TUuxBSeKDUvCsxPYHKL/Om7ChvoGST9nQ4WDlA/V5pPJbxTa6klPg10+N7vBv1j3194v2/eFUTY3BB4pOgDvvk9wX7MawYf9M2741ZKTYelqEHXyIy9zwa7ChOy3+eb9wS7rDDabTvSQFPtC+P/d3zii10fF1Lycc986GgbwJ/Km68hMBiD7t3AykX27L6UGk72ghkaNK5+BjWwZp4duEsNHLC7giq74ccC8yMZ2XAme3shMn8YyXy8LG/+sw+3wRgrJwG/OWP+wIHrrMA+ciDgt2UY2sEQy0cqWizmWXnzh1CYutkCYe/3WXMYTLggLwzMf8AjIqyBLbmHWWeemzd/5tuVzfpTJcBIP+ahg3uiqNv2wG6xYzw/j36YWag1wtbMX/n9SY+zQ44I07iflzd/DW6OwRHG9DXGiDN771PW7iyAlpM8sT5rw13Ltk8rxSrDSvbL8+a/4lAdYCYnn2F+tme+ksDcd5ef45n/xcq3tjU8tW+9C5XoVmHFT2Mfs8Tc8SFiAOyHY9+yyKhSH7Z5j2e+TNFe93A0X2oDf3bhJNaljS4u2oHt/QQwFLpoIj6KtvnD4ABcwwpj22AhK+yDiGrcvL74tMH/BH0xKaiO1+GvaL/nZ2YJXkjhf7se3h6wPnfd/snmnzcvCSJdxSV6h6WvTGWZpNHS9xu22Ulkbr/keS/N9NKlYdLIfN0z76CL0YT+OhMBMV8zRso4PkuAO0Bjs0uxwVO0zvzjE/nmT1XDSLaU/tjJFzzzEYZYwUS4pEMsAZdajPFLNAGVXNxoohIQmg123KkVja8cXxiPIG/+V2qgjkDb8qvHFuA1eT+cOcRnqHfPO7hESN4QeC/IHCSgS6W4V4hfQ3UuvF08fAkkrMvbLOcHZ4bzEvOmS8Uzz8v06M3VSCbrDb75aS2oXCRkIIx6feD9RMaaWPYzCyVKhR309jkPYnrkK1reQJdDwRtj/VSiJE3c5z3za3BWAntLRVDznxQNkdLUJ8ifixEX9Pa7eOX6og86ZMX7fYVIU6RN+GrrPm/F/F3QHZYo6+wzyL556Yr5oiIVWIwBrkLgpxUed2Zei+ZZglSRBpYpePt6U/WTEF2ivOiEGHr/JOjiU8BYrCME0DN/Fux3o+JggF60S7s9GMMOWdl/rsiV9ZaDZfwDosOe+YvjSxaC+DdILnRXYRRmmnnFivlLbdLU+KRuIs9jJ9QZkzkRC4oBflQrxeSWRWW8LjCfUKgTGkgntsngfjRjB9eyktDCkmTqmoTk4IKs659U7BWxl1TjvZpATeaAmK12v0Z8Ync02W0P9kzg/VymdxBxGgFxsOmdRGQCAEc29w8E5jUCbmNzyRLX8I0UfDigrKtKaNAXJpTYiM4xsMGo31A3Xr6m9jOuiurgmrOWXhboN3zKsy7bi4z3zXnzsykYsl8ZocedAn1rnmH0JiBA91/A6VToVwLzyw4axxcU/vIV80fBbuoOcDu+a/wKdFsmXSJUi0S6mxyvCsxPZfYPd2VuCs7kgwtMBVJ30JVvkmJZilOnHX0yMO8lJsJQ5TKEYnhDDrYg2DobLURkOjdvzJkvxGtMOrSy8j+Cg4kgT8wN896c+fHMnJkaYavH+7Y5Zb4WnB9cUl92W6w28+c583+wBrBXphMGTSWd2letmP+NVpUQ8SYGgSiDV6+YrwfEcelYCf58zvxsJkbWhG/a2rxmxfzf4GjHivO1K8TpeiNOt2WH+fukUhLSv5IQYQxsWh/vlPmhDJOh8UyVFfO6FSzxbhydR3KpFplP58yPZeYyeu2vybxiPkH1F3PmhZkSjIoXuPHzEZOkKiY3hLPp1Z6fop9Ax7F8/CbanvHpHw9P3QkEvafT4XJZ7Ai8mhYe5KgtFIFEu1tagH5W9AGi6g17jHPNaHBZmCJ6HowaARf1lOlOU1drsoLJaWPj+wObajhcPS0U7eAg/tbSfnHJ+N7BIgfXaVSaTM4POUySqIAsQONfs6uZTRQnnhpVbL48jHqjLrMxow+sGMIb9HC0DO0UlwUI0LB3KV6VGXFrpuqak8syf+PJ/cQCMNstKGfXgMvlZwNVaza3wpmCqO1Z/OroagIoD/DKkwurJ8AxuoSpFbmKawlgueLJ6Sy+YxtXPZUCLVe+AkvpPE4o8RZb9coEsFzxqqh7IdFDV7OYxduN89ekeR3Gu6y/NrDRN9QrU4h2l21QZMG8OTD+xYKcHoqy4rDTBPZ4WbNvkzeIbA/3LKBUyjrovQsodXMOWlrq4i0BMq7zZN8sWJnLAN8YmFULrWEGszhPcDJBxIgKa+lBLOMyfrEgP0Bq+K/eLOu7ZF7nuF7TNTv6c1lODlMDMYF76cokr9B68etXvq2dGqD5Zj+p2D7WFvWvn7u3KLz+ID2JPg7biCriCmNLGnHgND/EvnVhBHnN3EG7F1PQbAwdjmuqJWJLORcXdC8uF+RH7Gv0urKHfkAbbHb12ttqNOkNu0uvdZw4N5mcY++IBRqnnPlgw0UVEuPp6eXai/SBJJ3EDp9b+0wWcqgxOUR8GVzhjBHpXgCLk/6luO6Vy2Bb9ypHJX3vmqtTNCrgmm6/X7yEbx7VkBsxGK5lgojhtAf9QwIndd2UAF/X0wm0UkSg0FyfmiPHKPqVuausuxcZw1KhVuHplephYlb4YmSUcAXIgtrqtD39THdJ/FmcWfx2phStGBHtl+8hE5tGl2ZAs56qiFb22UMwQ0RC3x3EaCL8cs8/UnmIbxtXNX690Clt7thfnTEu09C3OmkWk2qbG1+sHbViLK2TKdu8wdk9IP4xjAip6jaM+rysrd1TGbTxKndvFWohPZhUrZAxMogj+Gdo8eIlHD5WjQyCkqaDGb8Qsl7KVX1/15QrqZyQXmJCUrba4qtXHwy8y8srFLLFMJQEqr2ZD8HLJaKEkNLRWrCxGsrLb3Ru9I3mcqEjr89JT5eZhwtaPmJpWapRoUxIiSRTGiGPGN7Gm1NeHkQ9Weqw8aOWJUstbWWzulkpCCPk1w2MS99B0nPpO0n7Ln0X6cCl5ZcOMi4tP3aQlV8q32gXWvJCd65m37zNF2vN0pm7t5qdCrmVFAkp4ny9Ras0wbOPsjfsoWVkY9cIjRglc8+vHg3bRNa+8C64vIRxPg6HLqvoWJSqKOEkb/Ny+9T39y2QKgiUywglZP16VzZtFExiuNpPpVOzB8GMgaSPjrLbByY1QBT2Z9i9XDokpnPQJSRnskvYSkvFxtu+DXaZpSoNlIRdhBkRGYpNqdkoFTqVBv/Iea3alv0xY79VK5Qqm033s+/BZXggfC6oPu0kRWA6oM8iJ72JnreP+ZfAP8fWMB1hrKqlr6AvMCrM095gfzJijSXwLx8dWyfdgcyCXfTeUqXSotNCdFn1CB56yw1aSk1HRmFy7oeqjH3L0bO/teev62uOQd0qqEyzs6nsWKbO4lnq08d6JoS1hwMgdPYmY9wuxAOLGvV4TGuhgpVasXKmr/F9Hs4q6VB+RHLW8VFw12kDUfFUogAqPDz5wU6efmOrXlRqlyevtWD4EsnBMsl7iy6+RPc2i5OMZpVdPyips5dyAX2Up9zM7o62hegITxUhBOniRoWf6+L6T8myqXm4+MNuDTRk/AMC+mLTBTgZ95cQ5dlEDwYykeyvHYzlOh6syQ7G/SSTqwsGCTWy7swJJFYmybQKW/bjO53mhrwbLPCdGOjX7YdDgq2GS2VcNcnuJNBseKbakh9Ydx/1yWm+WCidcYC8AvS7JithpaO9SPFO207DaiF2soRetmiNiQqhGalKjX+A0Bip6EfyARbQOXftQvUc3Nzj7Ki1cLkimOau8ygg/bMixE/Xk9oYdcJaYGGqiYVmh1HTNrP5nO23jD4kmrp8JYUtA6+CQWHO5EXK9bSLpF+XkKhM9ID4WXr/eU6GRbhUWKEkFnnk7oIIDwl/26laES6qpXA8DxxHSisUgSQYI87rukFCz4VUHTnvSc5RbI3nZ0ywvQQxd6Q21aPfE/GSzUm+a+E+6+EvgPJJjIYsxCB0XyaJPw+SsR/3WLTKWkDLfgwk/iRcbhlqLfT8MjA26VeWwYnxvrpdDatFNfzsV09QCgUya/FnUk4mHy055X4bBMGjKyVi5+iYr1iuo71fVunKRSVLx/G4rrqs2vHori4222w62mHCwmsc0LVM4Nc6uPaYQK9zUNtBAr5efza5wbJqy6cJOtWK9HeDZaV+BoU2i1m6sV5dfJfmJvn4TJy5WUoSRt4iRUnuQfp5luQrMg/WbPy1lodoTsnoVJsN6f7WxWdeHqql7oszD6sd/abMIzCIUh+deVRzu9JuV8tI3U54b73YrO2wDI159Oa9DI66Yjw9BnNpJ6zQXw20ZTiCtZ0WjMeGtabMAWOnb0XwOP2Ei3zTxX4/5vGad590saAn3LPTaoZVGQO5J6K1FrkntZsdHR3pJ9ebkrK/tSyfZiUtn435lmPgwoFvdfAUitscSP0ZbXz7EkSa3RFD0JWy4d0ZL2vxipKz24UCeWFKgaSrVCgXLXLBlQGFI59kr4ohUhvQ7kKXUKciB4ZODVKZrZF4mZ6+gjPV7YvpdqmsQgH9JdcHzVdz0pVTgB1BX08uo1E/heul4Lq8QoVSEGZmk/sxP3cNKlkO/iAXCGf4csECm3LkkhnF0JYNV27CxeFGEKV6ennc03H1KlSiQ8wdOll8Zgvq5dPHLZenYgrhK0F4pLRC0QOjkctFnRkGhEQNqJ3C9WqH62iVCuULhPO4xLwuY3x7ApBsz7VhhB+YYHwtGI+pUZ3rR14wRtgMG0xiVTF34zrmFVmITVNB7QN9AwCby7w+g72jrwC43FJdYOuHY2se0IfYXG+ggZWE1cvqdqSCCdZr+gkm++k6nt7mlqgJKzfJZNFEGJIa4ZsY4bF1KlRYMC0CKJ0X9JC6NbFzQrUUqreA6rLyCoULNFNXIJNpqwor7RB896EWoy4eT4csfSK+6OztSWep8gqFi84EaN4Bd5frYSqNu+qA2a9OvZUaqZks0zSYY6XN9NzgnRmTuTCZ20Pqd2VM9uAw4jBacu/OmJxF3Umq+95c0rX4lw8cjdsxBvwPkiWxjRal9QQlNhRnr9AAccu2rl9OX4FMbk0K19RHMZ12RZ6eq9fCnhtzAkdUy3jxVzKX+O8qWoTuTqWgA4m5VzdD9JOLPHJgIu/94+aN4ZG1jyCfo3NoRaE8c3KwOxysc14npn3DshfdkmreSBp+AJbKnZz48kK2dHw9k13YL8tRjQfY7PxqA4+syoZbrdXsNmsLgsv3NQ4WUp0WMFxdNNTPxKNyS+7DyAf6fVszGI7BaHCu2yN2rjawOKNlkao3YEMv4SwLv9Ys38eWI75eBXc+kSDmvHrpUyeZqU6ba16Vttax/giyluZZ3sbbZxKUABcxmoxZSVO5CiY6xQLHf9obnjMfzZgTfRcjsZ0Rjk6Ra1v6GblOadPsdHNGZzOv9+y3Vm2OJbI3mnRdGQHdJVQdodisFJv6K706dTw8jAb7jbZqAyurUarsyHd+AQRqA6m5nEn81Gy1XtBvr+Vk8njml/poHRk/KwfFIHd5NLvmeUN3rUw+bu+gn8l4fusIX9AGnBMO5EbL1IE+nZG9El0yGZmPMfsRx1pJ/U8wayM9lYDLmaHcUnclH0c7RMxQLwZ8ikk70h1/Fa3JlCvrhS39WWSjn8+SMXvVRmtLQPh7NQxkUkE11YMfHCJA0rHHbiJPwq4X5RmEaRr9wBXLNiNPmDOYSiIIlUC54YcM+Ag2jJECz44JGbU1YkwEWaVqZD6Jwm0c5RQhZDcg+HQZTXGnmWpqKpYnDhLmIi2fpbn1+YjLPVDljtQ0vnynC6Wn8mKQJDx1+alykSTP+qcVuRiJCNWbuM875eZZsR1NSb6EzdMTgdyplFEUhGwB+IUOVv8mFrF+0bWAygl37AespBgXbgufQHraSsPdt9d0guIjSmqfxQGkFIW8pdE0kvZLZFjhkvFts3qyHWWn+o4TOgetb9PbxM7huoLc+xANxIhcoLebhs+ULZsViiJty7s/Lps9q3VlhojEJC9WWMblk48fmrAirmpHl+NiXZbxhByzAgXiLIgYaqmLjJDKMhDhowsGpDuzsiOXnEVomNyJTTCwOXoFR5+kY4DyrYOCEY1vKfTxqTaIdIimlm/qKptN4qaQdhOc7lMGaPzVqQM5PqX7G1JDO/gia1dOYABmLGWR+VLGc6t20G8qjFJ0bcd+5gGm5veRQoArbG8YSYf2ZGfEZHvyyVk8BkK0i1eSzFUdfK6w1K7qj5+bUkvEwXO/Ce6XQtlag9OFbQ4QXJ2M3HLlmT0d6vzkNIhwt4DyrXs7mwpc2ZCteTVU8InwbFXjBGtnmvKBPFIn21uhQE4VC/rr9lcQL6qy4ynfrkzo1Gt44F2vbpwu1NlS9SfRTbldKG3VdHd1vyHK5EvWT7L4nhUAQQzAvVIHOBMDCJBVlIRsDKk59zRXlVgQ0cDKePFWBvt4TSaYALstLCPHcSGGFA81BAo4J16IkNt7YC030aoS9DgGOZs6INNkt23ZAmzUyO4X4XTQc/XindVWpIUvUih2vRCAThuRZOnR6+4hp2M27vncLIKEOYW3JkISf/qHM7GxezeGXKa4aECAWOIOVoa3GouMlwSHsLZgkbIssDSMbXzKPzEiqWheABmRhPigOWtOHEMCNqNcekvub3IECCNemDWr/WXQiyB3GSScR1O+GMr7k/vH2IM4pElnWZZKBC841edkM4bmhD1MR/JDIVn5BaF1uSJUg+jmXo1ylsZKeWEhSYEdmLdMgNDkSamOlTMfkVnYYRy7YvZ4CQNjiK9uQnwSFODsU0wqEx7HDRPIJ6QpNrWO1PLaHVlG/tFqvi02thhjOl3suGX8ar3FXlLtUMVU7knSix+YkJq4aNIS/T5UaWO2aPxS5ssWRHiJHup8YdRlIiYW30vi8wdUdrsADM4mmCuKxc8PFz10AJt7DAZPApKrgfpmgaBFbJOC5H4QUWD22w5B+nNI7usQgGNeKcjOk1tA4ojgJ9AudyCB9s2h+ibk8wltutzYiDrqTbHaGLgcjI3RPXYlj4ZdXE5MhFJ8BsJRiRImFlzXpeCL2F+2ghgQi58HKWgV4z9uQVkD7KxWOLyAdahq7sOvSyDpgduLV1rn++QeSFxHBmTHmBp4qLdAwwPkvaD+/QCW5iBvbCVD0WybvITiR8e+e7J6+TssJxb4MXGipRfE1yx5SQxg1TvJCpp1bQW35vbkl31jFG0wcNQnxUm3nrn5SIVqLAUXBoklLYcqtyzGYl8+X0GVjrdmo+o4+eXaa0bD8Xk1ZWU6HsGJtJvjN2TNI+eajCdfp+KKZdi2KtpX5syVy3Dzsqy5dhmkWoI+rlMpKyhZ5muBuerIaOxZ0mK0V2t9eTGyM5F5ZBKvT0DFS4UDdblXzQ0KbDFTu3iqbZnOVfMoWGClLaJv78Yku5DOl2e9m5YpDWGphvgetAxPooIPXoZT/4xauA+5sIB0tEoliRn2BeFjuipo5FVeXpU1ty4g2oB6u+ahCbC1L+v1lVnzsAQUiioxr86ah+trNoMaE2g88+ikgjBphIawAzRfD8xjkzLhWcLGxxVisO0G9Wc1tHoqXlKqtC6+0r2OPuZhvw28s94mUC9xeUB+CqRBeWB46AmMWD+QTApiA/0As0lvdnxiYOrxFHTa5b8nkVMURKIxqDiTS0stuYKOZzR29uGyL7z4oj8mttOKZb2OSKdnKvfGnzpmIz/TwERemKiyXXj3FJv37NiB+63wLh4BBppcZuF0gVyGmXdYofn84JKYY/IRD4hWqOvrtVnjb0L0jJk5jyVyqBfL9FuETLi/tO6wYJd+XVouvVSxdFvsHq4Wo6WfqrSVWyRSSmaNA1zRxvZygAKCOsqA0du9k0GkvNNSs3XvTnlLdrnYm7GVZRdS1Ac2P+hvocmqgs9PQMVLCTDYG8YvzWQi29Eb2dqSqrZilVm6UjYZB40RWHhe70+rkvBPOe58s0/72oLM/e7CWHbfvlnCLjYQRB14TXk+qV+V+1ib9s5YfKssDRM34wKqR07FT8RH3GLhkF9jSlMidVJ72LZ7uDLgFLLovh+AJ6+jAioRQeQzdIenAsJdp+Ji7ICCGhLBXiF3yy2GlUMdmxcPWmzbmLRgmZTMsePLHjO+3HLNs45vRxkUc3FlG3Lk1iyy6u7ysh4H7rNP+7izcpnXkY2M+povi7LTNRvYRhtWvjP1ySEKxs/27InytyC1Wq5Ia5NeV8ezx0JYgEPMJ1Vh8jPq+0cxWkyb+vZXm42V5nkCjqNh7zxhUerkoVE1A1jDI1uo3iwGi3t3Ndl6/Q4Tz6LFYbzAUpULDPp9UlKuX29/Mo+mk7nL+hGxDJeOtUvS2M5mdmJzrtY3Q8A8W9VWjXf0ydiVZVyzIvvtlHDYvNo37/RMNukzXOxHBW1oe9dPzq/LZTk2PkyjyfRggpHf43RfJBJ65qpR4rbAELhlmGJC9GYD+35jDJf9EG+MAMIxREjh/xdCQGU1yhFiBC/1IWcZTn3An8TW3mapTELZRUr7uO6WfD9rqzdsc7obRmIrQIrxMKTjTCgCDiT+aLlslUTpvUxXxyKfI9MNNpJ1jIxlK6IL0t93sN2phNmOomT959lDYCJoYZUQSL3dbiQWonChLLWdtETm3VkPcWTjU5lN/BVUON64u51i2hUC5nqRxIOj6jfKQMQCsoNHlU/YELSzD2SNNx7cn2T8y2SqLDIVkIqlDwiyN4w2bc3quDG4/8gQEMJ+QtwH8SKHcZhvLvPSkhduwJqvLsDxzDArkeS0F+9otzF54RIeqItiPClwZroPI81H2XZEaZdUO6CMo2Ul4i0pEb1N2GCiXF5d9TBuAeuiOE1rxGAf7+Wbtpd8GLdp6xD30NFApVZTorjivCFn1T3XBrlkGHKwyzldVSC5BEIsSiH55Tlt6VBNUG1wGM/OrZJQKDbbNknYr16vdmzGX27KktI3UeDMVLHAMPnM0znmVD4uyEYbyzY6PJTJ4fRNPmDNCo6UsJjjxJWjeSx0Frv5UNb4l4ND0BxG5mMEKdLoM4g9yjfBH+wuy2G8FKoERuQX0v1I6yfKOoiHZr/4znRd3rVQdAyhYUKRQ+qIiMwn8NyXiNQ9hHO/xR6VlRCixbYuvLQoWQc5GiX8iszHs16eMuLBkbxax1oXQUBzwXC2TXbEjs372+KgL8LG4iKL38Z5P4FJJIAmBRgzwnOMBVt2OMDzGTt3JXlVwo+rrQ/PtbojqvU0qElUWYmnhbOS/c0B1vPuoDtHRlAoFQm0a8zcFAulM0nOC4eE67bZ5EMZnJGf9ahVKMB6tG5AuUCgUuOJYaXTqTY2NArKSVCl3SGV0SMgCbyTyZYHchy3TixNjNkU2iD2Lsr6SySc/oWdijgGXrq9v4XVBE+F3/6TY8VaRji8SIUzTEBr5kkJG4UzbtwcXUp8t49SE3vH+sXZCxCixs7b0F8HzMzAvJ3gVxQvZbPrrUx26Vu+1sdusNofYGDF131PoP1QiGp7ROYdWW/NClVsb0TmnVnv5DzeJJtWrCPzrqx3iq5mSu0VKqVxnU2r+lj7Vy7BW/EuUxWhTCnLq5aqHbnZEK+gx8yTCo6GsggcO83VU3KLtcShUNa7ppcS3k/hz19YEtNPZ811aMOzcoEaBl+/j+W4TggiZEJZW565IaWpY40fmQ9nvRvnyL0T5I9kzU2SDRNW/3nW3JzMXEE34BDab9mbIMvNcYfKri0O+n4ixZ/L4pbHwwsXdkFBsZaF4vdkvYdcGB5jHLwv693aG8kvH8LLNfNQ7QoscvJW7cPdhx2HWSyRFPb3Zr2Hd93ycwR+JmseMTjWPnh/1ntkl7awSzpxX4kSrEk9un2UrWILUygi5PGJtkzczSToo7Q+OibC6YDPZs1jEXpOAd1r4cLBBbu/4ZnHIabpNf75rHn8WPAy/5WLPeVTZJ674j0BSo9dvl/ImicnEunGVBkNxNUraXN2DzhqJd3rjifjS7LKtmKQtZbKUB+wETGYyLIJ27JBiXRyGMWYbOW+MMGLtERvWLwsQAOxDjlL6E737z4czC6lzu6W3N5Gh1g0mmqnZQ+i5T78hsY+jmIwWBAYjuLGNegVAgkvTNkA2Y52Y+xfYWOTUktglKwQ39sdoTXWxSV3uxaKysoGLgusgv++xyJFEVmXT6Td3TdZwSa1dzfYCufA2/j0ajvYayOIAg4qcM0Gc1LCzLzJ0FFRLOcsTpFcOckT2e9G8zZaisnph0A71GZgB1NtnI8AbW1RFd+4vrizwk63IIEGogmoROfSgBT69JtjxnQM55MpHi8osi0mF5GQVwA4Ue7a8fsRiEmBDu4Mo5KoDM5apEViLjueYM6l6o4XWJ6dExseOmLFQeOgpEu6OJt0+z2oNH5uqXlveSK+noWnED8z32A+p3HH5jk5jIB45bXSYHtjyDwrJ5cBOEwpRHC+Qy3kyEWTECkTb2AkCbAoE43/xLnWY98CQvdKkkQHUAFhAlozT0Ank2CCZXhs9+PoYKjFjPDR44XUmdcEnq6xOP/FrJcdCqkyvmPX5JcIKwqGUBeRA345ax6lYmte7Hk5SRW7EduN3UFulfXfHbmNL9/t9aDVZMxKJKdIIf6VLVmN8x0Z5veaE3G+hAUMBQoumrWp8I3xZc1JTbplQhBcs+tJXOkK23Gre2nEdAK4MlpaqXJz7KtZ7yoZjx3JYh1+LWuu3gPTto3YMIxrFHsV6WZpY2Ndah7OI+HPuDdi0yZGL4YdHL5WK4qyU916HeLJMQK73Qh7cLQ17ste0jtvnp/zblBQe5AC3bgbyx7qM+fdNIvlM5TX4xFzd7yYNzdrP0Wmt7ePC0oEbR2C7dBv0bIKcevJTPn2osA8aCrO86Vxr8Dkoi6p9uDk52BUDsW9EBX5EJyz+SX5dEJ1jDXSHdUgiRE8tDcaTnfle7vJXtAenONvZN6Q9x4OdXDSqS0UrEz/CzggwGloD6ZsuDCpZOcSZI+URdFh8USy8onmEegeo58Ea4kN4hwBNSbo6773WLqlbnsAxtmgn8zRx/PmcTpOJV6H+bycefxk2ZBByjPmiZVjaLPxBTfzRzTu0ZLkDp8v4m1hSW0NrNraFhaZF+a8jNw+Lcg3AVNdE0c6B5eRi/g1eFCWh3t7pf1DCfKuLVChCz3Pelxoqr79wd8GxSxbbFJ1KquCKWPTbhllba7KIFnIyD+8zvUEe1TQ7/UzC519hFJAdJHf7XKsi1TD4s0hS3/W279EF97K9HLY6nGVNxiQiM2J6fHwNRmfTo/xi+1Co7TJPooeMw3cAXeFJiRgrrfiOWXd24uXrJ8fM96YHfTvKfdFzcCQPcu0yLwo5wWSLQpxUi2zK6mWktNYxpCdHgfNSXMl8cU5k5e3COsDToYUYvxCo1oXn3mHh27+ZpvTCAnle0nVskikT6ib9KYNn3qzuFDxvJRZjO1Aqa1Ac6NcjKvoj6Ga9VqzIOaGF3balkV+oVYtiBdjr+CQyHDE3JZfPNVrINm6Xi/KpS8+5u27AnLhkdyK3PnYcXclV6uNbTBKrRPK/PVqpVbeAaSdrHFokGROcljR2mlX5KcbT8UDv6JeaJCSu1FCYVJZfvVWbo5cdTrcaW815D2zpOxqubKnRyQV6NLOr4EeQXcthyn6A9py3b90xhZedwQol5PqFXnhgVYyiusrBfcmzg0xP9sDG2Zc8PXKb87XhJ2Wgdk0A3NLDMynGbgSM2LVDfjEMQNeu3zAJ4+MSYGnjgAvG+gVyUCvjAdaGNurLsa//gHuZq5xoMPicTkiMl09Z+foPYNJP3GXQvsmO7g4nbEToyIt6NXYJAfudqR5Lcsgcl8Hs5CPeZyBoL1D2ZUt6HU5syodC9ct5PWeOTFmaal+LEjHFs4p/xpnTinIW3Js3zO9SGwBb8uZU6hsXATNvj4nH4uQyw/9EE9qfC7V9l2cHY84AbG512fNVc+I2pzoDg/kx1PiWm/NmaujxY9txeN4Z85cc96FtDoYOufjgnfnzLVLBS054h6gRG35p3LmOg4NIMXmP59DEhMe4jyhWrEUzHXy5lVyt26rKJPrsh4rt1nbrtj3fOytH70N2FLdF5SrolhIZZL30rMNZElzZHKENMKdDhqTTD7J7DTbSZWVjXaFxdXWAvKr6Xy64omCBmvWdBmcpBcep+wCqa4LNVfQqlFoS/JK6NXfo96pNZtn9HLlVY3KBnhJXV2FivZWZ1NqXhPLNOlrF9xBMw6STMKqV+WMfGfUgQuzc4diaeqpe6Ip67FE+nJFBel2F7XehzY9xwZzBiAuYKo67pFWQbHnFi/zrCMFKrog4rBIRUqQeN1oXZaLpH0RHaoLcUIFISkRyCNywEGnQM1LWHaa6sTHYQLyu2p4DPpVKRJIrjvSm43QHmDT6CGhFrqDMzyeJbA9ZsubrMUELevSP5B80pN1baxXW2b83jwuiQ1W1EBhWFJToIUhN8WVCcTUdxn42D2c70/seaI/TTbFqm7Z6psuFjFtsdLgogRyOxMp1GjrmITWMm+Ge0OxqpozmRGG2ojLFINVyv7SS5Tu4q6cird2ChTYHzgXqZcPEWg7jDS0ljM2lVb97WpN2YNrTQZzwf9y3K7TS5oAWRhNJufjj8nJnayFxvHxy93lv3pa0wDyVbakpCu2JU3Mh5nbpWqtxdvSSF1lbN82OW87uqA9QGOY1kB0GeNdQuVo9Q/SwGrfvB35nC662RakRAtZHmfSioqaD0BwIRahFotMT7seoGKnHYbgslcm7ijD9rnk5PoSwrSHLeNMc3YU4t/yDYI9E+A5dGf3AMroukFAZCtAWi4IpXLHx+sD6LjJ8SFieZt+RW6xdMOBfjNVQghK35jhCQdxuNNvRQRWVlOtqvYMz8IFBQAOSeIa0tm20AOHPWqoW/HBlGpYVKhQKpN4IEjKIGEeF3VEIyR6KZQPpWG+FeTlklKzVRGx1bcb4p2fLMcqy2+wyp3mzubiTc3AvjSZESwEya3GV/2pWXK5cLPQSnLWGHGZFbR1U38se9WmdmJD50Rlfb1SoqLLr7l8bPWcXLxZemrJ2LlCc8krqldq1r12ehUmT+ol06trhO4Zm9wEtkv6GjFg9LJyCnjtApjcdL1O0bKncBLFxiiDvp5dshFyqCDx+xti6V5YO8s2DacdKUsmWQwKULkyQTx0szB5mQ07/OUGOrXxyw8fRmQ1pWg+woTHdTuy0lrxVqDF7A8JcoNlbDdWz7oLDAzNVuGAA5hojsPu6HhciOX5dAHi+27IOLJ2z6SrpNq6DSepR+v30Pp8ujowMC4PBd6msRwogeZjND2C0Hz8aNN0O2WW+QTN5sKSjz5g3W2t6HvTGMCBAYuwsNyZrNGpS33m8mI7V0cpZHgy5JAgNmpZ8IOGHQufTn+8DYHpE2OgkCQjVVAAeWOrVSpq1cEQR6MfKSYLNp8Ftf1gnwO8esX4NmnJ8Qea6cj4vw+LRnMW1edgx6IfOUGZETKSQG1ftEt/cQ/Vj9MoGFE0QX+Au09BRhMOmrXIxfbM2aQryPdmBFiI48zrEbGUlcs7dbQSuTJfgLFTdkK5Ix8XR+bLx9Laoh46CQWFGJuF3vB0wdoXtMn6qfeyA339mkTmeHTslszhAF0rmvgrEPOA9SpUEoU8JWu+xERMXHkkg/BL6GkiWvPuxRY7lWxd9H62UqRvg3nbburS9IZNUTG+faGji4kkb6VAwgWdoz3jyRsX8l1xFrG7GF5od6olHYQXojntwPxGYZtHgFdmrfRN+axRdvMO/uY27+RvfvMu/q5syueLVjefyt8Tm3Iu2iK1ltxKP7nebKI6SZ3CV0BHhCSvkDpXbgr0KvQGj6uXLrVfo+/PXbslf6/DTtrieX2tyt8bygK7sdzh701lGfHN69WNLcVxC6lSoeUG8KA6hxg8H4yjweMh4mTeqkemD5UdRBX2w8K6neyHC1WPYLoFzyPv5s+jyuvS+tGFYlHIfIx7i+Wxemj7uLYM4PHOdX2CeMQ8n+iOfJ+Etufx5LBQl2rfcqYodH4r7hGP20Jl0O0ymDsEcKcM7q66fRvlKcWyFDy1WJaZeVrYUr/m6UrCt53Vx7e3qqWOHfB3hM2ttr6a8p3Vuoznu9ym8t21QrEi4/qe+L267y1udTrKl4J9tYlUUeh3LxWwq3fiySuTtjzEQb+nU8CpIr3e3OpYXBsYsXhaOpOb6sSTqGp4xe4Ap2uVDfuC2Rnx8WQoNdkA2xNMKfMDsdw1MIl53FVotfSKpe3z1mL8lb+SmM21CvMPDcL8srM2qo11QVBxo113M72ByFZx1CyeTc7sbaoaVgrtkrywczr9+tephdw/lN1yq95IhPaRHIdxAuYwPapclY92NJWGx5SbpS0hifRjY449SVpaG+DJdia+xfH1NnkiVkLn7eyUQsUdOKDS61MQ/RBMMcVPa+s3657OI0b8baQFt1L17R13TPLdHeI9RRWyQjKvXmmzUjpTbMrL8L58q6JUUdEOMGVEtDIQveUoycbpVJtcDBMDTtibT8RgJZ5w2+dqXONEWGo3a44SIkHMtaSuCFvVRkLXlVDN42oeSLNK5TUiVrbXazvtSkV6JX0d811sWvj1MgKeNwj/LOhGIZDnTfK0fd6slMTMuoUupDrJBwlang+Wp0P1EOEa4QeSRXS2LuQztabMVq1eaN+9pS3q9m1HUshZXcfT1NrlasFWbiWpu61gWfJOhnrvmdRVS7rsYQuV9HA3JY8oswQd7NGVemsTJSs9Pm69opeSHo8isyv8CayjSrtaIvlEe2XEtvrWeNndKfKsJieZp4axYvsOlA2TY1+y+05UTqWdZL+LlsLu75Hx8fxeLDiN87VF0pDindvJhHHmDjKdOHMnma04cxeZ7TjzFDIqqpJ5Kpl7JKM03ptsAffJZmKn7p8stprvk/XrljbZfyrTSKzc8ur78SI2VKvs1I/8IAA+bdQvjQZYc/LxLC/xwtlMKRywn8qm+xyOFtJFFeDss0HsG+4JnIiD3syq25+17V92AhWUxAxvua//Gz9sb4hYm3I1bNXkg1XCGq88OeanAliCxI9Koj2Ma+YtNfNLx/4aAXEFqyGNvD+w02kmLw14mhCIlADwC6jXgvv+XsqVyC4FTiPKxYqSLM7mkpsRDMXPlHSWE3KtWJjNxBgT2JqXXepBDCy1AU02FXtG/Jh9El7skfhVndLAlsRvsGUuw4XZMxd0L8w7l8S8gAlZqhYxdalZfQmzell5hUKm1u/GQIbp8L0IfJtdDiRTv0oRV48lYT9drhcmNtMQWqQIeCkEVDh0VOfYxagGcZ4GctfpldSJ3CejI/OKvOdXkhoOTCt1IGzlMXJa2pejmnWRSit9cjiWaiiooSPS56tolBQh1MrFV8PFUde91T6gdHEwGlTIamWFpE9JcOhDHOBKR5Wpt4W24ekndz+C5M5Zhr2gs1NoiamSbTb0FRGml1xO9vawsF0hnS9I+Upopdl6LyGMHIDU6jJVdkY60pfSNetVln7iHSHAOqhQgLmgZoN35Dx2nSXnQm7Jemm10Wm6XXuomWajbDP+Ei12zjLEdUYSGbsSr859s11zfpxrMDswEh+LjHkNIczSAxwNs96mGpgRYZKplPCijxpJHZo37UnoniG2w3FuVU7u5Nj5gc/YM3vJCF9HpFTfN40/Sa9Q9EsTL4QBmlqVQ0cdq+d44S/VR9rO26DdXFq+kUWxKHcL8dxgzKGmjAo+UPM8zd60VPFM8i38jmBZ8L24Va2JJOzoDgjA072ZMzS2dhsBBXgsJtu5JestyG8L1ouTE8pvSaJJ1YFD9Fw8SHQNUSASnhgTPH0LoScb+JDrrwsMRXcZqSP4EWUJNFEJuxf7i1iPtPAK5W1ObJXaBVRuCC/wxJSgCyooAtEeUwcyb4NsmXUJHEfEjL3lpuXFD2L6QdzI4RGF8g6W8m6azLfD9CTW3QAxOOE1iaKrxh4o70ufN5+k6+50SoTSvI9W++I6mveza00R9ch8AKFVKTIfRILc7UtiB6NR96L5UN7kLEhdU6HXfIQAvL3/Y/48b1YOujO2QyIeebPao3/zsbx3IiZCW7lxOUddyU/CA8kZyKrnz5PKZRcDkL1H3X4SmcuLnc+f1SoukyvoUBcE6OVDhEPuq3FsU1BF0tnksIY9Fu1SbexsV/Ubpn4TW6Z9GRg3XizZHWvpW7MkE7/RmtqRM1Y3um9F+G73DXQ7JpFZJsz4q3NH23uYoH6C573M0WS+P5jV5OuPaItgQNScgcSjN+9mxhQWWq0TEA65yHpfqpETUFIhPx11L0VNjBaUxkqScTxb3RSZWFCWmglB5UUxGr8lIvOPqbguEvWPqRiqdMUCt2iR6V4cRub7qTodDPrMP0Fzy/LORO4UMY5Ai9wYMhZRR/oRMY0xdRyTWfMiAEnY9v+lCByP3Pgrc4f/w4xqadqODDnY48ApjIedmctNJ5vOJtPBmHJJRsblpSaO/B0y0JWSrr0FCQGWQjSdzOX8IX5D6l7Sfk8rblgDJqjbdbpol1uSuQWfsTwOR/3aZDJlFxStNNDfUFzm9nGVXBn73GE0aI5VqASQK6EWFv36PbLpe7efx/zsxfkWyq/AOaj98BRKKeP57Kmk20fvPfkZjNQ+9gkbEczWXyyJ7//1AcoMpIGx3U4h88HYJ3qhTBFkaqjKmEZVUcaXC+4IisgNTz9dg77nUukTMO5Qr59ydIhQwmd097g6bgzuP8s54ETe78vAGD0rqfabhH9tuglzJIAHMRI8tkAyH4cZcTZV5xMehhHj158G2JZymbiCrBEvO+/K9/6Tg6KDoSpO+eAQarM/2JNf8tpWS3fVZI/HYovRwRbVBc0iDEnt0J4ZJ1+Jm06ieaRvU5Lz77dHuPQ6nHdHw56MOprP5AfsAGYvXNYVUe28l0uwr4svpF/rHcQdMHaZNKbK3+seDJFBtbOgIjKfzXuZFE4gn857WaROcEl4s2d/qBEyXB+KAQkS5J7PKaKFgFNe60oydryh9JKurACKpW6ctlVtS4VFSYs9BTYkQ5tICm0Z0VrMdW0YA+La5vNs8VrVfDGuo+ZuLLXGY5H0B/pOjVj93qIKWBDnC0PHLy9i6FLFj1xbgtp5LxDmaCOkN9LXnLcTHuPpMgLzORrNHGVfYpEMLPqvsOPoJdgOrRKnTNIsns+IxDpEsEXrWefELF581wAQT7G53R7qSxwiyQWdJgHHHeIkm+jdMqEngJkl4KJyVgwdfKH4FYuOrEU2YPEW6sSi7IolnEnspFPgjG0B9CTSk8r71nNJQdSKSiFHyQ9Fg1r78xvII4Jm7wsE88FF/Hn2Yux6lIhc5SzITYasfGipxJYWmWeveDnJtQcRy5CQw4qXt/WeeheuxErcW4c60gKFPndJ7UO/2dRgRkj73dm56HSkjE7I7FBukX/TpjOtcrRx/I4CIjEGJMM8sMPWH0Tzh1Hnkh4YsQGIiMTvuDx/xdPXC0rgKKG7wS4CYDc1Do7k4r+VtTzyeHhw0MUehor1BAfEjrtKGnKtHJSbuHRYHsSffgkKVYtfi7ERGKGLBawgc6JHzIs4hLqsWkfqmPSppHMEED8JcGPG67W/ajkEeHn7RZAET29xocyLIK0HbTJyuSCy5rm2dYYPz9oaxFY5BO9C/kir3PF08kbKjc41xT/szRZHV3BtJshezPB6ljDzghUv6OlWqLObSdVXUcpahO4n6nzvwGImHrIiX9VlY5p1nN9qGfTE0lZoPyFhOqyxDqun1dQojCeBYfxujm4tQLzyTkFzO+HdW8T9AcLgBNhqtjkJq0rdjAWDWr3NrM2q4Z1bL5QqRIXOUF/x5hNASb5fudPatJ78SgKvbOMZ2lLgqwm8UAZH0ueJNDwhcI1gM6PSiATVNVRxMh5qcpZwammwi9Z6mXMBT/V21XJJjTM2zvrUa7x6UdRu4pBWFv1ckxS504VF0bWLovISuuvSBQllnHctoDAGbOrj33AvBzFbxcpOZ3OrXmwUqgK8MQYmvd0UQ3RObhaGlDYXxbdsNJsbUEfojiCtRnBszQfFBYU2prSCHuxAdZaUAh4SA5rFxeBt0a2uKDxzLy4V43Pwh5akh81mu3qf+NZCM4FxQKmRPZywDWKwhcmu1y0APUJ4r6lHul4QMwnnCM5HORARYmHYo112q8YUOthjGnK9pFPYYBKTmX1sAkzPwuOsCHNeUEsk8fH3NeUjLIXUC58c9p3pIIJCGNknLq+5sm6bdhd5GfpL41hVzN6ZfFibkqGmCfaxXFOFKKFYUQ4FKnfpsA/w/6YT8KJ1O4LSBPJTJHRripX7qkqiFwrXJPbmF/XgfpOQpWzzfmZ6uxiH3vT2Szz86R2SC6Z3SC5zZmDvLTQhXvGDm9AfaAwMqVV4es31dQvyO0P7yZwWgSmpbInxC8WQc7NOhSqmXZHzcQ38SexGX5YM1dQxQZOgCnBTa+oHbjzWMCcrBUv1/wMDGgAA3Vp5eFXVtd/n7OQSpiRImAlcEJF5DiDcs0+YBBSQ6aGMJYEQIhAQgswRJAyFiigqkyiDoKggoiKa3DQqIhVFS1MRHEAsElBU6kgRfb/fOuSc+L7X1/a9/vX6fWEtz9p7rbXXvPetZdlKq0qvltx/IqHyCjX2rpVKjY+f1q/n+Cn9bxvetmePHjP795rcYfjUW4eNU1VVkrKqqToqWTWwrOTPG9tW8oXGunRbjIpV6voYy1J2jLIsy47Fv7Zt4V9ta9VUxcRYStkqxortOXXczCkZ2TkqZMXdpZSqxH/wPw9gB7VSDVSMHTswLTMj3Pa/XViV/yZgtbJlfUOu75udkzE9O21y+JbsyXPCPdKy70yboULq7+5eBX15DHKwILFy7JCZ06ZNnZ6TlZ0ZzsmYnaPewhkmpLdJHzeh4/i2nTtOyMjolN52XEqn9PEp4zpMSOnYsX3KDW3Gde7UttO4FGVjRdsubduBd7XF+KfG3UoVNVBNgC+0mvafmp0zI2P69LQcNTgjc+bktOkq+NSy9FMza0jW3HB61txs6jB56pys2WlTsuaOTwvfkZaTnTZjYtaMieGsKZOmZmfNScvJykwLZ2Smzcia2yo8KKDPHDdxZna4e1pO2oQZWZPDOTMzp2BNdlY4fSpApqqEc1eAN8qrcioOip61rWVKrVuiVNjWllr8xME69jLVeZnO/LBRKIbql8NRTsWqUBsYPG/op/1B/mKCJqUMuU1oFMhLnrwYsvOU2qfxT1nyqFC60ulwmAggQYFjbp9PupSH3y0bi7oGFCu0oDCnKik2KAsPBBQ7lPvWllhStI0PGQFFhxYU9K1ESgwpTwSUmFDu0YYjSbGgW1GzgBJbRk6eCvcPKCFfTiwoC1cFlHKh3N11R5BCbupMQInzucXaS9QeHVDK+3tCoHzdKqBUCOUO3T+GFA1K0YiAUtE/TzlQFk4KKJV8OXGg7JkfUCqHchuHupFSHpRT2wJKfCg3blE1UixQVh8MKAk+twqgFB0LKImh3JyJVUipCMrASwGlSih3flIrUirZS9XyhIByTeiu5zclkGKBMrttQKnqy7FBSewSUJJ8W1cGJXxTQKnme64iKO/+JqBU9zXQoOyZHlBq+HaLByVxXkCp+StuRasDSi2fWwIom8vYrXZowezCR0mJJWVPQKnj+5TcUstYtK7PLRGU8PGAkhxa0GffN6RUAaWoJKDU87nRbmN/Dij1fbslIvHm64ASLsNtmepXMaA08LlpUOpWDygNfetYoPSrHVCu9eVUAmVdvYDSyPfpNaCsbh1Qrgvl3rivPSlxoLzfOaA09iMxFpRT3QPK9b5u1GBPmZxr4mtQHpSfBgWUpn70VgRl4oiA0sy3dQIo748LKM19z1HObbcHlBa+nBAoj2UHlJZ+NlLOujkBpZUvhxaNWxxQWvsWrWpLefQ+twnl5rop/BxCCVMpAaVtGSGLVVHfgNLOF5JIyqmA0t53NYvOqVYBpYN/GJaw1EEBJcVPqyRQNt8fUDqG5ie23EuKBqVoV0Dp5B+mGiip7wSUzqHc2+/bRYoUg+SAcoOvdQIoiT0CShffBSyIiaMDSlc/CITb8oAS8bklgpK4O6A4vg2qgDLw7YBifG5S3H4MKK5vHabiqZiAklqG21K1MCmgdPO5sbSEmwWU7r51qoOysF1A6RHKHZ94Gyk1QFF9AkrPUO6KbmFSKOfQ8IDSy5dDbhOnBpQbfW4sOiV5AaW3v4e6Ld8QUPr4utUEpWRrQOkbyr2p0t2ksFDF5QeUm3xbs+yVlLHozb7nuKfkREDp5++pBcqhCwGlf2jB1fJKW28u44UBvq2ZiuGYgHKL759yoEyOCygDfQoTbn+lgDLIPylTviQxoAz2ta4OysQaAWWIb1GmfJOGAWWon40se3VbBpT/8Msei0GSCSjDfBuwJOf1Dii3/uqkQ28JKLf552FB3DwkoAz3fco908YElBH+HtqgID2gjPRtEGPL0OV9HuV3uDgWnZEBZbRfj1la1ICAMqaMyvhwOKD8xhfPGehUuYAy1leZ097YMQElrdScIcsKJlx/6FX2XemJnXXSPGNqJtqRB+KG6WGNGtSas+i7ZzbgGrE5pOKs8nfhtlAhXeEAXWX445iHgQ6VqhmHNI5jHLww+mgOUxhaRnBAwn/P59CDCnAQ346hRlxCjiRwDMEg0AW5fBOHCI4L+O95SzECIE634W8PGzjox/GtZCnaLxst2mNFRER1wNpoBvXY+tBiOrOdsXGxRSHKRuDbODYYthKsm8P2QOVTUML74u8UbNcqj6WZRZjlFoUVyiWjvPXA32jgywF3A74N5X9cikKF8pIEhZoBtmNBQaoNZ5FAMubhUBsAty5FMgO+jb8ToF/AQX5kejGRmDJMDihYgwGPg7RkEDNcGZjLEIIMNoYVlR0JCw/A32EoW44u5TUBFyZroWVtx9j+pqUOW7G/01aerdba1tVbGezj3Ry8CxYvhIrYShXOrE0k2a6vGoOTvWDr3HoLUk8PXlA79WESNP/BhdBSX1g6HlfLVvafrWP1Nz9aK4pLCMKn9kncJeu03mR2bDyQry/n3i7IwwfC5i/bN0b06+E9zheDOjtVF6c685J2Oza+OjMmVjH6d5PPOsurH3c6tG9vhn663dE37pth3pud5ZAZof7wUqEg7/7wJ1Nu0YOOfm/2OfPFoP3Y8o25svOio7dPuwJKNUMIKUY+FPdPN+cbXzRTzs4zuvvYMyavaIVZ+vkf8Xef0X+4s9BsWL/ezDm3w2R0fdTopqPuNW0+esw8t2mqqWw/ZTRUNT/tfNbMXFPTLLy9wOhLQz51dPM3TELLvc7MNe8bPfWaxc7l3POGcNGD2pUPaWcS3Y5jXnamnK3j4izfYMv17vAbOpi/Hm3p6lVrs82kgg4uJRFiy2uCPHzglBmQ3saFYj+b/L4t3JLL5bGqkWuT8+pXq7mw4dfmsWnJbq2Y98x1oQauplY7NjZyk0c8JlA/UDNPkNSUMQZdzNWUS0VmFdY3p+cmuTq/byVz6pbKLuEDNWO8D7RjxWPXmswJnxkwjcAwx82lIePMuuyjRh/essQ81OOwoT8Ob3nd6EkFzxtLFZmdBw+bKre9JIYxDfbsNS8c+t488tXjtHas22rvJmyrCEm/MxqexhlmGsLHpjneh36dyps7nAouXQk7aBcWd56dXgJdtkU0RTKEKJZQvYL7f17Rmw6iTdlEMieEXHteUivofRUBxSMBotiBOQ7ZyJUYI9Ll+UPOI19d7+qSyzudJw42h5F3Oucbt/U+tFjWUVbsqtvF2/LiN45LHoSaoUzk9XAb03EMVnw538WJO7qEMyaCBxEy5QqR8sqbDUQ+eRCqWcpqF9dCtLOJ8MA2RJo+n/zN2APS3zWr1n5p7B0bezo+Ioe7Nf6Cd0oiue53xkYOOE1HJThYc8C5svMOx35/29fIhqsIJHgiAGEJ9T0eTR6bFqVp8/WuuhsEYWZ8e6U4ou9+sIfJum+K89m7DcECCXVTJdts7dXREH79+FIjH+hirkg7867RUA2p8pW5/8J88+X8X4z+/aMbTLXd5eDeqEBd8dinglwXstwXv7li9ID0RJf6L69ey40ddsTQPu5zm54xhCKFCOOPK6acvezIlutCixzyyLrvQkSYUnVKIfwvIUEHSST4CBfaDG67+TJjV7abU5qHYJO3CxA26vPJy2IEPeieY4LMT/rSMC70n/rbbkbXk85r38W5g/fXM/q5TQlujeMDYIAET3EimRN2GK548ZuokS3lFv3ZkEdx/9NGmNJelEKoU1MeEYR6yYpneqehiP0Z9r4R6oPHrfEt4fQdhlCkEKFYrhA9uIWKkYdoSqZUnVII1VJbWVPO5osjdPmnPxSEAbS7t+Vqu3k5d1uv7828pHiXRL3AreayIhF+3+RhYxOBcZTN/AT0kJlr1rH6aVnLcJNy+JftH0j8LnBfEKi5jAjKIgIHR/y+yShDQzB4Ov/2FaPpoXZxT0OBVihL9xhxGaQEfhFEQp8u8xEKtlnVJBir3HaDWBrhb1g/9bdXHpCTlh5d/Yzu1H3sdtSsmwtR2RcKwkqEKC+UMo38LpxV+Chy6WJUsgtaRxHVtWHug9Glnw+CQS9E9Uv1WA0rFrLmEopjidCXW3vtiyJENUtAlBAOchB92v3DncbY1F5OuWNjjDtyfL6H8KtdK6Z6gECyo4lEc9ZE23wUwwJSqB/56qxoXXoMZQ3e/wiTIKLf3zZNEPbQb68MdXT9JZ9Lm8VHZ132NVLVnb8e7Y9GFnGogny4cd9z3IaWBRtyC51FHh9egg3JlLajFEI9+t5XBUHEobsoVyNFYfKL4pXTc4uNrnE83n3j5hcRpPFyUPnAaOUKdhrZQpHk8fZb/Rxhig8RSiFU1p/6b/WCmT2GiKlwzBxt+IGj6WKErBk5/rKoqZNHxLgruo01hCKPyN9yn5QVVRcXGdnSYtl7hjwkBMmUrqIUQnEoEQzi3gpmGbfQbsIDR3TIlFCkEKFYrhA9uIWKkYdoSqZUnVIIVet/WKhA8UiASu1CvV7RbTNNkq8b7pkuCLs5gjCi8Q/D0+G8hNLqiDcZzYRSKohsrv2MTFR/Pfq2kS09V35hyANbeIg7xJuUQqibtD0kyNxzn3krmODc8sTBiq7wmFSQ5JIpoUghQrFcgS1eF6di5AGJEV1t9xuiOqUQeqdiadKszEQ41tFGGBrPSzV74+YfvPLGIsp6RyjyiLAicoWUSG5hzSQPKaJkSm8+fGCzQBmJiNA1soK25pZoTlWPB71JpoQihQjFcoXowS1UjDxEUzKl6qVnUctRZp+6eNRhXqKqLhMExnAwExTCKotfRpwUvv3WWwUoKIWsoRG0/SgGpTMRaBdNOzPQQYst1BhJEWOVC9GWBerYYfGojJULMVBQwygSpjsm2Teju+qOMMigqM0OXKf1RxF79L13Y9iu49iceplx9t9yK8BeQGKHrcLIuChKVTBLn4tyQMf5CnXk5C0YaNsVomKhdJpCtlwpL6XHUdYvxbMNhrcCqL24i7CjloK888Mag52OXbpGbcSUhtk+ghhW9guH7oSUNcYGCQV/kbEZFLKT9hRkQPpqzJvrjQ39DCcTcD/uqf/wAeWpf3ruA8iPhcZmXReGrKmQoOzUlI9BAsKiTjF2jeOrYKk7jJ9MvGuIPuoMsgr56W0gAnUckYcK6wl+dvoTBl44ThubjxsdpGmN7tD+OYkipj+hzpwwQZA3bu5kGOz6+rZxhrrUOH7EiZx8x9hY6lS2PzeaJ114+0+YDZqgwNiu5sWEiZZ2ZrVAVIvXBXmm9ycy3GnkEjz5AeLzilxQbCLQ2VMaEOMK3c6MQjdLFQTuNN3HZkRQdI846EgOu9lDPVY6HBMcupNw4D01ZG5wOv+2mxl4z1qHcz54FLGg4HyV8XeP0SPHdzXjEtdhbM0TCF+cCpBGH8wxNmscEdYaQVrtTYYJxhgN9QzDlHDD+lreB1RgtKNrDbVCWeiNzj0QQ3meQP3Zu1sF+aV4v7ei2ah3MAYed+gKmdheefMTSUJpuLwOMnmRJhHNuxQNUGoR9Rrc/Ezvbi5timweJEirvaNdGXpKLmfJ0IP+5g09g+6ZhaL1GiaTWd7QQwQqKxvmDBBOM0jYDFmLUoAP7xt9vvEgl21zyH4jUKedaSPI1483dqWflH+6rkudTYUargw9P+2s4nLoIaSxbSKQomz2XUAPEXlEKI+FTuTx8kf25xs/KxAfHhKE6SXyWBgoj0O9yGP5ojxCkUcEUoJ2I4hkGmcrH3mg5oEyQxYv1mynvMLKkPXkxfslbHF/E6hnFZ4UhN2Xf5gpKrocWzgeI8SM/ez0OJdJxbImjaZO62SXlx/cQ1uIm0r9JjcW3iHpUbk2E8FdjTkb4RMALgWLEFHbcNO+7HVA/P26A/JywRVy2+AWXj/Ig/kkTCmKUgj1daFXBGFUyJ3ml+IfoftXmFdjkK2wwbD4yi6vQYQihQhGSLwcxLgozw5G0UvQcApeLz7yopMugA75lEJYpgPef6FAkGjO/70Dkof0NzKlzpRCKM2KCELWW0H3e1v+jR3QYmlDKCmbiGQsrYZeaGx0NowJuIcRkYFn+A1JAYJN3i5A9b/xO4sVoehOhEMKV8jUwi3/s9/pIiL0mfidTqTJ6NW/7/cFbopEBlY6Eio0BGNH/M5ggg7/Rr9jlhO/05SyBXLgon/J796Wqh4PuplMCUUKEYrlCtGDW6gYeYimZErVKYVQWfQpRvxCcS6Lhfj940ZLjfiUNzBBpKrQ3T7i7yKiijE4VNu9TGwlDxJEMC0ZvnLwiQmtYD261afSwmwifFOx8RaDQnUVwfhjNBG2Dt7ZcDya93Z2Rrz4rBSIK9o2QXgB4rEwPBShzGpHr371BdhoKGaUHfiwuKtGixRNSlVTFlpqhAXXJiKHYbj5iE8ioqK4d3Iq4VZMEe0FgVccCoG970Db1fiP4ghWORiPpjiIcwfFdj/KWQGfeKRLy9jHrtfnk7kC5QxE+BoH3ME73etQvdgh5M1EPmA4wwNgPi4yqUYzgmmUH4dsw6Q1wmiOb+z/yCjy8i7ofABlSTtxZJa806FVLIS1zjg0AW6hj2O+uZdbHIY2NO3s1F/yFN9dHV7m5ANbFVqNU3L5nDy1IkUvG9R8jAUYgDBnSr6xZRHi5WCjILS+vEpyguL0x2GDvdpmFsKnbIiFVMbwQsYckP7Hl1EyIxT3E2GYIErYhT6XOyTh3Q++5n0YfsPzhjMbVYf8OuidW/muhykGh6J1lldfj4twrqEAvS77fsN+x1mDw7Q+ceRFDI0rDB+EOXhrSuC8u6LbKUk5zBnnxOyEeHv1PrDRskRgeHLklHT/C4f2wXOIh1Q838CX+YgFgf9Pnm+k0pPkIxQcTBb/+PlmE4oDCxLGWk6gYYzpE4194sgPXt4ltLzGKyt480AN2MhRfr24xy7d9S/ev63Ov7U8g9HrLBy4TD1pEP0UW8Mjla5Rx9GzGBn0GUqI5zzmEHL5n72tr1q7G4PuFtz60LP4+twu7guzuXZr+VEDITtJLPHHhhsFSnshwjsHmHovK2xztIP0Pb69sCARihQirN+r1sbzUZWNMN7l0EzI0LVxQUUwXkWaL3vI2OyAgjCBaQbcDC7jKvMENn2JZvl7g+vMaXkvwR4v3/gCxASkroTI2VxBnro42Fsx51xj2cKKIDyYkbx5EfJnGpsIcsSj4JqL30YSkZrJRuNRW1oSg5G1W/NsrJswr0CUl0JB2BoRB45+7bsS2LoAP0D9KC/a8hCH5Y7m6IkwxFXpJKJkZUSuYnReqTfVGkQeCg8HjnzIfloQLEUB6RDRy6sP56QXIYSWjnxgveYKvAY6soVVmTwImXdI9mJ5lpMVfFLnFkLhQYRMuUKkcAvFkgehOh+rLNYbvP1zRtotCL0DakTTzCg8OFR9lKZXHY1LI4xRVcILdYb5NVSaISGvtvLh94+ekBV0sGyBd6Showm7wpS/ZHGb/JLFVOMPV9SDED9//CIIfwCTFTdVauhyy6q1rTDjgwfmNPxHvFvcvztSG1Lem93XpVhC0YMIJXAFdGK0dXVpB/KQs5ApD0cpclqK5fGpB6GyPm7UGL8vxBfiGp0syNZe1TGQhAphqngKjn79eIh6R7HiCkz8fBQpyseDqIbdUZx09Dcv/4EwYvO3MfQbzvEW3mOrFvCJH4U3qo9tS3TRNKMsB3B3FBf9+lQpmjmhsUB2IkGend4HpXZxgc27KIpcFD8mpYpmpap67oQGDrLnB0Hw65gXo7w38vbOn/xoCvwy1hxXrK6onW1cXGKN5g9XfBUhFDMSYfRzBQurbOFYRh40gjD9ubimSympKfVcEYvrOc0iULMpEWEWywpmMbfUihkGd4AHqyaZNl9WXcq3XPMpllD0IELFuEI05RaqTh5yFjLl4ShFTkuxPD71IJQWiLCELkhALieChynCCHpUTZk80Ao4fTjyksFuS4hnDsPRzmG+23x/8RE4zqAuNIF6VaHAYFTJIw7CYQGbkMMndkI4/RVBeOsW9fiiw+xd/ep3cirIUwjM7pCn0AsWUt7VR6sGe642JSKwhLLZtAE9hIJtDjscuhHnl+W4nB4QgxEZ3nDC/NKjq4uwA5+T+R94eM0RhFcQxO4/22PYDrhC+gO38HmXPLCFr7k50lIohRC/8R0QhErxFzjpMZMKvgWPWHdX3RPG5vDAJ17UrNPm+yYfoqIfMf/x6Rmjr/3gJUySX7GiCERl9d7ZWbfZMiQW/vE1lD9acAX7uGz5Ve0nU5Z6SiEUsUSoByY5FtPTCNIDDjWVRz7qzjYvh8EkIyZHlY7IcWlUnp9QbUFb5+0RLlPykxAGeBdvkMWI7vau5mMGESYF6xyqV1OkSx1UhabuS/VivQ/syaPvbeiieLNJ1wGFY3kiSuLL/Bk1Bjm8BzpfQIbsMTbnOV7l8CBSCc25ALNZTTeh5V4a8Do8pjwOXVu4HEpQktthxXyEbzv5EVo+dMEP2KyRXZ7v43B6l4CDzZiU3iEAMd+ghvLRzrGH7P9YEDTlkEsE1saPsAUOsjeMS/oVbAi7h7f0YjoTWUJ/4MfNB9nHpY/i8etjxMR2YyMVA4QHtfl/ISAi/5cMInyTpts10sdlqBCi1MKEQMiaK0aOr+PKlrsfvBZV76hA5FZqgFBX9QPaM0YK6IjTEXnj5hqu3Bb7dWrqcq5HB3WRTb0QOC5+SFshEC+86wWhQeu0xs/7aMUYWLq6/H2Iv+rbvBuSBzu46bmyBd40tnDQdeVKGDnZWhoVIdycJQgeMFFYsIWnn3rNtS4hTyXmwOThXVLZUgSBzp7SgHAJmohcGm0iUjmYrz7ik4go9Z8=(/figma)--&gt;\\"></span><span style=\\"white-space:pre-wrap;\\">Siz bizning loyixamizda qatnashish imkoniyatiga egasiz. Qatnashish uchun Batafsil tugmasini bosing</span></p><p><span style=\\"white-space:pre-wrap;\\"><br></span></p><p><span data-metadata=\\"&lt;!--(figmeta)eyJmaWxlS2V5IjoicExEZG1NWFkxRENDdU1FbDRZb1dWYyIsInBhc3RlSUQiOjE0ODYxODE5NTYsImRhdGFUeXBlIjoic2NlbmUifQo=(/figmeta)--&gt;\\"></span><span data-buffer=\\"&lt;!--(figma)ZmlnLWtpd2llAAAAEGwAALW9CZxkS1XgHffeXKq6ut++A499B30bi7u5VVV25/byZlW/98axzMrM6ko6KzPNm9Wvm9kQEREREREREZFBRAYZZBAREREZRAYRERURGURkGIZhGIZhGIbB739OxL15s7oe+v2+3/d+r+tGnIg4ceLEiRPnnIh782cy9UEUdc8NOpemA2NuOt2sNnbCTqHdMfzXaJYrO6XNQmOjEpL1tsJKO5X3tXalUSYdhNWNRqFGKhN27q1VSGQ1sRNWBFdO6yrmnfBMtbXTrtSaBWmZbzQ71fV7d8LN5latvLPV2mgXytJ+xSV3ys2G5FfjfLuy3q6Em4BOhKVKo7IDuLW5c/dWpX0vwLU0sF1p1QR4slxdX+d5qlSrVhqdnWKb3kuFUGi7IkXb6eZWm3FUhLIrw067UqjbEvJXubwd8dXVRqfSLpQ61W0GWatCmGUNZde0K6Vmo1EpMdgUMTGF1x5fHNN6ndJDLzvVRqldqUNvoUapa0ON63VmoKuzFS56vcGNrU3TSluHcGPh4jBipu4hbQS3V+j1mHFADKW802xoj0YzZ9vVjuDxGpP+oLXfjQZUg4BCR3FRqd7c1qR3djjuD8fn2ocjqdNoNu6rtJsUmGZZywWDFanvorACyJSbpS0ZCkmvVGhsF0JS/ka7udUiEay3C3Wplyk2m7VKobHTbMHdTrXZAJjdZtzNNqkcg5ZnvlZVtCuVWq3aCiW5Coc6sEKF70S7srFVK7R3Ws3avRuKZI2uYEwZ/izqnexU7hGSTjGDJQFcEd5bLzZFkK+sNuisoVCmvlo6I6y6OtwstCo7Z6udzR3X9ho3MUrgtSWZmmKtWTpD7rqz1fKGLoDrwVWXkd5Qr5SrBRI3blY3Nmv8k+KbQhDYwd7skjswu10rSKe3nC2Em9WdDj2Te9B2oV0tFJX+B3dc4iGa2CnBD3K3xlXc8nsow9NF9bBCGFZDJnQHzM0tKXv45YJcqanUUfiIBJFQ06YQ4CPrzfKW9vooW3+DAnKPtrl28yyZx7BGW81GqFiViMcqa0rNOmCL/XHCwZ1WoSOL+fFanGL6ExRQqxbbBV02T9T8elV7fpJmGERFuP7kYntLNcK31AuNwgbDY61WGxtAvrXTLjTC9Wa7Tua2Uj3caVdLydzdzqITARckd5wOZZ3cWakXK2URlFa72Wl27lWm38U6YL2uV4ta9ymp0dnFqEN86tlKsUX/JJ92pnJvLNRPj9M7EKOC8W2FRrWu4k0vFRqnB/7tOjYlg9x3FKsNGEDXOvDvDPe708HZ4Xy/M7g4t4vs1vDurUK7Qqlh/t168BCzelN1lQ8zVOJRr2SDJFtunhWRyxy3NLKtQrtQq6GnUU91uGYlNbcMrlXWBZqvNDZ2ygWEsKCdr0gefbclmVXJOPJPaLpZQ0ORW4Mfrcp9TRWfk3CiXFlnYSvrS5VQVMQpJL9Sk/IrYhWyEzK1iu3KBFTfqnWqLQVehQxsoTGrjZYK+NWblXsKVgdcU9qsbLc1eW2LZg58XZNh26SsU6HshlZtS7q/sdBGnuNh3mRzMS9uDrfqdWjZOb3VYP0ogltUDTwobFUqiFlxq8jiAfBgXWVsLUhms21F5CHF0WDcr6MrhRxW5k5nk5nYEEFm823XdUP1yoX2mYqg9t0gZTEEogDRb0X2K7KZUrPWTHJZVSvaJheiwTWlKpMW5SYqifyKbRJnV2WBs55Ingib6x0WHjjIrW0W2qgLl9ONlN3FSuqpyj0l+GRHfsWmzvaVIdtSorqv0l5IXF3bglXNsNqRLq5pdYdjJ710h94AaJCocpVpoTchFYiXgOSp/GDPICkgJFV0PLAggVHJCX2GBaYjy7Jvna6SyG2jnmSbyqNyZDZIrjSaVZXY1eoBdlDY644GdkYwZNqVTkknY70qY/eQYaWgY2U5qOztDXpuFKtVNoE2ZkyBRUWhKbebrUXWQwNVZLdjWy/WtoRov4guWAYFVh2RyrAP1SsdVXxZRlcVYnMxsfmNGuJCYkWUQEm36lwTsURVCIVmq8X2ydOrNc9qApo7lugQsartlAotaZ9Z5FiV7ZJqnKwgLQ96k1l3PpyMaRNv4pCKkDA5pD34Uz1TWYisv9wsnF8S6yBIZrfchOmS8s4WtmVcfm3QFTOiMxsekIs7gZidzYqTN69xeLA7mG2Nh/MIZO2CMNO0qvdUaiEJj2FiQklNvzQZR/PZQq7yyBtwI+XKA69eEAXvQ7ib2CAsYeyRyKyDsbxjW2RdRmvnwvlscn5QGA3PjWmQIDMobMSJhMc+6pK+rVzqTlkH8Xjgjwqkl2hp36oRYaQMIrDZyt1b1ZrsRTqFGSfJojitPZqF34g8ajsB5dI2RH5hJezcTn4llb+D/Goqfyf5E6n8XeTXUvmnkD+Zyj+V/KlStV1K936FHe3pyVA4U8d6bAM1xcp2RUbgxQP3i5PJaNAdN6cDKxqMbqth9QNspJmYPKS9cKvIjqBp/x5VG4EIlTJ/czIbPnMynndHNHf6ODW3CL9ywT+9hbG2XlUKF623B7P5kMUtsGaLolTTIoLZrJPy65PDaFA6nEWTGfxgMyqgcSkwpXYzZC1X26S9yr0VWdyIHjkf81u7arFGcSy2SqwJ8hn2Fx5ZHqVqjVSuLnpcmuSZYlwpUivJ/Gl2VVa1KKgT2+iVyaw+nM2EkmT96fTz9DSBAkQxs6Gq/eSXu9G+VV1+CSMAkFlIuqfqzS6MbEstI3O6VZGnF27Lw2+VxUMK6q27eGQqF6eT2fzomgqwddlY2ILdwjExAEtXyfBiQLKE/Vr30uRwvjEb9i2SjF1mqRlY0OnbVRcs2rS68/lgNqaIWtWWrhh2CtUpns7v4XzSHkTDZ4I64ZSSowxK6PCSlGqqzuxw3HPi6JeroVi5gtPgPrGnk/BUhYUDN3amsh02nYLt4Any8EpIm5Wd9TYLmMkWzRZ0Kli5zm7NxGhg5nyQcDLRi2h33btIevGehSLp9s7b2czEY9pEw98Hd5UCj+0ap0TTbImKKtBWKu80u4zLlrV+EeET1UPaNihNDiFs5trlHqgd7HeTFBS2OiKmmRSqrKI6fRjNh3uXyD4gllahhHG7XbGuZ2DzxUrnrDVTMjLnpf3hqO/oybjOjMXoJRhjUdGOQzv9qrkB4qyG1fuwt5uoK+XsEgBpRTqq9RZeHzkpoY5lemsSDUUq2JgAxZ0XiszXlvWPtdrZmSh5Ni385kILsHFPW5zmqZt3asfYjg7ao8qYJU+3VjrW4jlHp2CoYDaKl0He22rrjBexHXgGpVpTLYKM+BCxs0Y+u9XCHK/sqLe5095qdKrqiuRYnuWqGGcqOfl0sx38Oqmz0iyeRiGzehBHqQqM6IviS2A7glDmHoOWAqqcqDLMWTc1iquohipSSk1hnZFoK/ZL8l69SUAJK520b9O2IKDVplijpDO2ABtKqmVtTp2YHLVwGNQKIoak3FopY1nzXKUMlytudoLsdtP692ukLU82VS5OJnmWPflTtotYxq6wWSIS29L6ys6sO7biYUd4C1YAHlNHHDvsAWEM1QzqBHHRJt46MSuevnWO19vNxGkKUqB4+8qkYHajyqYgyU6Va+HvWphDll9AYlwrC5BFtboAJJhOSFDHwhymtQUkxnRyAbKYYFMMSDBdYQllEqkUI7tyCRjju2oJalFevQRLsF6jPTmoQ3ptGhbjvC4NtCivT4MSjDegY6slhF3n50YsYAJ/Vq4FcBMeUxObeAG5udKN0AZ2xq8gNlfaKlZLFBhBHWc8vJtU1pe1YZ0TWshyTYoyUm8JkrVtl2A5u7Uk+XzYciGNlQ3Ek+WaAFZd1QRwwqZ0gbDA7epYWwZ2zooqOnkEuIm3CPhU2JtNRqPycGa1EkS7NfZNdiE4rLuDbYtKm4s2GPRRiPMB5ZV7WmzIVj+XwCCWnua8jS32L8+PCE3SGem88UYTzDVN+qXJCDPIy8zMqvHO8cff5U/Q5U/GWko0vkjOu8Qfvw2I2gvA/fwJ9vmTUUzhfDKlQU/Spm+8qdP4VLBdSYXt7sz4QU+yUkcTAntfzvipBkG9O58NLxovd3DbbeS9g9tu5+Ef3HYHj+DgdgFmDm4XYPbgdgHmWt0Z20F13B/Qzj93OOyb3RQVa8a3Tg+FF7qjwwFtvEN1gG41/jpsbXQPBsYL9roHw9El6nuRWBgkhLJ51JsNp3NygdSF5mGXJocHg9mwtz48dzhjLrCTXHjBIKcIAAmPqIzG7ElrN8tNw2m3xypYakuYBjNHtJ7mPeI/ziM/BsG6SIMMMI0BzUvgRdNYgci/CkS6dak7jZD+RRMWrLrhHo+dOOO3Kni4QnoAYCfJiaNBnF+SWUAMdoNkLoW/FfM9TRaOCH/xR7D5SCg9oTKZyUlqVVkEuja9cHAAqmHv7GB4bn++VIlosgwpqVLFgxn2lqos8JSw+MIxI96f0J8uG3QD+4qtGDZw1DdRZHYYXlN2Vj+G7hChtU5TrVZnY2VRE6SzWySS3x80d5/B0rB6LEOoMomfGsmoqcGSZDaBeA22ebRnXMW3+pBC0IquABbUJrGRCu+seoD7/PVElbnYhjtk8HH/dNdcH3TnKoR/57Xw9SkypTtadvh2pvxSKxR4IDPGUyeRZ9YdM+QIAIqvkm+2y0LrSmG9LeWr5YZq+BONrbrQvIZrJaH2kxghwq9TZfu8QnwunlcSy5DnVYWCunlXl+zzGvxceV4b2vx17W0NFl0v2o7nDeFZjTbfWArPyvMmBFjgN5dKGuO/JbR28oM2ibXzfLAzMB/SbDeEvltlwnk+FKNBZONh5Y5GMx6+XivIOB5R32jLzD4yZD3yfBR+o/T/6HXcGp6P2bTPx27afh/XsfnH322fT2jZ5xPFF+b5pNp6UfJPbrb0+S3tjj6/tWXb39Y60xA+3V5DJ/O8g6fQeWe7U5P8XTwl/5RCsb3N86mF4rbkn8ZT6H76tsXzbdsQxPPbi7WzMj/fwVPqfSdPqfddhTObMo7vLp1WH/97SuuqLL631NJ8obTVlnpF7CfJl9gx5Flet/grBIeFnnWed/Dc4Hknz026lf6qPAX/6U07HnrbEHpqm83TIjd4EGr0NapYZzybp1tPezrP1unW0wXP3adb33Ybz/bp1m138Qxrp+vSrsNxjtTfwlSQedkWi5HnWZ5Cxz31M3WB39uoqa17X2PrTIfnP2GlCF3fxzPk+U+3YTjP72+FHYHv8BT4D7TPtCXfbbc25bnb3irKvPdCPBSe/Y6lY9BpqNe5xzTJ/J3bJtTKc3/blg+37bifsX1G5eX8drvT5jnieQfPgzBkdzJmzFPyE5538pzyvIvnD/J8Cs8Zz6fyjHg+jeecp/DpkOe38bwQhuxrxtzPU/Bd5Cn4LvEUfM/kKfj+GU/B9895Cr5/wVPw/Uuegu9f8RR8z/LC8A5B+ENeaVspfLYkBOUPS0JwPkcSgvRHJCFYnysJQfujkhC8z5OEIP4xSQjm55NQUn9cEoL5BZIQzD8hCcH8QkkI5p+UhGB+kSQE809JQjC/WBKC+aclIZhfQkJp/hlJCOaXSkIw/6wkBPPLJCGYf04SgvnlkhDMPy8JwfwKSQjmX5CEYH4liTsF8y9KQjC/ShKC+ZckIZhfLQnB/K8lIZhfIwnB/MuSEMyvlYRg/hVJCObXkbhLMP+qJATz6yUhmP+NJATzGyQhmH9NEoL5jZIQzP9WEoL5TZIQzL8uCcH8ZhJPEcz/ThKC+S2SEMy/IQnB/FZJCObflIRgfpskBPNvSUIwv10Sgvm3JSGY30HiqYL5dyQhmN8pCcH8u5IQzO+ShGD+PUkI5ndLQjD/viQE83skIZj/vSQE83tJPE0w/4EkBPP7JCGY/1ASgvn9khDM/0ESgvkDkhDMfyQJwfxBSQjmP5aEYP4QiacL5j+RhGD+sCQE859KQjB/RBKC+c8kIZj/XBKC+S8kIZg/KgnB/JeSEMwfI6Eq6q8kIZg/LgnB/NeSEMyfkIRg/o+SEMyflIRg/htJCOZPSUIw/60kBPOnvaMRP8zPOdu1earxYjPUF0O93p1OxRD0/L3Z5EBM1/mEv35xNCHt7V6aDyITeDbiaPxgn7ik5MditWKj9rvzrtbNm2B72B9MjO/HdaI7t2YjqdTqRvNBODmc9UDhRzMsV4wvMXVnvYZYHHQIiIBDSSzzQv8ZhxEUr8yFcOzlaL/bn9wfkfT3MckIw+xjP2OR9wfz7nBEKjNgvJEYIljmFwjTDIgzks7NBwcaqLZF+QvDXZx+yFjFoRa+2G7dxRnjn/j/t8selucMZpBe3Z0JzjE9kzuhxBj/0TpJVxnrouCr+BOx1Ofi+QQXhtFwF8Z5JsPDHTZeYbIRHk5knuHlwD2O9iazAzM2+aHO2Es8s6Kpzj5uyFhIB7TaHQPEm6tKkUCushBMZyx7pjZvriafPkO7xpywkP3J4ahfEvrq3TEA6LlhNsG+pTFkrkXShMTJPeWt1nRT+nLPnJrKSNe1CH1prhgcTJ4xFIO2xdEDPM57V15QQXqpZ67hmODccIzrKD2fHfbn+1B27RJ001rpeXNdT3rCERC37vqhlLnMQ5VDkhl5N86FEZvdaL/ISRuKZs3clICQ2psjlVMRy6q4crdEMgGskFXzoKmNXocOsmce7SAd5LkjM/dqzzz4gjudKCA04wOcQ9S5ecg+RNsTjyX4rUPp5GHd0VzC2BDz8PFkGFlkr/LMI/oDCVHJ9D9SCzQ0umce1ZCM1sJr5Vyj2nEmO8dMTZf2yltxkiW4TCinb0QFOXlwLl4qEkCQXY/Y1bpJYgJL0BjdYigECjhr71CGoSe+BwnPRuHU36qzbMroCuNnzw8uGVb3HtDacBzPHwtNIOXhuQGCEuAQk7Ne2rMQeMk5fyzLmR45pnNoZc4PuheHUad7DiHwJNkQCUbvxJpOT45s79f29rviug5mETW8JKc9Vcsifn4k6SbTSPB60Omy1sxrIGgEsZF5XtY7OdLzjG1wSPd5s7LXHY12CRQLXZGZeycOhnGgOBne1baVm8DMLtJnMb7Z87LnRpem+xH7rJfrD+JD14hd1svvjvDLfvBwIor4bZ531R54E26+1vNW95nPGajOFycXqfNGz1ubJ8ch+J0zF53ImlMOPugnVF0xmpwTYdUqnUkp5kdzby8azNkdzKp3pcwwuCz+N3neNX1CABcG/ZrS//ysd23ZAhZ8djxyo/WWRusvRos6XRotim1ptNmjo81dPtq8GxU4lka74uCp0a7+I0Z74uho1/p2cDWln9Ge3EzRYPzcLscD/cjsE9ix+52LAgW9A6Rydm4wN29AaCe4zNVxY3A/ImU8sxgJ7l2W4HjSLWtkgTKaJ0MieIbWj9PBEI02oiNWx4Fte4aVlTfZomO28VfYoWw8hDm4X9Un60zK7iWhEp3wJiO5QtQDFbk8C3syG9RSh/rsX3vDWTRPuCZ9QVA6n9uQqTX+am9ycNBlCEVrGywCYnvGri8GzRhkelVG6P9y5N3+Bbdz5i7fJfIKqoqaD+Hwa1mGqV1otZwIFibHjEgJ3PTgZty1WDhO0lAgF5zOLrJHwHQF17szJtjNQ5poG6VUiZSWkmkM5vdPqO5GC+sOmJtnEi7lTzLmy3WKLBh06X4oswyhaDWrslCPs/u7M5ldtdOkkvE9kazI7HpeeOlgdzJyNESagTjkyqbjniLpxSfeCLqDkAEO1uEulgWzH6NF7NUE9H2ECQxTYNjlxi9buS/OBt3zU2G77c6bpJHr9dCNwVgsHphtqwTLVQ6jwTrCtSGWKCy5NNbt08N6HO7tNcejS23m8kJ3pLUD12314OBwLoxSg8Ti9ZfxknEa2D8dXbRVjlDnkD1QcSGKBvNqHxZQhOTPhhR8yEsKKoAu0W9XsrK82DM0Xe1j9Bu/IOn2gAn2z9tS0CtNqAEtpKKfl2kT1nYFItU/TNsIYYUnk8NptY+/YAKVEdIfZUXbaSTzMQ/rUrY6OEH24yiOOBsq9k96nCakUfmx/lnuLnTYH6g47vAByrddp0jZP1CjCQuEw9X+P1QzZADlB6qE0XlId/0HKm8Poim7BrMbguYBq3X2BwffhGhRKbUhFvrsUrX/zSphsX4TYqRGaXIAQQMOAx64Wnd8oRvJiqlSJ4jrRDHvmezLxUIVfrs7FktbShfbARJrt4PKxd7oUFgBEFpGo+6uKr8LA1EwzSnjpymuBpJJmpY9FBtaVjPHtbBGos+JKPYfRpwpV2qVToUEYe0jtUOWzXQ66Den7cOxXGYVO8q3+pwxfMkz3uxwXBuMz6FY6G5qj0z6EUVeMBvssl/1m2PItKDMP9xDbdJjl5wLkV8W9MqdL8I9TVkXpTioMkKYCY/aA4QygoEm6LHl0H1RPNvquHi4t8dmQ9OMI6QtGASQvYwM7Z5ddWgHtTQO615DTDCLEWQ09c2IyTpi0BY5132KD3kHagsaQbiyRFFrhDoVsuD1/hAXZ3apOY2EO9L+KyixZajw7KsQ6qDC0/G5kiXAsQHt29uX3qLOpADDx33ztWPnYzBi20OYmIQx0ixCvDccjPoyvZEWpsgOejBqXpivz+iMUWfmoNiGBYKAcWYXS7lDiSoqVRHU9vOY0med5WL7EM0ttj0V0CHr4NRNFj8viIE19hln2ADOJGBx0Wex+0ZJollb3Vn33Kw73U8V5sbsO8xMfn3UnboFkW1xmswiMPGFbm+9UKq07BVSn4OfjYbcYCYTyI38raLAMyFm2kAVUWs2wVX3V+aSiVkgu4ajI1RV9kkEeR5zQibzo6wTPBxATIX63Yd4HJdCx2kDT4dRcTLrO3f7mArZ6HBXDhN3sdKlc6eSclGPXDcmJY/hF7ndfNBnwg7KgwhTEAQri1Esb5fP8zFH0mUVCmTTnEue4XyGtaJpO/rn+Ow2mHliCYjeg5IBCwk7z1/dQ8uesRtppIUoqF0m25KnLjpHoaI3W93EcomIEOI5yIJGgrMjq87FvOlMQjdqqgmAaLCX68WK2vaUPxzvjcSflVtCaZQrw2grLlIerlqyS3H7epe4VmwI9mKoxepND3dHw2gfZNKxkNuZdAbdg9qCPOnEP9oJ+h4lDzvifTScy7AXNpWgau6F90OpaJNIK4vBhlJfImHZWjoe7/Yd/yjMIzm/D1MzEjdxqOl3hsDINrjOFFasBECQzSMEnwPL0WqshESKXux7XnF0OEu2nsWJanzyyQkmOa89mHLo6GpxBmwvZhhOUezBqrfF8borTu4Wm3alxoFnGkNTlgt11pvts4W2LGYqEe4ItY69Dl4gmsBavgeIfeXqnh1O+XYk6dsaxn/CXPq6zngT9SKx9tkC+sNDietlFjG7LI8kZpeLpljVfWrko/3J/cgV0cbiAGnpN6QGy83i2MYhQRfhT7GsXeaEbexyaxdd4uQllzilmztr+YqZDrQj9L3MN1d2ZTSv9M1VhzGHXu6bqyfKh1f45prdBf9f6ptrmf/ZvBkP6jqoTzIP1rK2ksggrlfyJFwZDXqTcR/5LjnITWOJVKmG3jM3RANkPG8e0hsNpyxOefuFsd64iHLdrNWVhFd55pZF9PNBs8GeeIaogaTbW6PpoHc46s4K43PweJVAnwNUZVdzKB+2y347UgpWzcN7+yg1NrJeYRcJJoHWWzWPALuoSnJltkeVe0JuQF2faYSPWoAtKY7vj457V3Ic8DExMMHgCh57DCWu6HHRlPCJyzx+0dtRFE/ozFzAF7EasjnOlHES23NvHpjUmwdeeKZylqd/WSuJe0vDV/spIfYXootuswKVWRaobCxQubRA5ROBWonOD+6/B46tSuJeEie0b40EVMd7clgwl1b3Ga9/aFlAJZ99Yj6RgvLgwrBnpWFxZ0nOX/XGglfiRFzvCPgKI3gpVxrI40NKw3YcDxBtYhuXSmd39MzFO9IJRpRkzOvgQSSyAgdYZvCiinTOLZ/Ye2hlcb7eN5kmWpCZarngRkcQYKVBiQZATafZiq+5eZJOSnzJxZfdgmJTbrPFNTMum1TOOkBcP2ffiSKVdwQUiT2ew2UQd4AdyUoLvSSjloulO82GvcApl+jcOw7eZQjsGJKWnK1Xyzvxez+XVy+wVWA7yXrx/d0ErFjeDCsXoFgh+I0upyXKQ61lso3CdnXD3s4zTRRwTV9c8sKzep/El2dyLzVwF/r06m1yrx3MTOceWwrA+DUyKpiwvaF3f8rVsAXandadO9t3AfBL9XvlcD+wGEIMQzZq9qOTEZbw8CIz7Q0ltKQk3mV8tFo0l/jFnCNmE0QXzsm23xALEeOLbLXMahqYd7AqyDUP5yNsULHYKMfiYFoIW0msg3yeGusTThlCfecCM+J8BHiFOElhN5qMDucDF3jC5uilR/c235z4QUw7dAALZY0GxWHvcHfYC7sH0xES6pmTbkjbG44kvLj1nUal4i7rFWpnC/eGJLyahmjlirbxT81loE83Gj83/tLqHx8ehFY3RoZApdMQnHpFFhrKciFGd+4QI2bmcnmlm/lemYptMxubbzerKUxOhZ2w2FxuLbKlgsOBTi6wOsipDcw/xE2j/pAaqywUxzlKsE6CFoYMFe5nO2Va9c3mFYM1shSTxJcW87pMMggl2REWyOU0K/ryagwPL+y0m2cE4rv3TIPK+jqHJ6QylXvkyhyprLu1nyvODqP9JiYNRz0yFJodb2BoRdtl6ja+CUv6Ohspr3xp3D1galVIwkREg73Z4AcPMZhFBIjqnmOzIeVHB5MJZrZo0IBQn3LtSNPsOSz3pUbd8TnZnE4PpTqAhX7DeIlgelKSBdlg3tvnsYTTm6QG+16mg2lSX0a9ttZEloyfmToVCSJCIi7I7GM/umQQDc5JFLvaFxHDMMDO1klpL7wDO2HWto3jbM4liB0KqcBygmJZnvAqEohrErEsWjEdtJEVZYvgl9xyxQBDNyG1AFTNyDJBDu6plHfOblZQn5vVWnmnub5ji6uNjR19FZhaiAmq9V5XIg39wqyXUIG1BLsKYhgwWqxeEcw46w/HeFzWliAbWEO7xtEAbQ9nQyj0+kM1ChqicdbgnM2qgoH+1uiQE1HX21QziCPNiKoeaoPzdqAtLWsPRl3ORvZtg8xUgbbBwcAehdPErReSwTAq40piuqMPMvXD0XwovQ9m6+KQb9upYILUTkBaCDClo01+acIAJe5c78o5uVzqc4vMvUQhuyMP322Bgd3xSGXiTS+bbIc5abOzOK8ElK/Y915XUm92rCadVsb9qRPDgUuKkQ1pu7hpsUCw3x9Y6j7lswzgkEQ7WoviTIKQBItg1BJMjHq6qGPVJ6ioYuvKDIWkpJygZrVcrumLK2xoqjjMAmSPS4mvuabNvb0C6HhEUJW6lVlkl+TpFSs1fR91ubf60I4RSYgASsef9dNaklQK7+cYbdIemRuEsmTorlIrNs/aPQP9VHDzgNHVth+OSPVqtVhiluhFYNYFKa8wHjuNwh7Ggdf8kq39cKdeBbdVr95ZHHbRgX7ybldQrzZ2YnBGMklRtl64JynCIrpnUZS3KJPSlVKzLa/zioe4JStzNVHgJ0SlMxf2ovSa5jSKsyxfJ9dJ7awX6lW9/XpKs+4e6BWaORt3fiVaobKg5SqipojtjrwkhLoAcjUzjw22AFxjAa1C2b2qdq0FuBd4rrM5pcqZNdc3pbHeJr0h/QmGG5WUeDQ3yZYkH3DY2VBD6mbNY8pt1RsOdIuCpEqpuaUoHqQQVykGPliBUq3QKMGYnWqjXBGf+CFa4GofKbtVy6QRQ20AeKgCXGUHe9jl4mF8by4S8iVkdlFaIh51jqhlS01yZrzBoEFgCiX5tkC1WK1ZhrAoNrEn1Vz15cUEy5qgzM5ba7YcBzPL96Ozl3dUUvPFrNxbqdlFZprtgv02i9e28t+qNtSGpDdmmVSmWNuSCtlORcUmt9G2r4Tlj8F/SBT2gDXa046+ymh7CippHpOMkOtAjpODyxvTbNhX7WXZ8RUMNtvafI3lfFkDCbD4cRQNhewN54ODyHzd9/xFXdRj3CV4dTKk3ZeppHBCRRDTsxjltGTXZBat64OuXIaSPVyUaygmmslYtW4Sde45Be/Haj1FawoDkcCh4Pf2cJEFHWl/PnEpDCAL1U6eHRBQnmD/2iyBFt1NrXZrOzWO2sth68bg9eFFtjKMVIsz1HNGNRoJdq1gX1nLfc2sumhdfXJh4BzWyah/RvdS4v8YGuuJEeGn6m4SRBAmwWaaHLlShCEi+dKRaB1+6GAkbFei9b7BeeZkbJvR396iqxFlzhQIJL2lFw8ymFznBtg4aH92YZ9zaG1Ll5X+kGMjGUBmPmSPn+MvVKPJ05962+00lBPaGRUFM4OSyoN+QTz+oEeoKc5kpCBW9yvlinwnijk0ZzernUqxaW1cT1/9EjXrs+Z25I3qpn6uKQipJfBMqSkfBCKVZQ/Ah08+MJFbr27UC7ob5DHjztuegkKttSlXoeUVLVGvpDy0SLWBypGMOyt0tWPNEKJN2Vjjdy31llSc80M2LmQuRPSwuRaNiltYeDw90ausarvSl2pbNmYjzZiXBkRH4dnWtA+ftsbDi52Yv3BMLVzOrqQ13A0SPmdYuRfCBEW2ePjMZ+JLz+QYvC3mPUdn2g+HQDYnrTyXGcy2YkR+DLJTFIB2OLg/rhCZNY8Jn7OhrxmOaubyzOmZJONo26Zm18sf0z8qI+4vMi/nsDxdp4FkOfJNEplhf8bBqWqUySu0iNvGlgJSsFEJKb17qyJfLAIYHI/OjjroHc6w+ucWZl4Jk+/vRi0Z3OQwGl2y7VjDnvG7mhayL+CYwAa3+Ezew7DpDyoHnHlYtJlDXSdy73RLU37Mm0DvAMr9yCpW4MC5FRmhq6QnYsZ/eca5l3oLw143e8p0v8tJXs74mrDAp067QntVTmbN1ASprK3wtLlI6gn0Fk8LevrYruasPC3o24ZRy54hiHZipG/0lqXpnf5ooXF0gM8NzLPSwJgTzwu8n3MewO+q21MQCRDx+KBn/t76VZjDeXO7S1oKBsNofTgahQKj/1/whpHz/hzkl4A02VYIIeixgmjNuOyrFm2HIZr3+OZfe5otL43gd2M3jvS/USW0Trx3fG47gf5kcMRre5c/eQYhxPAQRcmyxCWVOVI/xHzEN39JBPpCfTIZEyKpDUeXyuLhAP845yzhZG/u3JhQaIHINzGAxmRsF69j8697cPwYZxIsb0gXLTzTD/vm17zheH8wG7K1OIbBz13zyhic4psWvDouSFim4F+JwS6IkxS8LinQU4dFwa/GBRLHWYBfH4NT9BBysmRQ/ltepMA+QKnCEaP5gJ0xhdmKcckfpUqEYIF9MAWzRAn0j1NQoUhgH0oFBltd9iYWtOf9nncshcWkKlS+m+kRFWDvQzA3fwPZcbZlbRSC4bi4TYk5R+ZZWe8L8RypE72YpOf75plgU+jyuvpnpJIG6QPAf54uWMjkv7TgZP9OycgLfPMyd3K5LOkv8g7jUz6wpzt5jVz16rFzHF/86fggETaJgvhzZz3U7Co/o4v6xwNXSef+LyTSZUmzxR+FjaU7GOlfxsgGidO+Zj4mERz8/9Jyo68vsAiny4O9yHwo4z3fXwLD38i8P+P9uD2Qt8CQI4/IPDvr/a27mqa8eZdnfnCRtRpGZg3zzLFY4HKe+C/GAziKzmaymbr2QAJRlbFMl2j858cHlv3B2DbUYf/kMsGoOA6uxZpEy2W8FxDN5/S5MBsUD3cdol9PjjFDOQs1L/S9ryYXxBSEzfsi3/uaavzYPpzEGTuEadygJvabyZrf8w8W5shLAvMNUT2jiQSC/5hAiiTxnJlpgfy39BXI6+O0xVxl47C3EmTvoPqqueEIyFY8nUDj6wur5sajMFv1zJzlW5Br25vMur2Qbp5gHnYM2DboJCXbLDa5I2meZB5+GdBW3hJ4iY3Q3GAeEadt0bZkU5cybzKPXIbYamexZuOrGzPzuEXOFn+fcKjBFmnm5vFx2hb9U0UnEvR6zzwhztiy73di1nFQFLn5T3rffNtKbYlQ12Rck3MJXBCJu/+rpVKm6+L8sEtMblHjWSzcpEp5yGofyDhYlOlaP5SuZfdj4Ve6yrPTVVBk8moD4B9Og0NsTFbtfYPZhKLnpIsah/aNbPs2+AXzI8cUOhkwF81zjyldj0+Mnml+NF1c6k4j88/N89KwZCv+l+bHPPZSNF+MfGZ+2dZMVMv7qdFlPPYC8YPNu32xpci3iD7CT0XkmT+JwTX4Q/5PicRdrDH1ct7wH7FwH+h6EArf934pDnOxYsVYxJz+JFZACqS20csC87f+HARbmBk1PfqICc2b/+BJCZvuaMh589HSFwTziQTM5XJWZ30ASkgyL/C8P/Ligr295ZIPesn1bvN6BuGJIhJsb8piSCiXZAgCitjcvecoacVhf7jo9mcV1pnBK61ovptDV8zMzW6/3al1KINXr/EHR+9B/2gQ2es4zqLdRHSYjOelXiDKuaRdHt8+mvSwnIHnbcqCv0Mydawr83zPvDlYnMWvuKSt9p3gSS42rCYZW/hdEeqMgOiaPC3oezhHs+fPZmxOJhlb+L19iEW5IlZjs+qdSmVthcIBfiGUXiVPCyrHZxZN3cfo7XWBlFajpj2Go/o1SwDbbl1gqqVfHJjfSRkpTTs8RnrtZUDbdAOtRZAhCdlfl87bKpuRmlDupZVVc0s6b6s0LEgVqXmEeUgqayvcbSGsQ/Moc2uSsYXtJB/CW1bff+ecQSD6DbfHmIcucrZBuIeltTDAHrPI2vL7bAMLkhqPTQNsnX8yUFMvMq/yvSe6tC3ZWbAqDmHdcQRkK+5JvxuDycFALgm92/fuTANsnXO25xgote5aBtl6+3NWwWIPWQeRpVbI//lguTQ8P5xWWY+eeYWWbLGFygodsHojls7M/ILCFy06+8PeedRQRNkvHilTPWRuMa8KEhFG7PWeQMSq9P4gkLcO0Gusssm0NthjG1nICALxU166QlvE4kiNFy9qFCdzonvHYPnpo3WOQ/SSRaVFyVBMCLnjiWaCJz9ztE5ngmFF6aLKSzUuiF/C8CM2RWYEZqvi+FmPIy5iT4UI22/eFg6Zr+XMr0jE47Iz7Wf7uxOx/Bj2plpxwH7RwewgEvCrHFhGngB/yQF1qAn01Q6KPOJpsVpl3b/WAenKrjy48SsOZrtKwK9zYOkqAf6qA2pXCfT1DhqqSFowu0yaV//G35/EllTCqrl5mHnwcXArza1IvjaGFA1M2bAVuowtfIbmZVxslNBwPp23VUYKanX7suVS5SCdt1XoEFCJmUClqqYxm+aiAk8f2s+9nTaXNG9L182HPM1uJmQ7hHTwJ7aILUuNwEXBh20B8Uhs5ob5U5u1lhz5j9h8C6sAcwn1Ja0a5u+WwNp/lQhqBEmfsUVpwm3RuvlPrkg+M+eabswm8pmgz9oSR5ZOIdD/vAS1QgD4cxasaBR/OBjtwZzPW3hs99DEtMxP4OYCJOSEvA3uk6m/yKT/pAXr5+Ta5vdtztHsZoqe3uMfDMcMeiAr5N+LrRNn3rvUQqlARtRV6Ji/8CUUMmBzvQAepZN+hz0Mjqz30uAcPkhbXll+Rcb8O82hcw8PMC8AvEUBFG9A2ar5Dc3acgt5q0KoUOBYGOW9a35TIbZOAnybAqnGaMRE+S3N20oO9PYUKGJg0GpelTEfUzAtU7C/UpiOZNuJkI7Z1MzHF0WbieDFhX8tbtSYVb7RPUCr2NekPuqzlLASZZIkJKQ+4Y+LxrLXvEIUlMaKtOAFi4IiHD+32KTYt37CW6BS2/G1vvm5FKxDK3OfeXkKVF5cX/t5j4MMRqi1vs+8IlWLACbG54VBqNcNIPo38Fk5rVBbVetvm7emQPJ9wDXzmwtaOSNgws0bfPM2D7URX/XqUGTuMb+d6kqi0JNDkfd3pGvWu2T4p0r7dzwycUlqBO+UQOMcN0TyGE0X2Ca7cnHpXakOQn2vIWS5zQv67rio2z9ekFpdoI7MS7Lep7yJfrHIVo6hrw+SBjpB8E2PL8xrsuZ/e/ZignpsH/e9D7i8nI9gE9vbC5/wvb+KOSZhK3CYT/vmSwtYhVASkP+xgNQYv92+v+CbLy/g2hp7CmPrfy6gtLewryxgJeSRKVRSI/MZ3/u/i7Li4JnDweU1/iMnfa5GB0MiOaX/vG/+ftG4AyPMF33zPwmzONA2KgZ24Qr9TKabnJbh+gTef/cPkDV8DvEuIvOcwHtWsKhSYk44qpNDvG/45t8HhK2OfGz+pPnvnkK3EEunnVfN/yJcFEK8s/zKuIj4zszuizN9mz7m3bz3eeYbiM0DFMdj+KRPsHTMInTvGACTYvNez3zRe4Z7Se/9nvkvgUN12sE+4JnPY94KUhue+q+wsz8oiotSw2g5xP0xX82YH4ZvDtyRVw7M1zLm1/WIjLUnJyOK7a1Z81JfB+68K1jkmZfHXmOJuROGJqbFz/v6SYIWq2AXbWG+GrAEoeZgqujekjW/FrelG2xJ1Rqvz3OIPSWqJ7ZhKL0RRBuOdfWYd+bNzwX363mdvBBJCIxJG5hnZ8xP+QtwyX6+OG9e7IBly5bwcHfOKaUrflbG/LQrL3V7hAnQ1yxgSl4QmJe4kup4ejhPbjh9PmN+wRWInTcfTuHpKx1kc3KB/UoXyDcC86+JX51VeIiKPi9TAEt+Gf6JAoBHjoyoKS/qUE2bU+WzDl19MO/2hU9fyJjnOljlgjDYfC7j/aiDtDAt2QQu1QfjQ7u1fyXj/ZgrVOJFbBvMrorul2FU8IzoojQj1pgx/zlQ6WCHibfqyLyMnc9XMKqd/Wip5DdsCQ2s5EfmjRnzVgu01c+K+aLg37Tg+gAbt18ajEYor4x5eYblgRgz8eh08bmRnL2hXg0Vkv6Hf7S8hYIhwsBOaeNQVPqyT+DXvV/0bB9XdBjpiVV/gDXjVCPM/Ix16sPpgH1v1uAkj7M98yPUFrdmikhIMRVfzlEWgs8u9xnP/B8/EnBHINrh1/Lm/6ZgRJqZEs6NLGhwIOIqYX+3yn7MFhAn2mVKv543v50GhIMpQUaRszXzvqA/lHjjQatLvJ2zJTbZ/8JpskRS2hOin7vmcy4bzwKtPu+7VjUtkZuaHRnvezKoZlfkEKqJ9d6M+W8x3DZpdQ8jlNP7MmhNDsxQA+WhLFYRwK9b/hNOq4wPD9bRrqwK8/WM+T9eXCBMiQu+kTE/5Hf1A9Rj9BYIrljkrPlclOVvjYVKEo++8jKgrVwa6CEOMqHapGkv/159OdRWrxwMoak25IESvpmHy9ni+hzx7yBM59kjqfCgdN5WabLuEK+0Y4HD8ejLobb6vZaSkCAeKCLzdt978jLI1kMiiPYqJyIxVL/TfMsyxFbbHemEbGC3RZxNet+aytsavT2mDZmLzhMuVUbBj+gyoK2MflPck3X44Rk2uSRrK1zYRXEtfYn+ceZRR2G26j3EF/ssX/0EOwMzt5knHQHZij/QYxblHP2EJizwuyPsgiq78SyEixKov2kZYqvVuu6+50d98/scbMrerfm3e+a2RdZW7ltAQue22yDz5lc1zkDMaz+kkznmm3lTYKelyGRbOYtZBWPul+MIlMG7fO/5HnOrYi1SRdkLvUgtzcWnX7/f/CLGhrj34QGrcp+RM55XuXouELJnXuvZHjuQUojC7Q1JgPDfuoqIEpLUwxuBSLatHzBvBm0CY6JA8u+8Pblno0b8bDCO1+WaeYvDkuxGf+7DJMpQk6mjoJrKT8yZrHmPN6Y6cXOyqiXeilWj5zWjI+9gvNHHonAFYi2K/o0rQNgfxGULhlaFcRAvFd7kY81cVqOAkkXbsbOyp5g/1AqItirKXfNnOvwuhuWMo2lhnTs6FzOqMMa1EJ6LlfFx60+WwEmXsEqmoGH+eoFADrcFwwMg+IR3fnCJgPq5czDzdVnzSe/CBKegIjtqa3/GiQss/ltPKBUbQCSpONibzLA+iNfLAHe9/+IOKWsYRpH5mO/9V2/ODEv8XThvnpM1/40JgdD9JkeYCDmEYs5N0KIcRpCGkB/xR9TH7XN+7fMIRbNxKYI3ZzlN42hhvz5AXSvoZTnO0pAD5llmGfKc8LAJ/owfDdl7CD/Eh36t7njALkuszu/2GImGqzc79Zqsn6/nmGKJn7dZ7eYbOfNvNVeYz2fDXSJNkXlx3vxdqmFNLrDBljexR8QhvAuDqgTN6eJzyYvDSuj7cubN9jgTSAmleXgAD8R3YrPEuU7KJDhTvBRi4VDygox5R1IiMAo5Gs15b0tD2ZY/6ZnfSkDtAbExpF7F9hU5dHBcIqTo0XZkPpAzv53AO8jDuIHKZDifSKBhbzKl5ody3t/I+/UUI1yX0/47ajXD/Hn3onlRBr9EL7GFeqTM0TUuxBSeKDUvCsxPYHKL/Om7ChvoGST9nQ4WDlA/V5pPJbxTa6klPg10+N7vBv1j3194v2/eFUTY3BB4pOgDvvk9wX7MawYf9M2741ZKTYelqEHXyIy9zwa7ChOy3+eb9wS7rDDabTvSQFPtC+P/d3zii10fF1Lycc986GgbwJ/Km68hMBiD7t3AykX27L6UGk72ghkaNK5+BjWwZp4duEsNHLC7giq74ccC8yMZ2XAme3shMn8YyXy8LG/+sw+3wRgrJwG/OWP+wIHrrMA+ciDgt2UY2sEQy0cqWizmWXnzh1CYutkCYe/3WXMYTLggLwzMf8AjIqyBLbmHWWeemzd/5tuVzfpTJcBIP+ahg3uiqNv2wG6xYzw/j36YWag1wtbMX/n9SY+zQ44I07iflzd/DW6OwRHG9DXGiDN771PW7iyAlpM8sT5rw13Ltk8rxSrDSvbL8+a/4lAdYCYnn2F+tme+ksDcd5ef45n/xcq3tjU8tW+9C5XoVmHFT2Mfs8Tc8SFiAOyHY9+yyKhSH7Z5j2e+TNFe93A0X2oDf3bhJNaljS4u2oHt/QQwFLpoIj6KtvnD4ABcwwpj22AhK+yDiGrcvL74tMH/BH0xKaiO1+GvaL/nZ2YJXkjhf7se3h6wPnfd/snmnzcvCSJdxSV6h6WvTGWZpNHS9xu22Ulkbr/keS/N9NKlYdLIfN0z76CL0YT+OhMBMV8zRso4PkuAO0Bjs0uxwVO0zvzjE/nmT1XDSLaU/tjJFzzzEYZYwUS4pEMsAZdajPFLNAGVXNxoohIQmg123KkVja8cXxiPIG/+V2qgjkDb8qvHFuA1eT+cOcRnqHfPO7hESN4QeC/IHCSgS6W4V4hfQ3UuvF08fAkkrMvbLOcHZ4bzEvOmS8Uzz8v06M3VSCbrDb75aS2oXCRkIIx6feD9RMaaWPYzCyVKhR309jkPYnrkK1reQJdDwRtj/VSiJE3c5z3za3BWAntLRVDznxQNkdLUJ8ifixEX9Pa7eOX6og86ZMX7fYVIU6RN+GrrPm/F/F3QHZYo6+wzyL556Yr5oiIVWIwBrkLgpxUed2Zei+ZZglSRBpYpePt6U/WTEF2ivOiEGHr/JOjiU8BYrCME0DN/Fux3o+JggF60S7s9GMMOWdl/rsiV9ZaDZfwDosOe+YvjSxaC+DdILnRXYRRmmnnFivlLbdLU+KRuIs9jJ9QZkzkRC4oBflQrxeSWRWW8LjCfUKgTGkgntsngfjRjB9eyktDCkmTqmoTk4IKs659U7BWxl1TjvZpATeaAmK12v0Z8Ync02W0P9kzg/VymdxBxGgFxsOmdRGQCAEc29w8E5jUCbmNzyRLX8I0UfDigrKtKaNAXJpTYiM4xsMGo31A3Xr6m9jOuiurgmrOWXhboN3zKsy7bi4z3zXnzsykYsl8ZocedAn1rnmH0JiBA91/A6VToVwLzyw4axxcU/vIV80fBbuoOcDu+a/wKdFsmXSJUi0S6mxyvCsxPZfYPd2VuCs7kgwtMBVJ30JVvkmJZilOnHX0yMO8lJsJQ5TKEYnhDDrYg2DobLURkOjdvzJkvxGtMOrSy8j+Cg4kgT8wN896c+fHMnJkaYavH+7Y5Zb4WnB9cUl92W6w28+c583+wBrBXphMGTSWd2letmP+NVpUQ8SYGgSiDV6+YrwfEcelYCf58zvxsJkbWhG/a2rxmxfzf4GjHivO1K8TpeiNOt2WH+fukUhLSv5IQYQxsWh/vlPmhDJOh8UyVFfO6FSzxbhydR3KpFplP58yPZeYyeu2vybxiPkH1F3PmhZkSjIoXuPHzEZOkKiY3hLPp1Z6fop9Ax7F8/CbanvHpHw9P3QkEvafT4XJZ7Ai8mhYe5KgtFIFEu1tagH5W9AGi6g17jHPNaHBZmCJ6HowaARf1lOlOU1drsoLJaWPj+wObajhcPS0U7eAg/tbSfnHJ+N7BIgfXaVSaTM4POUySqIAsQONfs6uZTRQnnhpVbL48jHqjLrMxow+sGMIb9HC0DO0UlwUI0LB3KV6VGXFrpuqak8syf+PJ/cQCMNstKGfXgMvlZwNVaza3wpmCqO1Z/OroagIoD/DKkwurJ8AxuoSpFbmKawlgueLJ6Sy+YxtXPZUCLVe+AkvpPE4o8RZb9coEsFzxqqh7IdFDV7OYxduN89ekeR3Gu6y/NrDRN9QrU4h2l21QZMG8OTD+xYKcHoqy4rDTBPZ4WbNvkzeIbA/3LKBUyjrovQsodXMOWlrq4i0BMq7zZN8sWJnLAN8YmFULrWEGszhPcDJBxIgKa+lBLOMyfrEgP0Bq+K/eLOu7ZF7nuF7TNTv6c1lODlMDMYF76cokr9B68etXvq2dGqD5Zj+p2D7WFvWvn7u3KLz+ID2JPg7biCriCmNLGnHgND/EvnVhBHnN3EG7F1PQbAwdjmuqJWJLORcXdC8uF+RH7Gv0urKHfkAbbHb12ttqNOkNu0uvdZw4N5mcY++IBRqnnPlgw0UVEuPp6eXai/SBJJ3EDp9b+0wWcqgxOUR8GVzhjBHpXgCLk/6luO6Vy2Bb9ypHJX3vmqtTNCrgmm6/X7yEbx7VkBsxGK5lgojhtAf9QwIndd2UAF/X0wm0UkSg0FyfmiPHKPqVuausuxcZw1KhVuHplephYlb4YmSUcAXIgtrqtD39THdJ/FmcWfx2phStGBHtl+8hE5tGl2ZAs56qiFb22UMwQ0RC3x3EaCL8cs8/UnmIbxtXNX690Clt7thfnTEu09C3OmkWk2qbG1+sHbViLK2TKdu8wdk9IP4xjAip6jaM+rysrd1TGbTxKndvFWohPZhUrZAxMogj+Gdo8eIlHD5WjQyCkqaDGb8Qsl7KVX1/15QrqZyQXmJCUrba4qtXHwy8y8srFLLFMJQEqr2ZD8HLJaKEkNLRWrCxGsrLb3Ru9I3mcqEjr89JT5eZhwtaPmJpWapRoUxIiSRTGiGPGN7Gm1NeHkQ9Weqw8aOWJUstbWWzulkpCCPk1w2MS99B0nPpO0n7Ln0X6cCl5ZcOMi4tP3aQlV8q32gXWvJCd65m37zNF2vN0pm7t5qdCrmVFAkp4ny9Ras0wbOPsjfsoWVkY9cIjRglc8+vHg3bRNa+8C64vIRxPg6HLqvoWJSqKOEkb/Ny+9T39y2QKgiUywglZP16VzZtFExiuNpPpVOzB8GMgaSPjrLbByY1QBT2Z9i9XDokpnPQJSRnskvYSkvFxtu+DXaZpSoNlIRdhBkRGYpNqdkoFTqVBv/Iea3alv0xY79VK5Qqm033s+/BZXggfC6oPu0kRWA6oM8iJ72JnreP+ZfAP8fWMB1hrKqlr6AvMCrM095gfzJijSXwLx8dWyfdgcyCXfTeUqXSotNCdFn1CB56yw1aSk1HRmFy7oeqjH3L0bO/teev62uOQd0qqEyzs6nsWKbO4lnq08d6JoS1hwMgdPYmY9wuxAOLGvV4TGuhgpVasXKmr/F9Hs4q6VB+RHLW8VFw12kDUfFUogAqPDz5wU6efmOrXlRqlyevtWD4EsnBMsl7iy6+RPc2i5OMZpVdPyips5dyAX2Up9zM7o62hegITxUhBOniRoWf6+L6T8myqXm4+MNuDTRk/AMC+mLTBTgZ95cQ5dlEDwYykeyvHYzlOh6syQ7G/SSTqwsGCTWy7swJJFYmybQKW/bjO53mhrwbLPCdGOjX7YdDgq2GS2VcNcnuJNBseKbakh9Ydx/1yWm+WCidcYC8AvS7JithpaO9SPFO207DaiF2soRetmiNiQqhGalKjX+A0Bip6EfyARbQOXftQvUc3Nzj7Ki1cLkimOau8ygg/bMixE/Xk9oYdcJaYGGqiYVmh1HTNrP5nO23jD4kmrp8JYUtA6+CQWHO5EXK9bSLpF+XkKhM9ID4WXr/eU6GRbhUWKEkFnnk7oIIDwl/26laES6qpXA8DxxHSisUgSQYI87rukFCz4VUHTnvSc5RbI3nZ0ywvQQxd6Q21aPfE/GSzUm+a+E+6+EvgPJJjIYsxCB0XyaJPw+SsR/3WLTKWkDLfgwk/iRcbhlqLfT8MjA26VeWwYnxvrpdDatFNfzsV09QCgUya/FnUk4mHy055X4bBMGjKyVi5+iYr1iuo71fVunKRSVLx/G4rrqs2vHori4222w62mHCwmsc0LVM4Nc6uPaYQK9zUNtBAr5efza5wbJqy6cJOtWK9HeDZaV+BoU2i1m6sV5dfJfmJvn4TJy5WUoSRt4iRUnuQfp5luQrMg/WbPy1lodoTsnoVJsN6f7WxWdeHqql7oszD6sd/abMIzCIUh+deVRzu9JuV8tI3U54b73YrO2wDI159Oa9DI66Yjw9BnNpJ6zQXw20ZTiCtZ0WjMeGtabMAWOnb0XwOP2Ei3zTxX4/5vGad590saAn3LPTaoZVGQO5J6K1FrkntZsdHR3pJ9ebkrK/tSyfZiUtn435lmPgwoFvdfAUitscSP0ZbXz7EkSa3RFD0JWy4d0ZL2vxipKz24UCeWFKgaSrVCgXLXLBlQGFI59kr4ohUhvQ7kKXUKciB4ZODVKZrZF4mZ6+gjPV7YvpdqmsQgH9JdcHzVdz0pVTgB1BX08uo1E/heul4Lq8QoVSEGZmk/sxP3cNKlkO/iAXCGf4csECm3LkkhnF0JYNV27CxeFGEKV6ennc03H1KlSiQ8wdOll8Zgvq5dPHLZenYgrhK0F4pLRC0QOjkctFnRkGhEQNqJ3C9WqH62iVCuULhPO4xLwuY3x7ApBsz7VhhB+YYHwtGI+pUZ3rR14wRtgMG0xiVTF34zrmFVmITVNB7QN9AwCby7w+g72jrwC43FJdYOuHY2se0IfYXG+ggZWE1cvqdqSCCdZr+gkm++k6nt7mlqgJKzfJZNFEGJIa4ZsY4bF1KlRYMC0CKJ0X9JC6NbFzQrUUqreA6rLyCoULNFNXIJNpqwor7RB896EWoy4eT4csfSK+6OztSWep8gqFi84EaN4Bd5frYSqNu+qA2a9OvZUaqZks0zSYY6XN9NzgnRmTuTCZ20Pqd2VM9uAw4jBacu/OmJxF3Umq+95c0rX4lw8cjdsxBvwPkiWxjRal9QQlNhRnr9AAccu2rl9OX4FMbk0K19RHMZ12RZ6eq9fCnhtzAkdUy3jxVzKX+O8qWoTuTqWgA4m5VzdD9JOLPHJgIu/94+aN4ZG1jyCfo3NoRaE8c3KwOxysc14npn3DshfdkmreSBp+AJbKnZz48kK2dHw9k13YL8tRjQfY7PxqA4+syoZbrdXsNmsLgsv3NQ4WUp0WMFxdNNTPxKNyS+7DyAf6fVszGI7BaHCu2yN2rjawOKNlkao3YEMv4SwLv9Ys38eWI75eBXc+kSDmvHrpUyeZqU6ba16Vttax/giyluZZ3sbbZxKUABcxmoxZSVO5CiY6xQLHf9obnjMfzZgTfRcjsZ0Rjk6Ra1v6GblOadPsdHNGZzOv9+y3Vm2OJbI3mnRdGQHdJVQdodisFJv6K706dTw8jAb7jbZqAyurUarsyHd+AQRqA6m5nEn81Gy1XtBvr+Vk8njml/poHRk/KwfFIHd5NLvmeUN3rUw+bu+gn8l4fusIX9AGnBMO5EbL1IE+nZG9El0yGZmPMfsRx1pJ/U8wayM9lYDLmaHcUnclH0c7RMxQLwZ8ikk70h1/Fa3JlCvrhS39WWSjn8+SMXvVRmtLQPh7NQxkUkE11YMfHCJA0rHHbiJPwq4X5RmEaRr9wBXLNiNPmDOYSiIIlUC54YcM+Ag2jJECz44JGbU1YkwEWaVqZD6Jwm0c5RQhZDcg+HQZTXGnmWpqKpYnDhLmIi2fpbn1+YjLPVDljtQ0vnynC6Wn8mKQJDx1+alykSTP+qcVuRiJCNWbuM875eZZsR1NSb6EzdMTgdyplFEUhGwB+IUOVv8mFrF+0bWAygl37AespBgXbgufQHraSsPdt9d0guIjSmqfxQGkFIW8pdE0kvZLZFjhkvFts3qyHWWn+o4TOgetb9PbxM7huoLc+xANxIhcoLebhs+ULZsViiJty7s/Lps9q3VlhojEJC9WWMblk48fmrAirmpHl+NiXZbxhByzAgXiLIgYaqmLjJDKMhDhowsGpDuzsiOXnEVomNyJTTCwOXoFR5+kY4DyrYOCEY1vKfTxqTaIdIimlm/qKptN4qaQdhOc7lMGaPzVqQM5PqX7G1JDO/gia1dOYABmLGWR+VLGc6t20G8qjFJ0bcd+5gGm5veRQoArbG8YSYf2ZGfEZHvyyVk8BkK0i1eSzFUdfK6w1K7qj5+bUkvEwXO/Ce6XQtlag9OFbQ4QXJ2M3HLlmT0d6vzkNIhwt4DyrXs7mwpc2ZCteTVU8InwbFXjBGtnmvKBPFIn21uhQE4VC/rr9lcQL6qy4ynfrkzo1Gt44F2vbpwu1NlS9SfRTbldKG3VdHd1vyHK5EvWT7L4nhUAQQzAvVIHOBMDCJBVlIRsDKk59zRXlVgQ0cDKePFWBvt4TSaYALstLCPHcSGGFA81BAo4J16IkNt7YC030aoS9DgGOZs6INNkt23ZAmzUyO4X4XTQc/XindVWpIUvUih2vRCAThuRZOnR6+4hp2M27vncLIKEOYW3JkISf/qHM7GxezeGXKa4aECAWOIOVoa3GouMlwSHsLZgkbIssDSMbXzKPzEiqWheABmRhPigOWtOHEMCNqNcekvub3IECCNemDWr/WXQiyB3GSScR1O+GMr7k/vH2IM4pElnWZZKBC841edkM4bmhD1MR/JDIVn5BaF1uSJUg+jmXo1ylsZKeWEhSYEdmLdMgNDkSamOlTMfkVnYYRy7YvZ4CQNjiK9uQnwSFODsU0wqEx7HDRPIJ6QpNrWO1PLaHVlG/tFqvi02thhjOl3suGX8ar3FXlLtUMVU7knSix+YkJq4aNIS/T5UaWO2aPxS5ssWRHiJHup8YdRlIiYW30vi8wdUdrsADM4mmCuKxc8PFz10AJt7DAZPApKrgfpmgaBFbJOC5H4QUWD22w5B+nNI7usQgGNeKcjOk1tA4ojgJ9AudyCB9s2h+ibk8wltutzYiDrqTbHaGLgcjI3RPXYlj4ZdXE5MhFJ8BsJRiRImFlzXpeCL2F+2ghgQi58HKWgV4z9uQVkD7KxWOLyAdahq7sOvSyDpgduLV1rn++QeSFxHBmTHmBp4qLdAwwPkvaD+/QCW5iBvbCVD0WybvITiR8e+e7J6+TssJxb4MXGipRfE1yx5SQxg1TvJCpp1bQW35vbkl31jFG0wcNQnxUm3nrn5SIVqLAUXBoklLYcqtyzGYl8+X0GVjrdmo+o4+eXaa0bD8Xk1ZWU6HsGJtJvjN2TNI+eajCdfp+KKZdi2KtpX5syVy3Dzsqy5dhmkWoI+rlMpKyhZ5muBuerIaOxZ0mK0V2t9eTGyM5F5ZBKvT0DFS4UDdblXzQ0KbDFTu3iqbZnOVfMoWGClLaJv78Yku5DOl2e9m5YpDWGphvgetAxPooIPXoZT/4xauA+5sIB0tEoliRn2BeFjuipo5FVeXpU1ty4g2oB6u+ahCbC1L+v1lVnzsAQUiioxr86ah+trNoMaE2g88+ikgjBphIawAzRfD8xjkzLhWcLGxxVisO0G9Wc1tHoqXlKqtC6+0r2OPuZhvw28s94mUC9xeUB+CqRBeWB46AmMWD+QTApiA/0As0lvdnxiYOrxFHTa5b8nkVMURKIxqDiTS0stuYKOZzR29uGyL7z4oj8mttOKZb2OSKdnKvfGnzpmIz/TwERemKiyXXj3FJv37NiB+63wLh4BBppcZuF0gVyGmXdYofn84JKYY/IRD4hWqOvrtVnjb0L0jJk5jyVyqBfL9FuETLi/tO6wYJd+XVouvVSxdFvsHq4Wo6WfqrSVWyRSSmaNA1zRxvZygAKCOsqA0du9k0GkvNNSs3XvTnlLdrnYm7GVZRdS1Ac2P+hvocmqgs9PQMVLCTDYG8YvzWQi29Eb2dqSqrZilVm6UjYZB40RWHhe70+rkvBPOe58s0/72oLM/e7CWHbfvlnCLjYQRB14TXk+qV+V+1ib9s5YfKssDRM34wKqR07FT8RH3GLhkF9jSlMidVJ72LZ7uDLgFLLovh+AJ6+jAioRQeQzdIenAsJdp+Ji7ICCGhLBXiF3yy2GlUMdmxcPWmzbmLRgmZTMsePLHjO+3HLNs45vRxkUc3FlG3Lk1iyy6u7ysh4H7rNP+7izcpnXkY2M+povi7LTNRvYRhtWvjP1ySEKxs/27InytyC1Wq5Ia5NeV8ezx0JYgEPMJ1Vh8jPq+0cxWkyb+vZXm42V5nkCjqNh7zxhUerkoVE1A1jDI1uo3iwGi3t3Ndl6/Q4Tz6LFYbzAUpULDPp9UlKuX29/Mo+mk7nL+hGxDJeOtUvS2M5mdmJzrtY3Q8A8W9VWjXf0ydiVZVyzIvvtlHDYvNo37/RMNukzXOxHBW1oe9dPzq/LZTk2PkyjyfRggpHf43RfJBJ65qpR4rbAELhlmGJC9GYD+35jDJf9EG+MAMIxREjh/xdCQGU1yhFiBC/1IWcZTn3An8TW3mapTELZRUr7uO6WfD9rqzdsc7obRmIrQIrxMKTjTCgCDiT+aLlslUTpvUxXxyKfI9MNNpJ1jIxlK6IL0t93sN2phNmOomT959lDYCJoYZUQSL3dbiQWonChLLWdtETm3VkPcWTjU5lN/BVUON64u51i2hUC5nqRxIOj6jfKQMQCsoNHlU/YELSzD2SNNx7cn2T8y2SqLDIVkIqlDwiyN4w2bc3quDG4/8gQEMJ+QtwH8SKHcZhvLvPSkhduwJqvLsDxzDArkeS0F+9otzF54RIeqItiPClwZroPI81H2XZEaZdUO6CMo2Ul4i0pEb1N2GCiXF5d9TBuAeuiOE1rxGAf7+Wbtpd8GLdp6xD30NFApVZTorjivCFn1T3XBrlkGHKwyzldVSC5BEIsSiH55Tlt6VBNUG1wGM/OrZJQKDbbNknYr16vdmzGX27KktI3UeDMVLHAMPnM0znmVD4uyEYbyzY6PJTJ4fRNPmDNCo6UsJjjxJWjeSx0Frv5UNb4l4ND0BxG5mMEKdLoM4g9yjfBH+wuy2G8FKoERuQX0v1I6yfKOoiHZr/4znRd3rVQdAyhYUKRQ+qIiMwn8NyXiNQ9hHO/xR6VlRCixbYuvLQoWQc5GiX8iszHs16eMuLBkbxax1oXQUBzwXC2TXbEjs372+KgL8LG4iKL38Z5P4FJJIAmBRgzwnOMBVt2OMDzGTt3JXlVwo+rrQ/PtbojqvU0qElUWYmnhbOS/c0B1vPuoDtHRlAoFQm0a8zcFAulM0nOC4eE67bZ5EMZnJGf9ahVKMB6tG5AuUCgUuOJYaXTqTY2NArKSVCl3SGV0SMgCbyTyZYHchy3TixNjNkU2iD2Lsr6SySc/oWdijgGXrq9v4XVBE+F3/6TY8VaRji8SIUzTEBr5kkJG4UzbtwcXUp8t49SE3vH+sXZCxCixs7b0F8HzMzAvJ3gVxQvZbPrrUx26Vu+1sdusNofYGDF131PoP1QiGp7ROYdWW/NClVsb0TmnVnv5DzeJJtWrCPzrqx3iq5mSu0VKqVxnU2r+lj7Vy7BW/EuUxWhTCnLq5aqHbnZEK+gx8yTCo6GsggcO83VU3KLtcShUNa7ppcS3k/hz19YEtNPZ811aMOzcoEaBl+/j+W4TggiZEJZW565IaWpY40fmQ9nvRvnyL0T5I9kzU2SDRNW/3nW3JzMXEE34BDab9mbIMvNcYfKri0O+n4ixZ/L4pbHwwsXdkFBsZaF4vdkvYdcGB5jHLwv693aG8kvH8LLNfNQ7QoscvJW7cPdhx2HWSyRFPb3Zr2Hd93ycwR+JmseMTjWPnh/1ntkl7awSzpxX4kSrEk9un2UrWILUygi5PGJtkzczSToo7Q+OibC6YDPZs1jEXpOAd1r4cLBBbu/4ZnHIabpNf75rHn8WPAy/5WLPeVTZJ674j0BSo9dvl/ImicnEunGVBkNxNUraXN2DzhqJd3rjifjS7LKtmKQtZbKUB+wETGYyLIJ27JBiXRyGMWYbOW+MMGLtERvWLwsQAOxDjlL6E737z4czC6lzu6W3N5Gh1g0mmqnZQ+i5T78hsY+jmIwWBAYjuLGNegVAgkvTNkA2Y52Y+xfYWOTUktglKwQ39sdoTXWxSV3uxaKysoGLgusgv++xyJFEVmXT6Td3TdZwSa1dzfYCufA2/j0ajvYayOIAg4qcM0Gc1LCzLzJ0FFRLOcsTpFcOckT2e9G8zZaisnph0A71GZgB1NtnI8AbW1RFd+4vrizwk63IIEGogmoROfSgBT69JtjxnQM55MpHi8osi0mF5GQVwA4Ue7a8fsRiEmBDu4Mo5KoDM5apEViLjueYM6l6o4XWJ6dExseOmLFQeOgpEu6OJt0+z2oNH5uqXlveSK+noWnED8z32A+p3HH5jk5jIB45bXSYHtjyDwrJ5cBOEwpRHC+Qy3kyEWTECkTb2AkCbAoE43/xLnWY98CQvdKkkQHUAFhAlozT0Ank2CCZXhs9+PoYKjFjPDR44XUmdcEnq6xOP/FrJcdCqkyvmPX5JcIKwqGUBeRA345ax6lYmte7Hk5SRW7EduN3UFulfXfHbmNL9/t9aDVZMxKJKdIIf6VLVmN8x0Z5veaE3G+hAUMBQoumrWp8I3xZc1JTbplQhBcs+tJXOkK23Gre2nEdAK4MlpaqXJz7KtZ7yoZjx3JYh1+LWuu3gPTto3YMIxrFHsV6WZpY2Ndah7OI+HPuDdi0yZGL4YdHL5WK4qyU916HeLJMQK73Qh7cLQ17ste0jtvnp/zblBQe5AC3bgbyx7qM+fdNIvlM5TX4xFzd7yYNzdrP0Wmt7ePC0oEbR2C7dBv0bIKcevJTPn2osA8aCrO86Vxr8Dkoi6p9uDk52BUDsW9EBX5EJyz+SX5dEJ1jDXSHdUgiRE8tDcaTnfle7vJXtAenONvZN6Q9x4OdXDSqS0UrEz/CzggwGloD6ZsuDCpZOcSZI+URdFh8USy8onmEegeo58Ea4kN4hwBNSbo6773WLqlbnsAxtmgn8zRx/PmcTpOJV6H+bycefxk2ZBByjPmiZVjaLPxBTfzRzTu0ZLkDp8v4m1hSW0NrNraFhaZF+a8jNw+Lcg3AVNdE0c6B5eRi/g1eFCWh3t7pf1DCfKuLVChCz3Pelxoqr79wd8GxSxbbFJ1KquCKWPTbhllba7KIFnIyD+8zvUEe1TQ7/UzC519hFJAdJHf7XKsi1TD4s0hS3/W279EF97K9HLY6nGVNxiQiM2J6fHwNRmfTo/xi+1Co7TJPooeMw3cAXeFJiRgrrfiOWXd24uXrJ8fM96YHfTvKfdFzcCQPcu0yLwo5wWSLQpxUi2zK6mWktNYxpCdHgfNSXMl8cU5k5e3COsDToYUYvxCo1oXn3mHh27+ZpvTCAnle0nVskikT6ib9KYNn3qzuFDxvJRZjO1Aqa1Ac6NcjKvoj6Ga9VqzIOaGF3balkV+oVYtiBdjr+CQyHDE3JZfPNVrINm6Xi/KpS8+5u27AnLhkdyK3PnYcXclV6uNbTBKrRPK/PVqpVbeAaSdrHFokGROcljR2mlX5KcbT8UDv6JeaJCSu1FCYVJZfvVWbo5cdTrcaW815D2zpOxqubKnRyQV6NLOr4EeQXcthyn6A9py3b90xhZedwQol5PqFXnhgVYyiusrBfcmzg0xP9sDG2Zc8PXKb87XhJ2Wgdk0A3NLDMynGbgSM2LVDfjEMQNeu3zAJ4+MSYGnjgAvG+gVyUCvjAdaGNurLsa//gHuZq5xoMPicTkiMl09Z+foPYNJP3GXQvsmO7g4nbEToyIt6NXYJAfudqR5Lcsgcl8Hs5CPeZyBoL1D2ZUt6HU5syodC9ct5PWeOTFmaal+LEjHFs4p/xpnTinIW3Js3zO9SGwBb8uZU6hsXATNvj4nH4uQyw/9EE9qfC7V9l2cHY84AbG512fNVc+I2pzoDg/kx1PiWm/NmaujxY9txeN4Z85cc96FtDoYOufjgnfnzLVLBS054h6gRG35p3LmOg4NIMXmP59DEhMe4jyhWrEUzHXy5lVyt26rKJPrsh4rt1nbrtj3fOytH70N2FLdF5SrolhIZZL30rMNZElzZHKENMKdDhqTTD7J7DTbSZWVjXaFxdXWAvKr6Xy64omCBmvWdBmcpBcep+wCqa4LNVfQqlFoS/JK6NXfo96pNZtn9HLlVY3KBnhJXV2FivZWZ1NqXhPLNOlrF9xBMw6STMKqV+WMfGfUgQuzc4diaeqpe6Ip67FE+nJFBel2F7XehzY9xwZzBiAuYKo67pFWQbHnFi/zrCMFKrog4rBIRUqQeN1oXZaLpH0RHaoLcUIFISkRyCNywEGnQM1LWHaa6sTHYQLyu2p4DPpVKRJIrjvSm43QHmDT6CGhFrqDMzyeJbA9ZsubrMUELevSP5B80pN1baxXW2b83jwuiQ1W1EBhWFJToIUhN8WVCcTUdxn42D2c70/seaI/TTbFqm7Z6psuFjFtsdLgogRyOxMp1GjrmITWMm+Ge0OxqpozmRGG2ojLFINVyv7SS5Tu4q6cird2ChTYHzgXqZcPEWg7jDS0ljM2lVb97WpN2YNrTQZzwf9y3K7TS5oAWRhNJufjj8nJnayFxvHxy93lv3pa0wDyVbakpCu2JU3Mh5nbpWqtxdvSSF1lbN82OW87uqA9QGOY1kB0GeNdQuVo9Q/SwGrfvB35nC662RakRAtZHmfSioqaD0BwIRahFotMT7seoGKnHYbgslcm7ijD9rnk5PoSwrSHLeNMc3YU4t/yDYI9E+A5dGf3AMroukFAZCtAWi4IpXLHx+sD6LjJ8SFieZt+RW6xdMOBfjNVQghK35jhCQdxuNNvRQRWVlOtqvYMz8IFBQAOSeIa0tm20AOHPWqoW/HBlGpYVKhQKpN4IEjKIGEeF3VEIyR6KZQPpWG+FeTlklKzVRGx1bcb4p2fLMcqy2+wyp3mzubiTc3AvjSZESwEya3GV/2pWXK5cLPQSnLWGHGZFbR1U38se9WmdmJD50Rlfb1SoqLLr7l8bPWcXLxZemrJ2LlCc8krqldq1r12ehUmT+ol06trhO4Zm9wEtkv6GjFg9LJyCnjtApjcdL1O0bKncBLFxiiDvp5dshFyqCDx+xti6V5YO8s2DacdKUsmWQwKULkyQTx0szB5mQ07/OUGOrXxyw8fRmQ1pWg+woTHdTuy0lrxVqDF7A8JcoNlbDdWz7oLDAzNVuGAA5hojsPu6HhciOX5dAHi+27IOLJ2z6SrpNq6DSepR+v30Pp8ujowMC4PBd6msRwogeZjND2C0Hz8aNN0O2WW+QTN5sKSjz5g3W2t6HvTGMCBAYuwsNyZrNGpS33m8mI7V0cpZHgy5JAgNmpZ8IOGHQufTn+8DYHpE2OgkCQjVVAAeWOrVSpq1cEQR6MfKSYLNp8Ftf1gnwO8esX4NmnJ8Qea6cj4vw+LRnMW1edgx6IfOUGZETKSQG1ftEt/cQ/Vj9MoGFE0QX+Au09BRhMOmrXIxfbM2aQryPdmBFiI48zrEbGUlcs7dbQSuTJfgLFTdkK5Ix8XR+bLx9Laoh46CQWFGJuF3vB0wdoXtMn6qfeyA339mkTmeHTslszhAF0rmvgrEPOA9SpUEoU8JWu+xERMXHkkg/BL6GkiWvPuxRY7lWxd9H62UqRvg3nbburS9IZNUTG+faGji4kkb6VAwgWdoz3jyRsX8l1xFrG7GF5od6olHYQXojntwPxGYZtHgFdmrfRN+axRdvMO/uY27+RvfvMu/q5syueLVjefyt8Tm3Iu2iK1ltxKP7nebKI6SZ3CV0BHhCSvkDpXbgr0KvQGj6uXLrVfo+/PXbslf6/DTtrieX2tyt8bygK7sdzh701lGfHN69WNLcVxC6lSoeUG8KA6hxg8H4yjweMh4mTeqkemD5UdRBX2w8K6neyHC1WPYLoFzyPv5s+jyuvS+tGFYlHIfIx7i+Wxemj7uLYM4PHOdX2CeMQ8n+iOfJ+Etufx5LBQl2rfcqYodH4r7hGP20Jl0O0ymDsEcKcM7q66fRvlKcWyFDy1WJaZeVrYUr/m6UrCt53Vx7e3qqWOHfB3hM2ttr6a8p3Vuoznu9ym8t21QrEi4/qe+L267y1udTrKl4J9tYlUUeh3LxWwq3fiySuTtjzEQb+nU8CpIr3e3OpYXBsYsXhaOpOb6sSTqGp4xe4Ap2uVDfuC2Rnx8WQoNdkA2xNMKfMDsdw1MIl53FVotfSKpe3z1mL8lb+SmM21CvMPDcL8srM2qo11QVBxo113M72ByFZx1CyeTc7sbaoaVgrtkrywczr9+tephdw/lN1yq95IhPaRHIdxAuYwPapclY92NJWGx5SbpS0hifRjY449SVpaG+DJdia+xfH1NnkiVkLn7eyUQsUdOKDS61MQ/RBMMcVPa+s3657OI0b8baQFt1L17R13TPLdHeI9RRWyQjKvXmmzUjpTbMrL8L58q6JUUdEOMGVEtDIQveUoycbpVJtcDBMDTtibT8RgJZ5w2+dqXONEWGo3a44SIkHMtaSuCFvVRkLXlVDN42oeSLNK5TUiVrbXazvtSkV6JX0d811sWvj1MgKeNwj/LOhGIZDnTfK0fd6slMTMuoUupDrJBwlang+Wp0P1EOEa4QeSRXS2LuQztabMVq1eaN+9pS3q9m1HUshZXcfT1NrlasFWbiWpu61gWfJOhnrvmdRVS7rsYQuV9HA3JY8oswQd7NGVemsTJSs9Pm69opeSHo8isyv8CayjSrtaIvlEe2XEtvrWeNndKfKsJieZp4axYvsOlA2TY1+y+05UTqWdZL+LlsLu75Hx8fxeLDiN87VF0pDindvJhHHmDjKdOHMnma04cxeZ7TjzFDIqqpJ5Kpl7JKM03ptsAffJZmKn7p8stprvk/XrljbZfyrTSKzc8ur78SI2VKvs1I/8IAA+bdQvjQZYc/LxLC/xwtlMKRywn8qm+xyOFtJFFeDss0HsG+4JnIiD3syq25+17V92AhWUxAxvua//Gz9sb4hYm3I1bNXkg1XCGq88OeanAliCxI9Koj2Ma+YtNfNLx/4aAXEFqyGNvD+w02kmLw14mhCIlADwC6jXgvv+XsqVyC4FTiPKxYqSLM7mkpsRDMXPlHSWE3KtWJjNxBgT2JqXXepBDCy1AU02FXtG/Jh9El7skfhVndLAlsRvsGUuw4XZMxd0L8w7l8S8gAlZqhYxdalZfQmzell5hUKm1u/GQIbp8L0IfJtdDiRTv0oRV48lYT9drhcmNtMQWqQIeCkEVDh0VOfYxagGcZ4GctfpldSJ3CejI/OKvOdXkhoOTCt1IGzlMXJa2pejmnWRSit9cjiWaiiooSPS56tolBQh1MrFV8PFUde91T6gdHEwGlTIamWFpE9JcOhDHOBKR5Wpt4W24ekndz+C5M5Zhr2gs1NoiamSbTb0FRGml1xO9vawsF0hnS9I+Upopdl6LyGMHIDU6jJVdkY60pfSNetVln7iHSHAOqhQgLmgZoN35Dx2nSXnQm7Jemm10Wm6XXuomWajbDP+Ei12zjLEdUYSGbsSr859s11zfpxrMDswEh+LjHkNIczSAxwNs96mGpgRYZKplPCijxpJHZo37UnoniG2w3FuVU7u5Nj5gc/YM3vJCF9HpFTfN40/Sa9Q9EsTL4QBmlqVQ0cdq+d44S/VR9rO26DdXFq+kUWxKHcL8dxgzKGmjAo+UPM8zd60VPFM8i38jmBZ8L24Va2JJOzoDgjA072ZMzS2dhsBBXgsJtu5JestyG8L1ouTE8pvSaJJ1YFD9Fw8SHQNUSASnhgTPH0LoScb+JDrrwsMRXcZqSP4EWUJNFEJuxf7i1iPtPAK5W1ObJXaBVRuCC/wxJSgCyooAtEeUwcyb4NsmXUJHEfEjL3lpuXFD2L6QdzI4RGF8g6W8m6azLfD9CTW3QAxOOE1iaKrxh4o70ufN5+k6+50SoTSvI9W++I6mveza00R9ch8AKFVKTIfRILc7UtiB6NR96L5UN7kLEhdU6HXfIQAvL3/Y/48b1YOujO2QyIeebPao3/zsbx3IiZCW7lxOUddyU/CA8kZyKrnz5PKZRcDkL1H3X4SmcuLnc+f1SoukyvoUBcE6OVDhEPuq3FsU1BF0tnksIY9Fu1SbexsV/Ubpn4TW6Z9GRg3XizZHWvpW7MkE7/RmtqRM1Y3um9F+G73DXQ7JpFZJsz4q3NH23uYoH6C573M0WS+P5jV5OuPaItgQNScgcSjN+9mxhQWWq0TEA65yHpfqpETUFIhPx11L0VNjBaUxkqScTxb3RSZWFCWmglB5UUxGr8lIvOPqbguEvWPqRiqdMUCt2iR6V4cRub7qTodDPrMP0Fzy/LORO4UMY5Ai9wYMhZRR/oRMY0xdRyTWfMiAEnY9v+lCByP3Pgrc4f/w4xqadqODDnY48ApjIedmctNJ5vOJtPBmHJJRsblpSaO/B0y0JWSrr0FCQGWQjSdzOX8IX5D6l7Sfk8rblgDJqjbdbpol1uSuQWfsTwOR/3aZDJlFxStNNDfUFzm9nGVXBn73GE0aI5VqASQK6EWFv36PbLpe7efx/zsxfkWyq/AOaj98BRKKeP57Kmk20fvPfkZjNQ+9gkbEczWXyyJ7//1AcoMpIGx3U4h88HYJ3qhTBFkaqjKmEZVUcaXC+4IisgNTz9dg77nUukTMO5Qr59ydIhQwmd097g6bgzuP8s54ETe78vAGD0rqfabhH9tuglzJIAHMRI8tkAyH4cZcTZV5xMehhHj158G2JZymbiCrBEvO+/K9/6Tg6KDoSpO+eAQarM/2JNf8tpWS3fVZI/HYovRwRbVBc0iDEnt0J4ZJ1+Jm06ieaRvU5Lz77dHuPQ6nHdHw56MOprP5AfsAGYvXNYVUe28l0uwr4svpF/rHcQdMHaZNKbK3+seDJFBtbOgIjKfzXuZFE4gn857WaROcEl4s2d/qBEyXB+KAQkS5J7PKaKFgFNe60oydryh9JKurACKpW6ctlVtS4VFSYs9BTYkQ5tICm0Z0VrMdW0YA+La5vNs8VrVfDGuo+ZuLLXGY5H0B/pOjVj93qIKWBDnC0PHLy9i6FLFj1xbgtp5LxDmaCOkN9LXnLcTHuPpMgLzORrNHGVfYpEMLPqvsOPoJdgOrRKnTNIsns+IxDpEsEXrWefELF581wAQT7G53R7qSxwiyQWdJgHHHeIkm+jdMqEngJkl4KJyVgwdfKH4FYuOrEU2YPEW6sSi7IolnEnspFPgjG0B9CTSk8r71nNJQdSKSiFHyQ9Fg1r78xvII4Jm7wsE88FF/Hn2Yux6lIhc5SzITYasfGipxJYWmWeveDnJtQcRy5CQw4qXt/WeeheuxErcW4c60gKFPndJ7UO/2dRgRkj73dm56HSkjE7I7FBukX/TpjOtcrRx/I4CIjEGJMM8sMPWH0Tzh1Hnkh4YsQGIiMTvuDx/xdPXC0rgKKG7wS4CYDc1Do7k4r+VtTzyeHhw0MUehor1BAfEjrtKGnKtHJSbuHRYHsSffgkKVYtfi7ERGKGLBawgc6JHzIs4hLqsWkfqmPSppHMEED8JcGPG67W/ajkEeHn7RZAET29xocyLIK0HbTJyuSCy5rm2dYYPz9oaxFY5BO9C/kir3PF08kbKjc41xT/szRZHV3BtJshezPB6ljDzghUv6OlWqLObSdVXUcpahO4n6nzvwGImHrIiX9VlY5p1nN9qGfTE0lZoPyFhOqyxDqun1dQojCeBYfxujm4tQLzyTkFzO+HdW8T9AcLgBNhqtjkJq0rdjAWDWr3NrM2q4Z1bL5QqRIXOUF/x5hNASb5fudPatJ78SgKvbOMZ2lLgqwm8UAZH0ueJNDwhcI1gM6PSiATVNVRxMh5qcpZwammwi9Z6mXMBT/V21XJJjTM2zvrUa7x6UdRu4pBWFv1ckxS504VF0bWLovISuuvSBQllnHctoDAGbOrj33AvBzFbxcpOZ3OrXmwUqgK8MQYmvd0UQ3RObhaGlDYXxbdsNJsbUEfojiCtRnBszQfFBYU2prSCHuxAdZaUAh4SA5rFxeBt0a2uKDxzLy4V43Pwh5akh81mu3qf+NZCM4FxQKmRPZywDWKwhcmu1y0APUJ4r6lHul4QMwnnCM5HORARYmHYo112q8YUOthjGnK9pFPYYBKTmX1sAkzPwuOsCHNeUEsk8fH3NeUjLIXUC58c9p3pIIJCGNknLq+5sm6bdhd5GfpL41hVzN6ZfFibkqGmCfaxXFOFKKFYUQ4FKnfpsA/w/6YT8KJ1O4LSBPJTJHRripX7qkqiFwrXJPbmF/XgfpOQpWzzfmZ6uxiH3vT2Szz86R2SC6Z3SC5zZmDvLTQhXvGDm9AfaAwMqVV4es31dQvyO0P7yZwWgSmpbInxC8WQc7NOhSqmXZHzcQ38SexGX5YM1dQxQZOgCnBTa+oHbjzWMCcrBUv1/wMBHwAA3Vp3eFVVtt937+QSWgi9hBJClxZ6u2efUCyIiJSHgKgEQolAQgkCSmIwNIkiKiPYURRBBVEUGEnuBFRABlGRUbFSVMSKMooMg77fb53cczLPeVPeN3+9fN+9a+Wsvddae+9V97mhkFZGVVl25KnbKlddrsYtKFIF4xNnXDEgc/rgUaM7Dejff87gi6d1HZ1z9cgJqqaqpUK1VbJqpJqGQvrpQyEd0psOhUxsYpyKV6pVXCikdJwKYUg8vrUO4dtoo9qouLiQUlrFheIH5EyYM31idq4KhxJuUUpV4Rf+PIAZ1Es1VXE6/qqMyRNTOv3dgTX5XQ2jlZbxqRw/MDt34qzsjGkpQ7KnzU/pn5F9Y8ZsFVb/6+wV0FfWQRYhiKwaP3zOjBk5s3Kzsien5E6cl6sOYBGTxqeNnzCpe2annt0nTZzYY3ynCd16jM/sNqHrpG7du3fp1ittQs8enXpM6KY0RnTq3akzmNcuxFfdW5UqbapaAy8ItRmck507e+KsWRm5atjEyXOmZcxSwaP2sUcXhfrNSZmWMz9rSkbv4wUb2qeMnjMzZ1ZWytSM+ZOy5mfkTsuSp5fPycxImZ4xK2dm2YO+mRmzp0zOyE65MSM3IzszZ/YUcJuckTI/Z1ZmxvSU8RNnZWR6I4ccL7hvZtbsKSm5WTdlTc/KzkqZnzFv9pSsaRnzM7OUrpTg/5lQp4TyavfLmZZZXmf5f39IvR5Si7RarLHL2NFKOOeKqoJKwA6c1KGlSq1ZrNRRHR9ShRv2JOvFKn2gmfxh83Ac96XCraDFq3BlHOWiEScG6yXqsuqGlHLkyuEmIC9+6vswZhccNItAKUduEu7gkSfppargvwzEpZQjdwiP9Mh7wDxpE8kF5cgjw7OVyYYhiXokKOiTX2fz0oqwx5C+VRUsDSihcP686PWkaF2oCmYHFB3O272/KSkGFFUcUEw4b0yvrqTE6UWU7VPiwvkXjR1CSjwpIwNKfDg/qX1nUsKgqHUBJexzqwBKwWsBpUI4f/f+DFISsE+qekBJCOdnn+xDSkVQCnoGlIrhvOKBVUippOUAvMeVw3lxbWUDtF6o1NKAUsWfUJlbMzCgVA3nv9T4YlKqYAPSbUBJDOdnJo0ipSopXwaUauH8Q6nXkJKIxRwdFFCSwvktw31JqQZKyoMBpXo4r/SR+0lJAqXgYECpEc6L5tYkRYNy9HRAqelrXR0bkFYxoNQK51+yrQspNUBRHQNK7XD+glodSKkJSsqIgFInnJ+wsDYptUApnRtQ6obz3z/YgxTOKX04oNT351DOjNKA0sCXUxuUtM8DSnI4b170EVLqwHTrqYDS0F9pEihbEgJKI5+CA4XRi5sp+MjfHmhASfG3pq4caEBpGs6vVQhf9g5UtQgoqf6B1iPlrYDSzD/QGjiCdDegNPeXycMpXR5QWvga1Acl/ZmA0jJ8ywsPVSOFm6YaBJRWPrdqoJSWk9PaN49EUNaOCihtfJOqCkppQUC5yNe6Digp5TRo629nEihXlQSUdj7F2+hJ3uMOv93oMkpHf5kNYhtdRkkL569tkEOKbOc1AaWTr1gNbk1cQOnsb0AyKKVDAkqXcN5l286Q0hCU9BUBpWs4f3PDMaQ0AqX004DSLZw/Ysd1pHCj0xoHlO6+nMagnO4fUHr43DQoaTkBpae/0iagnL4loPT6Gy9Y+2hA6e3LoReM2xtQ+vhewDnjjgWUiD+nMbxgpQkojq9bPVDS6gcU6+9oIihHOwQU1zePZFBO9wso6eV2FHKGBZS+vhx6aNqUgNLPN48aoOybEVD6+1pXA2VDYUAZ4JtuI1DqrQwoF5c7nyVKrQ8ol/jcNChHdwSUS/1TqAlK+q6Acpl/CtyDlEMBZaC/B9Qt7fOAcrmvG3d07Q8BZZC/ozWQf1vHBZQrfN3qg7KmakAZ7Du2BmVlOXu70tc6BZTS1IAyxJfTFJQ17QPKVeH8fLcbKdVASe8RUIb6WlO3ryMBZZivWz1Qxl4SUIb7cpJA6To0oIzwz9Rz+T3e45G/dfkyytX+YlJjLl9GGRXOv+GuTaQ0g8uXzg0oo8MLkto/TwqTZen6gDKmnGJIiRcFlGt8xRgMCq4IKGPLmS7qiKKAcq1vuozHBccCynW+1nTFglBAud53RUbDguSAMs7XoDkoW9oFlIxw/oFH40nhnHGDA8p4f059UFZeF1Am+ObBOTMeCyiZ/hyGo7VbA8pEfz2cc/TjgDLJn8NAlXQ6oEz2V0oXmVLuTKf4LkKHS68eULJ8w2kBSkrzgHJDOD93SnVSGEC+6BpQppY7hSVq2YCAMq2c1ktU6zEBZbqvNUNL6fiAku1TqNuoqQElx9eN6/kiL6DM8NdD9923IqDMLGdVS9S8xwPKrJicsA4FZb/XBih9y/iknqbWzdbWS9KRVQkjzcjmTevPX/jjs/ejG/y5kio/Jdbd/JNZa9GshSreElKq0mwFf1kqFTZqadhnHD4jF6ESBnwNtUB12F9P9hJqIVwOgweisrT4fInKbxDc40EMPAj8NHJTRUzoiMQ+Aml/LiYVAT4MwyoF7XNEWsUaip1HOWaqBT5vIYG6SJXLAZ8BkwaY6MLuRgEWgCGeoSaAoPITr8FgqFs6BHAF4KeQ0hh5sD9gDuAtYPAoXGEvPseQTwwibf0lyEXMOvh/GP6fgkOawewA7VYy4oO+A4a4CyZ3CPTPlyAGM9oiElZlBGWsBN6e8Y+RjjGN0YsdUTnlSufis34Roge25wrsZxHgMawghE+yeC59lN5Iv6OH0ZfgNfQPKFAdCjSHbXWlHdNil8A2aYV4lgelV9CG2Aei1w4VhEJPoLNCj/jHUNztJrRIq9U6VNbQV461hl5vjruEWxSxIrVlegMijXQT1RKcdN5jNzXOSz8+LK9B+oMkGH7hLiGkEnEp0UFvxU2DKjH4UuGWj6KX/+L8Rgf/KE2ka5curr7/viOWiFmxOtEl8u2CJu7kSS1d8966NPf+++q7hOsfiPMeXJ34jb3+pTbuhKT3rPn8zVT31t+9bF/cV8f9eugOaxaVVsKITXbdxT9ZQg1R7uVVdluT8VmSINvPNHJf3LfNmqq6rds54RlbrX1nt+3Se625/75ebovwQkt46+/6ew/qHjno3D6tlfv6gSsck+fWdsFQVX73hAXwFgEID23+wXzb/INzju7w/EeCmO1nLgii21ZwZ0+pbs3Wh6q580+1tIR/vjDCe0CBHLFhT5GVKbbSaksehDrrrukBUpL7ttUXjX1DEJN11zeCPDHjgow380+F3edmfWEJyUge/GleRZcjuLcy5Y2zNV3yINRU2keoq1qiVWhZnftsTg1TjPHTBdk7qAdE3RMxl1fRdnSvrk7vF/Y5p5/c45ijQ+5w/vBIA0u49aEcq4lc/1JFV0+eNAnHVIYs/F2hNUSuvbOf7XnbQrtrf1Nrrhy/0pJjVf20QPP4jBJBNu75o5Ud29TwfRl6ePBxmWrO539pG43JtIT39i+ymoiISe7YyPURHIjSK1Z/6x0SkavuqGt1wQ1/xW6+68DSvrW9X7jM4f5VfnddxPx6eIesNLZ03Ep0VCGsWU5XE9l+xnH1O/OyYEBlCCgeCVCpTTDuh797Uqab9w/OFQTmbPuN+yxiJvb5xMmpUei0GXun0yIcsgZUp+dtfTkKG3ab96Brl62WI57+/pCVKV27nKFvYPHaFaYb9lR2KYXQUH0iK3f/6I3onFAFHnTGrtxd2yXR0JUu2bbVEooUIhTLEaIHp1Ax8hBNOQ+6FFMKobcqkB0z/eROQXg+R4dUtebTJz6wc6NNbNpHn+JY+1qzoNa3cj6EIo/Irv2PyoimW573ptBjyeP1AwesMK0f946lFELzxtl7BFlVb5E34rlZU2QKfUZ40BTIlFCkEKFYjhA9OIWKkYdoSqZUnVII1TIYepux1WzdI1dGDe2ZCE6VhxLFYRRGYOjRyu82K674TMOorlmY7nROaFdift94sQO/KBnd6wXnih63lRhsmvPpEw+UzHQqWULsaDtBvl3gQtScEvPm2eH266E9S6hhSW7NYjArsBSlTz+5BJa52oE5ncJKYL1vpSbjoIA0++D3jAslZkDRM7DVfSVvpT5gISNqZjrL7aspadHz+TfgXN2ogcayjNhyVAgKWoS2Ys0DFHZYhCcg665NcOEXHCDeGLULV60xKxZzlnHQz5tABBSPBIhYh5hs7/6moWsOpX7gEIEPOT8Pb+aaZXVGY3oblxB26z2o+ExERuTU6O9NeWfeQMZ17MFA1/zx0YsFefbSDPvzcIy4+5sF9vEZjkv4xlnwIPLF+TZlI5q55vSTl4h88iCUqLVz4AFxBsMEQeTn4cb9feN4F3EmSWLg+wfruowk8Kwmbu3Ney1hh+cfspoIFuaFCkAPmT3lLiuhgkY3N/oJ7G23NbOnvGXXZB9Cytkm0GBpghy/aRUOaL/FihbLUAbVau2ft4ZbSHslbNVpmf3tngqyPRZYfMS03Ws1Nyi928fWnBs+ATzPwaDvgLUjHb784wZZaWzp6jPEoB8Ove7xJsJop2E99GQrCPWgvdtrMndahr3rX3qNGm60TKiwaIESrIlck9nHZnz2JpddXVZ3+7STzms3RmUNDrOsYYYEe0ltt0+r4MpcqkOfIzQMZ0TgeLIAs3NgFfen1h9awuSOOAAi0NlTGhBGdsm22dS62MCOBMFZ0sEj5uZamxFHqznYX0TwexyD4O4wWhIO29HYyoPIJ0Pofs7U4lxGuWec1w/cjhVUwp6stua1G61sBRdMqHmCPsIV6CVf3SWIabJ4qiD140Za+rI4XOwz4kQL7wGc1cLaccinHHNh40zLBPnDoTsEGrIm8teNz9kmi79yMGUXhFeka9uba3Ww+s8XDvMfB5tzwBbcEHHy3BcZRyImvdvDsgGxHVFPwNw/bh62jOym+3UvOUS2n8lD7Nplzb39K2PxbyA/Vnb+68Rn3oPpJ8/LCCmjOKXJ4soueRAahBNBUORYGYHDtZxCKDyIkClHiBROoVjyIPQ0onrCngjlyQKoAAMoIao0Rx606pQgGqGE8xbBIyEPQmFPhPJkBBXgFELhQYRMOUKkcArFkgchMzgNAB+r8YVC5X6r0z563PoInnokfKyaq0KRT+4U89NEEOqtnnPPGosmzCKUFvaGKboa/i6xDTFiM8waRQirBkFglci/IL09ONVDGL1lOk9TGBKBBE8EoJLoRfsA453mw3P5gmzcM4gwYubcUw8L7um8f/Csg6jimJqFpc7xm2ph8aUOQyLSSakzeVLY1S//2BqGWoZwfxAhWjPl2Ke/H4bUcJBFaZ6FcTr9xj0hUOyQCDPuiBNPOCiLv4KbHcaW/GjbLq1jIU+5TLCEShVQnkJ9DjFNt9QIECxE6c2XhgKEgvWqenHuhY3fO+aazPPcb2d536M2ueNHEYTJV7nCnbGlq58QvRiO+Q/ibrYgX7bsZFG3RnDep1A5LXTwkNbsGPoIwxMhE6k8WNvgWU6D471OmznlMBuQh1TEZFp7cwUJ+oSyeiJQCLn0V2uqjzqH+vw71CtxrsS9kYlVXcZ/QpFCJM/tJn6CkQ5qx5+h4XSkuQ+5cRHTIryLOuykFEIVWt53rQxBKisWhEUWewcpaBm69g46ayV0vT1Yo+e40hKKPCI4GMsRLJBlCuTgXN+WwliYQhNLKYSGVQ8RGp6MYIDxptT0ePBEyJRQpBChWI4QPTiFipGHaEqmVJ1SCFUIpTpUvCSqibDa0tyTj5svsfrzN7XLwk4QMZHRvWoFiD+LiFTO5Mq9MqlbZgmC6gticO74QjQppLrIkBe8c0d98Ntz5wg5d04ZUPQ16pyu3rnDwOWYKYXQtO60T5CbTn3ujUDAcDmFaUp4TC2u5ZIpoUghQrEcgSmOTKFi5AGJEcOSgqpTCqG3Ku6VdDZE3jz7b5375Enr5dy3nynxzr3Cwj8hBZWdO5nymB985R+dO6fwVIUHj5lMCUUKEYrlCNGDU6gYeYimZErVY2tRW1AvLird79UtRORY0U17sYcIq3XEyWb2yvFwoe7X9bZrG3wH1XLsh+d+sWZN9t2y+6xxCaXY7ZzwtUWLs12QlbtfFGiYWnguzJuERrddKkh6t+uk6hKFWccQMptrIlDN0w1QSYUb+0eeiqIc5yOgeCRAFB+sE1bVa+4aljtEeiMzP/xdK9dwTzbsaesSIq54D9ot7S4jNjXs7U1hBUcehObBV1IEYYLCXrhowlyUj91x0eGiyAQPImTKESKFTS/FkgeheghL4Pkgc1pNhuxwNHKCt4Rq7csiMWojZkOLW5X7UO0stzo2639sARXC6A6imSCgeCRAbEHP28pC+VPf3w3liqz+S/5T0O5Jiq3rkWJjpPBEZe/xIAKHcKDDEehQicocgcIbeKNyxEIE8vweJgGL4m4r7OI7qWkJpXgkwjsHepZh0mf5y/TFCkSuGJikUMZ/4rClZ5JjnDGHB48Xe8r4bKVANGuvCvLspcdsvvujd8HCDpRw/qn1VhOBzp7SgFg42w26LxJfuiD0jX7jJkak0sVWOnOjjwAWOQbpl7060zCLTysPWAyyqWO5Dh6ljF5YX1V87rBIg31QWK/BqS4SiMM8GiAoaa1mmUCEgU2QDs83whZcZw3UQ2fRj4rilqq+94A1Pn2NWiEGXYp6/SrY7CKBuCF7TBC6iIzg5c+yOkccHgXNTO/af0w83gy9411WDTCNEmaLiGGJxA2I7Yg0zVwvipMoPVEQxEEHBhxFQCx8CUVPFE17MS6FoiiZTARuIT1yBIdaQkUQ9qOwg/scbEkUYgSa+JGJ2J+qUVg/g1OJtPSwlJJNDcdYlHglmkrAZCL62jtvxRkmO/rLlt971v+X/Eqe9cePXGFRI5RQFSzlVAl7ZBxf1LAbwEVflB6GujLKphB3EIOiseWo0K+H5yHuzGHTXNhb2FFLQdjJYKajY2PUdhj8ueEnxFc0kb2D6rro0E7gUqCNC/WYfLzmdmIfF368XCAXLgj9KLkjgsNjF2+zb6X2cUOqVGKCZsQjD/YsiHTtXNZH8E8XXc1q1OAd5aqQEPUNi/KOsPersFpMQZ1oc2o0cwlRu7maCDbc1Yg7uEg6YwWBzp7SgDB4mHKEba4mIutl4vMRn0SEOe2ox4CIDPIyVRkCikcCBO/ULT/A1L1AKgj7aByya9hdMuYRSiAlwkDKEbFACkd1XPIgFO8lQmfHOngREMZdbnckzDCuWMGDCJlyhEh57cZfRCx5EKrDCKS1Ny8Veza85SUCa7Wo3R05QBwRfPeEOLTsEufJvvkIz1fSGh1pyVdDpfRAgr6BcQLpoUig3AwQ4ZEyTaByLsX5GMcwv7GXZS6GufWRs8XwnTHV/s1TQasDZ5HzlBDOXZKg7iOgeCRApXZgFxin1j/wyk5EyXhBGB4gO2LoZog9DFw7obKjUdyhZK3JVrLIQVnscN0Y6uC2sCZi/XR0Jv0EypqJELIdRhmwDtE51aVbsdnzEMQJV1/R4zUYZRnyU+ux1hBhTGBrxQtaw0sV6hZT9v/SJODzt8Xi1oe8JiF+5MF/pUlgPU+EBb40Caz4Ec6g0D9qEh67uLu0EQhnjvQV3BZsLRcYkc4DOvwHmwTaEkcwfMsUr/IrKxbJlDpTCqHUdURY6MkIWok35T9YLIboiTA4JZ2A5BvuGnKHlQaANawgYqjsDXwEk7xZgEq9jHN/9tK+uLfDiVzYOFSQDs9f67LTRBGW5fIy6r11M+SYkMvmojh/2RL+1PpBq4mAjdJwyABhd4/sNFHGYhV48J41X7Yc6tKthu+wAvHuKE2Q00+2RGjBXuE61WW6tJXq4jod1yF/3VhdXiYRMs9rIpCiNCteQA8ReUQoj2ck8th7k/2XLZ8TiAf3CsJXJSKPWZDyGLBEHnee8ghFHhFICXxcEAkXrMh9ZFW9Vyz9GUUBDJf5gVf0tHmGSsNijzuLKxaBhtGYCNt3fnAbxjcQJ2E71VwEB6ufm5WApm+PZQ6XhopvYC479hde87WTY4qdm1qIsIP41wfqKbmAEe/ntaIgtlIPb8+YwwCVpqe26tTaxeZFPQTZ0FtejI9whF+6LDN5H7zA4mYmUa6PxY6EFBujSuLkVkh8DtVnF0HgBw7DMQxrJqKewT+HIxglt+S47v/GwU7tQCAp5sWjVHdSoCABO5cdu0mgRD4iU4tfIFMHyf9V+rpDuCa7Bi+GX2UZgZu1nbhNSbeGMYPp4+fh65DyxnivKVg3IoaRlzWMiuybGEzex/sfuYflLQxKKofJwqCSQF18J6c4DCbQtCdu956WSyNcGHkPaGewE+eL86d4+RnFzcl5iwNDOYnCGRWRHDLtjRBvaR4QhHmKNzion95An6lcFql0NE3zQRagNUepjGV3QIsW43015TTsdKFASZREmFCRT2lCXzmoWnHl+JXDVlEe4KUETjgBD5/mW6JkGP5jbJdQ/WJR3B1es/F6jAKkh6Sx0opY9knryDKLd+YsEQ0lvLjvRkS8o3RtiyBxSradkBdo8oBewoiBotuRVfL4ebcv9pCOq1ec5U7YgkC5q+PxcXMQBT4UhK2FhCHcAUsYurlWoheG+MKYrk4oYYgIbFbMN0AkLBDh2PfWnfbCAhsVRgHeGBLiKnCNIEig2J3jnnUwLKx/YAC2+18PCxJjSfIRCg7CQvVRvSQswB28sPDnC6tkpbGlq1/gRrxDZOmMJqdAkMdxPQJDjaJrP+OgSY2yokDSKMHLglPwq8ISw0oL9+AltHr4lbxPY3sabTTmcYGI3O8KAp8Es20l8CvDxriEkP0VKgrj0mLxajnsBVumFL7PEIRPdf24OgECyQ7Msg5uJO8pYUpGUxqF45wUrWPLYIMtpx0xSCOCMD7ADhwxULTWDh464sosI344NFjqCqogD1jncYTsIafwsMiDEV+Ycu8ohRARZLcgyKAwUuXiVeh5bLnX1By/6TBfrSS6ewdtR++bKAuVB7gzkxF4Z8K3p+dFJHmgTWJY2s0HEUohVKG3Bz8Gk9/oGLYYROgYaHcdeTkLk5W4TjUN3yot7zvOEoo8InRsjmCwlyntlr6DxPeuZ4JkyqOiFEI5UCJ0ORlxdWJ7mcJ9Ex5YokOmhCKFCMVyhOjBKVSMPERTMqXqlEL4/8QPeYySlX2Egv8dPxyuQkwPYMgV/L2+FaHUQYV1q4f8tmfm+zfMZq71+EiJzboM5rMTgfd+QaafvBmucDgiPROzIkp56IXSFtUbHLU7+0y49hIrD5jZOEKWwW2hSTAlSwHNFzBUn1II4eMnBGkRDqEAvGDZnrusypfVqe9KmY7SEdftz/LKAh4AKUTgdDICXuDIFCZB8kBoiQhTqk4phP+0R+JARJdmsD2UpzwOCPEQTPJmAaLkuOzYS7IJEq2I8JRomFKJwxmdl39MgKc39n7kw6KZUBQnwrKaI6TO5hQW3uQhlTiZcr8ohVDSEBHqJSMQB6VWZywQHvQYMiUUKUQoliNED06hYuQhmpIpVacUQnUE5850yr1Ch+plPJ6s7Ca+GML/yT08GzeWaEeHvG7ZwDu8xV3boKP8TAkxcaocM3/LQOi3VrzgA1MvnvHcaZpyD8+Ix36XUKQQYZvBGg/HzX7NK/YIme817p+QwcsQ/rILpWac/MRLM46xPcc13HkcwAZM+hYm+QeLu8PjEqUwxytSGHdZtVBXQhQ6+YLwXZqM4AtvTmEZJTwY8nnNSbiodLnVRBi6hILwjPvwJNQzjfhCup2cBiOHnAbXxlPA9gpETRYVhB0cHRrv8r7AXhfjDerP4muS/jDcMSy2ETNwL/kJUmdRBOHSe7UWO031ItI1QzZbaGzYZkG4EaBG8H5+GCJzOuY3QemEV4yMuWzyeJLIf4w7I+Rag5BXtvLgD4/w11mPSikpU7ARuL1pgverDfjSfxhqsVa4jimyPxxq7yImbsbblK4u9SDErfevgvCXeTLi8iqpLqesWN0BDQR44LIU/yS6hwf3o4+zWR/oUiyh6EGEEjgCOvFg+7jMI+QhayFTLo5SZLUUy+VTD0JvZ2DvDs78rCB4Me/tLPs73hC2CDfFBVN1iwuQtrx6QlxLQzjKsYY3VqxDCUUjIjwzjqBHyxTWJeTBxQjTXw7XcyklvVtjV8Qi7MjOEBrWn0RoezKCtscp/AmC8GC4IlPc8knckJtgiiUUPYig3uE9IFLZDC8nUXXykLWQKRdHKbJaiuXyqQeh2od+Dd2x8yHqF/Em7ioyxkcohKAmTlQQZDiHv5HExdG1uBhvi9ep1zpyH0fkqjt6yAiejEzh/SfNhRCmGg9HcLFlNeFqGMGsgct/9NmpUBM8iFw0tqNcHhwdAjNBZQkzb4vuvxEuiVqzW0lGwGgpm4HRLn9L4ekcU57v9uFyEr01EVqE/B6GvqP5moqRAPXjAKyxDKF/6VgwEoQFhtSy6AIdjHkF1e1MR7NS8BFI8EQAKvUAdhDNVASo0gxKPBL+5AB1wkL+rPMb726PsUAQ/igS7m41YxuTL7L5EU8D9l+C8FKMPSDWucpjyJIYEpRmIAVUuGos4BlaXffICipn/eylY/oo9d8=(/figma)--&gt;\\"></span><span style=\\"white-space:pre-wrap;\\">Bu loyiha: </span></p><ul><li><span style=\\"white-space:pre-wrap;\\">Yuqori kayfiyatli</span></li><li><span style=\\"white-space:pre-wrap;\\">Juda maroqli </span></li><li><span style=\\"white-space:pre-wrap;\\">Adashgan vatandoshlarga yordam beradi </span></li><li><span style=\\"white-space:pre-wrap;\\">O’qish tizimini yaxshilaydi</span></li></ul>"}	2025-12-30 16:43:36	2026-01-23 14:11:13
516	156	\N	\N	\N	ru	{"title": null, "description": null, "description1": null}	2025-12-31 01:02:51	2026-01-20 05:41:52
488	148	\N	\N	\N	ru	{"title": null, "description": null, "description1": null}	2025-12-30 16:43:36	2026-01-23 14:11:13
489	148	\N	\N	\N	en	{"title": null, "description": null, "description1": null}	2025-12-30 16:43:36	2026-01-23 14:11:13
515	156	\N	\N	\N	uz	{"title": "Universitet Tanlovi", "description": "Universitetlar haritasi", "description1": "<p><span style=\\"letter-spacing: 0.14px;\\">Loyiha Haqida...</span></p>"}	2025-12-31 01:02:51	2026-01-20 05:41:52
517	156	\N	\N	\N	en	{"title": null, "description": null, "description1": null}	2025-12-31 01:02:51	2026-01-20 05:41:52
189	63	\N	\N	\N	uz	{"title": "Farg'ona", "description": "Viloyatning eng qadimiy shahri va markazi bo‘lgan Termizda va uning atrofida zardushtiylar, nestorianlar, buddistlar kabi turli xalqlarning shaharlari va qalʼalarining xarobalari, meʼmorchilik va arxeologiya obidalari, shuningdek islom meʼmorchiligi yodgorliklari saqlanib qolgan. Termizdan uncha uzoq bo‘lmagan joyda esa, fil suyagidan yasalgan shaxmat donalari topilgan,"}	2025-12-26 13:45:33	2025-12-27 07:30:12
190	63	\N	\N	\N	ru	{"title": null, "description": null}	2025-12-26 13:45:33	2025-12-27 07:30:12
191	63	\N	\N	\N	en	{"title": null, "description": null}	2025-12-26 13:45:33	2025-12-27 07:30:12
192	64	\N	\N	\N	uz	{"title": "Jizzax", "description": "Viloyatning eng qadimiy shahri va markazi bo‘lgan Termizda va uning atrofida zardushtiylar, nestorianlar, buddistlar kabi turli xalqlarning shaharlari va qalʼalarining xarobalari, meʼmorchilik va arxeologiya obidalari, shuningdek islom meʼmorchiligi yodgorliklari saqlanib qolgan. Termizdan uncha uzoq bo‘lmagan joyda esa, fil suyagidan yasalgan shaxmat donalari topilgan,"}	2025-12-26 13:46:34	2025-12-27 07:30:47
323	84	\N	\N	\N	uz	{"title": "Real"}	2025-12-28 06:17:19	2025-12-28 06:17:19
324	84	\N	\N	\N	ru	{"title": null}	2025-12-28 06:17:19	2025-12-28 06:17:19
325	84	\N	\N	\N	en	{"title": null}	2025-12-28 06:17:19	2025-12-28 06:17:19
347	96	\N	\N	\N	uz	{"title": "Saylov"}	2025-12-28 06:25:23	2025-12-28 06:25:23
348	96	\N	\N	\N	ru	{"title": null}	2025-12-28 06:25:23	2025-12-28 06:25:23
349	96	\N	\N	\N	en	{"title": null}	2025-12-28 06:25:23	2025-12-28 06:25:23
371	104	\N	\N	\N	uz	{"title": "Sasuolo"}	2025-12-28 06:29:41	2025-12-28 06:29:41
372	104	\N	\N	\N	ru	{"title": null}	2025-12-28 06:29:41	2025-12-28 06:29:41
373	104	\N	\N	\N	en	{"title": null}	2025-12-28 06:29:41	2025-12-28 06:29:41
470	143	\N	\N	\N	uz	{"title": "<p><a href=\\"http://&lt;iframe width=&quot;560&quot; height=&quot;315&quot; src=&quot;https://www.youtube.com/embed/JhUEpd9GjRI?si=QapSvR0lTl0YTiAp&quot; title=&quot;YouTube video player&quot; frameborder=&quot;0&quot; allow=&quot;accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share&quot; referrerpolicy=&quot;strict-origin-when-cross-origin&quot; allowfullscreen&gt;&lt;/iframe&gt;\\" target=\\"_blank\\"><iframe width=\\"560\\" height=\\"315\\" src=\\"https://www.youtube.com/embed/JhUEpd9GjRI?si=QapSvR0lTl0YTiAp\\" title=\\"YouTube video player\\" frameborder=\\"0\\" allow=\\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\\" referrerpolicy=\\"strict-origin-when-cross-origin\\" allowfullscreen=\\"\\"></iframe></a><br></p>"}	2025-12-30 07:36:01	2025-12-30 07:36:01
471	143	\N	\N	\N	ru	{"title": null}	2025-12-30 07:36:01	2025-12-30 07:36:01
472	143	\N	\N	\N	en	{"title": null}	2025-12-30 07:36:01	2025-12-30 07:36:01
417	129	125	Rahbar	rahbar-6	uz	{"title": "Sadikov Baxodir Talibjonovich", "description": "Sadikov Baxodir Talibjonovich"}	2025-12-29 08:23:08	2025-12-29 08:57:25
418	129	125	Rahbar	rahbar-6	ru	{"title": null, "description": null}	2025-12-29 08:23:08	2025-12-29 08:57:25
419	129	125	Rahbar	rahbar-6	en	{"title": null, "description": null}	2025-12-29 08:23:08	2025-12-29 08:57:25
420	129	125	Rahbar	rahbar-6	\N	{"email": "sanayev@vatandoshlarfondi.uz", "phone": "+998(55) 502-22-99"}	2025-12-29 08:23:08	2025-12-29 08:57:25
430	131	\N	\N	\N	en	{"title": null}	2025-12-29 12:29:53	2025-12-29 13:02:43
431	131	\N	\N	\N	\N	{"url": "www.youtube.com/embed/1AHaFE9NOYo?si=IDkDf0Zvw7cyALnS"}	2025-12-29 12:29:53	2025-12-29 13:02:43
567	170	\N	\N	\N	uz	{"title": "bersz"}	2026-01-05 07:12:24	2026-01-05 08:22:48
568	170	\N	\N	\N	ru	{"title": null}	2026-01-05 07:12:24	2026-01-05 08:22:48
205	68	\N	\N	\N	ru	{"title": null, "description": null}	2025-12-26 13:49:13	2025-12-27 07:31:55
206	68	\N	\N	\N	en	{"title": null, "description": null}	2025-12-26 13:49:13	2025-12-27 07:31:55
299	76	\N	\N	\N	uz	{"title": "Asosiysi"}	2025-12-28 06:10:55	2025-12-28 06:10:55
198	66	\N	\N	\N	uz	{"title": "Navoiy", "description": "Viloyatning eng qadimiy shahri va markazi bo‘lgan Termizda va uning atrofida zardushtiylar, nestorianlar, buddistlar kabi turli xalqlarning shaharlari va qalʼalarining xarobalari, meʼmorchilik va arxeologiya obidalari, shuningdek islom meʼmorchiligi yodgorliklari saqlanib qolgan. Termizdan uncha uzoq bo‘lmagan joyda esa, fil suyagidan yasalgan shaxmat donalari topilgan,"}	2025-12-26 13:47:33	2025-12-27 07:05:08
199	66	\N	\N	\N	ru	{"title": null, "description": null}	2025-12-26 13:47:33	2025-12-27 07:05:08
200	66	\N	\N	\N	en	{"title": null, "description": null}	2025-12-26 13:47:33	2025-12-27 07:05:08
300	76	\N	\N	\N	ru	{"title": null}	2025-12-28 06:10:55	2025-12-28 06:10:55
301	76	\N	\N	\N	en	{"title": null}	2025-12-28 06:10:55	2025-12-28 06:10:55
326	85	\N	\N	\N	uz	{"title": "Man City"}	2025-12-28 06:20:50	2025-12-28 06:20:50
327	85	\N	\N	\N	ru	{"title": null}	2025-12-28 06:20:50	2025-12-28 06:20:50
201	67	\N	\N	\N	uz	{"title": "Qashqadaryo", "description": "Viloyatning eng qadimiy shahri va markazi bo‘lgan Termizda va uning atrofida zardushtiylar, nestorianlar, buddistlar kabi turli xalqlarning shaharlari va qalʼalarining xarobalari, meʼmorchilik va arxeologiya obidalari, shuningdek islom meʼmorchiligi yodgorliklari saqlanib qolgan. Termizdan uncha uzoq bo‘lmagan joyda esa, fil suyagidan yasalgan shaxmat donalari topilgan,"}	2025-12-26 13:48:32	2025-12-27 07:31:36
202	67	\N	\N	\N	ru	{"title": null, "description": null}	2025-12-26 13:48:32	2025-12-27 07:31:36
203	67	\N	\N	\N	en	{"title": null, "description": null}	2025-12-26 13:48:32	2025-12-27 07:31:36
204	68	\N	\N	\N	uz	{"title": "Samarqand", "description": "Viloyatning eng qadimiy shahri va markazi bo‘lgan Termizda va uning atrofida zardushtiylar, nestorianlar, buddistlar kabi turli xalqlarning shaharlari va qalʼalarining xarobalari, meʼmorchilik va arxeologiya obidalari, shuningdek islom meʼmorchiligi yodgorliklari saqlanib qolgan. Termizdan uncha uzoq bo‘lmagan joyda esa, fil suyagidan yasalgan shaxmat donalari topilgan,"}	2025-12-26 13:49:13	2025-12-27 07:31:55
328	85	\N	\N	\N	en	{"title": null}	2025-12-28 06:20:50	2025-12-28 06:20:50
350	97	\N	\N	\N	uz	{"title": "Golland"}	2025-12-28 06:25:45	2025-12-28 06:25:45
351	97	\N	\N	\N	ru	{"title": null}	2025-12-28 06:25:45	2025-12-28 06:25:45
352	97	\N	\N	\N	en	{"title": null}	2025-12-28 06:25:45	2025-12-28 06:25:45
374	105	\N	\N	\N	uz	{"title": "Bornmut"}	2025-12-28 06:30:40	2025-12-28 06:30:40
375	105	\N	\N	\N	ru	{"title": null}	2025-12-28 06:30:40	2025-12-28 06:30:40
376	105	\N	\N	\N	en	{"title": null}	2025-12-28 06:30:40	2025-12-28 06:30:40
569	170	\N	\N	\N	en	{"title": null}	2026-01-05 07:12:24	2026-01-05 08:22:48
155	57	52	Url	url	\N	{"url": null, "date": "2025-06-01T13:30"}	2025-12-26 11:10:22	2026-01-23 13:51:21
520	157	\N	\N	\N	ru	{"title": null, "description": null, "description1": null}	2025-12-31 01:03:31	2026-01-20 05:42:12
521	157	\N	\N	\N	en	{"title": null, "description": null, "description1": null}	2025-12-31 01:03:31	2026-01-20 05:42:12
579	173	\N	\N	\N	uz	{"title": "mbh0223"}	2026-01-05 07:22:35	2026-01-05 07:22:35
580	173	\N	\N	\N	ru	{"title": null}	2026-01-05 07:22:35	2026-01-05 07:22:35
581	173	\N	\N	\N	en	{"title": null}	2026-01-05 07:22:35	2026-01-05 07:22:35
582	173	\N	\N	\N	\N	{"age": null, "email": null, "phone": null}	2026-01-05 07:22:35	2026-01-05 07:22:35
537	162	\N	\N	\N	uz	{"title": "Yangi O’zbekiston tili va Adabiyoti fani o’qituvchilari", "description": "Ota meros"}	2026-01-05 05:00:18	2026-01-05 08:08:17
538	162	\N	\N	\N	ru	{"title": null, "description": null}	2026-01-05 05:00:18	2026-01-05 08:08:17
539	162	\N	\N	\N	en	{"title": null, "description": null}	2026-01-05 05:00:18	2026-01-05 08:08:17
551	166	\N	\N	\N	uz	{"title": "Biz barcha vatandoshlarni birlashtirib ularga kerakli mativatsiya"}	2026-01-05 05:39:36	2026-01-05 08:21:09
552	166	\N	\N	\N	ru	{"title": null}	2026-01-05 05:39:36	2026-01-05 08:21:09
553	166	\N	\N	\N	en	{"title": null}	2026-01-05 05:39:36	2026-01-05 08:21:09
554	166	\N	\N	\N	\N	{"age": "32", "email": "sadikov_bahodir@gmail.com", "phone": "+998(55) 502-22-99"}	2026-01-05 05:39:36	2026-01-05 08:21:09
222	74	60	video	video	\N	{"url": "https://www.youtube.com/embed/BHACKCNDMW8?si=AtPPS9WpLIT3_TaW"}	2025-12-26 13:55:58	2025-12-28 06:10:13
226	78	61	video	video-1	\N	{"url": "https://www.youtube.com/embed/BHACKCNDMW8?si=AtPPS9WpLIT3_TaW"}	2025-12-26 13:57:53	2025-12-28 06:12:16
208	69	\N	\N	\N	ru	{"title": null, "description": null}	2025-12-26 13:49:52	2025-12-27 07:32:20
209	69	\N	\N	\N	en	{"title": null, "description": null}	2025-12-26 13:49:52	2025-12-27 07:32:20
210	70	\N	\N	\N	uz	{"title": "Surxondaryo", "description": "Viloyatning eng qadimiy shahri va markazi bo‘lgan Termizda va uning atrofida zardushtiylar, nestorianlar, buddistlar kabi turli xalqlarning shaharlari va qalʼalarining xarobalari, meʼmorchilik va arxeologiya obidalari, shuningdek islom meʼmorchiligi yodgorliklari saqlanib qolgan. Termizdan uncha uzoq bo‘lmagan joyda esa, fil suyagidan yasalgan shaxmat donalari topilgan,"}	2025-12-26 13:51:09	2025-12-27 07:32:41
223	75	60	video	video	\N	{"url": "https://www.youtube.com/embed/BHACKCNDMW8?si=AtPPS9WpLIT3_TaW"}	2025-12-26 13:56:16	2025-12-28 06:10:28
224	76	60	video	video	\N	{"url": "https://www.youtube.com/embed/BHACKCNDMW8?si=AtPPS9WpLIT3_TaW"}	2025-12-26 13:56:35	2025-12-28 06:10:55
302	77	\N	\N	\N	uz	{"title": "Ajoyib manzil"}	2025-12-28 06:11:54	2025-12-28 06:11:54
227	79	61	video	video-1	\N	{"url": "https://www.youtube.com/embed/BHACKCNDMW8?si=AtPPS9WpLIT3_TaW"}	2025-12-26 13:58:11	2025-12-28 06:13:10
207	69	\N	\N	\N	uz	{"title": "Sirdaryo", "description": "Viloyatning eng qadimiy shahri va markazi bo‘lgan Termizda va uning atrofida zardushtiylar, nestorianlar, buddistlar kabi turli xalqlarning shaharlari va qalʼalarining xarobalari, meʼmorchilik va arxeologiya obidalari, shuningdek islom meʼmorchiligi yodgorliklari saqlanib qolgan. Termizdan uncha uzoq bo‘lmagan joyda esa, fil suyagidan yasalgan shaxmat donalari topilgan,"}	2025-12-26 13:49:52	2025-12-27 07:32:20
211	70	\N	\N	\N	ru	{"title": null, "description": null}	2025-12-26 13:51:09	2025-12-27 07:32:41
212	70	\N	\N	\N	en	{"title": null, "description": null}	2025-12-26 13:51:09	2025-12-27 07:32:41
303	77	\N	\N	\N	ru	{"title": null}	2025-12-28 06:11:54	2025-12-28 06:11:54
304	77	\N	\N	\N	en	{"title": null}	2025-12-28 06:11:54	2025-12-28 06:11:54
225	77	61	video	video-1	\N	{"url": "https://www.youtube.com/embed/BHACKCNDMW8?si=AtPPS9WpLIT3_TaW"}	2025-12-26 13:57:36	2025-12-28 06:11:54
228	80	62	video	video-2	\N	{"url": "https://www.youtube.com/embed/BHACKCNDMW8?si=AtPPS9WpLIT3_TaW"}	2025-12-26 14:17:34	2025-12-28 06:14:41
229	81	62	video	video-2	\N	{"url": "https://www.youtube.com/embed/BHACKCNDMW8?si=AtPPS9WpLIT3_TaW"}	2025-12-26 14:17:51	2025-12-28 06:14:55
230	82	62	video	video-2	\N	{"url": "https://www.youtube.com/embed/BHACKCNDMW8?si=AtPPS9WpLIT3_TaW"}	2025-12-26 14:18:09	2025-12-28 06:15:23
231	83	63	video	video-3	\N	{"url": "https://www.youtube.com/embed/BHACKCNDMW8?si=AtPPS9WpLIT3_TaW"}	2025-12-26 14:18:56	2025-12-28 06:17:03
232	84	63	video	video-3	\N	{"url": "https://www.youtube.com/embed/BHACKCNDMW8?si=AtPPS9WpLIT3_TaW"}	2025-12-26 14:19:13	2025-12-28 06:17:19
233	85	63	video	video-3	\N	{"url": "https://www.youtube.com/embed/BHACKCNDMW8?si=AtPPS9WpLIT3_TaW"}	2025-12-26 14:19:30	2025-12-28 06:20:50
329	86	\N	\N	\N	uz	{"title": "Man United"}	2025-12-28 06:22:02	2025-12-28 06:22:02
330	86	\N	\N	\N	ru	{"title": null}	2025-12-28 06:22:02	2025-12-28 06:22:02
331	86	\N	\N	\N	en	{"title": null}	2025-12-28 06:22:02	2025-12-28 06:22:02
234	86	64	video	video-4	\N	{"url": "https://www.youtube.com/embed/BHACKCNDMW8?si=AtPPS9WpLIT3_TaW"}	2025-12-26 14:20:10	2025-12-28 06:22:02
236	88	64	video	video-4	\N	{"url": "https://www.youtube.com/embed/BHACKCNDMW8?si=AtPPS9WpLIT3_TaW"}	2025-12-26 14:20:46	2025-12-28 06:22:17
235	87	64	video	video-4	\N	{"url": "https://www.youtube.com/embed/BHACKCNDMW8?si=AtPPS9WpLIT3_TaW"}	2025-12-26 14:20:28	2025-12-28 06:22:33
218	72	\N	\N	\N	en	{"title": null, "description": null}	2025-12-26 13:52:31	2026-01-19 05:15:07
213	71	\N	\N	\N	uz	{"title": "Toshkent v.", "description": "Viloyatning eng qadimiy shahri va markazi bo‘lgan Termizda va uning atrofida zardushtiylar, nestorianlar, buddistlar kabi turli xalqlarning shaharlari va qalʼalarining xarobalari, meʼmorchilik va arxeologiya obidalari, shuningdek islom meʼmorchiligi yodgorliklari saqlanib qolgan. Termizdan uncha uzoq bo‘lmagan joyda esa, fil suyagidan yasalgan shaxmat donalari topilgan,"}	2025-12-26 13:51:53	2026-01-19 05:15:20
217	72	\N	\N	\N	ru	{"title": null, "description": null}	2025-12-26 13:52:31	2026-01-19 05:15:07
214	71	\N	\N	\N	ru	{"title": null, "description": null}	2025-12-26 13:51:53	2026-01-19 05:15:20
215	71	\N	\N	\N	en	{"title": null, "description": null}	2025-12-26 13:51:53	2026-01-19 05:15:20
219	73	\N	\N	\N	uz	{"title": "Toshkent sh.", "description": "Viloyatning eng qadimiy shahri va markazi bo‘lgan Termizda va uning atrofida zardushtiylar, nestorianlar, buddistlar kabi turli xalqlarning shaharlari va qalʼalarining xarobalari, meʼmorchilik va arxeologiya obidalari, shuningdek islom meʼmorchiligi yodgorliklari saqlanib qolgan. Termizdan uncha uzoq bo‘lmagan joyda esa, fil suyagidan yasalgan shaxmat donalari topilgan,"}	2025-12-26 13:53:35	2026-01-19 05:15:28
220	73	\N	\N	\N	ru	{"title": null, "description": null}	2025-12-26 13:53:35	2026-01-19 05:15:28
221	73	\N	\N	\N	en	{"title": null, "description": null}	2025-12-26 13:53:35	2026-01-19 05:15:28
522	157	\N	\N	\N	\N	{"video": "https://www.youtube.com/watch?v=UqvRkpzTMJU", "content": "Futbol Loyihasi boshlandi", "last_date": "2025-06-01T13:30"}	2025-12-31 01:03:31	2026-01-20 05:42:12
353	98	\N	\N	\N	uz	{"title": "Chelsea"}	2025-12-28 06:26:01	2025-12-28 06:26:01
354	98	\N	\N	\N	ru	{"title": null}	2025-12-28 06:26:01	2025-12-28 06:26:01
355	98	\N	\N	\N	en	{"title": null}	2025-12-28 06:26:01	2025-12-28 06:26:01
377	106	\N	\N	\N	uz	{"title": "Astron Villa"}	2025-12-28 06:30:53	2025-12-28 06:30:53
378	106	\N	\N	\N	ru	{"title": null}	2025-12-28 06:30:53	2025-12-28 06:30:53
379	106	\N	\N	\N	en	{"title": null}	2025-12-28 06:30:53	2025-12-28 06:30:53
422	29	\N	\N	\N	en	{"title": null, "description": null}	2025-12-29 09:26:19	2025-12-29 09:26:19
436	133	\N	\N	\N	uz	{"title": "Malaka oshirish"}	2025-12-29 12:31:16	2025-12-29 12:31:16
437	133	\N	\N	\N	ru	{"title": null}	2025-12-29 12:31:16	2025-12-29 12:31:16
438	133	\N	\N	\N	en	{"title": null}	2025-12-29 12:31:16	2025-12-29 12:31:16
439	133	\N	\N	\N	\N	{"url": null}	2025-12-29 12:31:16	2025-12-29 12:31:16
262	111	72	video	video-13	\N	{"url": "https://www.youtube.com/embed/BHACKCNDMW8?si=AtPPS9WpLIT3_TaW"}	2025-12-26 14:34:51	2025-12-26 14:34:51
263	112	72	video	video-13	\N	{"url": "https://www.youtube.com/embed/BHACKCNDMW8?si=AtPPS9WpLIT3_TaW"}	2025-12-26 14:35:10	2025-12-26 14:35:10
264	113	72	video	video-13	\N	{"url": "https://www.youtube.com/embed/BHACKCNDMW8?si=AtPPS9WpLIT3_TaW"}	2025-12-26 14:35:23	2025-12-26 14:35:23
265	114	73	video	video-14	\N	{"url": "https://www.youtube.com/embed/BHACKCNDMW8?si=AtPPS9WpLIT3_TaW"}	2025-12-26 14:35:56	2025-12-26 14:35:56
266	115	73	video	video-14	\N	{"url": "https://www.youtube.com/embed/BHACKCNDMW8?si=AtPPS9WpLIT3_TaW"}	2025-12-26 14:36:11	2025-12-26 14:36:11
267	116	73	video	video-14	\N	{"url": "https://www.youtube.com/embed/BHACKCNDMW8?si=AtPPS9WpLIT3_TaW"}	2025-12-26 14:36:27	2025-12-26 14:36:27
169	63	\N	\N	\N	\N	{"code": "UZ-FA", "path": "m619.468 304.513.092-.607-.212-.505-.68-.607-2.675-1.204-1.499-.303-.919-.368h-.295l-.827.396-.395-.028-.423-.193-.304-.34-.423-1.02-.266-.285-.258-.092-.138-.68-.836-1.626-.055-.561.119-.184.745-.202.919-.744 1.094-.203 1.012-.523 1.884-.662h.736l.432-.377.11-.744.405-.405.129-.817.174-.368.368-.202.543-.074.707.065.442-.331.662-.019.395-.147.8-1.02 1.021-2.04.33-.349.598-.165.625-.671.469-.157.138-.257.377-.073.377-.46.892-.202.368.257.294.028.046-.607-.166-.909.285-.212.258.23.607-.037.404-.533.276-.919.533-.487.055-.239.313-.083.239-.238 4.477-1.149 3.099-.561 6.215-.092v.203l-.34.477-1.251 1.526.764 1.81 1.719 1.71 5.139 2.508.368.074.69-.386 2.776-2.619.699-.91.68-1.332 1.14-.736 3.779-2.049 3.163-.946 2.786 4.117.184-1.333 3.824.551 2.777 1.434.57.597 2.059 3.18 8.505 1.443h.303l.221-.156 2.069.413 3.686 1.176.285.772.102 3.318-.451.037-.984-.239-.358.073-.469 1.268-.276.46-.579.551-.423.221-.34.064-.543-.184-.818-.542-.423.956.414 1.571-.129.313-.588.652-.065.524-.266.368-1.26.376-.956 1.232-.469.349-.736 1.039-1.094.477-.855.791-.11.239.193.459.901.211.901.818-.064.451-1.021.946-.423.993-.266.294-.607.303-.57-.018-1.168-.846-1.857-.432-.441.359-.12.441.046.248.68 1.038.019.487-.69.46-.496-.028-2.29 1.462-1.213.386-.846.606-.322.055-.23-.128-.423-.782-.395-.468-.221-.065-.331-.367-.137-.331.156-1.746-.175-.744-.625-.837-.478-.331-.708-.073-1.131.11-.101.772.221 1.314-.193.873.073.515-.11.184-.267-.028-.745-.882h-.919l-.506.175-.846-.533-1.627-.726-.202-.497.175-1.24-.221-.478-1.195-.028-1.416-.367-.579-.46-1.003-1.13-.377-.248-.45-.138-.46.202-.57.055-.147-.285.083-.358-.294-.23-1.407.588-.69.092-.248-.092-.138-.248-.018-.919-1.416.101-.929-.312-.919-.083-.763.101-1.269.423-.901-.018-.561.193-2.353 1.635-1.793.322-1.903.827-.414.267-.129.248.285.845-.101.892-2.188.064-1.793.321-.248-.082-1.563 1.158-2.271 1.011-1.453.303-1.287.11-2.878.634-.763-.312-1.085-1.967-.294-.809-.662-.358-.487-.864.119-.101.065-1.176.34-.91-.506-1.608z", "offset": "10,-15"}	2025-12-26 13:28:16	2025-12-27 07:30:12
244	93	66	video	video-7	\N	{"url": "https://www.youtube.com/embed/BHACKCNDMW8?si=AtPPS9WpLIT3_TaW"}	2025-12-26 14:27:29	2025-12-27 14:23:30
245	94	66	video	video-7	\N	{"url": "https://www.youtube.com/embed/BHACKCNDMW8?si=AtPPS9WpLIT3_TaW"}	2025-12-26 14:27:50	2025-12-27 14:23:56
246	95	66	video	video-7	\N	{"url": "https://www.youtube.com/embed/BHACKCNDMW8?si=AtPPS9WpLIT3_TaW"}	2025-12-26 14:28:05	2025-12-27 14:24:21
241	90	89	video	video-6	\N	{"url": "https://www.youtube.com/embed/BHACKCNDMW8?si=AtPPS9WpLIT3_TaW"}	2025-12-26 14:26:17	2025-12-28 06:23:24
242	91	89	video	video-6	\N	{"url": "https://www.youtube.com/embed/BHACKCNDMW8?si=AtPPS9WpLIT3_TaW"}	2025-12-26 14:26:32	2025-12-28 06:23:42
243	92	89	video	video-6	\N	{"url": "https://www.youtube.com/embed/BHACKCNDMW8?si=AtPPS9WpLIT3_TaW"}	2025-12-26 14:26:48	2025-12-28 06:24:26
247	96	67	video	video-8	\N	{"url": "https://www.youtube.com/embed/BHACKCNDMW8?si=AtPPS9WpLIT3_TaW"}	2025-12-26 14:28:39	2025-12-28 06:25:23
248	97	67	video	video-8	\N	{"url": "https://www.youtube.com/embed/BHACKCNDMW8?si=AtPPS9WpLIT3_TaW"}	2025-12-26 14:28:53	2025-12-28 06:25:45
249	98	67	video	video-8	\N	{"url": "https://www.youtube.com/embed/BHACKCNDMW8?si=AtPPS9WpLIT3_TaW"}	2025-12-26 14:29:06	2025-12-28 06:26:01
250	99	68	video	video-9	\N	{"url": "https://www.youtube.com/embed/BHACKCNDMW8?si=AtPPS9WpLIT3_TaW"}	2025-12-26 14:29:51	2025-12-28 06:27:11
251	100	68	video	video-9	\N	{"url": "https://www.youtube.com/embed/BHACKCNDMW8?si=AtPPS9WpLIT3_TaW"}	2025-12-26 14:30:05	2025-12-28 06:27:26
252	101	68	video	video-9	\N	{"url": "https://www.youtube.com/embed/BHACKCNDMW8?si=AtPPS9WpLIT3_TaW"}	2025-12-26 14:30:18	2025-12-28 06:27:43
253	102	69	video	video-10	\N	{"url": "https://www.youtube.com/embed/BHACKCNDMW8?si=AtPPS9WpLIT3_TaW"}	2025-12-26 14:30:52	2025-12-28 06:28:55
254	103	69	video	video-10	\N	{"url": "https://www.youtube.com/embed/BHACKCNDMW8?si=AtPPS9WpLIT3_TaW"}	2025-12-26 14:31:09	2025-12-28 06:29:11
255	104	69	video	video-10	\N	{"url": "https://www.youtube.com/embed/BHACKCNDMW8?si=AtPPS9WpLIT3_TaW"}	2025-12-26 14:31:24	2025-12-28 06:29:41
256	105	70	video	video-11	\N	{"url": "https://www.youtube.com/embed/BHACKCNDMW8?si=AtPPS9WpLIT3_TaW"}	2025-12-26 14:32:13	2025-12-28 06:30:40
257	106	70	video	video-11	\N	{"url": "https://www.youtube.com/embed/BHACKCNDMW8?si=AtPPS9WpLIT3_TaW"}	2025-12-26 14:32:30	2025-12-28 06:30:53
258	107	70	video	video-11	\N	{"url": "https://www.youtube.com/embed/BHACKCNDMW8?si=AtPPS9WpLIT3_TaW"}	2025-12-26 14:32:43	2025-12-28 06:31:08
259	108	71	video	video-12	\N	{"url": "https://www.youtube.com/embed/BHACKCNDMW8?si=AtPPS9WpLIT3_TaW"}	2025-12-26 14:33:17	2025-12-28 06:32:15
260	109	71	video	video-12	\N	{"url": "https://www.youtube.com/embed/BHACKCNDMW8?si=AtPPS9WpLIT3_TaW"}	2025-12-26 14:33:35	2025-12-28 06:35:07
261	110	71	video	video-12	\N	{"url": "https://www.youtube.com/embed/BHACKCNDMW8?si=AtPPS9WpLIT3_TaW"}	2025-12-26 14:33:48	2025-12-28 06:35:30
584	3	\N	\N	\N	en	{"title": null}	2026-01-05 08:15:05	2026-01-05 08:15:05
585	174	\N	\N	\N	uz	{"title": "Qatnashgan vatandoshlar soni"}	2026-01-05 08:15:32	2026-01-05 08:15:32
586	174	\N	\N	\N	ru	{"title": null}	2026-01-05 08:15:32	2026-01-05 08:15:32
587	174	\N	\N	\N	en	{"title": null}	2026-01-05 08:15:32	2026-01-05 08:15:32
523	158	\N	\N	\N	uz	{"title": "Bank Loyihasi", "description": "Bank Loyihasi haqida", "description1": "<p><span style=\\"letter-spacing: 0.14px;\\">Loyiha Haqida...</span></p>"}	2025-12-31 01:05:11	2026-01-20 05:42:35
583	2	\N	\N	\N	en	{"title": null}	2026-01-05 08:12:34	2026-01-22 15:13:26
240	89	\N	\N	\N	\N	{"code": "UZ-NA", "path": "m688.919 258.371-.46-.772-.423-.266-.413-.064-.414.22-.966-.322-.698-.027-1.729 1.25-.322.073-.625-.275-1.6-1.03-1.048-.285-1.121-.128-1.067.726-.423-.202-.515-.046-1.489-.598-.294-.377.018-.808-.515-.055-.34-.184-.064-.193.588-1.838.846-1.48.717-.735.432-.753.515-1.241-.046-.23-.993-.533-.781-.946-.258-.598.12-1.194-.129-.34-.349-.258-.377.221-.313.515-.745.156-.229-.156-.056-.175.239-1.195-.57-.974-1.287-1.24-.965-2.031-.34-.092-.129.11-.101 1.553-.156.239-.285.064-.194-.377-.091-.624-.285-.249-.35-.027-.579.413-.11.368.377.607-.056.514-.248.193-.386-.239-.377-.652-.092-.423.083-.395.772-1.011.423-.763.064-.432-.22-1.295.119-.276-.055-.68.395-.827-.321-.561-1.048-.046-.331.092-.708.662-.699 1.25-.405.459-1.158.395-.221.322.046.386.294.22 1.049.101.524.212.459.717.12.625-.313 1.121-.404.744-.037.377.735 1.13-.266.607-.607.661-.331.644-.248.9-.202.009-.331-.229-.239.229-.295.662-.551.45-.157.533-.156.037-.23.873-.349.294-.552-.147-.561-.634-.367-.202-.809-.018-.387.321-.616.129-.754-.469-.294.065-1.324 1.58-.046.377.23.708-.239.781v.487l.166.34.79.34.276.662-.818 1.837-.294 1.829-.653 1.48-.028.34-.947 1.029-.487.037-.239-.156-.138-.267-.211-1.626-.212-.451-.726-.763-.359-.174-.496.009-.469.276-.322.377-.211 1.295-.368.699-.736.689-.469.11-.349-.101-.129-.276.203-2.196-.239-1.314-.24-.386-.873-.579-.276-.037-.57.267-.119.367.037.497-.286.211-.257-.055-.395-.974-.295-.009-.321.275-.432.662-.442-.019-.239.138-.763.809-.46.267-.367.027-1.113-.395-.377-.34-.561-.937-.735-.175-1.131-.735-.542.027-2.446 1.664-.515-.184-.496-1.13-.846-.791-.791-.496-.533-.781-.487-.46-.249-.036-.653.294-.432.625-.763 1.893-.276.404-.303.147-.791-.322-.459-.56-.203-.827.028-1.002.68-.873.166-.551-.092-.322-.57-.836-.23-.68-.064-1.645.386-.846.23-1.066-.451-1.884-2.344-3.749-.386-1.075-.175-.147-1.113-.313-.285.028-1.048.781-1.131-.055-1.397.441-.901.772-.377.68-1.545 1.277h-1.912l-.46-.496-.625 1.774-2.731 3.777.616 6.708 1.756 2.408.607 1.231.221 2.142.028 1.608-.138.808.183.386.414-.018.671.368.249.625 1.011.817.064.57.295.221.809 1.093.625.019.505 1.259.929 1.148.359.818 1.02 1.517.423 1.084.248.009.111.34.891.763.515 1.259.763.285.488.432.671.91-.441.349-.157-.083-.266.166.073.294-.175.266-.34.092-.524-.23-.432-1.112-.34 1.14.037.652.294.588.763-.22 1.131.092.781.413-.257.166.827.037.396.211.919.781.202.45.313-.082.239-.239 4.478-1.149 3.107-.561 6.206-.091v.202l-.34.478-1.25 1.525.763 1.81 1.728 1.701 5.13 2.508.368.074.699-.386 2.777-2.619.698-.919.69-1.333 1.131-.726 3.778-2.049 3.163-.947 1.747-1.112-2.023-2.453 1.867-1.737 1.103-.735 7.898-2.013 3.374.028.533.23.671.514 3.062.689 1.342.138 4.487-.404.487-.248.368-.423 1.158-5.385-.386-.239-.413-.533.147-.303 1.158-.276.487-.377.433-.937-.414-.754zm-64.781 13.5-2.924-3.961-1.122-.827-.928-.027-.175-.625.248-.432.671-.515-.248.349 1.104.469 1.388 1.627 1.59 2.159.589 1.452z", "offset": "10,-25"}	2025-12-26 14:25:11	2025-12-27 07:31:11
174	68	\N	\N	\N	\N	{"code": "UZ-SA", "path": "m489.969 359.172-.101.276-1.471-.285-.892.193-3.062 1.057-.211.267v.174l-.92.211-1.517-.294-3.53-1.093-2.354-1.002-4.1-1.167-.809.046-.396.441.065 1.636-.102.322-.386.441-.754.193-3.567.22-1.738-.138-.855-.487-.303-.441-.055-.533.423-1.562.101-1.158-.451-1.213-.579-.616-7.879-1.406-1.094.055-.745.258-.763.873-1.011 1.635-.754.883-3.347 1.433-.276.009-.634-.303-1.508-1.057-1.517-1.323-1.076-.689-.579-.147-6.942 1.718-3.006 1.535-2.032 1.268-1.407.037-2.831-.717-.662-.23-.203-.193-.082-1.369-2.547-4.273-3.034-3.501-3.963-.809-.036.303-.175.248-1.315.984-1.204.505-1.37.165-16.136-.487-.634-.147-1.949-3.492-.745-1.663-.156-.745.036-.579 1.076-2.15.469-1.342.156-.891-1.241-4.797-.864-1.333-.892-.744-1.361-1.406-.303-.708.074-.34.459-.321 7.953-2.684.919.451 2.621.808.542-.009.478-.276.653-1.185 1.683-5.091.386-5.33-.046-.892.147-.643.322-.524.478-.257.928.156 5.039 1.902.919 1.425.423.956 1.922 1.047 4.946 2.114 1.122.184 8.192-1.774 1.498-.698 3.209-3.024.395-.57.129-1.029-.166-.413-.753-.065-1.315.846-.736-.092-.184-.901 2.115-5.578.791-1.231.809-5.625.156-2.086-.34-.661-.497-.184-.229-.322.542-4.512 1.977-4.301.836-.992 1.021-.175 1.094.083.947 1.424.956.726 1.683.23 1.268-.101 2.161-1.186 1.94-1.764.533.248.892 1.029 1.71 2.445 1.159 3.189 7.162.845 4.238.092.883 2.003.009 1.011-.763 1.682-.129.708.092 3.611.772 3.768 1.711 1.526 1.324 2.582-.065.744-.414 1.232-.22.147-1.14.266-.092.322.322 3.409 5.36 3.612 1.949.735 4.422.368 10.913 2.325.194.22.983 5.477.074.938-1.195.138-1.416.349-1.986.946-.635.497-.698.836-2.961 4.815-.092.34.019 3.823.193.873.597.882.947.965 4.165 3.511 2.051 4.292.763 2.113.864 1.792.193.745z", "offset": "5,-10"}	2025-12-26 13:31:14	2025-12-27 07:31:55
268	93	\N	\N	\N	uz	{"title": "Yurtdosh"}	2025-12-27 14:23:30	2025-12-27 14:23:30
269	93	\N	\N	\N	ru	{"title": null}	2025-12-27 14:23:30	2025-12-27 14:23:30
270	93	\N	\N	\N	en	{"title": null}	2025-12-27 14:23:30	2025-12-27 14:23:30
271	94	\N	\N	\N	uz	{"title": "Qollsh"}	2025-12-27 14:23:56	2025-12-27 14:23:56
272	94	\N	\N	\N	ru	{"title": null}	2025-12-27 14:23:56	2025-12-27 14:23:56
273	94	\N	\N	\N	en	{"title": null}	2025-12-27 14:23:56	2025-12-27 14:23:56
274	95	\N	\N	\N	uz	{"title": "Qollang"}	2025-12-27 14:24:21	2025-12-27 14:24:21
275	95	\N	\N	\N	ru	{"title": null}	2025-12-27 14:24:21	2025-12-27 14:24:21
276	95	\N	\N	\N	en	{"title": null}	2025-12-27 14:24:21	2025-12-27 14:24:21
293	74	\N	\N	\N	uz	{"title": "Qollash"}	2025-12-28 06:10:13	2025-12-28 06:10:13
294	74	\N	\N	\N	ru	{"title": null}	2025-12-28 06:10:13	2025-12-28 06:10:13
403	124	19	tashkilot	tashkilot	\N	{"title": "New York University"}	2025-12-29 08:12:53	2025-12-29 08:12:53
429	131	\N	\N	\N	ru	{"title": null}	2025-12-29 12:29:53	2025-12-29 13:02:43
588	174	\N	\N	\N	\N	{"number": "124683"}	2026-01-05 08:15:32	2026-01-05 08:15:32
282	118	\N	\N	\N	ru	{"title": null, "description": null}	2025-12-27 16:59:20	2026-01-21 08:03:13
283	118	\N	\N	\N	en	{"title": null, "description": null}	2025-12-27 16:59:20	2026-01-21 08:03:13
287	119	\N	\N	\N	en	{"title": null, "description": null}	2025-12-27 17:01:20	2026-01-21 08:03:40
157	57	\N	\N	\N	uz	{"title": "Yurtdoshlar"}	2025-12-26 11:29:45	2026-01-23 13:51:21
279	117	\N	\N	\N	en	{"title": "Xorijdagi Vatandoshlar uchun Anor damolish oromgohi ochildi eng", "description": "<p><span style=\\"letter-spacing: 0.14px;\\">news eng content</span></p>"}	2025-12-27 16:57:51	2026-01-22 05:44:43
292	4	\N	\N	\N	en	{"title": "Vatandoshlar jamoat fondi eng", "content": null, "content1": null, "description": null}	2025-12-27 19:41:11	2026-01-23 12:34:28
589	175	\N	\N	\N	uz	{"title": "Qatnashgan vatandoshlar soni"}	2026-01-05 08:16:14	2026-01-05 08:16:14
590	175	\N	\N	\N	ru	{"title": null}	2026-01-05 08:16:14	2026-01-05 08:16:14
591	175	\N	\N	\N	en	{"title": null}	2026-01-05 08:16:14	2026-01-05 08:16:14
592	175	\N	\N	\N	\N	{"number": "8565"}	2026-01-05 08:16:14	2026-01-05 08:16:14
593	176	\N	\N	\N	uz	{"title": "Qatnashgan vatandoshlar soni"}	2026-01-05 08:17:25	2026-01-05 08:17:25
594	176	\N	\N	\N	ru	{"title": null}	2026-01-05 08:17:25	2026-01-05 08:17:25
595	176	\N	\N	\N	en	{"title": null}	2026-01-05 08:17:25	2026-01-05 08:17:25
596	176	\N	\N	\N	\N	{"number": "32351"}	2026-01-05 08:17:25	2026-01-05 08:17:25
597	177	\N	\N	\N	uz	{"title": "Qatnashgan vatandoshlar soni"}	2026-01-05 08:17:42	2026-01-05 08:17:42
598	177	\N	\N	\N	ru	{"title": null}	2026-01-05 08:17:42	2026-01-05 08:17:42
599	177	\N	\N	\N	en	{"title": null}	2026-01-05 08:17:42	2026-01-05 08:17:42
600	177	\N	\N	\N	\N	{"number": "512"}	2026-01-05 08:17:42	2026-01-05 08:17:42
17	8	\N	\N	\N	uz	{"title": "Qadriyatlarimiz bizni birlashtiradi!", "url_title": "Eng chiroyli Namuna", "description": "Qadriyatlarimiz bizni birlashtiradi! Qadriyatlarimiz – bu bizning ildizlarimiz, qalbimizning kuchi va kelajagimizning yorqin yo‘li. Ular bizni bog‘laydi, har birimizning yuragimizni birlashtiradi va bizga chinakam muvaffaqiyatga erishish imkonini beradi. Biz bu qadriyatlar bilan faxrlanishimiz kerak, chunki ular bizni yuksaltiradi va dunyoga haqiqiy kuchimizni ko‘rsatadi. Qadriyatlarimizga sodiq qolish, ularni davom ettirish – bu nafaqat bugungi kunimiz, balki kelajagimiz uchun ham zarur. Qadriyatlarimiz – bu bizning abadiy merosimiz!"}	2025-12-23 05:10:29	2026-01-05 13:18:53
119	8	\N	\N	\N	en	{"title": null, "url_title": null, "description": null}	2025-12-25 10:18:34	2026-01-05 13:18:53
43	20	\N	\N	\N	uz	{"title": "Buyuk Britaniya"}	2025-12-23 05:48:00	2026-01-12 09:40:36
608	20	\N	\N	\N	en	{"title": null}	2026-01-12 09:40:36	2026-01-12 09:40:36
609	20	\N	\N	\N	\N	{"code": "GB"}	2026-01-12 09:40:36	2026-01-12 09:40:36
610	19	\N	\N	\N	en	{"title": null}	2026-01-12 09:40:45	2026-01-12 09:40:45
611	19	\N	\N	\N	\N	{"code": "UZ"}	2026-01-12 09:40:45	2026-01-12 09:40:45
77	34	\N	\N	\N	uz	{"title": "Na'munali Yurtdoshlar"}	2025-12-23 06:22:39	2026-01-14 11:30:41
145	34	\N	\N	\N	en	{"title": null}	2025-12-26 05:11:42	2026-01-14 11:30:41
150	34	\N	\N	\N	\N	{"url": "https://www.youtube.com/embed/BHACKCNDMW8?si=AtPPS9WpLIT3_TaW", "url_title": "Na'munali Yurtdoshlar"}	2025-12-26 05:31:25	2026-01-14 11:30:41
640	188	\N	\N	\N	uz	{"title": "Google Map"}	2026-01-15 14:30:30	2026-01-15 14:33:02
280	117	\N	\N	\N	\N	{"url": "https://www.youtube.com/embed/BHACKCNDMW8?si=AtPPS9WpLIT3_TaW"}	2025-12-27 16:57:51	2026-01-21 08:02:52
494	149	\N	\N	\N	\N	{"video": "https://www.youtube.com/watch?v=UqvRkpzTMJU", "content": "Yoshlar Loyihasi boshlandi", "last_date": "2025-06-01T13:30"}	2025-12-30 16:44:29	2026-01-20 05:41:31
76	33	\N	\N	\N	\N	{"url": "https://www.youtube.com/embed/BHACKCNDMW8?si=AtPPS9WpLIT3_TaW"}	2025-12-23 06:21:44	2026-01-21 08:03:05
277	117	\N	\N	\N	uz	{"title": "Xorijdagi Vatandoshlar uchun Anor damolish oromgohi ochildi", "description": "<p><span style=\\"letter-spacing: 0.14px;\\">news uz contentasd asd asda dad ads&nbsp;</span></p><br>"}	2025-12-27 16:57:51	2026-01-22 05:44:43
491	149	\N	\N	\N	uz	{"title": "Yoshlar Tanlovi", "description": "Yosh tanlovi Haritasi", "description1": "<p><span style=\\"letter-spacing: 0.14px;\\">Loyiha Haqida...</span></p>"}	2025-12-30 16:44:29	2026-01-20 05:41:31
285	119	\N	\N	\N	uz	{"title": "Xorijdagi Vatandoshlar  uchun Anor  damolish oromgohi ochildi", "description": null}	2025-12-27 17:01:20	2026-01-21 08:03:40
286	119	\N	\N	\N	ru	{"title": null, "description": null}	2025-12-27 17:01:20	2026-01-21 08:03:40
288	119	\N	\N	\N	\N	{"url": "https://www.youtube.com/embed/pDgzE2tXZEs?si=LLxCo7PYWkSD18xd"}	2025-12-27 17:01:20	2026-01-21 08:03:40
278	117	\N	\N	\N	ru	{"title": "Xorijdagi Vatandoshlar uchun Anor damolish oromgohi ochildi RUS", "description": "<p><span style=\\"letter-spacing: 0.14px;\\">news ru content</span></p>"}	2025-12-27 16:57:51	2026-01-22 05:44:43
636	187	\N	\N	\N	uz	{"title": "text"}	2026-01-14 17:15:56	2026-01-22 09:24:10
637	187	\N	\N	\N	ru	{"title": null}	2026-01-14 17:15:56	2026-01-22 09:24:10
638	187	\N	\N	\N	en	{"title": null}	2026-01-14 17:15:56	2026-01-22 09:24:10
639	187	\N	\N	\N	\N	{"url": "dd", "url_title": "dd"}	2026-01-14 17:15:56	2026-01-22 09:24:10
641	188	\N	\N	\N	ru	{"title": null}	2026-01-15 14:30:30	2026-01-15 14:33:02
642	188	\N	\N	\N	en	{"title": null}	2026-01-15 14:30:30	2026-01-15 14:33:02
643	188	\N	\N	\N	\N	{"map": "<iframe\\r\\n        src=\\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d749.4925232956783!2d69.25348876967365!3d41.287755348207035!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x38ae8aee77c2889f%3A0x1a0e4085e1b2ab8!2s77Q3%2B4M6%2C%20Babur%20Street%2045%2C%20Tashkent%2C%20Uzbekistan!5e0!3m2!1sen!2s!4v1766139483379!5m2!1sen!2s\\"\\r\\n        width=\\"600\\" height=\\"450\\" style=\\"border:0;\\" allowfullscreen=\\"\\" loading=\\"lazy\\"\\r\\n        referrerpolicy=\\"no-referrer-when-downgrade\\"></iframe>"}	2026-01-15 14:33:02	2026-01-15 14:33:02
178	72	\N	\N	\N	\N	{"code": "UZ-XO", "path": "m259.77 287.025-1.159-2.628-.478-.69-.634-.56-.276-.744-.147-2.546-.423-.68-.239-.947-1.122-1.874-.082-1.122.147-1.084-.065-1.819-.137-.442-.23-2.619.211-1.488-.202-.368-.469-.193-.166-.662.019-.588-.267-.744-.68-.864-1.352-.717-.524-.101-.413-.239-.276-.514.174-.864-.34-.965-.432-.8-1.122-.671-1.728-1.819-1.039-.313-1.37-.928-1.866-2.215-.442-.275-1.167-.12-.607-.211-.451-.313-.376-.349-.258-.873-.349-.661-.782-.589-.432-.009-1.195.524-1.627-.129-.681-.202-1.48-.827-1.618-.266-.478.036-.432.285-.754 1.351.055 2.435-.414.736-.257 1.442-.396.837-.321.358-.451.303-.965.147-.138.129-1.536.175-.303-.092-1.214.046-.184-.12-.257.092-.644-.147-2.85-1.36-1.958-2.049-.313-.138-1.848.165-1.213-1.433-4.515-.202-.386.192-.956-.064-2.004.294-2.372-.11-1.545.285-3.613.009-4.376.276-.81-.046-2.39.395-.873-.055-.662-.221-2.979-1.783-2.676-2.389-5.617-3.832-3.099-1.774-1.066-.955-.524-1.14-.019-.634.147-.726.037-2.748.258-1.709.349-.744 1.968-1.838.229-.561v-1.075l-.248-.818-1.039-1.856-1.057-1.406-1.701-2.656-.349-1.379.478-1.139.515-2.068.22-.129.285.019.828.45.919-.018 1.821.661 1.02.487 1.177.965 1.094-.027.717.579.754.248.239-.368.671.009.239-.147.028-.404-.478-.643-1.039-.818-1.067-1.213-1.149-.524-1.517-.34-1.278-.8-.699-.781-.285-.661 2.455-4.807 1.747-.781 3.917-1.277 4.854 1.029.359.441.147.533.037 2.426.377 2.252 2.831 4.953.35.432.607.597.643.285 4.753 4.439 3.08 3.584 1.444 1.388 7.567 6.717 5.479 4.173 1.297.533 1.986.33.68.267.653.56 1.848 2.086.34.8.239 1.066 2.069 1.323h1.369l.662-.698.469-1.728 1.076-2.113.717-.809 1.278-.708.57-.184 2.795.01 8.229 1.893 3.236 1.709 2.832 1.755 7.355 8.097 1.379 2.545 4.193 6.81.248.202.598.175 2.344-1.122 2.979 3.061 5.434 6.138.625 1.057-.028 1.415-.726 3.493-4.22 4.714-5.774 6.993z", "offset": "0,-20"}	2025-12-26 13:33:21	2026-01-19 05:15:07
179	73	\N	\N	\N	\N	{"code": "UZ-TK", "path": "m569.056 244.898.046-.524-.083-.128h-.221l-.275.229-.12.34-.69.212-.652.689-.644-.064-.331.606-.506-.248-.524.101-1.471-.772-.183.019-.24.312-.753.34-.947-.193-.102-.165h-.128l-1.104 1.213-.092.781-.413 1.149-.129.799-.11 1.342.082.312.855.202.267.193.304-.165.441.23.294.772.147.046.331-.212.156.23.635.119.524-.055.009-.441.993-.799 1.002.082.662.212-.147.377.395.863.341.23.579-.083.965-.965.35-.799-.065-1.084-.349-.671-.267-.248.441-.699.313-.23-.119-.312.046-.441.266-.625.138-.11.368.046-.083-.607.258-.248.11-.441-.101-.294-.221-.129z", "offset": "0,-30"}	2025-12-26 13:33:53	2026-01-19 05:15:28
89	38	\N	\N	\N	uz	{"url": null, "title": "Fondning tashkil topishi haqida", "content": null, "description": "\\"Vatandoshlar\\" jamoat fondi 2021 yil 11 avgustda O‘zbekiston Respublikasi Prezidentining PQ-5220-sonli qarori bilan xorijiy davlatlardagi vatandoshlarimiz bilan doimiy va samarali aloqalar o‘rnatish va rivojlantirish hamda yagona Vatani atrofida jipslashtirish maqsadida tashkil etilgan.  \\"Vatandoshlar\\" jamoat fondining vasiylik kengashi Fondning oliy organi hisoblanadi. Vasiylik kengashi tomonidan shakllantiriladigan Fond Boshqaruvi — Fondning ijro organi hisoblananadi.  O‘zbekiston Respublikasi Oliy Majlisi huzuridagi Nodavlat notijorat tashkilotlarini va fuqarolik jamiyatining boshqa institutlarini qo‘llab -quvvatlash jamoat fondi mablag‘larini boshqarish bo‘yicha Parlament komissiyasiga har yili asoslangan buyurtmanoma asosida Fondning asosiy vazifalarini bajarish doirasidagi tadbirlarni tashkil etish va o‘tkazishni moliyalashtirish uchun subsidiya shaklida zarur mablag‘larni ajratadi."}	2025-12-25 08:48:32	2026-01-19 12:36:37
86	37	\N	\N	\N	uz	{"url": null, "title": "Fondning ramzi", "content": "\\"Vatandoshlar\\" jamoat fondining ramzida asosan milliy qadriyatlarimizni anglatuvchi minoralar hamda tarixiy obidalarimizning naqshlarida aks etgan ko‘k rangdan foydalanilgan. Ko‘k rang – bu tinchlik va hotirjamlik ramzi bo‘lib, u yaxshilikni, donishmandlikni, halollikni va sadoqatni bildiradi. Markazda O‘zbekiston Respublikasining 30 yilligi munosabati bilan “Yangi O‘zbekiston” bog‘ida bunyod etilgan muhtasham obida “Mustaqillik monumenti” joy olgan. Obidaning eng yuqori qismida O‘zbekiston gerbidan ham o‘rin olgan “Humo qushi” tasvirlangan. Obidaning orqa tomonida globus tasviri tushirilgan bo‘lib, bu xorijda istiqomat qilayotgan vatandoshlar bilan ishlashni nazarda tutadi. Shuningdek, ramzda ochiq kaftlar keltirilgan bo‘lib, bu Fondning ochiqlik va qabul qilishlikni, halollik va samimiylikni, vatandoshlarni “Yangi O‘zbekiston” atrofida yanada jipslashishiga, ularga doimiy ravishda g‘amxo‘rlik qilishga ham tayyor ekanligini anglatadi.", "description": "\\"Vatandoshlar\\" jamoat fondining ramzida asosan milliy qadriyatlarimizni anglatuvchi minoralar hamda tarixiy obidalarimizning naqshlarida aks etgan ko‘k rangdan foydalanilgan. Ko‘k rang – bu tinchlik va hotirjamlik ramzi bo‘lib, u yaxshilikni, donishmandlikni, halollikni va sadoqatni bildiradi. Markazda O‘zbekiston Respublikasining 30 yilligi munosabati bilan “Yangi O‘zbekiston” bog‘ida bunyod etilgan muhtasham obida “Mustaqillik monumenti” joy olgan. Obidaning eng yuqori qismida O‘zbekiston gerbidan ham o‘rin olgan “Humo qushi” tasvirlangan. Obidaning orqa tomonida globus tasviri tushirilgan bo‘lib, bu xorijda istiqomat qilayotgan vatandoshlar bilan ishlashni nazarda tutadi. Shuningdek, ramzda ochiq kaftlar keltirilgan bo‘lib, bu Fondning ochiqlik va qabul qilishlikni, halollik va samimiylikni, vatandoshlarni “Yangi O‘zbekiston” atrofida yanada jipslashishiga, ularga doimiy ravishda g‘amxo‘rlik qilishga ham tayyor ekanligini anglatadi."}	2025-12-25 08:48:11	2026-01-22 11:56:50
87	37	\N	\N	\N	ru	{"url": null, "title": null, "content": null, "description": null}	2025-12-25 08:48:11	2026-01-22 11:56:50
289	120	\N	\N	\N	uz	{"title": "Biz barcha vatandoshlarni birlashtirib ularga kerakli mativatsiya"}	2025-12-27 19:14:10	2026-01-23 06:03:32
290	120	\N	\N	\N	ru	{"title": "Мы объединяем всех наших соотечественников и даем им необходимую мотивацию."}	2025-12-27 19:14:10	2026-01-23 06:03:32
291	120	\N	\N	\N	en	{"title": "We unite all our compatriots and give them the motivation they need."}	2025-12-27 19:14:10	2026-01-23 06:03:32
180	60	\N	\N	\N	uz	{"title": "Qoraqalpog'iston Respublikasi", "description": "Viloyatning eng qadimiy shahri va markazi bo‘lgan Termizda va uning atrofida zardushtiylar, nestorianlar, buddistlar kabi turli xalqlarning shaharlari va qalʼalarining xarobalari, meʼmorchilik va arxeologiya obidalari, shuningdek islom meʼmorchiligi yodgorliklari saqlanib qolgan. Termizdan uncha uzoq bo‘lmagan joyda esa, fil suyagidan yasalgan shaxmat donalari topilgan,"}	2025-12-26 13:38:23	2026-01-17 11:43:43
166	60	\N	\N	\N	\N	{"code": "UZ-QR", "path": "m144.74 21.815.321 7.095-1.848 5.366-2.96 5-2.593 5.55-.928 3.888H134.7l-1.664.183-1.297 1.296-.551 2.408.744 4.255 1.113 2.407.745 2.592-2.225.744-2.777-1.48-2.225 1.297-1.664 3.703-2.225 3.887-2.032 2.224-2.777-1.663-.367-3.704-.184-5.734-1.113-1.48v-3.17h1.481l1.112 2.592 1.664.928 2.593-.928 1.296-2.776v-3.703l.929-2.96-2.786-1.663-2.96-2.407-.552-2.224 1.664-1.848 1.664-.367 1.848.928.184-7.582 2.593-.367-.184-2.96-2.225-.55-3.512-.552-1.297.928-1.48 1.847-2.032.928 1.297-2.03 2.592-4.807 1.665-2.407-.929-2.776-1.848-2.591.552-3.51.928-3.144 3.126-5.909zM109.508.311l-.165 3.262-1.481 2.96-.184 4.438-3.512 3.143-1.848 2.96-.184 5.366-2.408 2.408-1.113 5.183-2.776 4.438-1.849 4.99-.367 4.255.184 5.551 1.112 2.591 1.848 3.327-.368 2.408-2.776 7.765.368 4.807 2.031 4.806 2.032 2.407 2.777 1.296 3.705 1.48 2.777.184 2.409 1.847 1.848.551.928-1.847 1.48-.368 2.225.184 1.664-.744 4.625-1.48 2.409-1.112 1.48.928.745 3.327-1.664 2.031-2.602 1.682.928 3.327 2.032.928 1.664 1.663 4.809.745 2.409 2.03 2.776.368 5.554.551 4.073.184 3.328-2.03 2.225 1.295 1.112.928 3.512-.744 1.848-.552 3.329 1.112 4.624-.928 4.441-1.48 6.482-2.59.551-2.409h3.145l1.112-1.663-.919-1.654 1.48-3.143 5.737-4.623 4.257-4.254 2.593-4.623.744-3.51-.928-1.296-1.48-1.296-.929-1.847 3.567-.322 19.933 14.382 2.032 6.48 5.581 5.632 5.875 7.086.266.588.589.542 2.326 2.766 5.24 6.442 15.474 19.207 1.498 1.434.506.046 5.379 9.649 14.186 3.841-25.431 47.971-1.158 14.492 6.197 11.166-11.815 6.524 19.234 26.348 12.679 17.626-10.058 4.65-2.345 1.112-.598-.175-.248-.202-4.192-6.81-1.379-2.545-7.356-8.097-2.831-1.755-3.237-1.709-8.228-1.893-2.795-.019-.57.184-1.278.708-.717.818-1.076 2.113-.469 1.719-.662.707h-1.37l-2.069-1.323-.229-1.066-.341-.799-1.857-2.087-.653-.56-.68-.267-1.986-.33-1.296-.533-5.48-4.173-7.567-6.717-1.443-1.379-3.08-3.584-4.753-4.439-.635-.284-.616-.598-.34-.422-2.832-4.954-.377-2.26-.036-2.417-.157-.533-.358-.441-4.855-1.03-3.916 1.278-1.747.772-2.455 4.806-.202-.487-.46-.552-.506-.358-2.225-.763-.744-.468-1.637-2.013-.156.037-.304-.322-.809.184-1.158-1.14-.175-.744.175-.312.515-.414 2.592-.184.322-.413-.184-.735-.469-.671-.376-.892-.203-.864-.147-2.086-1.158-1.507-.028-.616.166-.441 1.002-.533.386.175.781.092.423-.101.414-.395.23-.359.018-.588-.45-1.094-.442-.514-.91-.552-1.609-.22-.533-.221-.754-.652-.763-1.029-.625-1.25-.579-.515-1.812-.588-.956-.772-.285.506-.423 1.314-.331.321-.459.01-1.655-.506-.626-.322-.422.019-.497-.193-1.811-.037-1.444.34h-1.388l-1.232.147-6.813.092-.524-.414-.671-1.286-.598-.276-.809-.974-3.714-3.703-.037-.368.423-1.139-.101-1.131-3.135-4.089-.432-.423-1.021-.607-.368-.055-1.002.276-.882.708-.524.22-2.391-.156-.643-.202-1.453-.791-2.087-.606-.616-.294-1.591-1.379-3.852-4.227-4.422-4.916-2.832-3.584-.441-.396-.028.782-.285 1.084.092.505.818.818.037.267-.156.478-.313.202-.386-.009-.506-.285h-.579l-.469.579v.156l.634.524.24.386-.387 2.003-.285.45-.45.276-1.057-.34-2.437.46-.984.055-1.213-.588-1.113-.221-1.094-.524-1.37-.377-2.666-.551-.827.028-1.306.523-.956.552-2.142 1.783-.57.055-.377.321-.166.634.294.699 1.71 1.24 2.18 1.223.91.349 1.24.23.415.496 2.454 5.698 1.196 1.883.524.625.174.864-.036 1.112.404.368.487-.12 2.896 1.82.883.726.12.652-.469.956-.34.239-.396.018-1.94-.459-1.719.349-.175-.616.111-1.856-.102-.965-.744-2.628-.653-1.232-.818-.909-1.15-.772-4.459-1.149-.735.046-2.004 1.038-1.196.442-.174-.092-.175-.662-.846-.597-.267-.34-.248-1.103-.781-.689-.883-.166-1.315.285-.91.625-.487-.009-.248.266-.368 1.682-.267.689-.294-.119-.68-.791-.405-.101-.616.203-.202.358-.258 1.424.313.717.818.754.405.661.303.993-.018.496-.34.965.027 1.296-.22 1.02.11 1.424-.184 1.48-.166.551-.312.359-.432.147-.782-.028-1.526-.634-.404.092-.258.478-.312 1.103.643 1.102.405 1.011-.175.386-.8.11-2.813-.477-2.382.817-1.627.855-.68.166-.552-.019-1.49-.91-1.719-.34-2.105-.165-4.753.257-1.802.671-2.317 1.14-2.014 1.47-1.158 1.002-1.03 1.479-.377.8-.625 1.461-.984 3.06-.56.781-1.04 1.011-.652.395-1.26.469-1.986.588-.671.404-.79.726-.847 1.765-.285 1.875-.413 1.681.046 2.528.275 2.462-.128 2.509.515 2.178.367.91.35.459-.019.221.331.147.488.947.22 1.056.083.736-.184 1.121v2.15l.386 2.886.276.91.35.661 1.7 2.426.837.019 1.793-.552.395.368.037.478-.294.652-.368.368-.487.303-1.82.634-.773.726-.423.809-.037 1.378-.294.616-.45.496-.506.267H42.85l-1.655-.405-3.64-.312-3.816-.542-6.206-.386-3.466-.074-5.406-.625-3.209-.239-1.728.01-4.763-.432-8.66-.359L.227 34.681l1.397-.359 1.315-.579 27.71-9.051.02-.12 1.535-.266.312-.322.929-.312 12.08-3.86L85.669 7.406l6.114-2.04 2.041-.423z", "offset": null}	2025-12-26 13:22:38	2026-01-17 11:43:43
216	72	\N	\N	\N	uz	{"title": "Xorazm", "description": "Viloyatning eng qadimiy shahri va markazi bo‘lgan Termizda va uning atrofida zardushtiylar, nestorianlar, buddistlar kabi turli xalqlarning shaharlari va qalʼalarining xarobalari, meʼmorchilik va arxeologiya obidalari, shuningdek islom meʼmorchiligi yodgorliklari saqlanib qolgan. Termizdan uncha uzoq bo‘lmagan joyda esa, fil suyagidan yasalgan shaxmat donalari topilgan,"}	2025-12-26 13:52:31	2026-01-19 05:15:07
83	36	\N	\N	\N	uz	{"url": null, "title": "Vatandoshlar", "content": null, "description": "“Vatandoshlar” jamoat fondi 2021 yil 11 avgustda tashkil etilgan. Bizning asosiy maqsadimiz- xorijda istiqomat qilayotgan vatandoshlarni tarixiy Vatani atrofida yanada jipslashtirish, ularning qalbi va ongida yurt bilan faxrlanish tuyg‘usini yuksaltirish, milliy o‘zlikni saqlab qolish, vatandoshlar va ular tomonidan tuzilgan jamoat birlashmalarini qo‘llab-quvvatlash, turli sohalarda faoliyat yuritayotgan vatandoshlarimizning salohiyatini mamlakatimiz taraqqiyotiga samarali yo‘naltirishdir!"}	2025-12-25 08:47:03	2026-01-19 12:36:50
680	200	\N	\N	\N	en	{"title": null}	2026-01-21 06:35:22	2026-01-21 06:35:22
681	201	\N	\N	\N	uz	{"title": "Vatandoshlarimizni respublika oliy ta’lim muassasalarida o‘zbek tili yo‘nalishi bo‘yicha ta’lim olishlariga ko‘mak ko‘rsatish"}	2026-01-21 06:35:47	2026-01-21 06:35:47
662	194	\N	\N	\N	en	{"title": null, "description": null}	2026-01-20 06:40:04	2026-01-23 12:37:07
648	190	\N	\N	\N	ru	{"title": null, "description": null}	2026-01-19 16:38:51	2026-01-23 12:45:01
660	194	\N	\N	\N	uz	{"title": "O’zbek tilini o’rganish mobil ilovasini yuklab oling", "description": "O’zbek tilini o’rganish platformasiga marxamat"}	2026-01-20 06:40:04	2026-01-23 12:37:07
649	190	\N	\N	\N	en	{"title": null, "description": null}	2026-01-19 16:38:51	2026-01-23 12:45:01
650	191	\N	\N	\N	uz	{"title": "Mutoola"}	2026-01-19 17:46:56	2026-01-19 17:47:41
651	191	\N	\N	\N	ru	{"title": null}	2026-01-19 17:46:56	2026-01-19 17:47:41
652	191	\N	\N	\N	en	{"title": null}	2026-01-19 17:46:56	2026-01-19 17:47:41
653	192	\N	\N	\N	uz	{"title": "Mutoola2"}	2026-01-19 17:48:02	2026-01-19 17:48:02
654	192	\N	\N	\N	ru	{"title": null}	2026-01-19 17:48:02	2026-01-19 17:48:02
655	192	\N	\N	\N	en	{"title": null}	2026-01-19 17:48:02	2026-01-19 17:48:02
656	193	\N	\N	\N	uz	{"title": "Mutoola3"}	2026-01-19 17:48:22	2026-01-19 17:48:22
657	193	\N	\N	\N	ru	{"title": null}	2026-01-19 17:48:22	2026-01-19 17:48:22
658	193	\N	\N	\N	en	{"title": null}	2026-01-19 17:48:22	2026-01-19 17:48:22
647	190	\N	\N	\N	uz	{"title": "O’zbek tilini o’rganish platformasiga marxamat", "description": "Siz yuklab olish yoki havola orqali o’tishingiz mumkin"}	2026-01-19 16:38:51	2026-01-23 12:45:01
663	195	\N	\N	\N	uz	{"title": "Yurtimizning boy ilmiy, madaniy va ma’naviy merosini keng targ‘ib qilish"}	2026-01-21 06:32:49	2026-01-21 06:32:49
664	195	\N	\N	\N	ru	{"title": null}	2026-01-21 06:32:49	2026-01-21 06:32:49
665	195	\N	\N	\N	en	{"title": null}	2026-01-21 06:32:49	2026-01-21 06:32:49
666	196	\N	\N	\N	uz	{"title": "Migratsiya va ta’lim sohalarida shartnomaviy-huquqiy hamkorlikni kengaytirish"}	2026-01-21 06:33:14	2026-01-21 06:33:14
518	156	\N	\N	\N	\N	{"video": "https://www.youtube.com/watch?v=UqvRkpzTMJU", "content": "Universitet Loyihasi boshlandi", "last_date": "2025-06-01T13:30"}	2025-12-31 01:02:51	2026-01-20 05:41:52
519	157	\N	\N	\N	uz	{"title": "Futbol mavzusi", "description": "Futbol haqida tushuncha", "description1": "<p><span style=\\"letter-spacing: 0.14px;\\">Loyiha Haqida...</span></p>"}	2025-12-31 01:03:31	2026-01-20 05:42:12
525	158	\N	\N	\N	en	{"title": null, "description": null, "description1": null}	2025-12-31 01:05:11	2026-01-20 05:42:35
526	158	\N	\N	\N	\N	{"video": "https://www.youtube.com/watch?v=UqvRkpzTMJU", "content": "Bank Loyihasi boshlandi", "last_date": "2025-06-01T13:30"}	2025-12-31 01:05:11	2026-01-20 05:42:35
39	18	\N	\N	\N	uz	{"title": "Fond faoliyatining asosiy yo‘nalishlaridan bu xorijda istiqomat qilayotgan vatandoshlar va ular tomonidan tuzilgan jamoat birlashmalari bilan hamkorlik aloqalarini yo‘lga qo‘yish va rivojlantirish. Shu bois vatandoshlar tomonidan tashkil etilgan jamoat birlashmalari faoliyatini rag‘batlantirish, ularga xorijda o‘zbek milliy madaniy markazlarini tashkil etishda amaliy yordam ko‘rsatish, vatandosh birlashmalari bilan hamkorlikda xorijda o‘zbek tili, madaniyati va an’analarini saqlab qolish va rivojlantirishga qaratilgan faoliyatni qo‘llab-quvvatlash va xorijda yurtimizning boy ilmiy, madaniy va ma’naviy merosini keng targ‘ib qilish va ommalashtirish, vatandoshlarga madaniy-ma’rifiy tadbirlarni tashkil etishda ko‘maklashish.x"}	2025-12-23 05:46:01	2026-01-20 06:39:23
659	18	\N	\N	\N	en	{"title": null}	2026-01-20 06:39:23	2026-01-20 06:39:23
682	201	\N	\N	\N	ru	{"title": null}	2026-01-21 06:35:47	2026-01-21 06:35:47
683	201	\N	\N	\N	en	{"title": null}	2026-01-21 06:35:47	2026-01-21 06:35:47
684	202	\N	\N	\N	uz	{"title": "Vatandoshlarimizni yurtimiz nufuzini oshirishga qaratilgan ilmiy, ijodiy izlanishlarini qo‘llab-quvvatlash"}	2026-01-21 06:36:09	2026-01-21 06:36:09
685	202	\N	\N	\N	ru	{"title": null}	2026-01-21 06:36:09	2026-01-21 06:36:09
667	196	\N	\N	\N	ru	{"title": null}	2026-01-21 06:33:14	2026-01-21 06:33:14
668	196	\N	\N	\N	en	{"title": null}	2026-01-21 06:33:14	2026-01-21 06:33:14
669	197	\N	\N	\N	uz	{"title": "Murakkab hayotiy vaziyatga tushib qolgan vatandoshlarni ijtimoiy qo‘llab-quvvatlash va huquqiy yordam ko‘rsatishga ko‘maklashish"}	2026-01-21 06:33:41	2026-01-21 06:33:41
670	197	\N	\N	\N	ru	{"title": null}	2026-01-21 06:33:41	2026-01-21 06:33:41
671	197	\N	\N	\N	en	{"title": null}	2026-01-21 06:33:41	2026-01-21 06:33:41
672	198	\N	\N	\N	uz	{"title": "Vatandoshlar tomonidan tashkil etilgan jamoat birlashmalari faoliyatini rag‘batlantirish"}	2026-01-21 06:34:12	2026-01-21 06:34:12
673	198	\N	\N	\N	ru	{"title": null}	2026-01-21 06:34:12	2026-01-21 06:34:12
674	198	\N	\N	\N	en	{"title": null}	2026-01-21 06:34:12	2026-01-21 06:34:12
675	199	\N	\N	\N	uz	{"title": "Xorijda o‘zbek milliy madaniy markazlarini tashkil etishda amaliy yordam ko‘rsatish"}	2026-01-21 06:34:48	2026-01-21 06:34:48
676	199	\N	\N	\N	ru	{"title": null}	2026-01-21 06:34:48	2026-01-21 06:34:48
677	199	\N	\N	\N	en	{"title": null}	2026-01-21 06:34:48	2026-01-21 06:34:48
678	200	\N	\N	\N	uz	{"title": "Vatandoshlarga madaniy-ma’rifiy tadbirlarni tashkil etishda ko‘maklashish"}	2026-01-21 06:35:22	2026-01-21 06:35:22
679	200	\N	\N	\N	ru	{"title": null}	2026-01-21 06:35:22	2026-01-21 06:35:22
686	202	\N	\N	\N	en	{"title": null}	2026-01-21 06:36:09	2026-01-21 06:36:09
687	203	\N	\N	\N	uz	{"title": "Vatandoshlarni O‘zbekiston hududida tadbirkorlik, investitsiyaviy, ilmiy, madaniy va ma’rifiy faoliyat bilan shug‘ullanishga faol jalb qilish"}	2026-01-21 06:36:32	2026-01-21 06:36:32
688	203	\N	\N	\N	ru	{"title": null}	2026-01-21 06:36:32	2026-01-21 06:36:32
689	203	\N	\N	\N	en	{"title": null}	2026-01-21 06:36:32	2026-01-21 06:36:32
661	194	\N	\N	\N	ru	{"title": null, "description": null}	2026-01-20 06:40:04	2026-01-23 12:37:07
713	211	\N	\N	\N	uz	{"title": "BAAda Vatandoshlar mintaqaviy forumi bo‘lib o‘tmoqda", "description": "<p><strong>Vatandoshlar jamoat fondi</strong>, <strong>O‘zbekiston Respublikasi Tashqi ishlar vazirligi</strong> hamda <strong>Millatlararo munosabatlar qo'mitasi</strong> hamkorligida BAAning Dubay shahrida <strong>Vatandoshlar mintaqaviy forumi</strong>\\r\\n o'tkazilmoqda. Unda BAA, Saudiya Arabistoni, Qatar, Iordaniya, Quvayt \\r\\nva Ummon mamlakatlarida istiqomat qilayotgan vatandoshlar ishtirok \\r\\netmoqda.</p><p class=\\"p1\\"><strong>✔️ Forum doirasida:</strong></p>\\r\\n<p class=\\"p1\\">▫️xorijda o‘zbek tili va madaniyatini asrash,</p>\\r\\n<p class=\\"p1\\">▫️ilm-fan va innovatsiyalarni rivojlantirishda vatandoshlar ishtiroki,</p>\\r\\n<p class=\\"p1\\">▫️ iqtisodiy aloqalar va investitsiyalarni kengaytirish masalalari muhokama qilindi.</p><p><br></p>"}	2026-01-22 05:29:16	2026-01-22 16:17:48
714	211	\N	\N	\N	ru	{"title": null, "description": null}	2026-01-22 05:29:16	2026-01-22 16:17:48
697	205	\N	\N	\N	en	{"title": "<span>“Mutolaa”</span> - eng sara audio va elektron kitoblar!", "url_title": "Mutolaa saytiga otish", "description": "O‘zbek tilidagi eng katta mobil kutubxonani hozir yuklab oling!"}	2026-01-21 12:01:01	2026-01-23 07:11:06
727	205	\N	\N	\N	\N	{"url": "https://mutolaa.com/uz"}	2026-01-23 07:10:26	2026-01-23 07:11:06
698	206	\N	\N	\N	uz	{"title": "Vatandoshlar", "description": "Sotsiyal podcast"}	2026-01-21 18:35:24	2026-01-21 18:35:24
699	206	\N	\N	\N	ru	{"title": null, "description": null}	2026-01-21 18:35:24	2026-01-21 18:35:24
700	206	\N	\N	\N	en	{"title": null, "description": null}	2026-01-21 18:35:24	2026-01-21 18:35:24
701	207	\N	\N	\N	uz	{"title": "Vatanparvar", "description": "Vatanparvarlar"}	2026-01-21 18:36:02	2026-01-21 18:36:02
702	207	\N	\N	\N	ru	{"title": null, "description": null}	2026-01-21 18:36:02	2026-01-21 18:36:02
703	207	\N	\N	\N	en	{"title": null, "description": null}	2026-01-21 18:36:02	2026-01-21 18:36:02
707	209	\N	\N	\N	uz	{"title": "Yosh Avlod", "description": "Yoshlar"}	2026-01-21 18:38:13	2026-01-21 18:51:54
708	209	\N	\N	\N	ru	{"title": null, "description": null}	2026-01-21 18:38:13	2026-01-21 18:51:54
709	209	\N	\N	\N	en	{"title": null, "description": null}	2026-01-21 18:38:13	2026-01-21 18:51:54
19	9	\N	\N	\N	uz	{"title": "Moziydan saboq, bugundan yuksalish", "description": "Moziy va bugun – bu vaqtning ikki qutbi: o‘tgan zamonning ulug‘vorligi va bugunning yuksalishi. Bu yerda tariximizning buyuk sahifalari va hozirgi kunda yaratilayotgan yangi yutuqlar birlashadi. Moziy – bu bizni yuksaltirgan ildizlar, Bugun esa bizning yuksalishimiz, kuchimiz va kelajakka ishonchimizdir. Har bir qadriyat, har bir qadam, bizni kelajakka yetaklaydi. Moziyda o‘rgangan saboqlarimiz, bugunda amalga oshirgan ishlarimizga yo‘l ochadi. Moziy va Bugun – bu vaqtning qiyofasi, bizning kelajakka yo‘limiz!"}	2025-12-23 05:11:35	2026-01-22 09:36:27
716	9	\N	\N	\N	\N	{"url": "https://www.youtube.com/embed/BHACKCNDMW8?si=AtPPS9WpLIT3_TaW"}	2026-01-22 09:36:27	2026-01-22 09:36:27
717	212	\N	\N	\N	uz	{"title": "Birinchi guruh"}	2026-01-22 10:20:38	2026-01-22 10:22:01
718	212	\N	\N	\N	ru	{"title": null}	2026-01-22 10:20:38	2026-01-22 10:22:01
719	212	\N	\N	\N	en	{"title": null}	2026-01-22 10:20:38	2026-01-22 10:22:01
720	213	\N	\N	\N	uz	{"title": "Ikkinchi guruh"}	2026-01-22 10:22:59	2026-01-22 10:22:59
721	213	\N	\N	\N	ru	{"title": null}	2026-01-22 10:22:59	2026-01-22 10:22:59
722	213	\N	\N	\N	en	{"title": null}	2026-01-22 10:22:59	2026-01-22 10:22:59
723	214	\N	\N	\N	uz	{"title": "Hozir", "description": null}	2026-01-22 13:44:13	2026-01-22 13:44:13
724	214	\N	\N	\N	ru	{"title": null, "description": null}	2026-01-22 13:44:13	2026-01-22 13:44:13
725	214	\N	\N	\N	en	{"title": null, "description": null}	2026-01-22 13:44:13	2026-01-22 13:44:13
715	211	\N	\N	\N	en	{"title": null, "description": null}	2026-01-22 05:29:16	2026-01-22 16:17:48
694	1	\N	\N	\N	en	{"title": "<span>Vatandoshlar </span> Jamoat Fondi", "description": "\\"Vatandoshlar\\" jamoat fondi — bu xorijdagi o‘zbekistonlik vatandoshlar bilan aloqalarni mustahkamlash, ularning huquq va manfaatlarini qo‘llab-quvvatlash, shuningdek, ularni O‘zbekiston taraqqiyotiga jalb etish maqsadida tashkil etilgan notijorat tashkilotdir."}	2026-01-21 08:29:27	2026-01-23 06:34:18
706	208	\N	\N	\N	en	{"title": null, "description": null}	2026-01-21 18:37:10	2026-01-23 12:48:46
729	208	\N	\N	\N	\N	{"url": "https://gov.uz/oz/mudofaa/news/view/46786"}	2026-01-23 12:48:46	2026-01-23 12:48:46
695	205	\N	\N	\N	uz	{"title": "<span>“Mutolaa”</span> - eng sara audio va elektron kitoblar!", "url_title": "Mutolaa saytiga otish", "description": "O‘zbek tilidagi eng katta mobil kutubxonani hozir yuklab oling!"}	2026-01-21 12:01:01	2026-01-23 07:11:06
696	205	\N	\N	\N	ru	{"title": "<span>“Mutolaa”</span> - eng sara audio va elektron kitoblar!", "url_title": "O‘zbek tilidagi eng katta mobil kutubxonani hozir yuklab oling!", "description": "O‘zbek tilidagi eng katta mobil kutubxonani hozir yuklab oling!"}	2026-01-21 12:01:01	2026-01-23 07:11:06
1	1	\N	\N	\N	uz	{"title": "<span>Vatandoshlar </span> Jamoat Fondi", "description": "\\"Vatandoshlar\\" jamoat fondi — bu xorijdagi o‘zbekistonlik vatandoshlar bilan aloqalarni mustahkamlash, ularning huquq va manfaatlarini qo‘llab-quvvatlash, shuningdek, ularni O‘zbekiston taraqqiyotiga jalb etish maqsadida tashkil etilgan notijorat tashkilotdir."}	2025-12-23 04:43:11	2026-01-23 06:34:18
726	194	\N	\N	\N	\N	{"link1": "https://apple.com/", "link2": "https://google.com/"}	2026-01-23 06:58:27	2026-01-23 12:37:07
728	190	\N	\N	\N	\N	{"link1": null, "link2": null}	2026-01-23 12:44:51	2026-01-23 12:45:01
704	208	\N	\N	\N	uz	{"title": "Vatan Himoyachilari", "description": "Askarlar"}	2026-01-21 18:37:10	2026-01-23 12:48:46
705	208	\N	\N	\N	ru	{"title": null, "description": null}	2026-01-21 18:37:10	2026-01-23 12:48:46
\.


--
-- Data for Name: page_sections; Type: TABLE DATA; Schema: public; Owner: vatandoshlar_usr
--

COPY public.page_sections (id, menu_main_id, sort_order, status, slug, category, category_slug, parent_id, created_at, updated_at, publish_at) FROM stdin;
43	16	43	t	vatandoshlar-jamoat-fondi-pul-mablag-ini-kimdan-oladi	\N	\N	\N	2025-12-25 09:50:30	2026-01-23 14:06:13	2026-01-23 19:06:01
74	33	74	t	qollash	video	video	60	2025-12-26 13:55:58	2025-12-28 06:10:13	\N
3	3	3	t	qatnashgan-vatandoshlar-soni-c	\N	\N	\N	2025-12-23 04:45:52	2025-12-23 04:45:52	\N
75	33	75	t	togri-yol	video	video	60	2025-12-26 13:56:16	2025-12-28 06:10:28	\N
76	33	76	t	asosiysi	video	video	60	2025-12-26 13:56:35	2025-12-28 06:10:55	\N
5	11	5	t	o-zbekiston-sirli-o-tmish-va-yorqin-kelajak-maskani	\N	\N	\N	2025-12-23 05:06:24	2025-12-23 05:06:24	\N
6	12	6	t	forum-va-seminarlardan-video	\N	\N	\N	2025-12-23 05:07:48	2025-12-23 05:07:48	\N
7	12	7	t	fotogalareya	\N	\N	\N	2025-12-23 05:08:27	2025-12-23 05:08:27	\N
8	7	8	t	qadriyatlarimiz-bizni-birlashtiradi	\N	\N	\N	2025-12-23 05:10:29	2025-12-23 05:10:29	\N
54	31	54	t	fotogalareya11	\N	\N	\N	2025-12-25 13:36:22	2025-12-29 10:30:46	\N
13	19	13	t	oliy-maqsadimiz-xorijdagi-vatandoshlarni-vatan-atrofida-birlashtirish-ularning-qalbi-va-ongida-yurtdan-faxrlanish-tuyg-usini-yuksaltirish-milliy-o-zlikni-asrashdir	\N	\N	\N	2025-12-23 05:30:06	2025-12-23 05:30:06	\N
57	30	57	t	yurtdoshlar	Url	url	52	2025-12-26 11:10:22	2026-01-23 13:51:21	2026-01-22 14:34:51
58	30	58	t	sahifa-haqida	Url	url	52	2025-12-26 11:10:39	2026-01-23 13:54:19	2026-01-22 14:35:13
19	23	19	t	ozbekiston	\N	\N	\N	2025-12-23 05:47:39	2025-12-23 05:47:39	\N
20	23	20	t	buyuk-britaniya	\N	\N	\N	2025-12-23 05:48:00	2025-12-23 05:48:00	\N
27	23	27	t	mahalla-usa-o-zbek-diasporal-tashkiloti	tashkilot	tashkilot-1	20	2025-12-23 06:02:28	2025-12-23 06:02:28	\N
28	23	28	t	mahalla-usa-o-zbek-diasporal-tashkiloticbf	Nomi	nomi-2	27	2025-12-23 06:03:58	2025-12-23 06:03:58	\N
29	23	29	t	sadikov-baxodir-talibjonovich-pittsburgdagi-uzbeklar-jamiyati-rahbariew	Rahbar	rahbar-2	27	2025-12-23 06:05:38	2025-12-23 06:05:38	\N
30	23	30	t	yurtdosh-uzbek-amerika-assotsiatsiyasi	tashkilot	tashkilot-1	20	2025-12-23 06:06:15	2025-12-23 06:06:15	\N
31	23	31	t	yurtdosh-uzbek-amerika-assotsiatsiyasi-batafsildd	Nomi	nomi-3	30	2025-12-23 06:07:24	2025-12-23 06:07:24	\N
32	23	32	t	sadikov-baxodir-talibjonovich-pittsburgdagi-uzbeklar-jamiyati-rahbaricc	Rahbar	rahbar-3	30	2025-12-23 06:08:35	2025-12-23 06:08:35	\N
35	17	35	t		\N	\N	\N	2025-12-25 08:29:18	2025-12-25 08:29:18	\N
12	18	12	t	fondning-ramzi	\N	\N	\N	2025-12-23 05:29:07	2025-12-25 08:31:46	\N
41	16	41	t	vatandosh-kim	\N	\N	\N	2025-12-25 09:49:29	2025-12-25 09:49:29	\N
42	16	42	t	vatandoshlar-jamoat-fondi-qanday-tashkilot	\N	\N	\N	2025-12-25 09:50:10	2025-12-25 09:50:10	\N
48	28	48	t	forum-va-seminarlardan-csfdgrthfyj	\N	\N	\N	2025-12-25 13:22:39	2025-12-25 13:22:39	\N
50	29	50	t	o-zbekiston-sirli-o-tmish-va-yorqin-kelajak-maskanidfvhg	\N	\N	\N	2025-12-25 13:23:52	2025-12-25 13:23:52	\N
51	29	51	t	fotogalareyacdvfghjkl-xcdsgrtyu7io	\N	\N	\N	2025-12-25 13:24:51	2025-12-25 13:24:51	\N
52	30	52	t	forum-va-seminarlardan-videovv	\N	\N	\N	2025-12-25 13:32:21	2025-12-25 13:32:21	\N
53	31	53	t	o-zbekiston-sirli-o-tmish-va-yorqin-kelajak-maskanixzfbgnhmjkl	\N	\N	\N	2025-12-25 13:35:56	2025-12-25 13:35:56	\N
14	14	14	t	sattarov-odiljon-berdimuratovich	\N	\N	\N	2025-12-23 05:32:28	2025-12-26 05:17:05	\N
1	2	1	t	span-vatandoshlar-span-jamoat-fondi	\N	\N	\N	2025-12-23 04:43:11	2026-02-01 16:32:01	2026-01-21 08:29:24
39	24	40	t	oliy-maqsadimiz-xorijdagi-vatandoshlarni-vatan-atrofida-birlashtirish-ularning-qalbi-va-ongida-yurtdan-faxrlanish-tuyg-usini-yuksaltirish-milliy-o-zlikni-asrashdirv	\N	\N	\N	2025-12-25 08:50:21	2025-12-26 06:52:21	\N
59	32	59	t	har-bir-manzil-yangi-bir-orzuss	\N	\N	\N	2025-12-26 13:16:46	2025-12-26 13:16:46	\N
61	33	61	t	andijon	\N	\N	\N	2025-12-26 13:25:28	2025-12-26 13:25:28	\N
62	33	62	t	buxoro	\N	\N	\N	2025-12-26 13:26:58	2025-12-26 13:26:58	\N
63	33	63	t	farg-ona	\N	\N	\N	2025-12-26 13:28:16	2025-12-26 13:28:16	\N
64	33	64	t	jizzax	\N	\N	\N	2025-12-26 13:28:53	2025-12-26 13:28:53	\N
66	33	66	t	navoiy	\N	\N	\N	2025-12-26 13:29:58	2025-12-26 13:29:58	\N
67	33	67	t	qashqadaryo	\N	\N	\N	2025-12-26 13:30:35	2025-12-26 13:30:35	\N
68	33	68	t	samarqand	\N	\N	\N	2025-12-26 13:31:14	2025-12-26 13:31:14	\N
69	33	69	t	sirdaryo	\N	\N	\N	2025-12-26 13:31:46	2025-12-26 13:31:46	\N
70	33	70	t	surxondaryo	\N	\N	\N	2025-12-26 13:32:12	2025-12-26 13:32:12	\N
89	33	66	t	namanganvs	\N	\N	\N	2025-12-26 14:25:11	2025-12-26 14:25:21	\N
111	33	111	t		video	video-13	72	2025-12-26 14:34:51	2025-12-26 14:34:51	\N
112	33	112	t		video	video-13	72	2025-12-26 14:35:10	2025-12-26 14:35:10	\N
113	33	113	t		video	video-13	72	2025-12-26 14:35:23	2025-12-26 14:35:23	\N
114	33	114	t		video	video-14	73	2025-12-26 14:35:56	2025-12-26 14:35:56	\N
115	33	115	t		video	video-14	73	2025-12-26 14:36:11	2025-12-26 14:36:11	\N
116	33	116	t		video	video-14	73	2025-12-26 14:36:27	2025-12-26 14:36:27	\N
93	33	93	t	yurtdosh	video	video-7	66	2025-12-26 14:27:29	2025-12-27 14:23:30	\N
94	33	94	t	qollsh	video	video-7	66	2025-12-26 14:27:50	2025-12-27 14:23:56	\N
95	33	95	t	qollang	video	video-7	66	2025-12-26 14:28:05	2025-12-27 14:24:21	\N
34	27	34	t	na-munali-yurtdoshlar	\N	\N	\N	2025-12-23 06:22:39	2026-01-14 11:30:41	2026-01-14 11:30:31
71	33	71	t	toshkent-v	\N	\N	\N	2025-12-26 13:32:47	2026-01-19 05:15:20	2026-01-19 05:15:15
60	33	60	t	qoraqalpog-iston-respublikasi	\N	\N	\N	2025-12-26 13:22:38	2026-01-17 11:43:43	2026-01-17 11:43:41
72	33	72	t	xorazm	\N	\N	\N	2025-12-26 13:33:21	2026-01-19 05:15:07	2026-01-17 11:42:06
73	33	73	t	toshkent-sh	\N	\N	\N	2025-12-26 13:33:53	2026-01-19 05:15:28	2026-01-19 05:15:23
18	22	18	t		\N	\N	\N	2025-12-23 05:46:01	2026-01-20 06:39:23	2026-01-20 06:39:16
56	24	38	t	video	\N	\N	\N	2025-12-26 06:41:10	2026-01-19 12:36:30	2026-01-19 12:36:27
38	24	39	t	fondning-tashkil-topishi-haqida	\N	\N	\N	2025-12-25 08:48:32	2026-01-19 12:36:37	2026-01-19 12:36:33
36	24	36	t	vatandoshlar	\N	\N	\N	2025-12-25 08:47:03	2026-01-19 12:36:50	2026-01-19 12:35:29
17	15	2	t	vatandoshlarning-huquq-va-erkinliklarini-himoya-qilishga-ko-maklashish	\N	\N	\N	2025-12-23 05:34:27	2026-01-21 06:41:18	\N
40	15	3	t	o-zbek-tili-madaniyati-va-an-analarini-saqlab-qolish-va-rivojlantirish	\N	\N	\N	2025-12-25 09:42:07	2026-01-21 06:41:35	\N
4	4	4	t	vatandoshlar-jamoat-fondi	\N	\N	\N	2025-12-23 04:50:44	2026-02-02 10:29:29	2026-01-23 17:33:52
9	9	9	t	moziydan-saboq-bugundan-yuksalish	\N	\N	\N	2025-12-23 05:11:35	2026-01-22 09:36:27	2026-01-22 14:35:56
37	24	37	t	fondning-ramzi1	\N	\N	\N	2025-12-25 08:48:11	2026-01-22 11:56:50	2026-01-19 12:32:58
15	14	15	t	sanayev-bolidin-elamonovich	\N	\N	\N	2025-12-23 05:33:13	2026-01-22 12:09:28	\N
2	3	2	t	qatnashgan-vatandoshlar-soni	\N	\N	\N	2025-12-23 04:45:01	2026-01-22 15:13:26	2026-01-22 20:13:07
77	33	77	t	ajoyib-manzil	video	video-1	61	2025-12-26 13:57:36	2025-12-28 06:11:54	\N
78	33	78	t	eng-sara-joylar	video	video-1	61	2025-12-26 13:57:53	2025-12-28 06:12:16	\N
79	33	79	t	korishga-arziydigan-joylar	video	video-1	61	2025-12-26 13:58:11	2025-12-28 06:13:10	\N
80	33	80	t	chiroyli-manzilgohlar	video	video-2	62	2025-12-26 14:17:34	2025-12-28 06:14:41	\N
81	33	81	t	eng-chiroyli-joy	video	video-2	62	2025-12-26 14:17:51	2025-12-28 06:14:55	\N
82	33	82	t	golsdo	video	video-2	62	2025-12-26 14:18:09	2025-12-28 06:15:23	\N
83	33	83	t	futbol	video	video-3	63	2025-12-26 14:18:56	2025-12-28 06:17:03	\N
84	33	84	t	real	video	video-3	63	2025-12-26 14:19:13	2025-12-28 06:17:19	\N
85	33	85	t	man-city	video	video-3	63	2025-12-26 14:19:30	2025-12-28 06:20:50	\N
86	33	86	t	man-united	video	video-4	64	2025-12-26 14:20:10	2025-12-28 06:22:02	\N
88	33	88	t	juventus	video	video-4	64	2025-12-26 14:20:46	2025-12-28 06:22:17	\N
87	33	87	t	barcelona	video	video-4	64	2025-12-26 14:20:28	2025-12-28 06:22:33	\N
90	33	90	t	roma	video	video-6	89	2025-12-26 14:26:17	2025-12-28 06:23:24	\N
91	33	91	t	latsio	video	video-6	89	2025-12-26 14:26:32	2025-12-28 06:23:42	\N
92	33	92	t	inter	video	video-6	89	2025-12-26 14:26:48	2025-12-28 06:24:26	\N
96	33	96	t	saylov	video	video-8	67	2025-12-26 14:28:39	2025-12-28 06:25:23	\N
97	33	97	t	golland	video	video-8	67	2025-12-26 14:28:53	2025-12-28 06:25:45	\N
98	33	98	t	chelsea	video	video-8	67	2025-12-26 14:29:06	2025-12-28 06:26:01	\N
99	33	99	t	atetico-madrid	video	video-9	68	2025-12-26 14:29:51	2025-12-28 06:27:11	\N
100	33	100	t	betis	video	video-9	68	2025-12-26 14:30:05	2025-12-28 06:27:26	\N
101	33	101	t	sevila	video	video-9	68	2025-12-26 14:30:18	2025-12-28 06:27:43	\N
102	33	102	t	atalanta	video	video-10	69	2025-12-26 14:30:52	2025-12-28 06:28:55	\N
103	33	103	t	spezia	video	video-10	69	2025-12-26 14:31:09	2025-12-28 06:29:10	\N
104	33	104	t	sasuolo	video	video-10	69	2025-12-26 14:31:24	2025-12-28 06:29:41	\N
105	33	105	t	bornmut	video	video-11	70	2025-12-26 14:32:13	2025-12-28 06:30:40	\N
106	33	106	t	astron-villa	video	video-11	70	2025-12-26 14:32:30	2025-12-28 06:30:53	\N
107	33	107	t	swansea	video	video-11	70	2025-12-26 14:32:43	2025-12-28 06:31:08	\N
108	33	108	t	futbolchi	video	video-12	71	2025-12-26 14:33:17	2025-12-28 06:32:15	\N
109	33	109	t	championship	video	video-12	71	2025-12-26 14:33:35	2025-12-28 06:35:06	\N
110	33	110	t	b-seria	video	video-12	71	2025-12-26 14:33:48	2025-12-28 06:35:30	\N
124	23	124	t	new-york-university	tashkilot	tashkilot	19	2025-12-29 08:12:53	2025-12-29 08:12:53	\N
125	23	125	t	harvard-university	tashkilot	tashkilot	19	2025-12-29 08:13:35	2025-12-29 08:13:35	\N
126	23	126	t	pittsburgdagi-uzbeklar-jamiyati	Nomi	nomi-5	124	2025-12-29 08:15:50	2025-12-29 08:15:50	\N
127	23	127	t	pittsburgdagi-uzbeklar-jamiyatisddd	Nomi	nomi-6	125	2025-12-29 08:19:13	2025-12-29 08:19:13	\N
128	23	128	t	sadikov-baxodir-talibjonovich	Rahbar	rahbar-5	124	2025-12-29 08:22:05	2025-12-29 08:22:05	\N
129	23	129	t	sadikov-baxodir-talibjonovichff	Rahbar	rahbar-6	125	2025-12-29 08:23:08	2025-12-29 08:23:08	\N
132	40	132	t	chinor	\N	\N	\N	2025-12-29 12:30:29	2025-12-29 12:30:29	\N
133	40	133	t	malaka-oshirish	\N	\N	\N	2025-12-29 12:31:16	2025-12-29 12:31:16	\N
134	40	134	t	maktab-loyihasi	\N	\N	\N	2025-12-29 12:31:57	2025-12-29 12:31:57	\N
135	41	135	t	2023-yil	\N	\N	\N	2025-12-29 12:34:27	2025-12-29 12:39:21	\N
139	41	139	t	2024-yil	\N	\N	\N	2025-12-29 12:44:36	2025-12-29 12:44:36	\N
131	40	131	t	anor-tanlovi	\N	\N	\N	2025-12-29 12:29:53	2025-12-29 12:47:40	\N
143	42	143	t		\N	\N	\N	2025-12-30 07:36:01	2025-12-30 07:36:01	\N
150	38	150	t	2022-mavsum	Yillar	yillar-1	148	2025-12-30 16:47:11	2025-12-30 16:47:11	\N
151	38	151	t	2023mavsum	Yillar	yillar-1	148	2025-12-30 16:47:54	2025-12-30 16:47:54	\N
152	38	152	t	2022-mavsumdagi	Yillar	yillar-2	149	2025-12-30 16:54:48	2025-12-30 16:54:48	\N
153	38	153	t	2023mavsumdagi	Yillar	yillar-2	149	2025-12-30 16:58:03	2025-12-30 16:58:03	\N
160	46	160	t	yangi-o-zbekiston-tili-va-adabiyoti-fani-o-qituvchilari	\N	\N	\N	2026-01-05 04:59:13	2026-01-05 08:07:49	\N
162	46	162	t	yangi-o-zbekiston-tili-va-adabiyoti-fani-o-qituvchilarir	\N	\N	\N	2026-01-05 05:00:18	2026-01-05 08:08:17	\N
165	45	165	t	transfor	\N	\N	\N	2026-01-05 05:39:04	2026-01-05 05:39:04	\N
166	45	166	t	biz-barcha-vatandoshlarni-birlashtirib-ularga-kerakli-mativatsiyacc	\N	\N	\N	2026-01-05 05:39:36	2026-01-05 05:39:36	\N
167	45	167	t	jahongir	\N	\N	\N	2026-01-05 07:09:42	2026-01-05 07:09:42	\N
168	45	168	t	murod	\N	\N	\N	2026-01-05 07:10:19	2026-01-05 07:10:19	\N
169	45	169	t	mustafo	\N	\N	\N	2026-01-05 07:10:54	2026-01-05 07:10:54	\N
170	45	170	t	bersz	\N	\N	\N	2026-01-05 07:12:23	2026-01-05 07:12:23	\N
171	45	171	t	forum-va-seminarlardan-videodd	\N	\N	\N	2026-01-05 07:13:02	2026-01-05 07:13:02	\N
172	45	172	t	man	\N	\N	\N	2026-01-05 07:14:23	2026-01-05 07:14:23	\N
173	45	173	t	mbh0223	\N	\N	\N	2026-01-05 07:22:35	2026-01-05 07:22:35	\N
161	46	161	t	yangi-o-zbekiston-tili-va-adabiyoti-fani-o-qituvchilariv	\N	\N	\N	2026-01-05 04:59:44	2026-01-05 08:08:03	\N
163	46	163	t	yangi-o-zbekiston-tili-va-adabiyoti-fani-o-qituvchilaric	\N	\N	\N	2026-01-05 05:00:57	2026-01-05 08:08:36	\N
174	3	174	t	qatnashgan-vatandoshlar-sonid	\N	\N	\N	2026-01-05 08:15:32	2026-01-05 08:15:32	\N
175	3	175	t	qatnashgan-vatandoshlar-soniz	\N	\N	\N	2026-01-05 08:16:14	2026-01-05 08:16:14	\N
176	3	176	t	qatnashgan-vatandoshlar-sonidd	\N	\N	\N	2026-01-05 08:17:25	2026-01-05 08:17:25	\N
158	38	158	t	bank-loyihasi	\N	\N	\N	2025-12-31 01:05:11	2026-01-20 05:42:35	2026-01-19 17:16:16
157	38	157	t	futbol-mavzusi	\N	\N	\N	2025-12-31 01:03:31	2026-01-20 05:42:12	2026-01-19 16:51:14
149	38	149	t	yoshlar-tanlovi	\N	\N	\N	2025-12-30 16:44:29	2026-01-21 12:21:52	2026-01-19 17:22:35
156	38	156	t	universitet-tanlovi2	\N	\N	\N	2025-12-31 01:02:51	2026-01-20 05:41:52	2026-01-19 16:51:45
119	26	5	t	xorijdagi-vatandoshlar-uchun-anor-damolish-oromgohi-ochildixxx	\N	\N	\N	2025-12-27 17:01:20	2026-01-22 15:36:07	2026-01-17 08:03:23
118	26	4	t	xorijdagi-vatandoshlar-uchun-anor-damolish-oromgohi-ochildixx	\N	\N	\N	2025-12-27 16:59:20	2026-01-22 15:36:08	2026-01-18 08:03:07
177	3	177	t	qatnashgan-vatandoshlar-sonii	\N	\N	\N	2026-01-05 08:17:42	2026-01-05 08:17:42	\N
164	45	164	t	tt	\N	\N	\N	2026-01-05 05:37:55	2026-01-05 08:20:20	\N
190	47	1	t	o-zbek-tilini-o-rganish-platformasiga-marxamat	\N	\N	\N	2026-01-19 16:38:51	2026-01-23 12:45:01	2026-01-19 16:38:28
188	44	188	t	google-map	\N	\N	\N	2026-01-15 14:30:30	2026-01-15 14:33:02	2026-01-15 14:29:15
197	15	6	t	murakkab-hayotiy-vaziyatga-tushib-qolgan-vatandoshlarni-ijtimoiy-qo-llab-quvvatlash-va-huquqiy-yordam-ko-rsatishga-ko-maklashish	\N	\N	\N	2026-01-21 06:33:41	2026-01-21 06:42:20	2026-01-21 06:33:16
198	15	7	t	vatandoshlar-tomonidan-tashkil-etilgan-jamoat-birlashmalari-faoliyatini-rag-batlantirish	\N	\N	\N	2026-01-21 06:34:12	2026-01-21 06:42:34	2026-01-21 06:33:55
199	15	8	t	xorijda-o-zbek-milliy-madaniy-markazlarini-tashkil-etishda-amaliy-yordam-ko-rsatish	\N	\N	\N	2026-01-21 06:34:48	2026-01-21 06:42:45	2026-01-21 06:34:14
200	15	9	t	vatandoshlarga-madaniy-ma-rifiy-tadbirlarni-tashkil-etishda-ko-maklashish	\N	\N	\N	2026-01-21 06:35:22	2026-01-21 06:42:58	2026-01-21 06:34:57
201	15	10	t	vatandoshlarimizni-respublika-oliy-ta-lim-muassasalarida-o-zbek-tili-yo-nalishi-bo-yicha-ta-lim-olishlariga-ko-mak-ko-rsatish	\N	\N	\N	2026-01-21 06:35:47	2026-01-21 06:43:17	2026-01-21 06:35:25
202	15	11	t	vatandoshlarimizni-yurtimiz-nufuzini-oshirishga-qaratilgan-ilmiy-ijodiy-izlanishlarini-qo-llab-quvvatlash	\N	\N	\N	2026-01-21 06:36:09	2026-01-21 06:43:25	2026-01-21 06:35:50
203	15	12	t	vatandoshlarni-o-zbekiston-hududida-tadbirkorlik-investitsiyaviy-ilmiy-madaniy-va-ma-rifiy-faoliyat-bilan-shug-ullanishga-faol-jalb-qilish	\N	\N	\N	2026-01-21 06:36:32	2026-01-21 06:43:33	2026-01-21 06:36:19
208	52	1	t	vatan-himoyachilari	\N	\N	\N	2026-01-21 18:37:10	2026-01-23 12:48:46	2026-01-21 18:36:23
148	38	148	t	anor-loyihasi1	\N	\N	\N	2025-12-30 16:43:36	2026-01-23 14:11:13	2026-01-14 06:08:47
194	47	2	t	o-zbek-tilini-o-rganish-mobil-ilovasini-yuklab-oling	\N	\N	\N	2026-01-20 06:40:04	2026-02-02 10:33:07	2026-01-20 06:36:55
191	50	1	t	mutoola1	\N	\N	\N	2026-01-19 17:46:56	2026-01-19 17:47:41	2026-01-19 17:46:43
192	50	1	t	mutoola2	\N	\N	\N	2026-01-19 17:48:02	2026-01-19 17:48:02	2026-01-19 17:47:43
193	50	1	t	mutoola3	\N	\N	\N	2026-01-19 17:48:22	2026-01-19 17:48:22	2026-01-19 17:48:06
209	52	1	t	yosh-avlod	\N	\N	\N	2026-01-21 18:38:13	2026-01-21 18:51:54	2026-01-21 18:37:23
33	26	3	t	vatandoshlar-jamoat-fondi-tomonidan-xorijdagi-vatandoshlar-uchun-yangi-loyiha-amalga-oshirilmoqda	\N	\N	\N	2025-12-23 06:21:44	2026-01-22 15:36:24	2026-01-19 08:02:59
117	26	2	t	xorijdagi-vatandoshlar-uchun-anor-damolish-oromgohi-ochildi	\N	\N	\N	2025-12-27 16:57:51	2026-01-22 15:36:26	2026-01-20 08:02:45
16	15	1	t	jamoat-birlashmalari-bilan-hamkorlik-aloqalarini-yo-lga-qo-yish-va-rivojlantirish	\N	\N	\N	2025-12-23 05:34:07	2026-01-21 06:40:58	\N
195	15	4	t	yurtimizning-boy-ilmiy-madaniy-va-ma-naviy-merosini-keng-targ-ib-qilish	\N	\N	\N	2026-01-21 06:32:49	2026-01-21 06:41:49	2026-01-21 06:32:02
196	15	5	t	migratsiya-va-ta-lim-sohalarida-shartnomaviy-huquqiy-hamkorlikni-kengaytirish	\N	\N	\N	2026-01-21 06:33:14	2026-01-21 06:42:06	2026-01-21 06:32:52
211	26	1	t	baada-vatandoshlar-mintaqaviy-forumi-bo-lib-o-tmoqda	\N	\N	\N	2026-01-22 05:29:16	2026-01-22 16:17:48	2026-01-22 10:28:04
214	26	2132	t	hozir	\N	\N	\N	2026-01-22 13:44:13	2026-01-23 05:30:38	2026-01-22 18:43:38
120	35	120	t	biz-barcha-vatandoshlarni-birlashtirib-ularga-kerakli-mativatsiya	\N	\N	\N	2025-12-27 19:14:10	2026-01-23 06:03:32	2026-01-17 10:32:04
206	52	1	t	vatandoshlartr	\N	\N	\N	2026-01-21 18:35:24	2026-01-21 18:35:24	2026-01-21 18:34:03
207	52	1	t	vatanparvar	\N	\N	\N	2026-01-21 18:36:02	2026-01-21 18:36:02	2026-01-21 18:35:26
187	27	187	t	text	\N	\N	\N	2026-01-14 17:15:56	2026-01-22 09:24:10	2026-01-14 17:15:40
212	53	211	t	birinchi-guruh	\N	\N	\N	2026-01-22 10:20:38	2026-01-22 10:22:01	2026-01-22 15:19:35
213	53	212	t	ikkinchi-guruh	\N	\N	\N	2026-01-22 10:22:59	2026-01-22 10:22:59	2026-01-22 15:22:12
205	51	1	t	span-mutolaa-span-eng-sara-audio-va-elektron-kitoblar	\N	\N	\N	2026-01-21 12:01:01	2026-01-23 07:11:06	2026-01-21 11:57:53
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: vatandoshlar_usr
--

COPY public.password_reset_tokens (email, token, created_at) FROM stdin;
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: vatandoshlar_usr
--

COPY public.permissions (id, name, sort_order, created_at, updated_at) FROM stdin;
1	given	0	2026-01-14 12:33:50	2026-01-14 12:33:50
2	not_given	0	2026-01-14 13:21:36	2026-01-14 13:21:36
\.


--
-- Data for Name: role_menu_permissions; Type: TABLE DATA; Schema: public; Owner: vatandoshlar_usr
--

COPY public.role_menu_permissions (id, role_id, menu_main_id, permission_id, created_at, updated_at) FROM stdin;
16	3	13	1	2026-01-27 09:29:57	2026-01-27 09:29:57
17	3	15	1	2026-01-27 09:29:57	2026-01-27 09:29:57
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: vatandoshlar_usr
--

COPY public.roles (id, name, sort_order, created_at, updated_at, status) FROM stdin;
1	admin	0	\N	\N	t
2	moderator	0	\N	2026-01-22 06:36:29	f
3	test-role	0	2026-01-27 09:25:50	2026-01-27 09:25:50	t
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: vatandoshlar_usr
--

COPY public.sessions (id, user_id, ip_address, user_agent, payload, last_activity) FROM stdin;
Ebk30JTihEOfko2Folq4iqLb0VItg2tPBs1dJYGm	\N	95.130.227.60	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36	YTo0OntzOjY6Il90b2tlbiI7czo0MDoiUEhWOXlhOE9keksyUXZWdGZMSDlXVzE1Rm5qS1VCT1VKN0JjMVVpdiI7czo2OiJsb2NhbGUiO3M6MjoidXoiO3M6OToiX3ByZXZpb3VzIjthOjI6e3M6MzoidXJsIjtzOjI2OiJodHRwOi8vdmF0YW5kb3NobGFyLjd6Ny51eiI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1769089324
jmBfGmgucpnRNG8N4j1EQKHpVypoIrNOGWhLHmcg	\N	95.130.227.60	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36	YTo0OntzOjY6Il90b2tlbiI7czo0MDoiRUpsWWE1UGxVcWppT2kzZXlGZ3BZdWx0bjl5aWZUd0E0T2NqZVBOMCI7czo2OiJsb2NhbGUiO3M6MjoidXoiO3M6OToiX3ByZXZpb3VzIjthOjI6e3M6MzoidXJsIjtzOjI2OiJodHRwOi8vdmF0YW5kb3NobGFyLjd6Ny51eiI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1769095683
fZu0rSQCJjpOrek5ABnmO2TvvksDG4OnlrTiin1n	\N	95.130.227.60	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36	YTo0OntzOjY6Il90b2tlbiI7czo0MDoiMmxUYUFKblRYZjFBcFlwUTBZVmcwd2FXQ0lKakxoY2xFVVZTN2NzTCI7czo2OiJsb2NhbGUiO3M6MjoidXoiO3M6OToiX3ByZXZpb3VzIjthOjI6e3M6MzoidXJsIjtzOjI2OiJodHRwOi8vdmF0YW5kb3NobGFyLjd6Ny51eiI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1769097606
WoSSVN6QGmbtcyBrxRSZXL8JABiYdCLjCA3dBLlQ	\N	95.130.227.60	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36	YTo0OntzOjY6Il90b2tlbiI7czo0MDoiN0daVjZuNjNvb0xHY0NQSFEydWNSNkRnQlNaWERocVBPMzQ1cG5FNiI7czo2OiJsb2NhbGUiO3M6MjoidXoiO3M6OToiX3ByZXZpb3VzIjthOjI6e3M6MzoidXJsIjtzOjI2OiJodHRwOi8vdmF0YW5kb3NobGFyLjd6Ny51eiI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1769090164
Jq3W4aTgyAw6cAgAMrfrqNKBT5XuKWWXcUYHZjGv	\N	213.206.63.164	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0	YTo0OntzOjY6Il90b2tlbiI7czo0MDoiRnB3T2pWYnR4M0lsRjFYcThSR01VYUxudGN5VjJlM2RzVkRYeGZMRiI7czo2OiJsb2NhbGUiO3M6MjoidXoiO3M6OToiX3ByZXZpb3VzIjthOjI6e3M6MzoidXJsIjtzOjQwOiJodHRwczovL3ZhdGFuZG9zaGxhci43ejcudXovdXovbWVkaWF0ZWthIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1769090294
IwpxixXrNVrF1jfBuvQiD9H0ADiOayGv3c88q1aZ	\N	95.130.227.60	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36	YTo0OntzOjY6Il90b2tlbiI7czo0MDoidkdxYkhMcGlINGx4NEtuYnJ1T1NqTU9TZ0VyOUcxQTFYeE1mc3ZMNiI7czo2OiJsb2NhbGUiO3M6MjoidXoiO3M6OToiX3ByZXZpb3VzIjthOjI6e3M6MzoidXJsIjtzOjI2OiJodHRwOi8vdmF0YW5kb3NobGFyLjd6Ny51eiI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1769092924
MFAquBX3yVXPpYXelA5tfGY7LFy7LbG76wU6yHF5	\N	95.130.227.60	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36	YTo0OntzOjY6Il90b2tlbiI7czo0MDoiUjVhb0F6ZFVKMVU3Mmo5eWExOXFIVFVUeFc3ZzhZVUxoU2NtNjc2ViI7czo2OiJsb2NhbGUiO3M6MjoidXoiO3M6OToiX3ByZXZpb3VzIjthOjI6e3M6MzoidXJsIjtzOjI2OiJodHRwOi8vdmF0YW5kb3NobGFyLjd6Ny51eiI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1769088482
dkBTitqmY1Ajy2gEf8H9yOxa7woqRBmPLewM2h1U	\N	95.130.227.60	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36	YTo0OntzOjY6Il90b2tlbiI7czo0MDoiS0tPTTJPZHgzV3ZKUjNXWWxTU0k5amtsVFNqUzZ1WGNHTTQ0WmJGTiI7czo2OiJsb2NhbGUiO3M6MjoidXoiO3M6OToiX3ByZXZpb3VzIjthOjI6e3M6MzoidXJsIjtzOjI2OiJodHRwOi8vdmF0YW5kb3NobGFyLjd6Ny51eiI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1769094843
6YapdWKAkmCmRwUU3rmDvwBKQBkn9x6KOpP0glKv	1	213.206.63.164	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	YTo2OntzOjY6Il90b2tlbiI7czo0MDoiVmdKMVQ4blNQNTJ2Rnh4YktSMWpnajV3ZzV1YUNVWlVQSEtwRzY5NyI7czo2OiJsb2NhbGUiO3M6MjoidXoiO3M6OToiX3ByZXZpb3VzIjthOjI6e3M6MzoidXJsIjtzOjI3OiJodHRwczovL3ZhdGFuZG9zaGxhci43ejcudXoiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6MzoidXJsIjthOjE6e3M6ODoiaW50ZW5kZWQiO3M6MzM6Imh0dHBzOi8vdmF0YW5kb3NobGFyLjd6Ny51ei9hZG1pbiI7fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjE7fQ==	1769095221
KLNStOelFdIRsTTtn5sBFWjm4xryexegMSSJdgdK	\N	95.130.227.60	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36	YTo0OntzOjY6Il90b2tlbiI7czo0MDoibHhvcVdTVFljM0lPeVVoTWw5SWVYWlNFNmFHWDhtSzhmZWZ2QmU5ViI7czo2OiJsb2NhbGUiO3M6MjoidXoiO3M6OToiX3ByZXZpb3VzIjthOjI6e3M6MzoidXJsIjtzOjI2OiJodHRwOi8vdmF0YW5kb3NobGFyLjd6Ny51eiI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1769093764
Lry4KCZbmY4eWWI5T4XoBPvcNDwvVIHVFYREmCNh	\N	213.206.63.164	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0	YTo0OntzOjY6Il90b2tlbiI7czo0MDoiNjNUU2JrOU82TEpQTTFTbklzR05uZ0x0SnRzTlFteFh4RzhnUjV0NCI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czo0MjoiaHR0cHM6Ly92YXRhbmRvc2hsYXIuN3o3LnV6L2FkbWluL3NldHRpbmdzIjt9czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NDI6Imh0dHBzOi8vdmF0YW5kb3NobGFyLjd6Ny51ei9hZG1pbi9zZXR0aW5ncyI7czo1OiJyb3V0ZSI7czoxNDoiYWRtaW4uc2V0dGluZ3MiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1769091814
ZcxuZMprPvjbCONYUnRihjnMutuHEby2DaM3fSd3	1	213.206.63.164	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0	YTo2OntzOjY6Il90b2tlbiI7czo0MDoiWUxnVHVVRnFmajlSN21WQ052Z3BLd2NLTzVScmhjamJxalRzYW5VbSI7czo2OiJsb2NhbGUiO3M6MjoidXoiO3M6OToiX3ByZXZpb3VzIjthOjI6e3M6MzoidXJsIjtzOjMzOiJodHRwczovL3ZhdGFuZG9zaGxhci43ejcudXovYWRtaW4iO3M6NToicm91dGUiO3M6MTE6ImFkbWluLmluZGV4Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czo2NjoiaHR0cHM6Ly92YXRhbmRvc2hsYXIuN3o3LnV6L2FkbWluL3BhZ2VzL21lZGlhdGVrYS9zZWN0aW9uLzI3L2l0ZW1zIjt9czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6MTt9	1769092097
kNwyx6A7pu9WRcauIdpORELFkjWW1n13GYdFWCYz	\N	213.206.63.164	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiR3pQQzRYbkIza296dDM4UUhpdlpwWjE3YXkwUzBDS0M2ekZrajhMOCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzM6Imh0dHBzOi8vdmF0YW5kb3NobGFyLjd6Ny51ei9sb2dpbiI7czo1OiJyb3V0ZSI7czo1OiJsb2dpbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1769091814
CY6Zzhh1VanraKMxuA8TF1Gi7EZFuxA3ZONYAgkk	\N	95.130.227.60	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36	YTo0OntzOjY6Il90b2tlbiI7czo0MDoiY0JhamlnTmRIbldsSmlwNlRwNXhvVU1HS3FWWWpiRmszU2VxcjZ6YiI7czo2OiJsb2NhbGUiO3M6MjoidXoiO3M6OToiX3ByZXZpb3VzIjthOjI6e3M6MzoidXJsIjtzOjI2OiJodHRwOi8vdmF0YW5kb3NobGFyLjd6Ny51eiI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1769094003
kKIvBrsvWCYTKDL57eoQQS5uum3HLlhB9TPvyDYN	1	195.158.2.216	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	YTo2OntzOjY6Il90b2tlbiI7czo0MDoiOVRZaEtZYVZFU0ptQ3NDUExMQkhCWjAwNTZ3bXJ5VU45b09PcFViSSI7czo2OiJsb2NhbGUiO3M6MjoidXoiO3M6OToiX3ByZXZpb3VzIjthOjI6e3M6MzoidXJsIjtzOjQxOiJodHRwczovL3ZhdGFuZG9zaGxhci43ejcudXovdXovdXpiZWtpc3RhbiI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czozMzoiaHR0cHM6Ly92YXRhbmRvc2hsYXIuN3o3LnV6L2FkbWluIjt9czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6MTt9	1769098201
lWJ45scWuZk88svAxKHYvHhoUTAEzQXJV0798S3R	\N	213.206.63.164	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0	YTo0OntzOjY6Il90b2tlbiI7czo0MDoiOTlzbElvdkE1S1JsbTR4R20wVTkwS1lEWU9iTU82MmozNVBGelh1ViI7czo2OiJsb2NhbGUiO3M6MjoidXoiO3M6OToiX3ByZXZpb3VzIjthOjI6e3M6MzoidXJsIjtzOjQwOiJodHRwczovL3ZhdGFuZG9zaGxhci43ejcudXovdXovbWVkaWF0ZWthIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1769090843
snC2UYzCjieSVHZodzgFuActWCxDb8NLm8AZqhda	1	213.206.63.164	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	YTo2OntzOjY6Il90b2tlbiI7czo0MDoiT1hTbGRjWjgzd0lMY3NFWWk0TEZxVDFKMXVVdDdiUnB6bkdhb01DNiI7czo2OiJsb2NhbGUiO3M6MjoidXoiO3M6OToiX3ByZXZpb3VzIjthOjI6e3M6MzoidXJsIjtzOjMwOiJodHRwczovL3ZhdGFuZG9zaGxhci43ejcudXovdXoiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6MzoidXJsIjthOjE6e3M6ODoiaW50ZW5kZWQiO3M6MzM6Imh0dHBzOi8vdmF0YW5kb3NobGFyLjd6Ny51ei9hZG1pbiI7fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjE7fQ==	1769091122
1n9ZQe2IgBeFin6WRQITifWU1afMbiKdsAexaShb	\N	95.130.227.60	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36	YTo0OntzOjY6Il90b2tlbiI7czo0MDoiT0V1cW5HaUJBYk5xVDVCeTBzQjlFcWM0SEMxTDltWVFZeGZTUTJsRCI7czo2OiJsb2NhbGUiO3M6MjoidXoiO3M6OToiX3ByZXZpb3VzIjthOjI6e3M6MzoidXJsIjtzOjI2OiJodHRwOi8vdmF0YW5kb3NobGFyLjd6Ny51eiI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1769091244
IYfjJvZ9nbqjd14OGP3zqMCGF3hWOqFwNkiGQ5Nc	\N	149.154.161.213	TelegramBot (like TwitterBot)	YTo0OntzOjY6Il90b2tlbiI7czo0MDoiTlpjdzZreGNzU3B3d2lmdzB4a2lXMHZ3S2lPeHoyTWlkRkJucklmbyI7czo2OiJsb2NhbGUiO3M6MjoidXoiO3M6OToiX3ByZXZpb3VzIjthOjI6e3M6MzoidXJsIjtzOjg4OiJodHRwczovL3ZhdGFuZG9zaGxhci43ejcudXovdXovbmV3cy9iYWFkYS12YXRhbmRvc2hsYXItbWludGFxYXZpeS1mb3J1bWktYm8tbGliLW8tdG1vcWRhIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1769095159
WmZwbvdrXdPI12aVGQqqHhtWklJJRps5LxvxTGst	\N	95.130.227.60	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36	YTo0OntzOjY6Il90b2tlbiI7czo0MDoiS1FjbUZaSGxUM1IxS1RVdnJGQTZ4VENuM1BDTzdUeU5zMzlEeThETiI7czo2OiJsb2NhbGUiO3M6MjoidXoiO3M6OToiX3ByZXZpb3VzIjthOjI6e3M6MzoidXJsIjtzOjI2OiJodHRwOi8vdmF0YW5kb3NobGFyLjd6Ny51eiI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1769096522
p56qF4A4Qx3QijHBDAlvy45drXg9u1fKszs1WdaW	\N	95.130.227.60	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36	YTo0OntzOjY6Il90b2tlbiI7czo0MDoiYjJ2cG5PU09wSlZjcldjQUY4dE9EN0RLTno3RjBIbDQ0TEM4YjFUeiI7czo2OiJsb2NhbGUiO3M6MjoidXoiO3M6OToiX3ByZXZpb3VzIjthOjI6e3M6MzoidXJsIjtzOjI2OiJodHRwOi8vdmF0YW5kb3NobGFyLjd6Ny51eiI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1769092085
DBrlKHnSpC4CnwpWsmCSRMnQo6NF7lL7k7Ro28a0	\N	95.130.227.60	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36	YTo0OntzOjY6Il90b2tlbiI7czo0MDoicVJkQ3VtWkNoUmFKejJzNTNBeVR2VkxIUk1nTDhMMVpLcGloRmQ0MyI7czo2OiJsb2NhbGUiO3M6MjoidXoiO3M6OToiX3ByZXZpb3VzIjthOjI6e3M6MzoidXJsIjtzOjI2OiJodHRwOi8vdmF0YW5kb3NobGFyLjd6Ny51eiI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1769097364
4rgN7ZBisxbBeQvaxbiLtRCbTgXDyDw311cMyx2m	\N	149.154.161.218	TelegramBot (like TwitterBot)	YTo0OntzOjY6Il90b2tlbiI7czo0MDoidW1iZ1VoQzJ4MTF5R2lVaEY0SkRxbUg0ZThqbWZ0azJSZVduT01rYSI7czo2OiJsb2NhbGUiO3M6MjoidXoiO3M6OToiX3ByZXZpb3VzIjthOjI6e3M6MzoidXJsIjtzOjM5OiJodHRwczovL3ZhdGFuZG9zaGxhci43ejcudXovdXovY29udGFjdHMiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1769088110
ttmqGgnXjpFjEYuBm3XKsKEGHHMQyvAUZDwjmK6P	\N	95.130.227.60	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36	YTo0OntzOjY6Il90b2tlbiI7czo0MDoiVW1tM3dKdjFQanFLOWJqZ3RBWHBDYVJEcnZhekx3UGhDd3BxTHBXeSI7czo2OiJsb2NhbGUiO3M6MjoidXoiO3M6OToiX3ByZXZpb3VzIjthOjI6e3M6MzoidXJsIjtzOjI2OiJodHRwOi8vdmF0YW5kb3NobGFyLjd6Ny51eiI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1769090404
pf4cjMCD98qL9G7IpRMZGH8x6LrvNli1ne4DA9nJ	\N	213.206.63.164	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0	YTo0OntzOjY6Il90b2tlbiI7czo0MDoiaGFtVERNcUtTblBib21BOWdmc0pwMVNnVmN2c1RKV0JobjVvYURHMSI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czo2OToiaHR0cHM6Ly92YXRhbmRvc2hsYXIuN3o3LnV6L2FkbWluL3BhZ2VzL21lZGlhdGVrYS9zZWN0aW9uLzI3L2VkaXQvMTg3Ijt9czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Njk6Imh0dHBzOi8vdmF0YW5kb3NobGFyLjd6Ny51ei9hZG1pbi9wYWdlcy9tZWRpYXRla2Evc2VjdGlvbi8yNy9lZGl0LzE4NyI7czo1OiJyb3V0ZSI7czoyNDoiYWRtaW4ucGFnZXMuc2VjdGlvbi5lZGl0Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1769091253
ADx4HmeGD9jQkBi9wTOdhEHz2FM0zSPhSmMOAHAl	\N	213.206.63.164	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiUXV3dGZsemtJVm45blNlcER1VUtTYkExU0o0MTdRZnE3cTdLVXZibiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzM6Imh0dHBzOi8vdmF0YW5kb3NobGFyLjd6Ny51ei9sb2dpbiI7czo1OiJyb3V0ZSI7czo1OiJsb2dpbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1769091253
5XTJou10kUdVLP4ND1WpWIRZ9RiycFBjtDJMSP8y	1	213.206.63.164	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0	YTo2OntzOjY6Il90b2tlbiI7czo0MDoiUEFqVEh2SmlpYzhuczI3eWtZQ2dyOVVaNzJQaU03QlRGNFpIWndzNCI7czo2OiJsb2NhbGUiO3M6MjoidXoiO3M6OToiX3ByZXZpb3VzIjthOjI6e3M6MzoidXJsIjtzOjQwOiJodHRwczovL3ZhdGFuZG9zaGxhci43ejcudXovdXovbWVkaWF0ZWthIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjM6InVybCI7YToxOntzOjg6ImludGVuZGVkIjtzOjMzOiJodHRwczovL3ZhdGFuZG9zaGxhci43ejcudXovYWRtaW4iO31zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aToxO30=	1769090289
\.


--
-- Data for Name: setting_images; Type: TABLE DATA; Schema: public; Owner: vatandoshlar_usr
--

COPY public.setting_images (id, setting_id, image, compressed, type, size, main, status, created_at, updated_at, sort_order) FROM stdin;
2	1	settings/a0e178d2-8396-456a-b547-a15e69f4ca64127.jpg	\N	image/jpeg	268394	f	t	2026-01-20 09:49:11	2026-01-20 09:49:11	\N
3	1	settings/a0e3313c-3d27-490e-91bf-6e109a4f36c4157.png	\N	image/png	98609	t	t	2026-01-21 06:20:40	2026-01-21 06:20:45	\N
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: vatandoshlar_usr
--

COPY public.settings (id, title, meta_description, meta_keywords, email, status, main_page_id, admin_ips, created_at, updated_at, search_ids, sorting_ids, bot_token, chat_id, week_short, week_long, month_long, month_short, default_lang) FROM stdin;
1	{"en": "Vatandoshlar jamoat fondi", "ru": "Vatandoshlar jamoat fondi", "uz": "Vatandoshlar jamoat fondi"}	{"en": "Vatandoshlar jamoat fondi", "ru": "ProEnd", "uz": "Vatandoshlar jamoat fondi2"}	{"en": "ProEnd, ProEnd", "ru": "ProEnd, ProEnd", "uz": "ProEnd, ProEnd"}	\N	f	38	\N	2025-12-20 15:22:52	2026-01-29 12:20:52	["6","16","14","26","38"]	["26"]	8596886322:AAGpsyAEe1W9gbc81iFms31oLhVcYSQ5rvw	-4998826522	{"en": "Sun, Mon, Tue, Wed, Thu, Fri, Sat", "ru": "Вс, Пн, Вт, Ср, Чт, Пт, Сб", "uz": "Yak, Du, Se, Ch, Pa, Ju, Sha"}	{"en": "Sunday, Monday, Tuesday, Wednesday, Thursday, Friday, Saturday", "ru": "Воскресенье, Понедельник, Вторник, Среда, Четверг, Пятница, Суббота", "uz": "Yakshanba, Dushanba, Seshanba, Chorshanba, Payshanba, Juma, Shanba"}	{"en": "January, February, March, April, May, June, July, August, September, October, November, December", "ru": "Январь, Февраль, Март, Апрель, Май, Июнь, Июль, Август, Сентябрь, Октябрь, Ноябрь, Декабрь", "uz": "Yanvar, Fevral, Mart, Aprel, May, Iyun, Iyul, Avgust, Sentyabr, Oktyabr, Noyabr, Dekabr"}	{"en": "Jan, Feb, Mar, Apr, May, Jun, Jul, Aug, Sep, Oct, Nov, Dec", "ru": "Янв, Фев, Мар, Апр, Май, Июн, Июл, Авг, Сен, Окт, Ноя, Дек", "uz": "Yan, Fev, Mar, Apr, May, Iyn, Iyl, Avg, Sen, Okt, Noy, Dek"}	uz
\.


--
-- Data for Name: socials; Type: TABLE DATA; Schema: public; Owner: vatandoshlar_usr
--

COPY public.socials (id, name, icon, url, key, status, created_at, updated_at) FROM stdin;
2	facebook	i-facebook	https://fb.com/vatandoshlarfondi	\N	t	2026-01-19 05:36:05	2026-01-19 05:36:05
1	telegram	i-telegram	https://t.me/vatandoshlar_fond	\N	t	2026-01-19 05:29:50	2026-01-22 06:56:31
3	instagram	i-instagram	https://www.instagram.com/vatandoshlar_fondi	\N	t	2026-01-19 05:36:21	2026-01-22 14:36:49
4	youtube	i-youtube	https://www.youtube.com/@vatandoshlar	\N	t	2026-01-19 05:36:42	2026-01-22 14:37:12
\.


--
-- Data for Name: supports; Type: TABLE DATA; Schema: public; Owner: vatandoshlar_usr
--

COPY public.supports (id, data, created_at, updated_at, type, user_id, chat_id) FROM stdin;
61	{"name": "Asad", "email": "yam@gmail.com", "phone": "+998 90-597-55-54", "description": "yZSH"}	2026-01-09 05:13:50	2026-01-09 05:13:50	form	\N	\N
97	{"city": "sirdaryo", "name": "Asad", "email": "wq@gmail.com", "phone": "905975554", "gender": "female", "country": "uzbekistan", "position": "Junior", "telegram": null, "whatsapp": null, "birthdate": "2026-01-01", "education": "boshlangich", "instagram": null, "workplace": "ProEnd", "specialization": "orta"}	2026-01-09 10:48:01	2026-01-09 10:48:01	participation	\N	\N
98	{"city": "fergana", "name": "Asad", "email": "wq@gmail.com", "phone": "905975554", "gender": "male", "country": "uzbekistan", "position": "Junior", "telegram": null, "whatsapp": null, "birthdate": "2026-01-01", "education": "boshlangich", "instagram": null, "workplace": "ProEnd", "specialization": "orta"}	2026-01-09 11:15:49	2026-01-09 11:15:49	participation	\N	\N
99	{"name": "saasfs", "email": "wq@gmail.com", "phone": "+998 90-597-55-54", "description": "csdvfxsf"}	2026-01-09 12:08:27	2026-01-09 12:08:27	form	\N	\N
100	{"name": "cdfvd", "email": "qwerty@gmail.com", "phone": "+998 90-597-55-54", "description": "wefvregdt"}	2026-01-09 12:15:45	2026-01-09 12:15:45	form	\N	\N
101	{"name": "asdasd", "email": "asdasds@asd.ru", "phone": "+998 23-423-42-34", "description": "asd asd asd asd"}	2026-01-12 10:14:42	2026-01-12 10:14:42	form	\N	\N
102	{"name": "asdasdsd", "email": "asdasd@asd.ru", "phone": "+998 24-234-23-42", "description": "ada das dasd asd"}	2026-01-12 10:17:04	2026-01-12 10:17:04	form	\N	\N
110	{"job": "27", "name": "frthtrfhrh", "address": "reehe", "birthdate": "2026-01-05", "extra_info": "te@gmail.xin", "description": "fsdgggfe"}	2026-01-12 13:01:26	2026-01-12 13:01:26	application	\N	\N
112	{"name": "cfsvds", "email": "qwerty@gmail.com", "phone": "+998 41-242-41-23", "description": "caca"}	2026-01-14 12:23:13	2026-01-14 12:23:13	form	\N	\N
113	{"name": "cfsvds", "email": "qwerty@gmail.com", "phone": "+998 41-242-41-23", "description": "caca"}	2026-01-14 12:23:13	2026-01-14 12:23:13	form	\N	\N
114	{"job": "34", "name": "gol", "address": "x cx x", "birthdate": "2026-01-11", "extra_info": "cxxc@gmIail.com", "description": "fdbvfdbdb"}	2026-01-14 18:59:28	2026-01-14 18:59:28	application	\N	\N
115	{"job": "Oshpazimiz", "name": "f vbgfv", "address": "c c c", "birthdate": "2025-12-30", "extra_info": "cxxc", "description": "daaa"}	2026-01-14 19:01:35	2026-01-14 19:01:35	application	\N	\N
116	{"job": "Oshpazimiz", "name": "csdvdfv", "address": "vdvdvds", "birthdate": "2026-01-22", "extra_info": "DSFBRDFF", "description": "c  vfgbgfbd"}	2026-01-14 19:08:10	2026-01-14 19:08:10	application	\N	\N
1	{"job": "Oshpazimiz", "name": "asdaa", "address": "asda", "birthdate": "2022-12-31", "extra_info": "dasdaad", "description": "adasd"}	2026-01-19 06:29:48	2026-01-19 06:29:48	application	\N	\N
2	{"name": "Muhammadali", "email": "yam@gmail.com", "phone": "+998 90-597-55-54", "description": "Salom"}	2026-01-19 10:10:01	2026-01-19 10:10:01	form	\N	\N
3	{"name": "Muhammadali", "email": "qwerty@gmail.com", "phone": "+998 41-242-41-23", "description": "Salom"}	2026-01-19 10:10:26	2026-01-19 10:10:26	form	\N	\N
4	{"name": "asdadasada", "email": "sadas@Eawdsa.dsa", "phone": "+998 21-313-13-11", "description": "adsada"}	2026-01-19 10:56:41	2026-01-19 10:56:41	form	\N	\N
109	{"city": "tashkent", "name": "asdasdsad", "email": "joha_gamer@mail.ru", "phone": "+998 23-423-42-34", "gender": "male", "country": "uzbekistan", "position": "adasdasd", "telegram": "a sdas dasd asd", "whatsapp": "a sdad sa", "birthdate": "06-01-2026", "education": "ыфв", "instagram": "a sda da dads", "workplace": "asdsad", "specialization": "asdasdasd ada dad ads"}	2026-01-12 12:30:04	2026-01-22 08:37:34	participation	1	\N
106	{"city": "fergana", "name": "jftj", "email": "rser@gmail.cvlm", "phone": "+998 24-524-77-74", "gender": "female", "country": "uzbekistan", "position": "fgsgsggw", "telegram": null, "whatsapp": null, "birthdate": "2000-02-05", "education": "fstgsgwsgrg", "instagram": null, "workplace": "hdffhd", "specialization": "gwgwgwghw"}	2026-01-12 11:00:16	2026-01-22 08:39:01	participation	1	\N
63	{"city": "tashkent", "name": "saasfs", "email": "yam@gmail.com", "phone": "905975554", "gender": "male", "country": "uzbekistan", "position": "Junior", "telegram": null, "whatsapp": null, "birthdate": "2026-01-07", "education": "boshlangich", "instagram": null, "workplace": "ProEnd", "specialization": "orta"}	2026-01-09 07:15:17	2026-01-22 08:39:09	participation	1	\N
64	{"city": "tashkent", "name": "Asad", "email": "qwerty@gmail.com", "phone": "905975554", "gender": "male", "country": "uzbekistan", "position": "Junior", "telegram": null, "whatsapp": null, "birthdate": "2026-01-09", "education": "boshlangich", "instagram": null, "workplace": "ProEnd", "specialization": "orta"}	2026-01-09 07:19:13	2026-01-22 08:40:11	participation	1	\N
103	{"city": "tashkent", "name": "dfgbdgd", "email": "ww@gmail.cmno", "phone": "+998 55-220-42-42", "gender": "male", "country": "uzbekistan", "position": "frhrtfgne", "telegram": null, "whatsapp": null, "birthdate": "2026-01-07", "education": "ertghrehrt", "instagram": null, "workplace": "twete4", "specialization": "jtjtyjrytjtrj"}	2026-01-12 10:54:26	2026-01-22 08:40:19	participation	1	\N
108	{"city": "tashkent", "name": "asdasdsad", "email": "joha_gamer@mail.ru", "phone": "+998 23-423-42-34", "gender": "male", "country": "uzbekistan", "position": "adasdasd", "telegram": "a sdas dasd asd", "whatsapp": "a sdad sa", "birthdate": "06-01-2026", "education": "ыфв", "instagram": "a sda da dads", "workplace": "asdsad", "specialization": "asdasdasd ada dad ads"}	2026-01-12 12:29:43	2026-01-23 15:43:18	participation	1	\N
105	{"city": "fergana", "name": "jftj", "email": "rser@gmail.cvlm", "phone": "+998 24-524-77-74", "gender": "female", "country": "uzbekistan", "position": "fgsgsggw", "telegram": null, "whatsapp": null, "birthdate": "2000-02-05", "education": "fstgsgwsgrg", "instagram": null, "workplace": "hdffhd", "specialization": "gwgwgwghw"}	2026-01-12 10:59:20	2026-01-23 15:43:30	participation	1	\N
104	{"city": "fergana", "name": "jftj", "email": "rser@gmail.cvlm", "phone": "+998 24-524-77-74", "gender": "female", "country": "uzbekistan", "position": "fgsgsggw", "telegram": null, "whatsapp": null, "birthdate": "2000-02-05", "education": "fstgsgwsgrg", "instagram": null, "workplace": "hdffhd", "specialization": "gwgwgwghw"}	2026-01-12 10:58:16	2026-01-24 13:50:45	participation	1	\N
7	{"name": "Asad", "email": "qwerty@gmail.com", "phone": "+998 90-597-55-54", "description": "ewvew"}	2026-01-19 11:16:05	2026-01-19 11:16:05	form	\N	\N
9	{"name": "Muhammadali", "email": "as@gnai.vom", "phone": "+998 32-333-33-21", "description": "cx"}	2026-01-19 11:31:53	2026-01-19 11:31:53	form	\N	\N
117	{"name": "asda", "email": "3asda@s.adf", "phone": "+998 23-112-32-11", "description": "asda"}	2026-01-20 08:35:36	2026-01-20 08:35:36	form	\N	\N
118	{"name": "asda", "email": "asdas2@das.sdf", "phone": "+998 21-312-31-31", "description": "sda"}	2026-01-20 08:46:55	2026-01-20 08:46:55	form	\N	\N
119	{"name": "asda", "email": "sda@das.sf", "phone": "+998 21-313-12-13", "description": "aas"}	2026-01-20 08:48:07	2026-01-20 08:48:07	form	\N	\N
120	{"name": "asda", "email": "d@d12.df", "phone": "+998 23-123-11-31", "description": "a"}	2026-01-20 08:49:33	2026-01-20 08:49:33	form	\N	\N
121	{"name": "213", "email": "231@d.sd", "phone": "+998 21-321-31-31", "description": "1231"}	2026-01-20 08:50:57	2026-01-20 08:50:57	form	\N	\N
122	{"name": "asd", "email": "2das@ds.s", "phone": "+998 23-313-13-13", "description": "adsada"}	2026-01-20 08:52:32	2026-01-20 08:52:32	form	\N	\N
123	{"name": "asda", "email": "2adsdas@dsa.sdafds", "phone": "+998 23-123-23-13", "description": "asdadas"}	2026-01-20 08:53:11	2026-01-20 08:53:11	form	\N	\N
124	{"name": "test", "email": "fasfd@asdfsaf.aretre", "phone": "+998 33-145-00-04", "description": "gsdfgdsf"}	2026-01-21 08:13:22	2026-01-21 08:13:22	form	\N	\N
126	{"name": "adfsgadfgda", "email": "sgdfgsdfg@twe.wetwet", "phone": "+998 41-234-12-41", "description": "gsdfgds"}	2026-01-21 08:15:47	2026-01-21 08:15:47	form	\N	\N
127	{"name": "Asad", "email": "wq@gmail.com", "phone": "+241 45 757-55-67", "description": "VFBED"}	2026-01-21 13:03:46	2026-01-21 13:03:46	form	\N	\N
13	{"city": "jizzakh", "name": "saasfs", "email": "qwerty@gmail.com", "phone": "+998 41-242-41-23", "gender": "male", "country": "Gvatemala", "position": "Junior", "telegram": null, "whatsapp": null, "birthdate": "06-01-2026", "education": "sdfsdf", "instagram": null, "workplace": "sdfsdsfsd", "specialization": "orta"}	2026-01-19 12:00:12	2026-01-22 08:37:10	participation	1	\N
111	{"city": "sirdaryo", "name": "asdasdsad", "email": "joha_gamer@mail.ru", "phone": "+998 23-423-42-34", "gender": "female", "country": "uzbekistan", "position": "adasdasd", "telegram": null, "whatsapp": null, "birthdate": "16-01-2026", "education": "adasd", "instagram": null, "workplace": "asdsad", "specialization": "asdasdasd ada dad ads"}	2026-01-12 13:06:21	2026-01-22 08:37:19	participation	1	\N
128	{"name": "aLI", "email": "wq@gmail.com", "phone": "+220 43 643-64-36", "description": "casca"}	2026-01-21 13:05:23	2026-01-22 08:40:32	form	1	\N
125	{"name": "vxcvbxzcv", "email": "sadfgsdfg@masdfsd.twerterw", "phone": "+998 34-345-63-42", "description": "gsdfgdsf"}	2026-01-21 08:15:19	2026-01-22 08:40:35	form	1	\N
129	{"name": "asdasdasd", "email": "asdasd@asdads.sdu", "phone": "+998 32 423-42-34", "description": "adasd asd asd"}	2026-01-22 08:42:07	2026-01-22 08:42:07	form	\N	\N
130	{"name": "tet", "email": "asda@ds.sdf", "phone": "+998 21 312-31-23", "description": "dasfdfd"}	2026-01-22 11:53:10	2026-01-22 11:53:10	form	\N	\N
131	{"name": "test", "email": "asdad@asdad.ds", "phone": "+998 23 123-21-31", "description": "asda"}	2026-01-22 11:54:56	2026-01-22 11:54:56	form	\N	\N
132	{"name": "tetetetest", "email": "dsadas@ds.dd", "phone": "+998 23 132-13-12", "description": "ddas"}	2026-01-22 11:58:01	2026-01-22 11:58:01	form	\N	\N
133	{"name": "asdada", "email": "asdad@dsd.sd", "phone": "+998 21 312-31-23", "description": "asdada"}	2026-01-22 11:58:32	2026-01-22 11:58:32	form	\N	\N
134	{"name": "te", "email": "aAS2@dsd.f", "phone": "+998 23 123-21-32", "description": "d"}	2026-01-22 11:58:47	2026-01-22 11:58:47	form	\N	\N
135	{"name": "tadsa", "email": "sdfsfds@asdasd.sdf", "phone": "+998 23 123-21-31", "description": "sdfsfss"}	2026-01-22 11:59:23	2026-01-22 11:59:23	form	\N	\N
136	{"name": "asad", "email": "sds@sd.ds", "phone": "+998 21 312-32-11", "description": "adada"}	2026-01-22 12:03:21	2026-01-22 12:03:21	form	\N	\N
137	{"name": "wsd231312", "email": "122131@asa.dsds", "phone": "+998 12 313-13-13", "description": "asada"}	2026-01-22 12:03:34	2026-01-22 12:03:34	form	\N	\N
138	{"name": "asd", "email": "asda@asdadsadsd.asd", "phone": "+998 21 312-33-13", "description": "asd"}	2026-01-22 13:12:06	2026-01-22 13:12:06	form	\N	\N
139	{"name": "123131", "email": "asd@sada.ds", "phone": "+998 12 313-11-32", "description": "asdada"}	2026-01-22 13:13:14	2026-01-22 13:13:14	form	\N	\N
140	{"name": "Muhammadali Azizov", "email": "wweqe@gmail.com", "phone": "+998 32 535-33-64", "description": "fsegseges"}	2026-01-22 13:31:12	2026-01-22 13:31:12	form	\N	\N
141	{"name": "fdhq2", "email": "qwerty@gmail.com", "phone": "+998 63 463-46-43", "description": "vsdds"}	2026-01-22 13:32:22	2026-01-22 13:32:22	form	\N	\N
142	{"name": "gzfgdg", "email": "dfghhfg@adf.tre", "phone": "+998 56 756-75-67", "description": "jfgjh"}	2026-01-22 16:14:16	2026-01-22 16:14:16	form	\N	\N
143	{"name": "asdasd", "email": "asdas@asd.ru", "phone": "+998 23 423-42-34", "description": "asdasdasd"}	2026-01-23 07:31:24	2026-01-23 07:31:24	form	\N	\N
144	{"name": "asdasdasd", "email": "asda@asd.ru", "phone": "+998 23 423-42-34", "description": "asdasdas dasd"}	2026-01-23 07:31:40	2026-01-23 07:31:40	form	\N	\N
145	{"name": "asdasdad", "email": "asdasd@asd.ru", "phone": "+998 34 234-23-42", "description": "asdasdsa"}	2026-01-23 07:35:23	2026-01-23 07:35:23	form	\N	\N
146	{"name": "asda", "email": "2@2.s", "phone": "+998 21 321-21-32", "description": "sda"}	2026-01-23 07:37:16	2026-01-23 07:37:16	form	\N	\N
147	{"name": "123", "email": "2@2.2", "phone": "+998 21 231-13-13", "description": "dsa"}	2026-01-23 07:37:55	2026-01-23 07:37:55	form	\N	\N
148	{"name": "123213", "email": "as@sda.sd", "phone": "+998 12 323-13-13", "description": "s"}	2026-01-23 07:38:16	2026-01-23 07:38:16	form	\N	\N
149	{"name": "asdad", "email": "ada@sdad.sadf", "phone": "+998 23 132-13-13", "description": "asdsad"}	2026-01-23 08:56:12	2026-01-23 08:56:12	form	\N	\N
150	{"name": "asda", "email": "sda2@ds.dsd", "phone": "+998 21 321-31-1_", "description": "as"}	2026-01-23 08:58:37	2026-01-23 08:58:37	form	\N	\N
151	{"name": "asda", "email": "asa@sd.sdad", "phone": "+998 23 213-11-1_", "description": "asda"}	2026-01-23 08:59:23	2026-01-23 08:59:23	form	\N	\N
153	{"name": "Saidakbar", "email": "info@proend.uz", "phone": "+998 33 145-00-04", "description": "test matn"}	2026-01-28 10:03:08	2026-01-28 10:03:08	form	\N	-1003249220292
154	{"name": "hfghdgh", "email": "sfgsdfg@fasd.reaw", "phone": "+998 33 145-00-04", "description": "gsdfgsdfg"}	2026-01-28 10:03:41	2026-01-28 10:04:10	form	1	-1003249220292
156	{"name": "gsdfgdsf", "email": "fasdfasd@dfasdf.gsdfg", "phone": "+998 41 234-12-34", "description": "gsdfgsdfg"}	2026-01-28 10:07:23	2026-01-28 10:07:23	form	\N	\N
152	{"name": "asda2132", "email": "asd@asd.df", "phone": "+998 21 312-31-13", "description": "asd"}	2026-01-23 09:00:38	2026-01-28 10:13:14	form	1	\N
155	{"name": "test Saidakbar", "email": "fasfs@afsd.ut", "phone": "+998 33 145-00-04", "description": "bxcvbxcb"}	2026-01-28 10:04:39	2026-01-28 10:13:28	form	1	-1003249220292
157	{"job": "Musiqachi", "name": "S.M.R", "address": "Mirzo Ulug'bek", "birthdate": "2026-01-17", "extra_info": "+998331450004", "description": "test taklif"}	2026-01-28 10:14:45	2026-01-28 10:15:00	application	1	\N
158	{"city": "adsasd", "name": "фывфыв", "email": "asdasd@sad.ru", "phone": "+998 24 234-23-42", "gender": "male", "country": "Gaiti", "position": "asdasd", "telegram": "adas", "whatsapp": "asd", "birthdate": "16-01-2026", "education": "asdasd", "instagram": "asd", "workplace": "adasd", "specialization": "Musiqachi"}	2026-01-28 10:30:51	2026-01-28 10:30:51	participation	\N	\N
159	{"city": "asdasd", "name": "adasdasdasd", "email": "asdasd@asd.ru", "phone": "+998 23 423-42-34", "gender": "female", "country": "Gaiti", "position": "asdasd", "telegram": "asda", "whatsapp": "asd", "birthdate": "13-01-2026", "education": "asdasd", "instagram": "asd", "workplace": "asdasd", "specialization": "Musiqachi"}	2026-01-28 10:38:35	2026-01-28 10:38:35	participation	\N	\N
160	{"city": "asdasd", "name": "asdasd", "email": "sdfsdf@asd.ru", "phone": "+998 23 423-42-34", "gender": "male", "country": "Gvineya", "position": "adsasd", "telegram": "adssad", "whatsapp": "asdasdasd", "birthdate": "13-01-2026", "education": "adasd", "instagram": "adsasd", "workplace": "asdasd", "specialization": "Musiqachi"}	2026-01-28 11:50:07	2026-01-28 11:50:07	participation	\N	\N
161	{"city": "asdsa", "name": "asdasd", "email": "ads@asd.ru", "phone": "+998 98 989-89-89", "gender": "male", "country": "Vatikan", "position": "adasd", "telegram": "adasd", "whatsapp": "ad", "birthdate": "08-01-2026", "education": "adsasd", "instagram": "adas", "workplace": "asdasd", "specialization": "Musiqachi"}	2026-01-28 11:54:23	2026-01-28 11:54:23	participation	\N	\N
163	{"name": "asdasd", "email": "adasd@sad.ru", "phone": "+998 23 532-45-34", "description": "asda dsasdasd sasd asd"}	2026-01-28 11:58:04	2026-01-28 16:01:05	form	1	\N
162	{"city": "Tashkent", "name": "test", "email": "adads@sad.ru", "phone": "+998 23 423-42-34", "gender": "male", "country": "Gaiti", "position": "Lavozimisadd", "telegram": "tele", "whatsapp": "wahtsasd", "birthdate": "13-01-2026", "education": "masdalsda", "instagram": "instasd", "workplace": "asdasd", "specialization": "Musiqachi"}	2026-01-28 11:56:26	2026-01-28 16:01:12	participation	1	\N
164	{"name": "Saidakbar", "email": "info@proend.uz", "phone": "+998 33 145-00-04", "description": "test matn"}	2026-01-29 12:22:44	2026-01-29 12:22:59	form	1	\N
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: vatandoshlar_usr
--

COPY public.users (id, name, username, status, password, role_id, email, email_verified_at, remember_token, created_at, updated_at) FROM stdin;
1	Admin	admin	t	$2y$12$IdkZ.NfglZq6MhMc5ZI2buef.eMXylpbETW9tRtKsK2g06N.URDP2	1	\N	\N	\N	\N	\N
5	admin	Administrator	t	$2y$12$DDfw68V3BuFA0r3ucoA9O.EyhbTt9Dwm2cLi3SKU.IY27/ctTfg4W	2	\N	\N	\N	2026-01-14 18:18:26	2026-01-14 18:18:26
2	Moderator	moderator	f	$2y$12$6ZkAf8mM7gBLGpKS61RCku6S8hnXw3Sj5mcPzt5OTyHXM83QtD6C6	2	\N	\N	\N	\N	2026-01-24 13:29:04
3	Editor	editor	f	$2y$12$xmCOMOGc46IeFlCVSHaM5ujFkUnN5VgiPhHgNkR8VR.IEWnIKEw4S	2	\N	\N	\N	\N	2026-01-24 13:29:05
4	Asilvbek	Gerino	f	$2y$12$QxaBPJXJbwCC5q/qQSW2..jENwdw2VEWqne0CpGiRWiJ.JMalpaxi	2	\N	\N	\N	2026-01-14 18:13:01	2026-01-24 13:29:05
6	said	said	t	$2y$12$ee0uKc5bnt/5CKWEuj6CX..D5FB1tsC6rRkhd8LlXEqKAbqlhz0YC	3	\N	\N	\N	2026-01-27 09:18:25	2026-01-27 09:25:59
\.


--
-- Data for Name: view_counts; Type: TABLE DATA; Schema: public; Owner: vatandoshlar_usr
--

COPY public.view_counts (id, viewable_type, viewable_id, ip_address, user_agent, created_at, updated_at, page_section_created_at) FROM stdin;
13	App\\Models\\PageSection	33	172.23.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2026-01-06 09:31:35	2026-01-06 09:31:35	\N
14	App\\Models\\PageSection	117	172.23.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2026-01-07 16:22:48	2026-01-07 16:22:48	\N
15	App\\Models\\PageSection	117	172.23.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0	2026-01-09 11:50:54	2026-01-09 11:50:54	\N
16	App\\Models\\PageSection	117	172.20.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2026-01-12 06:29:37	2026-01-12 06:29:37	\N
17	App\\Models\\PageSection	33	172.20.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2026-01-12 06:30:02	2026-01-12 06:30:02	\N
18	App\\Models\\PageSection	119	172.20.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2026-01-12 08:22:40	2026-01-12 08:22:40	\N
19	App\\Models\\PageSection	33	172.24.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2026-01-14 04:57:12	2026-01-14 04:57:12	\N
20	App\\Models\\PageSection	118	172.24.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2026-01-14 08:27:13	2026-01-14 08:27:13	\N
21	App\\Models\\PageSection	117	172.24.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2026-01-14 08:27:28	2026-01-14 08:27:28	\N
22	App\\Models\\PageSection	119	172.24.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2026-01-14 08:27:34	2026-01-14 08:27:34	\N
1	App\\Models\\PageSection	117	84.54.122.33	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2026-01-17 10:00:36	2026-01-17 10:00:36	\N
2	App\\Models\\PageSection	33	84.54.122.33	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2026-01-17 10:16:39	2026-01-17 10:16:39	\N
3	App\\Models\\PageSection	118	84.54.122.33	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2026-01-17 11:15:04	2026-01-17 11:15:04	\N
4	App\\Models\\PageSection	119	84.54.122.33	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2026-01-17 12:06:38	2026-01-17 12:06:38	\N
5	App\\Models\\PageSection	117	216.73.216.134	Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; ClaudeBot/1.0; +claudebot@anthropic.com)	2026-01-17 12:22:17	2026-01-17 12:22:17	\N
6	App\\Models\\PageSection	118	216.73.216.134	Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; ClaudeBot/1.0; +claudebot@anthropic.com)	2026-01-17 12:22:23	2026-01-17 12:22:23	\N
7	App\\Models\\PageSection	119	216.73.216.134	Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; ClaudeBot/1.0; +claudebot@anthropic.com)	2026-01-17 12:23:24	2026-01-17 12:23:24	\N
8	App\\Models\\PageSection	33	216.73.216.134	Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; ClaudeBot/1.0; +claudebot@anthropic.com)	2026-01-17 12:23:29	2026-01-17 12:23:29	\N
9	App\\Models\\PageSection	118	84.54.84.143	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2026-01-17 13:38:11	2026-01-17 13:38:11	\N
10	App\\Models\\PageSection	119	213.206.63.164	Mozilla/5.0 (iPhone; CPU iPhone OS 14_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0.3 Mobile/15E148 Safari/604.1	2026-01-19 05:49:05	2026-01-19 05:49:05	\N
11	App\\Models\\PageSection	117	213.206.63.164	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2026-01-19 09:03:33	2026-01-19 09:03:33	\N
12	App\\Models\\PageSection	118	213.206.63.164	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2026-01-19 10:40:49	2026-01-19 10:40:49	\N
23	App\\Models\\PageSection	33	195.158.2.216	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0	2026-01-19 12:42:01	2026-01-19 12:42:01	\N
24	App\\Models\\PageSection	117	195.158.2.216	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0	2026-01-19 12:42:01	2026-01-19 12:42:01	\N
25	App\\Models\\PageSection	118	195.158.2.216	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0	2026-01-19 12:42:03	2026-01-19 12:42:03	\N
26	App\\Models\\PageSection	118	213.206.63.164	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0	2026-01-19 12:42:10	2026-01-19 12:42:10	\N
27	App\\Models\\PageSection	119	74.7.241.59	Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; GPTBot/1.3; +https://openai.com/gptbot)	2026-01-20 10:32:25	2026-01-20 10:32:25	\N
28	App\\Models\\PageSection	118	74.7.241.59	Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; GPTBot/1.3; +https://openai.com/gptbot)	2026-01-20 10:32:26	2026-01-20 10:32:26	\N
29	App\\Models\\PageSection	117	74.7.241.59	Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; GPTBot/1.3; +https://openai.com/gptbot)	2026-01-20 10:32:31	2026-01-20 10:32:31	\N
30	App\\Models\\PageSection	33	74.7.241.59	Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; GPTBot/1.3; +https://openai.com/gptbot)	2026-01-20 10:35:32	2026-01-20 10:35:32	\N
31	App\\Models\\PageSection	117	213.206.63.164	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	2026-01-20 11:12:29	2026-01-20 11:12:29	\N
32	App\\Models\\PageSection	33	213.206.63.164	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2026-01-20 11:32:08	2026-01-20 11:32:08	\N
33	App\\Models\\PageSection	119	213.206.63.164	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2026-01-20 11:32:30	2026-01-20 11:32:30	\N
34	App\\Models\\PageSection	33	90.156.197.174	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2026-01-20 13:49:00	2026-01-20 13:49:00	\N
35	App\\Models\\PageSection	119	90.156.197.174	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2026-01-20 13:49:18	2026-01-20 13:49:18	\N
36	App\\Models\\PageSection	204	213.206.63.164	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	2026-01-21 07:53:14	2026-01-21 07:53:14	\N
37	App\\Models\\PageSection	204	213.206.63.164	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2026-01-21 10:43:54	2026-01-21 10:43:54	\N
38	App\\Models\\PageSection	33	213.206.63.164	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	2026-01-21 11:07:53	2026-01-21 11:07:53	\N
39	App\\Models\\PageSection	204	84.54.80.177	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2026-01-21 21:09:53	2026-01-21 21:09:53	\N
40	App\\Models\\PageSection	210	213.206.63.164	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0	2026-01-22 05:30:42	2026-01-22 05:30:42	\N
41	App\\Models\\PageSection	117	213.206.63.164	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0	2026-01-22 06:02:43	2026-01-22 06:02:43	\N
42	App\\Models\\PageSection	211	213.206.63.164	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0	2026-01-22 06:02:45	2026-01-22 06:02:45	\N
43	App\\Models\\PageSection	33	213.206.63.164	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0	2026-01-22 06:02:57	2026-01-22 06:02:57	\N
44	App\\Models\\PageSection	119	213.206.63.164	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0	2026-01-22 06:03:00	2026-01-22 06:03:00	\N
45	App\\Models\\PageSection	211	213.206.63.164	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	2026-01-22 06:15:30	2026-01-22 06:15:30	\N
46	App\\Models\\PageSection	118	213.206.63.164	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	2026-01-22 09:03:14	2026-01-22 09:03:14	\N
47	App\\Models\\PageSection	118	149.154.161.235	TelegramBot (like TwitterBot)	2026-01-22 09:17:56	2026-01-22 09:17:56	\N
48	App\\Models\\PageSection	211	149.154.161.236	TelegramBot (like TwitterBot)	2026-01-22 09:18:13	2026-01-22 09:18:13	\N
49	App\\Models\\PageSection	117	90.156.197.210	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	2026-01-22 12:11:08	2026-01-22 12:11:08	\N
50	App\\Models\\PageSection	211	213.206.63.164	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2026-01-22 13:27:44	2026-01-22 13:27:44	\N
51	App\\Models\\PageSection	211	195.158.2.216	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	2026-01-22 14:54:45	2026-01-22 14:54:45	\N
52	App\\Models\\PageSection	214	213.206.63.164	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	2026-01-22 15:09:35	2026-01-22 15:09:35	\N
53	App\\Models\\PageSection	214	195.158.2.216	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	2026-01-22 15:15:22	2026-01-22 15:15:22	\N
54	App\\Models\\PageSection	118	195.158.2.216	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	2026-01-22 15:18:58	2026-01-22 15:18:58	\N
55	App\\Models\\PageSection	119	195.158.2.216	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	2026-01-22 15:19:05	2026-01-22 15:19:05	\N
56	App\\Models\\PageSection	211	149.154.161.213	TelegramBot (like TwitterBot)	2026-01-22 15:19:19	2026-01-22 15:19:19	\N
57	App\\Models\\PageSection	214	213.230.72.155	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	2026-01-22 16:57:02	2026-01-22 16:57:02	\N
58	App\\Models\\PageSection	214	84.54.92.157	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2026-01-23 11:21:24	2026-01-23 11:21:24	\N
59	App\\Models\\PageSection	119	84.54.92.157	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2026-01-23 11:52:13	2026-01-23 11:52:13	\N
60	App\\Models\\PageSection	118	84.54.92.157	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2026-01-23 11:52:16	2026-01-23 11:52:16	\N
61	App\\Models\\PageSection	33	84.54.92.157	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2026-01-23 11:52:19	2026-01-23 11:52:19	\N
62	App\\Models\\PageSection	117	84.54.92.157	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2026-01-23 11:52:25	2026-01-23 11:52:25	\N
63	App\\Models\\PageSection	211	84.54.92.157	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2026-01-23 11:52:32	2026-01-23 11:52:32	\N
64	App\\Models\\PageSection	211	149.154.161.202	TelegramBot (like TwitterBot)	2026-01-23 11:53:13	2026-01-23 11:53:13	\N
65	App\\Models\\PageSection	211	84.54.92.157	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	2026-01-23 11:55:07	2026-01-23 11:55:07	\N
66	App\\Models\\PageSection	211	149.154.161.217	TelegramBot (like TwitterBot)	2026-01-23 12:02:12	2026-01-23 12:02:12	\N
67	App\\Models\\PageSection	211	149.154.161.246	TelegramBot (like TwitterBot)	2026-01-23 12:02:14	2026-01-23 12:02:14	\N
68	App\\Models\\PageSection	211	149.154.161.203	TelegramBot (like TwitterBot)	2026-01-23 12:02:20	2026-01-23 12:02:20	\N
69	App\\Models\\PageSection	214	84.54.92.157	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	2026-01-24 11:50:01	2026-01-24 11:50:01	\N
70	App\\Models\\PageSection	33	84.54.92.157	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	2026-01-24 12:02:19	2026-01-24 12:02:19	\N
71	App\\Models\\PageSection	211	74.7.242.50	Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; GPTBot/1.3; +https://openai.com/gptbot)	2026-01-27 00:58:51	2026-01-27 00:58:51	\N
72	App\\Models\\PageSection	214	74.7.242.50	Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; GPTBot/1.3; +https://openai.com/gptbot)	2026-01-27 00:59:18	2026-01-27 00:59:18	\N
73	App\\Models\\PageSection	214	84.54.94.131	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	2026-01-27 09:05:53	2026-01-27 09:05:53	2026-01-22 13:44:13
74	App\\Models\\PageSection	214	157.245.217.212	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36	2026-02-02 10:14:01	2026-02-02 10:14:01	2026-01-22 13:44:13
\.


--
-- Name: content_images_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vatandoshlar_usr
--

SELECT pg_catalog.setval('public.content_images_id_seq', 3, true);


--
-- Name: content_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vatandoshlar_usr
--

SELECT pg_catalog.setval('public.content_settings_id_seq', 1, false);


--
-- Name: content_translations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vatandoshlar_usr
--

SELECT pg_catalog.setval('public.content_translations_id_seq', 1, false);


--
-- Name: contents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vatandoshlar_usr
--

SELECT pg_catalog.setval('public.contents_id_seq', 1, false);


--
-- Name: countries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vatandoshlar_usr
--

SELECT pg_catalog.setval('public.countries_id_seq', 1, false);


--
-- Name: failed_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vatandoshlar_usr
--

SELECT pg_catalog.setval('public.failed_jobs_id_seq', 1, false);


--
-- Name: form_images_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vatandoshlar_usr
--

SELECT pg_catalog.setval('public.form_images_id_seq', 4, true);


--
-- Name: jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vatandoshlar_usr
--

SELECT pg_catalog.setval('public.jobs_id_seq', 1, false);


--
-- Name: lang_images_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vatandoshlar_usr
--

SELECT pg_catalog.setval('public.lang_images_id_seq', 10, true);


--
-- Name: langs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vatandoshlar_usr
--

SELECT pg_catalog.setval('public.langs_id_seq', 1, false);


--
-- Name: menu_main_images_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vatandoshlar_usr
--

SELECT pg_catalog.setval('public.menu_main_images_id_seq', 1, false);


--
-- Name: menu_main_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vatandoshlar_usr
--

SELECT pg_catalog.setval('public.menu_main_settings_id_seq', 1, false);


--
-- Name: menu_main_translations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vatandoshlar_usr
--

SELECT pg_catalog.setval('public.menu_main_translations_id_seq', 1, false);


--
-- Name: menu_mains_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vatandoshlar_usr
--

SELECT pg_catalog.setval('public.menu_mains_id_seq', 1, false);


--
-- Name: menus_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vatandoshlar_usr
--

SELECT pg_catalog.setval('public.menus_id_seq', 1, false);


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vatandoshlar_usr
--

SELECT pg_catalog.setval('public.migrations_id_seq', 1, false);


--
-- Name: order_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vatandoshlar_usr
--

SELECT pg_catalog.setval('public.order_settings_id_seq', 1, false);


--
-- Name: page_section_images_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vatandoshlar_usr
--

SELECT pg_catalog.setval('public.page_section_images_id_seq', 14, true);


--
-- Name: page_section_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vatandoshlar_usr
--

SELECT pg_catalog.setval('public.page_section_settings_id_seq', 1, false);


--
-- Name: page_section_translations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vatandoshlar_usr
--

SELECT pg_catalog.setval('public.page_section_translations_id_seq', 1, false);


--
-- Name: page_sections_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vatandoshlar_usr
--

SELECT pg_catalog.setval('public.page_sections_id_seq', 2, true);


--
-- Name: permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vatandoshlar_usr
--

SELECT pg_catalog.setval('public.permissions_id_seq', 1, false);


--
-- Name: role_menu_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vatandoshlar_usr
--

SELECT pg_catalog.setval('public.role_menu_permissions_id_seq', 17, true);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vatandoshlar_usr
--

SELECT pg_catalog.setval('public.roles_id_seq', 1, false);


--
-- Name: setting_images_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vatandoshlar_usr
--

SELECT pg_catalog.setval('public.setting_images_id_seq', 1, false);


--
-- Name: settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vatandoshlar_usr
--

SELECT pg_catalog.setval('public.settings_id_seq', 1, false);


--
-- Name: socials_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vatandoshlar_usr
--

SELECT pg_catalog.setval('public.socials_id_seq', 4, true);


--
-- Name: supports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vatandoshlar_usr
--

SELECT pg_catalog.setval('public.supports_id_seq', 13, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vatandoshlar_usr
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: view_counts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vatandoshlar_usr
--

SELECT pg_catalog.setval('public.view_counts_id_seq', 26, true);


--
-- Name: cache_locks cache_locks_pkey; Type: CONSTRAINT; Schema: public; Owner: vatandoshlar_usr
--

ALTER TABLE ONLY public.cache_locks
    ADD CONSTRAINT cache_locks_pkey PRIMARY KEY (key);


--
-- Name: cache cache_pkey; Type: CONSTRAINT; Schema: public; Owner: vatandoshlar_usr
--

ALTER TABLE ONLY public.cache
    ADD CONSTRAINT cache_pkey PRIMARY KEY (key);


--
-- Name: content_images content_images_pkey; Type: CONSTRAINT; Schema: public; Owner: vatandoshlar_usr
--

ALTER TABLE ONLY public.content_images
    ADD CONSTRAINT content_images_pkey PRIMARY KEY (id);


--
-- Name: content_settings content_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: vatandoshlar_usr
--

ALTER TABLE ONLY public.content_settings
    ADD CONSTRAINT content_settings_pkey PRIMARY KEY (id);


--
-- Name: content_translations content_translations_pkey; Type: CONSTRAINT; Schema: public; Owner: vatandoshlar_usr
--

ALTER TABLE ONLY public.content_translations
    ADD CONSTRAINT content_translations_pkey PRIMARY KEY (id);


--
-- Name: contents contents_pkey; Type: CONSTRAINT; Schema: public; Owner: vatandoshlar_usr
--

ALTER TABLE ONLY public.contents
    ADD CONSTRAINT contents_pkey PRIMARY KEY (id);


--
-- Name: countries countries_pkey; Type: CONSTRAINT; Schema: public; Owner: vatandoshlar_usr
--

ALTER TABLE ONLY public.countries
    ADD CONSTRAINT countries_pkey PRIMARY KEY (id);


--
-- Name: failed_jobs failed_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: vatandoshlar_usr
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_pkey PRIMARY KEY (id);


--
-- Name: form_images form_images_pkey; Type: CONSTRAINT; Schema: public; Owner: vatandoshlar_usr
--

ALTER TABLE ONLY public.form_images
    ADD CONSTRAINT form_images_pkey PRIMARY KEY (id);


--
-- Name: job_batches job_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: vatandoshlar_usr
--

ALTER TABLE ONLY public.job_batches
    ADD CONSTRAINT job_batches_pkey PRIMARY KEY (id);


--
-- Name: jobs jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: vatandoshlar_usr
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_pkey PRIMARY KEY (id);


--
-- Name: lang_images lang_images_pkey; Type: CONSTRAINT; Schema: public; Owner: vatandoshlar_usr
--

ALTER TABLE ONLY public.lang_images
    ADD CONSTRAINT lang_images_pkey PRIMARY KEY (id);


--
-- Name: langs langs_pkey; Type: CONSTRAINT; Schema: public; Owner: vatandoshlar_usr
--

ALTER TABLE ONLY public.langs
    ADD CONSTRAINT langs_pkey PRIMARY KEY (id);


--
-- Name: menu_main_images menu_main_images_pkey; Type: CONSTRAINT; Schema: public; Owner: vatandoshlar_usr
--

ALTER TABLE ONLY public.menu_main_images
    ADD CONSTRAINT menu_main_images_pkey PRIMARY KEY (id);


--
-- Name: menu_main_settings menu_main_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: vatandoshlar_usr
--

ALTER TABLE ONLY public.menu_main_settings
    ADD CONSTRAINT menu_main_settings_pkey PRIMARY KEY (id);


--
-- Name: menu_main_translations menu_main_translations_pkey; Type: CONSTRAINT; Schema: public; Owner: vatandoshlar_usr
--

ALTER TABLE ONLY public.menu_main_translations
    ADD CONSTRAINT menu_main_translations_pkey PRIMARY KEY (id);


--
-- Name: menu_mains menu_mains_pkey; Type: CONSTRAINT; Schema: public; Owner: vatandoshlar_usr
--

ALTER TABLE ONLY public.menu_mains
    ADD CONSTRAINT menu_mains_pkey PRIMARY KEY (id);


--
-- Name: menus menus_pkey; Type: CONSTRAINT; Schema: public; Owner: vatandoshlar_usr
--

ALTER TABLE ONLY public.menus
    ADD CONSTRAINT menus_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: vatandoshlar_usr
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: order_settings order_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: vatandoshlar_usr
--

ALTER TABLE ONLY public.order_settings
    ADD CONSTRAINT order_settings_pkey PRIMARY KEY (id);


--
-- Name: page_section_images page_section_images_pkey; Type: CONSTRAINT; Schema: public; Owner: vatandoshlar_usr
--

ALTER TABLE ONLY public.page_section_images
    ADD CONSTRAINT page_section_images_pkey PRIMARY KEY (id);


--
-- Name: page_section_settings page_section_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: vatandoshlar_usr
--

ALTER TABLE ONLY public.page_section_settings
    ADD CONSTRAINT page_section_settings_pkey PRIMARY KEY (id);


--
-- Name: page_section_translations page_section_translations_pkey; Type: CONSTRAINT; Schema: public; Owner: vatandoshlar_usr
--

ALTER TABLE ONLY public.page_section_translations
    ADD CONSTRAINT page_section_translations_pkey PRIMARY KEY (id);


--
-- Name: page_sections page_sections_pkey; Type: CONSTRAINT; Schema: public; Owner: vatandoshlar_usr
--

ALTER TABLE ONLY public.page_sections
    ADD CONSTRAINT page_sections_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: vatandoshlar_usr
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (email);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: vatandoshlar_usr
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: role_menu_permissions role_menu_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: vatandoshlar_usr
--

ALTER TABLE ONLY public.role_menu_permissions
    ADD CONSTRAINT role_menu_permissions_pkey PRIMARY KEY (id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: vatandoshlar_usr
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: vatandoshlar_usr
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: setting_images setting_images_pkey; Type: CONSTRAINT; Schema: public; Owner: vatandoshlar_usr
--

ALTER TABLE ONLY public.setting_images
    ADD CONSTRAINT setting_images_pkey PRIMARY KEY (id);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: vatandoshlar_usr
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (id);


--
-- Name: socials socials_pkey; Type: CONSTRAINT; Schema: public; Owner: vatandoshlar_usr
--

ALTER TABLE ONLY public.socials
    ADD CONSTRAINT socials_pkey PRIMARY KEY (id);


--
-- Name: supports supports_pkey; Type: CONSTRAINT; Schema: public; Owner: vatandoshlar_usr
--

ALTER TABLE ONLY public.supports
    ADD CONSTRAINT supports_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: vatandoshlar_usr
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: view_counts view_counts_pkey; Type: CONSTRAINT; Schema: public; Owner: vatandoshlar_usr
--

ALTER TABLE ONLY public.view_counts
    ADD CONSTRAINT view_counts_pkey PRIMARY KEY (id);


--
-- Name: content_images_main_index; Type: INDEX; Schema: public; Owner: vatandoshlar_usr
--

CREATE INDEX content_images_main_index ON public.content_images USING btree (main);


--
-- Name: content_settings_key_is_translatable_status_sort_order_index; Type: INDEX; Schema: public; Owner: vatandoshlar_usr
--

CREATE INDEX content_settings_key_is_translatable_status_sort_order_index ON public.content_settings USING btree (key, is_translatable, status, sort_order);


--
-- Name: content_translations_locale_index; Type: INDEX; Schema: public; Owner: vatandoshlar_usr
--

CREATE INDEX content_translations_locale_index ON public.content_translations USING btree (locale);


--
-- Name: contents_type_slug_status_sort_order_index; Type: INDEX; Schema: public; Owner: vatandoshlar_usr
--

CREATE INDEX contents_type_slug_status_sort_order_index ON public.contents USING btree (type, slug, status, sort_order);


--
-- Name: failed_jobs_uuid_unique; Type: INDEX; Schema: public; Owner: vatandoshlar_usr
--

CREATE UNIQUE INDEX failed_jobs_uuid_unique ON public.failed_jobs USING btree (uuid);


--
-- Name: jobs_queue_index; Type: INDEX; Schema: public; Owner: vatandoshlar_usr
--

CREATE INDEX jobs_queue_index ON public.jobs USING btree (queue);


--
-- Name: lang_images_main_index; Type: INDEX; Schema: public; Owner: vatandoshlar_usr
--

CREATE INDEX lang_images_main_index ON public.lang_images USING btree (main);


--
-- Name: langs_code_unique; Type: INDEX; Schema: public; Owner: vatandoshlar_usr
--

CREATE UNIQUE INDEX langs_code_unique ON public.langs USING btree (code);


--
-- Name: menu_main_images_main_index; Type: INDEX; Schema: public; Owner: vatandoshlar_usr
--

CREATE INDEX menu_main_images_main_index ON public.menu_main_images USING btree (main);


--
-- Name: menu_main_settings_key_is_translatable_status_sort_order_index; Type: INDEX; Schema: public; Owner: vatandoshlar_usr
--

CREATE INDEX menu_main_settings_key_is_translatable_status_sort_order_index ON public.menu_main_settings USING btree (key, is_translatable, status, sort_order);


--
-- Name: menu_main_translations_locale_index; Type: INDEX; Schema: public; Owner: vatandoshlar_usr
--

CREATE INDEX menu_main_translations_locale_index ON public.menu_main_translations USING btree (locale);


--
-- Name: menu_mains_type_slug_status_sort_order_index; Type: INDEX; Schema: public; Owner: vatandoshlar_usr
--

CREATE INDEX menu_mains_type_slug_status_sort_order_index ON public.menu_mains USING btree (type, slug, status, sort_order);


--
-- Name: page_section_images_main_status_category_category_slug_page_sec; Type: INDEX; Schema: public; Owner: vatandoshlar_usr
--

CREATE INDEX page_section_images_main_status_category_category_slug_page_sec ON public.page_section_images USING btree (main, status, category, category_slug, page_section_parent_id, page_section_id);


--
-- Name: page_section_settings_key_is_translatable_status_sort_order_cat; Type: INDEX; Schema: public; Owner: vatandoshlar_usr
--

CREATE INDEX page_section_settings_key_is_translatable_status_sort_order_cat ON public.page_section_settings USING btree (key, is_translatable, status, sort_order, category, category_slug);


--
-- Name: page_section_translations_locale_category_page_section_id_page_; Type: INDEX; Schema: public; Owner: vatandoshlar_usr
--

CREATE INDEX page_section_translations_locale_category_page_section_id_page_ ON public.page_section_translations USING btree (locale, category, page_section_id, page_section_parent_id, category_slug);


--
-- Name: page_sections_status_sort_order_menu_main_id_category_category_; Type: INDEX; Schema: public; Owner: vatandoshlar_usr
--

CREATE INDEX page_sections_status_sort_order_menu_main_id_category_category_ ON public.page_sections USING btree (status, sort_order, menu_main_id, category, category_slug, parent_id);


--
-- Name: role_menu_permissions_role_id_menu_main_id_permission_id_index; Type: INDEX; Schema: public; Owner: vatandoshlar_usr
--

CREATE INDEX role_menu_permissions_role_id_menu_main_id_permission_id_index ON public.role_menu_permissions USING btree (role_id, menu_main_id, permission_id);


--
-- Name: sessions_last_activity_index; Type: INDEX; Schema: public; Owner: vatandoshlar_usr
--

CREATE INDEX sessions_last_activity_index ON public.sessions USING btree (last_activity);


--
-- Name: sessions_user_id_index; Type: INDEX; Schema: public; Owner: vatandoshlar_usr
--

CREATE INDEX sessions_user_id_index ON public.sessions USING btree (user_id);


--
-- Name: setting_images_main_index; Type: INDEX; Schema: public; Owner: vatandoshlar_usr
--

CREATE INDEX setting_images_main_index ON public.setting_images USING btree (main);


--
-- Name: users_username_unique; Type: INDEX; Schema: public; Owner: vatandoshlar_usr
--

CREATE UNIQUE INDEX users_username_unique ON public.users USING btree (username);


--
-- Name: view_counts_viewable_type_viewable_id_index; Type: INDEX; Schema: public; Owner: vatandoshlar_usr
--

CREATE INDEX view_counts_viewable_type_viewable_id_index ON public.view_counts USING btree (viewable_type, viewable_id);


--
-- Name: content_images content_images_content_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: vatandoshlar_usr
--

ALTER TABLE ONLY public.content_images
    ADD CONSTRAINT content_images_content_id_foreign FOREIGN KEY (content_id) REFERENCES public.contents(id);


--
-- Name: content_translations content_translations_content_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: vatandoshlar_usr
--

ALTER TABLE ONLY public.content_translations
    ADD CONSTRAINT content_translations_content_id_foreign FOREIGN KEY (content_id) REFERENCES public.contents(id) ON DELETE CASCADE;


--
-- Name: contents contents_parent_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: vatandoshlar_usr
--

ALTER TABLE ONLY public.contents
    ADD CONSTRAINT contents_parent_id_foreign FOREIGN KEY (parent_id) REFERENCES public.contents(id);


--
-- Name: menu_main_images menu_main_images_menu_main_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: vatandoshlar_usr
--

ALTER TABLE ONLY public.menu_main_images
    ADD CONSTRAINT menu_main_images_menu_main_id_foreign FOREIGN KEY (menu_main_id) REFERENCES public.menu_mains(id);


--
-- Name: menu_main_translations menu_main_translations_menu_main_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: vatandoshlar_usr
--

ALTER TABLE ONLY public.menu_main_translations
    ADD CONSTRAINT menu_main_translations_menu_main_id_foreign FOREIGN KEY (menu_main_id) REFERENCES public.menu_mains(id) ON DELETE CASCADE;


--
-- Name: menu_mains menu_mains_parent_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: vatandoshlar_usr
--

ALTER TABLE ONLY public.menu_mains
    ADD CONSTRAINT menu_mains_parent_id_foreign FOREIGN KEY (parent_id) REFERENCES public.menu_mains(id);


--
-- Name: role_menu_permissions role_menu_permissions_menu_main_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: vatandoshlar_usr
--

ALTER TABLE ONLY public.role_menu_permissions
    ADD CONSTRAINT role_menu_permissions_menu_main_id_foreign FOREIGN KEY (menu_main_id) REFERENCES public.menu_mains(id) ON DELETE CASCADE;


--
-- Name: role_menu_permissions role_menu_permissions_permission_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: vatandoshlar_usr
--

ALTER TABLE ONLY public.role_menu_permissions
    ADD CONSTRAINT role_menu_permissions_permission_id_foreign FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- Name: role_menu_permissions role_menu_permissions_role_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: vatandoshlar_usr
--

ALTER TABLE ONLY public.role_menu_permissions
    ADD CONSTRAINT role_menu_permissions_role_id_foreign FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: setting_images setting_images_setting_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: vatandoshlar_usr
--

ALTER TABLE ONLY public.setting_images
    ADD CONSTRAINT setting_images_setting_id_foreign FOREIGN KEY (setting_id) REFERENCES public.settings(id);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO vatandoshlar_7z7_db_grp;


--
-- PostgreSQL database dump complete
--

