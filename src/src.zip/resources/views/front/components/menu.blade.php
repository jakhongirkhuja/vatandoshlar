<ul class="header__menu">
    @include('front.components.menu-items', ['menus' => $headerMenu])
</ul>