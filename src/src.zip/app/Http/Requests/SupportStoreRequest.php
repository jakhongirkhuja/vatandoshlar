<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class SupportStoreRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'type' => 'required|string|in:form,application,participation',
            'data' => 'required|array',
            'data.name' => 'required|string',
            'data.phone' => 'required',
            'data.email' => 'required|email',
            'data.description' => 'required|string',
        ];
    }
}
